<?php
/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('panel_ingenieria.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!isset($_SESSION['rol_activo'])) {
    header("Location: ingreso.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Ingeniería - ARCA</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #f4f6f9; margin: 0; }
        .header { background-color: #34495e; padding: 20px 40px; color: white; display: flex; justify-content: space-between; align-items: center; border-bottom: 4px solid #f39c12; text-align: center; }
        .header h1 { margin: 0; font-size: 26px; }
        .logout-btn { background-color: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; }
        .container { display: flex; justify-content: center; gap: 30px; padding: 40px; }
        .card { background: white; padding: 30px; border-radius: 10px; width: 350px; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 4px solid #f39c12; }
        .btn-action { display: block; padding: 12px; border-radius: 5px; text-decoration: none; font-weight: bold; color: white; margin-top: 15px; }
        .btn-inventario { background-color: #34495e; }
        .btn-alta { background-color: #27ae60; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <div>
            <h1>Módulo de Ingeniería, Obras y Tecnología</h1>
            <p style="margin: 5px 0 0 0; color: #bdc3c7;">Técnico en turno: <b><?php echo $_SESSION['usuario_activo']; ?></b> | Cargo: <b><?php echo $_SESSION['rol_activo']; ?></b></p>
        </div>
        <a href="cerrar_sesion.php" class="logout-btn">Cerrar Sesión</a>
    </div>

    <div class="container">
        <div class="card">
            <h3>Control de Almacén (Compras)</h3>
            <p>Gestión de entradas y salidas de materiales de construcción y maquinaria pesada.</p>
            <a href="panel_oficina_almacen.php?vista=movimientos" class="btn-action btn-inventario">Auditar Inventario</a>
            <a href="panel_oficina_almacen.php?vista=materiales" class="btn-action btn-alta">Dar de Alta Material</a>
        </div>
        
        <div class="card">
            <h3>Planos, Proyectos y BIM</h3>
            <p>Visualización de maquetas, IA aplicada, uso de drones y asignación de obras operativas.</p>
            <a href="arca_obra_360.php" class="btn-action btn-inventario">Ver Obras Activas</a>
        </div>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>