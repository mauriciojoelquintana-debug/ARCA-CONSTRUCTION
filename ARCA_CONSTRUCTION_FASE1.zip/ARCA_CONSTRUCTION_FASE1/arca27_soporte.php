<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca27.php';$db=a27_boot(['CEO','Director General','CIO']);
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 a27_post();if(arx_role()!=='CIO')a27_die('Solo Sistemas administra tickets.');
 try{
  $id=arx_int($_POST['id_ticket']??null);$estado=(string)($_POST['estado']??'');
  if(!in_array($estado,['Abierto','En Revisión','Resuelto'],true))throw new InvalidArgumentException('Estado incorrecto.');
  $db->begin_transaction();try{$old=arx_one($db,'SELECT id_ticket,estado FROM soporte_tickets WHERE id_ticket=? FOR UPDATE',[$id]);if(!$old)throw new InvalidArgumentException('Ticket no encontrado.');arx_exec($db,'UPDATE soporte_tickets SET estado=? WHERE id_ticket=?',[$estado,$id]);arx_audit($db,'sistemas','ticket',$id,'CAMBIAR_ESTADO',['estado'=>$old['estado']],['estado'=>$estado]);$db->commit();}catch(Throwable $e){$db->rollback();throw $e;}
  a27_alert('Estado del ticket actualizado.');
 }catch(Throwable $e){a27_alert('No se pudo actualizar el ticket.',true);error_log('[ARCA27_SOPORTE] '.$e->getMessage());}
 a27_redirect('arca27_soporte.php');
}
$rows=arx_rows($db,'SELECT id_ticket,numero_empleado,descripcion_falla,estado,fecha_reporte FROM soporte_tickets ORDER BY fecha_reporte DESC,id_ticket DESC LIMIT 150');
a27_layout('Mesa de soporte · Help Desk','Tickets reales desde soporte_tickets; cambios auditados y controlados por CIO.','arca27_soporte.php');
?><section class="a27-grid"><article class="a27-card"><div class="a27-sub">Tickets consultados</div><div class="a27-metric"><?=count($rows)?></div></article><article class="a27-card"><div class="a27-sub">Abiertos (en la muestra)</div><div class="a27-metric"><?=count(array_filter($rows,fn($r)=>$r['estado']==='Abierto'))?></div></article></section><section class="a27-card"><h2>Bandeja de incidencias</h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Folio</th><th>Empleado</th><th>Descripción</th><th>Fecha</th><th>Estado y gestión</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td>#<?=(int)$r['id_ticket']?></td><td><?=a27_h($r['numero_empleado'])?></td><td><?=a27_h($r['descripcion_falla'])?></td><td><?=a27_h($r['fecha_reporte'])?></td><td><?php if(arx_role()==='CIO'):?><form method="post" class="a27-actions"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="id_ticket" value="<?=(int)$r['id_ticket']?>"><select name="estado" aria-label="Estado del ticket"><?php a27_opt(['Abierto'=>'Abierto','En Revisión'=>'En revisión','Resuelto'=>'Resuelto'],(string)$r['estado']);?></select><button>Guardar</button></form><?php else:?><?=a27_h($r['estado'])?><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></section><?php a27_end();
