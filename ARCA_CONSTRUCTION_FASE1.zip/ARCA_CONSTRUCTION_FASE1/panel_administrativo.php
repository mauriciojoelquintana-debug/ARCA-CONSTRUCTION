<?php
session_start();
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';

$roles_admin = ['Secretaria', 'Secretaria / Asistente', 'CEO', 'CIO', 'COO', 'Director General', 'Ejecutivo', 'CHRO', 'Director de RR.HH.', 'Departamento RRHH'];
if (!in_array($rol_limpio, $roles_admin)) {
    header("Location: ingreso.html");
    exit(); 
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Administrativo - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9ebf2; margin: 0; padding: 20px; }
        .header { background-color: #8e44ad; color: white; padding: 15px; text-align: center; border-radius: 5px; }
        .dashboard-container { display: flex; justify-content: space-around; margin-top: 30px; flex-wrap: wrap; gap: 20px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 22%; min-width: 250px; text-align: center; border-top: 4px solid #9b59b6; }
        .logout-btn { background-color: #e74c3c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; float: right; margin-top: -40px; font-weight: bold; }
        .logout-btn:hover { background-color: #c0392b; }
        button { background-color: #8e44ad; color: white; border: none; padding: 12px 20px; border-radius: 5px; cursor: pointer; width: 90%; font-weight: bold; font-size: 14px; }
        button:hover { background-color: #732d91; }
        .btn-baja { background-color: #e74c3c; margin-top: 10px; }
        .btn-baja:hover { background-color: #c0392b; }
        .btn-actualizar { background-color: #3498db; margin-top: 10px; }
        .btn-actualizar:hover { background-color: #2980b9; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">
    <div class="header">
        <h1>Bienvenid@, <?php echo $_SESSION['usuario_activo']; ?></h1>
        <p>Nivel de Acceso: <b>Administrativo / Dirección</b> | Cargo: <b><?php echo $_SESSION['rol_activo']; ?></b></p>
        <a href="cerrar_sesion.php" class="logout-btn">Cerrar Sesión</a>
    </div>
    <h2 style="text-align: center; margin-top: 20px; color: #2c3e50;">Gestión de Citas, Documentos y RRHH</h2>
    <div class="dashboard-container">
        <div class="card">
            <h3>Agenda de Citas</h3>
            <p>Programa reuniones para la Junta Directiva y proveedores.</p>
            <a href="formulario_agenda.php"><button>Ver Agenda</button></a>
        </div>
        <div class="card">
            <h3>Contratos Base</h3>
            <p>Visualización general de contratos vigentes.</p>
            <button>Revisar Contratos</button>
        </div>
        <div class="card">
            <h3>Organización</h3>
            <p>Gestión de expedientes y archivo general.</p>
            <button>Ir al Archivo</button>
        </div>
        <div class="card">
            <h3>Recursos Humanos</h3>
            <p>Gestión de credenciales y administración de personal.</p>
            <a href="formulario_alta_empleado.php"><button>Dar de Alta Empleado</button></a>
            <a href="baja.html"><button class="btn-baja">Dar de Baja Empleado</button></a>
            <a href="actualiza.html"><button class="btn-actualizar">Actualizar Empleado</button></a>
        </div>
    </div>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>