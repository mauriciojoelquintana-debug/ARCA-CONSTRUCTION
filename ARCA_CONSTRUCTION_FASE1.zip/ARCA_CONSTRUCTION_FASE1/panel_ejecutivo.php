<?php
/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('panel_ejecutivo.php');

// 1. Reanudamos la sesión segura
if(session_status() !== PHP_SESSION_ACTIVE) session_start();

// Quitamos temporalmente la regeneración de token para evitar conflictos con el servidor local Laragon

// 2. CIBERSEGURIDAD: Bloqueo de URL por Roles (Ajustado)
// Usamos trim() para limpiar cualquier espacio invisible que venga de la base de datos
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';

if ($rol_limpio != 'Ejecutivo' && $rol_limpio != 'Director General / CEO') {
    // Quitamos el rebote silencioso y ponemos un freno visible para diagnosticar el problema
    die("<div style='text-align:center; margin-top:50px; font-family:Arial;'>
            <h2 style='color:#e74c3c;'>Acceso Denegado por el Panel Ejecutivo</h2>
            <p>El sistema detectó tu rol como: <b>'" . ($rol_limpio ? $rol_limpio : 'Vacío / Sesión Perdida') . "'</b></p>
            <p>Este panel es exclusivo para Ejecutivos.</p>
            <a href='login.html' style='color:#2980b9;'>Volver al portal</a>
         </div>");
}

// 3. Incluimos la conexión a la base de datos
include("conexion.php");

// 4. INTELIGENCIA DE NEGOCIO (Alta Seguridad SQL)
$stmt_finanzas = $conectar->prepare("SELECT SUM(presupuesto) as total_dinero, COUNT(id_proyecto) as total_obras FROM proyectos");
$stmt_finanzas->execute();
$resultado_finanzas = $stmt_finanzas->get_result();
$datos_finanzas = $resultado_finanzas->fetch_assoc();

// Validamos que no vengan nulos si no hay obras
$total_dinero = $datos_finanzas['total_dinero'] ? $datos_finanzas['total_dinero'] : 0;
$total_obras = $datos_finanzas['total_obras'] ? $datos_finanzas['total_obras'] : 0;
$stmt_finanzas->close(); 

$stmt_inventario = $conectar->prepare("SELECT SUM(cantidad) as total_materiales FROM inventario");
$stmt_inventario->execute();
$resultado_inventario = $stmt_inventario->get_result();
$datos_inventario = $resultado_inventario->fetch_assoc();

$total_materiales = $datos_inventario['total_materiales'] ? $datos_inventario['total_materiales'] : 0;
$stmt_inventario->close(); 
$conectar->close(); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Ejecutivo - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 20px; }
        .header { background-color: #2c3e50; color: white; padding: 15px; text-align: center; border-radius: 5px; border-bottom: 4px solid #e74c3c; }
        .dashboard-container { display: flex; justify-content: space-around; margin-top: 30px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 30%; text-align: center; border-top: 4px solid #2980b9; }
        .logout-btn { background-color: #e74c3c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; float: right; margin-top: -40px; }
        .cifra { font-size: 26px; color: #27ae60; font-weight: bold; margin: 15px 0; }
        .badge-seguridad { display: inline-block; background-color: #27ae60; color: white; padding: 5px 10px; border-radius: 15px; font-size: 12px; margin-top: 10px; }
        button { background-color: #2c3e50; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin-top: 10px; }
        button:hover { background-color: #1a252f; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <h1>Bienvenido, <?php echo $_SESSION['usuario_activo']; ?></h1>
        <p>Nivel de Acceso: <b><?php echo $_SESSION['rol_activo']; ?></b></p>
        <span class="badge-seguridad">Conexión Cifrada y Segura</span>
        <a href="cerrar_sesion.php" class="logout-btn">Cerrar Sesión</a>
    </div>

    <h2 style="text-align: center; margin-top: 20px;">Dashboard Financiero y Operativo</h2>

    <div class="dashboard-container">
        <!-- Tarjeta 1: Control Financiero Real -->
        <div class="card">
            <h3>Control Financiero</h3>
            <p>Presupuesto corporativo activo abarcando <b><?php echo $total_obras; ?></b> proyectos.</p>
            <div class="cifra">$<?php echo number_format($total_dinero, 2); ?> MXN</div>
            <a href="desglose_federal.php" style="display:inline-block; background-color: #2c3e50; color: white; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin-top: 10px; text-decoration:none;">Ver Desglose Federal</a>
        </div>

        <!-- Tarjeta 2: Auditoría de Inventarios -->
        <div class="card">
            <h3>Inventario Global</h3>
            <p>Volumen total de recursos e insumos físicos circulando en las obras.</p>
            <div class="cifra" style="color: #f39c12;"><?php echo number_format($total_materiales); ?> unidades</div>
            <button>Auditar Almacenes</button>
        </div>

        <!-- Tarjeta 3: Gestión Legal -->
        <div class="card">
            <h3>Administración y Legal</h3>
            <p>Minutas de Juntas Directivas y contratos vigentes de obras gubernamentales.</p>
            <div class="cifra" style="color: #8e44ad;">Activo y Protegido</div>
            <button>Ver Contratos</button>
        </div>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>