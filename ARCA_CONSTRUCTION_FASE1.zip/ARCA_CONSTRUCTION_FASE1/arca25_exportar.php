<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca25_informes.php';
$db=a26_db();
try {
    $f=a25_filtros($_GET,arx_role());
    $fmt=(string)($_GET['formato']??'');if(!in_array($fmt,['pdf','xlsx'],true))throw new InvalidArgumentException('Formato desconocido.');
    $codes=a26_codes($db,$f['obra']);
    $rows=a25_data($db,$f,$codes);
    [$title,$headers,$numeric]=a25_catalog()[$f['tipo']];
    $title='ARCA | '.$title.' | '.a25_summary($f,count($rows));
    $name='ARCA_'.$f['tipo'].'_'.date('Ymd_His').'.'.$fmt;
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, max-age=0');
    if($fmt==='pdf'){$bytes=ax_pdf($title,$headers,$rows);header('Content-Disposition: attachment; filename="'.$name.'"');header('Content-Type: application/pdf');header('Content-Length: '.strlen($bytes));echo $bytes;}
    else{$temp=ax_xlsx($title,$headers,$rows,$numeric);header('Content-Disposition: attachment; filename="'.$name.'"');header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Length: '.filesize($temp));readfile($temp);@unlink($temp);}
}catch(InvalidArgumentException $e){http_response_code(422);header('Content-Type: text/plain; charset=UTF-8');echo $e->getMessage();}
catch(Throwable $e){error_log('ARCA25: '.$e->getMessage());http_response_code(500);header('Content-Type: text/plain; charset=UTF-8');echo 'No fue posible generar el documento. Revisa el log PHP.';}
