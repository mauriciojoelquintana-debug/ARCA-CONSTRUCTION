<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_fases_8_13.php';$db=arx_boot(['COO']);arx_check_post();$action=(string)($_POST['accion']??'');
// Fase 14: recepción documental heredada deshabilitada. Registrar entrada física vía flujo integrado atómico.
if ($action==='recibir') { arx_flash('Para recibir una orden y actualizar el almacén en un solo paso utiliza Recepciones integradas.',true); arx_redirect('arca_recepcion.php'); }
try{
 $db->begin_transaction();
 if($action==='proveedor'){
  $id=strtoupper(arx_text($_POST['identificador']??'',30));if(!preg_match('/^[A-Z0-9-]{3,30}$/D',$id))throw new InvalidArgumentException('Identificador inválido.');
  $nombre=arx_text($_POST['razon_social']??'',160);$correo=trim((string)($_POST['correo']??''));if($correo!==''&&!filter_var($correo,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('Correo inválido.');
  $tel=trim((string)($_POST['telefono']??''));if(strlen($tel)>35)throw new InvalidArgumentException('Teléfono demasiado largo.');
  arx_exec($db,'INSERT INTO arca_proveedores_compras(identificador,razon_social,correo,telefono,creado_por) VALUES(?,?,?,?,?)',[$id,$nombre,$correo?:null,$tel?:null,arx_uid()]);
  arx_audit($db,'COMPRAS','arca_proveedores_compras',(int)$db->insert_id,'ALTA',null,['codigo'=>$id]);
 }elseif($action==='cotizacion'){
  $sid=arx_int($_POST['id_solicitud']??null);$pid=arx_int($_POST['id_proveedor']??null);$precio=arx_decimal($_POST['precio']??'',true);$moneda=arx_currency($_POST['moneda']??'');$vigencia=arx_date((string)($_POST['vigencia']??''));$notas=trim((string)($_POST['notas']??''));if(strlen($notas)>250)throw new InvalidArgumentException('Notas demasiado largas.');
  $sol=arx_one($db,'SELECT estado,moneda FROM arca_solicitudes_compra WHERE id_solicitud=? FOR UPDATE',[$sid]);if(!$sol||$sol['estado']!=='APROBADA')throw new InvalidArgumentException('Solicitud no aprobada.');
  if($sol['moneda']!==$moneda)throw new InvalidArgumentException('La cotización debe utilizar la misma moneda de la solicitud.');
  if($vigencia<date('Y-m-d'))throw new InvalidArgumentException('La cotización ya venció.');
  if(!arx_one($db,'SELECT id_proveedor FROM arca_proveedores_compras WHERE id_proveedor=? AND activo=1',[$pid]))throw new InvalidArgumentException('Proveedor no disponible.');
  arx_exec($db,'INSERT INTO arca_cotizaciones_compra(id_solicitud,id_proveedor,precio_unitario,moneda,vigencia,notas,creado_por) VALUES(?,?,?,?,?,?,?)',[$sid,$pid,$precio,$moneda,$vigencia,$notas?:null,arx_uid()]);
  arx_audit($db,'COMPRAS','arca_cotizaciones_compra',(int)$db->insert_id,'COTIZAR',null,['solicitud'=>$sid,'moneda'=>$moneda]);
 }elseif($action==='orden'){
  $cid=arx_int($_POST['id_cotizacion']??null);
  $q=arx_one($db,'SELECT c.id_solicitud,c.precio_unitario,c.moneda,c.vigencia,s.estado,s.codigo_obra,s.cantidad,s.moneda moneda_solicitud,s.solicitado_por,s.revisado_por,p.activo FROM arca_cotizaciones_compra c JOIN arca_solicitudes_compra s ON s.id_solicitud=c.id_solicitud JOIN arca_proveedores_compras p ON p.id_proveedor=c.id_proveedor WHERE c.id_cotizacion=? FOR UPDATE',[$cid]);
  if(!$q||$q['estado']!=='APROBADA'||(int)$q['activo']!==1||$q['vigencia']<date('Y-m-d')||$q['moneda']!==$q['moneda_solicitud'])throw new InvalidArgumentException('Cotización o solicitud no válida.');
  if((int)$q['solicitado_por']===arx_uid())throw new InvalidArgumentException('No puedes emitir la orden de tu propia solicitud.');
  if(empty($q['revisado_por']))throw new InvalidArgumentException('Falta aprobación registrada de la solicitud.');
  $total=number_format((float)$q['precio_unitario']*(float)$q['cantidad'],2,'.','');
  arx_exec($db,'INSERT INTO arca_ordenes_compra(id_solicitud,id_cotizacion,codigo_obra,total,moneda,emitida_por) VALUES(?,?,?,?,?,?)',[(int)$q['id_solicitud'],$cid,$q['codigo_obra'],$total,$q['moneda'],arx_uid()]);
  arx_audit($db,'COMPRAS','arca_ordenes_compra',(int)$db->insert_id,'EMITIR',null,['solicitud'=>(int)$q['id_solicitud'],'divisa'=>$q['moneda']]);
 }elseif($action==='recibir'){
  $id=arx_int($_POST['id_orden']??null);$old=arx_one($db,'SELECT estado FROM arca_ordenes_compra WHERE id_orden=? FOR UPDATE',[$id]);if(!$old||$old['estado']!=='EMITIDA')throw new InvalidArgumentException('La orden no está pendiente de recepción.');
  arx_exec($db,"UPDATE arca_ordenes_compra SET estado='RECIBIDA',recibida_por=?,recibida=NOW() WHERE id_orden=?",[arx_uid(),$id]);arx_audit($db,'COMPRAS','arca_ordenes_compra',$id,'RECIBIR',$old,['estado'=>'RECIBIDA']);
 }else throw new InvalidArgumentException('Acción no permitida.');
 $db->commit();arx_flash('Operación de compras registrada con auditoría.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $unused){}error_log('ARCA compras: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo guardar. Revisa el log de Apache.',true);}
arx_redirect('arca_compras.php');
