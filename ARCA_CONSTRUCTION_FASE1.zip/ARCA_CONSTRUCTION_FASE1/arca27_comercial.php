<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca27.php';
$db=a27_boot(['CEO','Director General','CCO']);
$modules=['oportunidades'=>'Oportunidades','licitaciones'=>'Licitaciones','propuestas'=>'Propuestas','seguimiento'=>'Seguimiento','contratos'=>'Contratos'];
$m=(string)($_GET['modulo']??'oportunidades');if(!isset($modules[$m]))a27_die('Módulo comercial inexistente.',404);
$obraPermitidas=a27_comercial_obras($db);$codes=array_column($obraPermitidas,'codigo_obra');
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 a27_post();if(arx_role()!=='CCO')a27_die('Solo el CCO puede registrar operaciones.');
 try{
  $accion=(string)($_POST['accion']??'');
  if($accion==='crear'){
   $type=(string)($_POST['modulo']??'');if(!isset($modules[$type]))throw new InvalidArgumentException('Proceso comercial incorrecto.');
   $code=arx_code($_POST['codigo_obra']??'');if(!a27_comercial_can($db,$code))a27_die('Obra no autorizada.');
   $cliente=arx_text($_POST['cliente']??'',100);$desc=arx_text($_POST['descripcion']??'',1000);
   $valor=arx_decimal($_POST['valor_estimado']??'0',true);$moneda=arx_currency($_POST['moneda']??'');
   $etapa=arx_text($_POST['etapa_comercial']??'',30);$fecha=arx_date((string)($_POST['fecha_cierre']??''));
   $db->begin_transaction();
   try{
    arx_exec($db,'INSERT INTO comercial_cco(codigo_obra,modulo,cliente,descripcion,valor_estimado,etapa_comercial,fecha_cierre) VALUES(?,?,?,?,?,?,?)',[$code,$type,$cliente,$desc,$valor,$etapa,$fecha]);
    $id=(int)$db->insert_id;
    arx_exec($db,'INSERT INTO arca27_comercial_monedas(id_comercial,moneda,asignado_por) VALUES(?,?,?)',[$id,$moneda,arx_uid()]);
    arx_audit($db,'comercial','comercial_cco',$id,'CREAR',null,['modulo'=>$type,'obra'=>$code,'moneda'=>$moneda,'etapa'=>$etapa]);
    $db->commit();
   }catch(Throwable $e){$db->rollback();throw $e;}
   a27_alert('Registro comercial creado con ID '.$id.'.');a27_redirect('arca27_comercial.php?modulo='.rawurlencode($type));
  }
  if($accion==='vincular'){
   $origin=arx_int($_POST['id_origen']??null);$dest=arx_int($_POST['id_destino']??null);
   $a=arx_one($db,'SELECT id_comercial,codigo_obra,modulo,cliente FROM comercial_cco WHERE id_comercial=?',[$origin]);
   $b=arx_one($db,'SELECT id_comercial,codigo_obra,modulo,cliente FROM comercial_cco WHERE id_comercial=?',[$dest]);
   if(!$a||!$b||$origin===$dest||$a['codigo_obra']!==$b['codigo_obra']||$a['cliente']!==$b['cliente']||!a27_comercial_can($db,(string)$a['codigo_obra']))throw new InvalidArgumentException('La relación requiere el mismo cliente, obra y dos registros diferentes autorizados.');
   $edge=['oportunidades'=>['licitaciones','propuestas','seguimiento'],'licitaciones'=>['propuestas','seguimiento'],'propuestas'=>['seguimiento','contratos'],'seguimiento'=>['contratos'],'contratos'=>[]];
   if(!in_array($b['modulo'],$edge[$a['modulo']]??[],true))throw new InvalidArgumentException('Relación no coherente con el flujo comercial.');
   $db->begin_transaction();try{
    arx_exec($db,'INSERT INTO arca27_comercial_relaciones(id_origen,id_destino,creado_por) VALUES(?,?,?)',[$origin,$dest,arx_uid()]);
    arx_audit($db,'comercial','relacion',$origin,'VINCULAR',null,['destino'=>$dest]);$db->commit();
   }catch(Throwable $e){$db->rollback();throw $e;}
   a27_alert('Relación comercial registrada.');a27_redirect('arca27_comercial.php?modulo='.rawurlencode($m));
  }
  throw new InvalidArgumentException('Acción comercial no reconocida.');
 }catch(Throwable $e){a27_alert($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo completar la operación. Revisa el registro de errores.',true);error_log('[ARCA27_COMERCIAL] '.$e->getMessage());a27_redirect('arca27_comercial.php?modulo='.rawurlencode($m));}
}
// Consulta limitada a obras permitidas. No se exponen registros de otras obras.
$items=[];
if($codes){$qs=implode(',',array_fill(0,count($codes),'?'));
 $items=arx_rows($db,"SELECT c.id_comercial,c.codigo_obra,c.cliente,c.descripcion,c.valor_estimado,c.etapa_comercial,c.fecha_cierre,m.moneda FROM comercial_cco c LEFT JOIN arca27_comercial_monedas m ON m.id_comercial=c.id_comercial WHERE c.modulo=? AND c.codigo_obra IN ($qs) ORDER BY c.id_comercial DESC LIMIT 150",array_merge([$m],$codes));
}
$rels=[];
if($items){$ids=array_column($items,'id_comercial');$qs=implode(',',array_fill(0,count($ids),'?'));
 $rels=arx_rows($db,"SELECT id_origen,id_destino FROM arca27_comercial_relaciones WHERE id_origen IN ($qs) OR id_destino IN ($qs)",array_merge($ids,$ids));}
$go=[];foreach($rels as $r){$go[(int)$r['id_origen']][]=(int)$r['id_destino'];}
a27_layout('Gestión comercial · '.$modules[$m],'Embudo trazable por cliente, obra, etapa, relación documental y divisa confirmada.','arca27_comercial.php');
?><section class="a27-card"><div class="a27-actions"><?php foreach($modules as $key=>$name):?><a class="a27-btn <?= $key===$m?'':'secondary'?>" href="?modulo=<?=a27_h($key)?>"><?=a27_h($name)?></a><?php endforeach;?></div></section>
<section class="a27-grid"><article class="a27-card"><div class="a27-sub">Registros visibles</div><div class="a27-metric"><?=count($items)?></div><p class="a27-sub">Solo obras autorizadas</p></article><article class="a27-card"><div class="a27-sub">Divisas históricas</div><p class="a27-warning">Un registro sin moneda confirmada no se etiqueta automáticamente como USD ni se suma con MXN.</p></article></section>
<section class="a27-card"><h2>Expedientes · <?=a27_h($modules[$m])?></h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Folio</th><th>Obra</th><th>Cliente</th><th>Descripción</th><th>Etapa</th><th>Valor registrado</th><th>Vínculos</th></tr></thead><tbody><?php foreach($items as $it):?><tr><td>#<?= (int)$it['id_comercial']?></td><td><?=a27_h($it['codigo_obra'])?></td><td><?=a27_h($it['cliente'])?></td><td><?=a27_h($it['descripcion'])?></td><td><span class="a27-label"><?=a27_h($it['etapa_comercial'])?></span></td><td><?=a27_h(number_format((float)$it['valor_estimado'],2))?> <?=a27_h($it['moneda']??'SIN CONFIRMAR')?></td><td><?=a27_h(implode(', ',$go[(int)$it['id_comercial']]??[]))?></td></tr><?php endforeach;?><?php if(!$items):?><tr><td colspan="7">No hay registros de esta categoría en tus obras autorizadas.</td></tr><?php endif;?></tbody></table></div></section>
<?php if(arx_role()==='CCO' && $codes):?><section class="a27-card"><h2>Registrar <?=a27_h($modules[$m])?></h2><form method="post" class="a27-form"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="crear"><input type="hidden" name="modulo" value="<?=a27_h($m)?>"><label>Obra<select name="codigo_obra" required><?php foreach($obraPermitidas as $ob):?><option value="<?=a27_h($ob['codigo_obra'])?>"><?=a27_h($ob['codigo_obra'].' · '.$ob['nombre_proyecto'])?></option><?php endforeach;?></select></label><label>Cliente o dependencia<input name="cliente" required maxlength="100"></label><label>Etapa comercial<input name="etapa_comercial" placeholder="Prospecto, Cotización, Negociación…" maxlength="30" required></label><label>Valor estimado<input type="number" name="valor_estimado" value="0" min="0" step="0.01" required></label><label>Divisa<select name="moneda" required><option>USD</option><option>MXN</option></select></label><label>Fecha objetivo<input type="date" name="fecha_cierre" required></label><label class="a27-wide">Descripción<textarea name="descripcion" maxlength="1000" required></textarea></label><button>Guardar registro comercial</button></form></section>
<section class="a27-card"><h2>Vincular expedientes existentes</h2><p class="a27-muted">El sistema comprueba la misma obra y cliente y el orden del proceso: oportunidad → licitación/propuesta → seguimiento/contrato. Los registros históricos no se vinculan automáticamente.</p><form method="post" class="a27-form"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="vincular"><label>ID origen<input type="number" name="id_origen" min="1" required></label><label>ID destino<input type="number" name="id_destino" min="1" required></label><button>Registrar correlación</button></form></section><?php endif; a27_end();
