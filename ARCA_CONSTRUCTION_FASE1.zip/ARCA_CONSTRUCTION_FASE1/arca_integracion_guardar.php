<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_integracion.php';
$db=arx_boot(['COO','CFO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén']);arx_check_post();
$accion=(string)($_POST['accion']??'');$obra='';$dest='arca_integracion.php';
try {
 $obra=arx_code($_POST['codigo_obra']??'');$dest=match($accion){'solicitar','autorizar'=>'arca_autorizaciones.php','recepcion'=>'arca_recepcion.php',default=>'arca_obra_360.php'};
 $dest.='?obra='.rawurlencode($obra);
 $db->begin_transaction();
 if($accion==='nota') {
  ax_require_obra($db,$obra,'operar');$cat=(string)($_POST['categoria']??'');if(!in_array($cat,['RIESGO','ACUERDO','SEGUIMIENTO'],true))throw new InvalidArgumentException('Categoría no válida.');
  $nota=arx_text($_POST['descripcion']??'',600);
  arx_exec($db,'INSERT INTO arca_seguimiento_integrado(codigo_obra,categoria,descripcion,creado_por) VALUES(?,?,?,?)',[$obra,$cat,$nota,arx_uid()]);$id=(int)$db->insert_id;
  arx_audit($db,'INTEGRACION','arca_seguimiento_integrado',$id,'CREAR',null,['obra'=>$obra,'categoria'=>$cat]);
 }elseif($accion==='solicitar') {
  ax_require_obra($db,$obra,'operar');$tipo=(string)($_POST['tipo']??'');if(!in_array($tipo,['GASTO_EXTRAORDINARIO','CAMBIO_ALCANCE'],true))throw new InvalidArgumentException('Tipo no válido.');
  $texto=arx_text($_POST['descripcion']??'',400);
  $monto=null;$moneda=null;
  if($tipo==='GASTO_EXTRAORDINARIO'){$monto=arx_decimal($_POST['monto']??'');$moneda=arx_currency($_POST['moneda']??'');}
  arx_exec($db,'INSERT INTO arca_autorizaciones_transversales(codigo_obra,tipo,descripcion,monto_estimado,moneda,solicitado_por) VALUES(?,?,?,?,?,?)',[$obra,$tipo,$texto,$monto,$moneda,arx_uid()]);$id=(int)$db->insert_id;
  arx_audit($db,'AUTORIZACIONES','arca_autorizaciones_transversales',$id,'SOLICITAR',null,['obra'=>$obra,'tipo'=>$tipo,'monto'=>$monto,'moneda'=>$moneda]);
 }elseif($accion==='autorizar') {
  $id=arx_int($_POST['id_autorizacion']??null);$decision=(string)($_POST['decision']??'');if(!in_array($decision,['APROBADA','RECHAZADA'],true))throw new InvalidArgumentException('Decisión no válida.');
  $coment=arx_text($_POST['comentario']??'',400);
  $row=arx_one($db,'SELECT codigo_obra,tipo,estado,solicitado_por FROM arca_autorizaciones_transversales WHERE id_autorizacion=? FOR UPDATE',[$id]);
  if(!$row || $row['codigo_obra']!==$obra || $row['estado']!=='PENDIENTE')throw new InvalidArgumentException('Solicitud no pendiente o ajena a la obra.');
  if((int)$row['solicitado_por']===arx_uid())throw new InvalidArgumentException('Una persona no puede aprobar su propia solicitud.');
  if(($row['tipo']==='GASTO_EXTRAORDINARIO' && arx_role()!=='CFO') || ($row['tipo']==='CAMBIO_ALCANCE' && arx_role()!=='COO'))throw new InvalidArgumentException('Este cargo no está facultado para decidir esta solicitud.');
  if($row['tipo']==='CAMBIO_ALCANCE')ax_require_obra($db,$obra,'aprobar');
  else if(!arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=?',[$obra]))throw new InvalidArgumentException('Obra no registrada.');
  arx_exec($db,'UPDATE arca_autorizaciones_transversales SET estado=?,decidido_por=?,decidido_en=NOW(),observacion_resolucion=? WHERE id_autorizacion=?',[$decision,arx_uid(),$coment,$id]);
  arx_audit($db,'AUTORIZACIONES','arca_autorizaciones_transversales',$id,'DECIDIR',['estado'=>'PENDIENTE'],['estado'=>$decision,'comentario'=>$coment]);
 }elseif($accion==='recepcion') {
  ax_require_obra($db,$obra,'operar');$oid=arx_int($_POST['id_orden']??null);$iid=arx_int($_POST['id_insumo']??null);
  $row=arx_one($db,'SELECT o.id_orden,o.codigo_obra,o.estado,s.cantidad,s.unidad FROM arca_ordenes_compra o JOIN arca_solicitudes_compra s ON s.id_solicitud=o.id_solicitud WHERE o.id_orden=? FOR UPDATE',[$oid]);
  if(!$row || $row['codigo_obra']!==$obra || $row['estado']!=='EMITIDA')throw new InvalidArgumentException('La orden no existe, no pertenece a la obra o ya fue recibida.');
  if(arx_one($db,'SELECT id_recepcion FROM arca_recepciones_integradas WHERE id_orden=?',[$oid]))throw new InvalidArgumentException('La orden ya tiene una recepción registrada.');
  $item=arx_one($db,'SELECT id_insumo,codigo_obra,cantidad_actual,stock_minimo,categoria_recurso,unidad_medida FROM inventario_almacen_arca WHERE id_insumo=? FOR UPDATE',[$iid]);
  if(!$item || $item['codigo_obra']!==$obra)throw new InvalidArgumentException('El artículo no pertenece a esta obra.');
  $norm=static fn($v)=>strtolower(trim((string)$v));
  if($norm($item['unidad_medida'])!==$norm($row['unidad']))throw new InvalidArgumentException('La unidad del artículo no coincide con la solicitud. Corrige el catálogo antes de recibir.');
  $quantity=(float)$row['cantidad'];$old=(float)$item['cantidad_actual'];$new=round($old+$quantity,2);
  if($quantity<=0 || $new>9999999999.99)throw new InvalidArgumentException('Cantidad no válida para el inventario.');
  $estado=$item['categoria_recurso']==='Maquinaria Pesada'?'En Operación':($new<=(float)$item['stock_minimo']?'Stock Bajo (Reordenar)':'Stock Óptimo');
  arx_exec($db,'UPDATE inventario_almacen_arca SET cantidad_actual=?,estado_inventario=? WHERE id_insumo=?',[$new,$estado,$iid]);
  arx_exec($db,'INSERT INTO arca_movimientos_material(id_insumo,codigo_obra,tipo,cantidad,anterior,posterior,observaciones,usuario_id) VALUES(?,?,?,?,?,?,?,?)',[$iid,$obra,'ENTRADA',(string)$row['cantidad'],(string)$old,(string)$new,'Recepción física vinculada a orden #'.$oid,arx_uid()]);
  $mid=(int)$db->insert_id;
  arx_exec($db,'UPDATE arca_ordenes_compra SET estado=?,recibida_por=?,recibida=NOW() WHERE id_orden=?',['RECIBIDA',arx_uid(),$oid]);
  arx_exec($db,'INSERT INTO arca_recepciones_integradas(id_orden,id_insumo,id_movimiento,cantidad,recibido_por) VALUES(?,?,?,?,?)',[$oid,$iid,$mid,(string)$row['cantidad'],arx_uid()]);
  arx_audit($db,'INTEGRACION','arca_ordenes_compra',$oid,'RECEPCION',['estado'=>'EMITIDA','stock'=>$old],['estado'=>'RECIBIDA','stock'=>$new,'id_movimiento'=>$mid]);
 }else throw new InvalidArgumentException('Acción no permitida.');
 $db->commit();arx_flash('Operación registrada y auditada. La información se refleja al actualizar los paneles.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $unused){}error_log('ARCA F14-19: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No fue posible procesar. Consulta el log de PHP.',true);}
arx_redirect($dest);
