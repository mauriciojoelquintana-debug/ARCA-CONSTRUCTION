<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca24_26.php';
$db=a26_db(['CEO','Director General','CIO']);
$checks=[];
function a26_check(string $title,int $total,string $meaning): array{return ['title'=>$title,'total'=>$total,'meaning'=>$meaning];}
try {
 $pending=(int)(arx_one($db,"SELECT COUNT(*) n FROM finanzas_coo WHERE moneda IS NULL OR moneda='' OR moneda NOT IN ('USD','MXN')")['n']??0);
 $checks[]=a26_check('Movimientos sin divisa confirmada',$pending,'Clasificar con documentos de soporte; no convertir automáticamente.');
 $orphan=(int)(arx_one($db,"SELECT COUNT(*) n FROM arca_accesos_obra a LEFT JOIN obras_coo o ON o.codigo_obra=a.codigo_obra WHERE o.codigo_obra IS NULL")['n']??0);
 $checks[]=a26_check('Permisos a obras inexistentes',$orphan,'Eliminar concesiones incorrectas solo después de revisión autorizada.');
 $negative=(int)(arx_one($db,'SELECT COUNT(*) n FROM inventario_almacen_arca WHERE cantidad_actual<0')['n']??0);
 $checks[]=a26_check('Existencias negativas',$negative,'Verificar ajustes físicos y transacciones de almacén.');
 $missing=(int)(arx_one($db,"SELECT COUNT(*) n FROM arca_ordenes_compra oc LEFT JOIN arca_solicitudes_compra s ON s.id_solicitud=oc.id_solicitud WHERE s.id_solicitud IS NULL")['n']??0);
 $checks[]=a26_check('Órdenes sin solicitud asociada',$missing,'Revisión de claves y de solicitudes eliminadas.');
 $received=(int)(arx_one($db,"SELECT COUNT(*) n FROM arca_ordenes_compra o WHERE o.estado='RECIBIDA' AND NOT EXISTS(SELECT 1 FROM arca_recepciones_integradas r WHERE r.id_orden=o.id_orden)")['n']??0);
 $checks[]=a26_check('Órdenes recibidas sin recepción integrada',$received,'Comprobar si son recepciones históricas legítimas antes de conciliarlas.');
} catch(Throwable $e){error_log('ARCA26: '.$e->getMessage());http_response_code(500);exit('No se pudo completar la consulta de calidad. Revisa el registro PHP.');}
a26_layout('Auditoría e integridad del ERP','Controles de calidad de datos y plan de pruebas de seguridad; acceso reservado a Dirección General y CIO.','arca26_seguridad.php');
?>
<section class="arx-card"><h2>Hallazgos de integridad</h2><p class="a26-note">El número indica registros que requieren revisión, no demuestra por sí solo un fallo ni corrige datos automáticamente.</p><div class="a26-cards">
<?php foreach($checks as $check):?><article class="a26-stat"><span><?=arx_h($check['title'])?></span><strong class="<?=(int)$check['total']?'a26-status-warn':'a26-status-ok'?>"><?=(int)$check['total']?></strong><small><?=arx_h($check['meaning'])?></small></article><?php endforeach;?>
</div></section>
<section class="arx-card"><h2>Controles pendientes para aprobar despliegue</h2><div class="a26-table-wrap"><table class="a26-results"><thead><tr><th>Control</th><th>Criterio de aceptación</th><th>Resultado</th></tr></thead><tbody>
<?php foreach([
 ['Control de acceso directo','La URL y cada POST requieren permisos del servidor, no solo estar ocultos en el menú'],
 ['Protección CSRF','Todos los cambios usan token de sesión verificado'],
 ['Sesiones y credenciales','HTTPS, cookies seguras, cierre real de sesión y MFA si aplica'],
 ['Archivos privados','Planos, nóminas y respaldos fuera de la carpeta pública'],
 ['Restauración','Restaurar copia de base y archivos en un entorno aislado'],
 ['Integridad de datos','Recibos, órdenes y movimientos no se duplican al repetir solicitudes'],
 ['Escaneo de código','Revisar todas las rutas heredadas detectadas por el inventario CLI'],
 ['Carga y rendimiento','Probar paginación, concurrencia y volumen de archivos']
] as $task):?><tr><td><?=arx_h($task[0])?></td><td><?=arx_h($task[1])?></td><td><span class="a26-badge">Pendiente de evidencia</span></td></tr><?php endforeach;?></tbody></table></div><p class="a26-alert">Esta pantalla no constituye una certificación de seguridad. El software debe permanecer en Laragon hasta completar las pruebas y revisión de los controladores antiguos.</p></section>
<section class="arx-card"><h2>Seguimiento de accesos</h2><p>El área de Sistemas puede revisar las rutas pendientes y documentar el alcance de los controles de acceso.</p><div class="a26-actions"><a class="arx-btn" href="arca22_mis_permisos.php">Mis permisos</a><a class="arx-btn" href="arca22_portal.php">Portal ARCA</a></div></section>
<?php arx_layout_end(); ?>
