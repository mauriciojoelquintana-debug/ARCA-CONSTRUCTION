<?php
// 1. Mantenemos el candado de seguridad RBAC
session_start();
$roles_tecnicos = ['Ingeniero Civil', 'Arquitecto', 'Residente de Obra', 'Supervisor de Obra'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_tecnicos)) {
    header("Location: login.html");
    exit(); 
}

// 2. Incluimos la conexión a la base de datos
include("conexion.php");

// 3. Verificamos que los datos del nuevo formulario corporativo hayan llegado
if (isset($_POST['codigo_articulo']) && isset($_POST['nombre_material'])) {
    
    // Capturamos las variables enviadas por el usuario
    $codigo = $_POST['codigo_articulo'];
    $nombre = $_POST['nombre_material'];
    $categoria = $_POST['categoria'];
    $cantidad = $_POST['cantidad'];
    $unidad = $_POST['unidad_medida'];
    $responsable = $_POST['responsable_registro']; 

    // 4. Ciberseguridad: Sentencias Preparadas para evitar Inyección SQL
    // Se insertan los 5 datos exactos que requiere tu nueva tabla 'inventario'
    $stmt = $conectar->prepare("INSERT INTO inventario (codigo_articulo, nombre_material, categoria, cantidad, unidad_medida) VALUES (?, ?, ?, ?, ?)");
    
    // Las letras "sssis" indican el tipo de dato: String, String, String, Integer, String
    $stmt->bind_param("sssis", $codigo, $nombre, $categoria, $cantidad, $unidad);
    
    // 5. Interfaz de respuesta profesional para el usuario
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Procesando Auditoría</title>";
    echo "<style>body { font-family: Arial; text-align: center; padding: 50px; background-color: #f4f6f7; }</style></head><body>";
    
    if ($stmt->execute()) {
        echo "<h2 style='color: #27ae60;'>✅ Material Registrado Exitosamente</h2>";
        echo "<p>El lote de <b>$cantidad $unidad</b> de <b>$nombre</b> (Código: $codigo) ha sido ingresado al almacén.</p>";
        echo "<p>Auditor responsable: <b>$responsable</b>.</p>";
    } else {
        echo "<h2 style='color: #e74c3c;'>❌ Error en el Registro</h2>";
        // Si intentan registrar dos veces el mismo código (UNIQUE), el sistema lo bloqueará
        echo "<p>Verifique que el código de artículo no esté duplicado en el inventario.</p>";
        echo "<p>Detalle técnico: " . $conectar->error . "</p>";
    }
    
    $stmt->close();
    
    echo "<br><br><a href='formulario_inventario.php' style='padding: 10px 20px; background: #f39c12; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;'>Registrar otro material</a>";
    echo "<br><br><a href='panel_ingenieria.php' style='color: #34495e; text-decoration: none; font-weight: bold; display: block; margin-top: 20px;'>← Volver al Panel de Ingeniería</a>";
    echo "</body></html>";
} else {
    echo "<h3>Error de sistema: No se recibieron datos del formulario.</h3>";
}

$conectar->close();
?>