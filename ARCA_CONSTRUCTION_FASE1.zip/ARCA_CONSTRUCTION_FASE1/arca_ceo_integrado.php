<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_fases_8_13.php';
$db=arx_boot(['CEO','Director General']);
$obras=arx_rows($db,'SELECT codigo_obra,nombre_proyecto,avance_fisico,estado_tiempo FROM obras_coo ORDER BY codigo_obra');
$usuarios=af8_count($db,'usuarios');$empleados=af8_count($db,'arca_empleados');$confirmados=af8_count($db,'arca_empleados',"estado_laboral='ACTIVO'");$gerencias=af8_count($db,'gerencias_arca');
$material=af8_count($db,'inventario_almacen_arca');$maquinas=af8_count($db,'arca_maquinaria_obra');
$compras=af8_count($db,'arca_solicitudes_compra',"estado='PENDIENTE'");
$saldo=arx_rows($db,"SELECT COALESCE(moneda,'SIN DEFINIR') moneda, modulo, estado_pago, SUM(monto) total FROM finanzas_coo GROUP BY COALESCE(moneda,'SIN DEFINIR'),modulo,estado_pago ORDER BY moneda,modulo");
$alertas=array_values(array_filter($obras,static fn($o)=>in_array($o['estado_tiempo'],['Riesgo','Retraso'],true)));
af8_layout('Resumen ejecutivo consolidado','Datos de Finanzas, Operaciones y Recursos Humanos. Las cantidades históricas sin divisa no se mezclan con importes USD/MXN.','arca_ceo_integrado.php');
?>
<section class="arx-grid4">
<div class="arx-kpi"><span>Obras registradas</span><strong><?=count($obras)?></strong></div>
<div class="arx-kpi"><span>Cuentas / expedientes</span><strong><?=$usuarios?> / <?=$empleados?></strong><small>No son equivalentes a plantilla</small></div>
<div class="arx-kpi"><span>Empleados confirmados activos</span><strong><?=$confirmados?></strong></div>
<div class="arx-kpi"><span>Gerencias / insumos</span><strong><?=$gerencias?> / <?=$material?></strong></div>
<div class="arx-kpi"><span>Máquinas registradas</span><strong><?=$maquinas?></strong></div>
<div class="arx-kpi"><span>Compras pendientes</span><strong><?=$compras?></strong></div>
<div class="arx-kpi"><span>Obras en riesgo / retraso</span><strong><?=count($alertas)?></strong></div>
</section>
<section class="arx-card"><h2>Obras · situación global</h2><div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Obra</th><th>Avance</th><th>Estado</th><th>Detalle</th></tr></thead><tbody>
<?php foreach($obras as $o):?><tr><td><?=arx_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></td><td><?=number_format((float)$o['avance_fisico'],1)?>%</td><td><?=af8_badge((string)$o['estado_tiempo'])?></td><td><a href="arca_expediente_obra.php?obra=<?=rawurlencode($o['codigo_obra'])?>">Abrir expediente</a></td></tr><?php endforeach;?></tbody></table></div></section>
<section class="arx-card"><h2>Movimientos financieros por divisa y estado</h2><p class="arx-sub">Totales de movimientos por clasificación; no representan saldos bancarios ni suman monedas distintas.</p><div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Divisa</th><th>Módulo</th><th>Estado</th><th>Importe</th></tr></thead><tbody>
<?php foreach($saldo as $s):?><tr><td><?=arx_h($s['moneda'])?></td><td><?=arx_h($s['modulo'])?></td><td><?=arx_h($s['estado_pago'])?></td><td><?=af8_money($s['total'],$s['moneda']==='SIN DEFINIR'?null:$s['moneda'])?></td></tr><?php endforeach;?></tbody></table></div></section>
<section class="arx-card"><h2>Acciones de dirección</h2><div class="af8-links"><a class="arx-btn" href="arca_integracion.php">Abrir gestión integrada</a><a class="arx-btn" href="arca_estructura.php">Gerencias y departamentos</a><a class="arx-btn" href="arca_reportes.php">Reportes de obras</a><a class="arx-btn" href="arca_validacion.php">Verificaciones de calidad</a><a class="arx-btn" href="panel_ceo.php">Panel CEO anterior</a></div></section>
<?php arx_layout_end(); ?>
