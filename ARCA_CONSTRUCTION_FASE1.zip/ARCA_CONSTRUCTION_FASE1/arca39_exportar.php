<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca39_datos.php';
$db=a27_boot(a39_roles());
try{$data=a39_panoramica($db,__DIR__);}catch(Throwable $e){error_log('[ARCA39 CSV] '.$e->getMessage());http_response_code(500);exit('No fue posible generar el reporte.');}
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="arca_validacion_'.date('Ymd_His').'.csv"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
$out=fopen('php://output','wb');
fwrite($out,"\xEF\xBB\xBF"."sep=;\r\n");
$put=static function(array $cells)use($out):void {fputcsv($out,array_map('a39_csv_safe',$cells),';','"','');};
$put(['ARCA CONSTRUCTION','INCIDENCIAS Y VALIDACIÓN','SOLO DIAGNÓSTICO','Fecha',date('Y-m-d H:i:s')]);
$put(['Sección','Referencia','Área','Control/Incidencia','Estado','Prioridad']);
foreach($data['f32'] as $r)$put(['Auditoría','', $r['modulo'],$r['control'],$r['estado'],'']);
foreach($data['f33'] as $r)$put(['Infraestructura','',$r['area'],$r['nombre'],$r['estado'],'']);
foreach($data['catalogo'] as $id=>$c)$put(['Verificación operativa',$id,$c[0],$c[1],$data['f35'][$id]['resultado']??'NO_EJECUTADA','']);
foreach($data['incidencias'] as $r)$put(['Incidencias',(string)$r['id_incidencia'],$r['categoria'],$r['titulo'],$r['estado'],$r['prioridad']]);
$put(['Solicitudes','Flujos','Integridad','Inconsistencias',''.(int)$data['f38']['errores'],'']);
$put(['Solicitudes','Alcance','Integridad','Revisión completa',$data['f38']['completa']?'SI':'NO','']);
$put(['Habilitación operativa','Control','Operación','Resultado',$data['puerta']['sin_bloqueos_detectados']?'REVISION HUMANA PENDIENTE':'NO APTO','']);
fclose($out);
