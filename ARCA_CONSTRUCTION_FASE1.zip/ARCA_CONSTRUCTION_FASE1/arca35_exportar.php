<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a35_roles());
try {a34_base_pruebas($db);$save=a34_instalado($db)?a35_guardados($db):[];}
catch(Throwable $e){error_log('[ARCA35 CSV] '.$e->getMessage());http_response_code(500);exit('No se pudo preparar el informe.');}
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="arca_verificaciones_'.date('Ymd_His').'.csv"');
header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');
$out=fopen('php://output','wb');if($out===false)exit;
fwrite($out,"\xEF\xBB\xBF");fwrite($out,"sep=;\r\n");
$csv=static function(array $r)use($out):void{fputcsv($out,array_map('a34_csv_seguro',$r),';','"','');};
$csv(['Código','Área','Verificación','Resultado registrado','Evidencia (referencia)','Observación','Última actualización']);
foreach(a35_catalogo() as $id=>$v){$s=$save[$id]??[];$csv([$id,$v[0],$v[1],$s['resultado']??'NO_EJECUTADA',$s['referencia_evidencia']??'',$s['observacion']??'',$s['ejecutado_en']??'']);}
fclose($out);
