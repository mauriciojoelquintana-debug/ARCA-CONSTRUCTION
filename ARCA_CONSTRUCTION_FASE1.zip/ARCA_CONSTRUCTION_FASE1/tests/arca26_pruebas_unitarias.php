<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
require dirname(__DIR__).'/includes/arca24_26_puro.php';
$cases=[
 ['CFO no puede exportar personal',!in_array('personal',a26_reportes_por_rol('CFO'),true)],
 ['COO no puede exportar finanzas',!in_array('finanzas',a26_reportes_por_rol('COO'),true)],
 ['CHRO no puede exportar finanzas',!in_array('finanzas',a26_reportes_por_rol('CHRO'),true)],
 ['CEO puede exportar finanzas',in_array('finanzas',a26_reportes_por_rol('CEO'),true)],
 ['Rol desconocido sin exportaciones',a26_reportes_por_rol('otro')===[]],
 ['CFO puede visualizar finanzas',a26_rol_finanzas('CFO')],
 ['COO no puede visualizar finanzas',!a26_rol_finanzas('COO')],
 ['Moneda USD',a26_currency('usd')==='USD'],
 ['Moneda pendiente',a26_currency('SIN_CONFIRMAR')==='SIN_CONFIRMAR'],
 ['Rango fechas',a26_periodo('2026-01-01','2026-02-01')===['2026-01-01','2026-02-01']],
 ['SQL IN usa placeholders',a26_sql_in(['O1','O2'])==='?,?'],
 ['Dinero no convertido',a26_format_money(100,'MXN')==='$100.00 MXN'],
];
function expect_throw(callable $fn):bool{try{$fn();return false;}catch(InvalidArgumentException $e){return true;}}
$cases[]=['Fechas inválidas rechazadas',expect_throw(fn()=>a26_periodo('2026-02-30',''))];
$cases[]=['Orden fechas invertidas rechazado',expect_throw(fn()=>a26_periodo('2026-10-10','2026-01-01'))];
$cases[]=['Divisa ajena rechazada',expect_throw(fn()=>a26_currency('EUR'))];
$cases[]=['Sin obras no genera IN',expect_throw(fn()=>a26_sql_in([]))];
$passed=0;foreach($cases as [$title,$ok]){echo ($ok?'OK':'FALLO').' '.$title."\n";if($ok)$passed++;}
echo "$passed / ".count($cases)." comprobaciones superadas.\n";exit($passed===count($cases)?0:1);
