<?php
declare(strict_types=1);
/** Pruebas puras: sin acceso a red, MySQL o código de producción. */
require_once __DIR__.'/../includes/arca39_reglas.php';
// Las funciones puras existentes se cargan del ERP cuando están presentes.
// Para esta prueba autónoma basta un motor mínimo de transiciones F38.
if(!function_exists('a38_transicion')){function a38_transicion(string $estado,string $accion):string{
  if($estado==='PENDIENTE')return match($accion){'APROBAR'=>'APROBADA','RECHAZAR'=>'RECHAZADA','DEVOLVER'=>'DEVUELTA',default=>throw new DomainException('Acción inválida')};
  if($estado==='DEVUELTA'&&$accion==='REENVIAR')return 'PENDIENTE';
  throw new DomainException('Transición inválida');
}}
$pass=0;$fail=0;
function qa(string $name,bool $truth):void{global $pass,$fail;if($truth){$pass++;echo "OK: $name\n";}else{$fail++;echo "FALLO: $name\n";}}
function thrown(callable $fn):bool{try{$fn();return false;}catch(Throwable $e){return true;}}
qa('F39 CEO autorizado',in_array('CEO',a39_roles(),true));
qa('F39 Director General autorizado',in_array('Director General',a39_roles(),true));
foreach(['CFO','COO','CHRO','CIO','CTO','CCO','CMO','CSO'] as $r)qa('F39 rol '.$r.' no autorizado',!in_array($r,a39_roles(),true));
qa('Categoría datos',isset(a39_categorias()['DATOS']));
qa('Categoría respaldos',isset(a39_categorias()['RESPALDOS']));
qa('Texto válido',a39_texto('  Informe de prueba ',160)==='Informe de prueba');
qa('Texto vacío bloqueado',thrown(fn()=>a39_texto('',160)));
qa('Control en texto bloqueado',thrown(fn()=>a39_texto("abc\x00",160)));
qa('Texto límite bloqueado',thrown(fn()=>a39_texto(str_repeat('x',161),160)));
qa('Estado abrir a proceso',a39_transicion('ABIERTA','EN_PROCESO'));
qa('Estado en proceso a validación',a39_transicion('EN_PROCESO','EN_VALIDACION'));
qa('Estado validación a cerrada',a39_transicion('EN_VALIDACION','CERRADA'));
qa('Estado validación a proceso',a39_transicion('EN_VALIDACION','EN_PROCESO'));
qa('Cierre directo bloqueado',!a39_transicion('ABIERTA','CERRADA'));
qa('Cierre irreversible',!a39_transicion('CERRADA','ABIERTA'));
qa('Estado sin cambio bloqueado',!a39_transicion('ABIERTA','ABIERTA'));
qa('Cerrar sin evidencia bloqueado',thrown(fn()=>a39_validar_cierre('CERRADA','','Justificación')));
qa('Validación sin evidencia bloqueada',thrown(fn()=>a39_validar_cierre('EN_VALIDACION','','Observación')));
qa('Cierre documentado',!thrown(fn()=>a39_validar_cierre('CERRADA','ACTA-001','Verificado')));
qa('Estado desconocido bloqueado',thrown(fn()=>a39_validar_cierre('SUPERADO','A','B')));
qa('CSV fórmula',str_starts_with(a39_csv_safe('=2+2'),"'"));
qa('CSV plus',str_starts_with(a39_csv_safe('+2+2'),"'"));
qa('CSV arroba',str_starts_with(a39_csv_safe('@SUM(A1)'),"'"));
qa('CSV signo negativo',str_starts_with(a39_csv_safe('-1+2'),"'"));
qa('CSV valor neutro',a39_csv_safe('Control de obra')==='Control de obra');
qa('CSV salto neutralizado',a39_csv_safe("A\nB")==='A B');
$cat=['SEG01'=>[],'SEG02'=>[],'SEG03'=>[]];$records=['SEG01'=>['resultado'=>'APROBADA'],'SEG02'=>['resultado'=>'FALLIDA']];
$s=a39_resumen_casos($cat,$records);
qa('Resumen total',$s['total']===3);qa('Resumen aprobadas',$s['aprobadas']===1);qa('Resumen fallidas',$s['fallidas_bloqueadas']===1);qa('Resumen no aprobadas',$s['sin_aprobar']===2);
$flow=['estado'=>'APROBADA','creado_por'=>3];
$events=[['accion'=>'CREAR','estado_anterior'=>null,'estado_nuevo'=>'PENDIENTE','actor_id'=>3],['accion'=>'APROBAR','estado_anterior'=>'PENDIENTE','estado_nuevo'=>'APROBADA','actor_id'=>2]];
qa('Flujo COO CFO válido',!a39_validar_eventos($flow,$events));
qa('Flujo sin creación detectado',!!a39_validar_eventos($flow,[]));
$bad=$events;$bad[1]['actor_id']=3;
qa('Autoaprobación detectada',!!a39_validar_eventos($flow,$bad));
$bad=$events;$bad[1]['estado_anterior']='OTRO';
qa('Estado anterior falso detectado',!!a39_validar_eventos($flow,$bad));
$bad=$events;$bad[1]['estado_nuevo']='RECHAZADA';
qa('Transición falsa detectada',!!a39_validar_eventos($flow,$bad));
$bad=$events;$bad[1]['accion']='CREAR';
qa('Evento duplicado rechazado',!!a39_validar_eventos($flow,$bad));
$gate=a39_puerta([['estado'=>'AVISO']],[['estado'=>'OK']],[],['completa'=>true,'errores'=>0],0,0);
qa('F32 mantiene bloqueo',!$gate['sin_bloqueos_detectados']);
$gate=a39_puerta([['estado'=>'OK']],[['estado'=>'OK']],[],['completa'=>true,'errores'=>0],0,1);
qa('F35 pendiente mantiene bloqueo',!$gate['sin_bloqueos_detectados']);
$gate=a39_puerta([] ,[],[],['completa'=>false,'errores'=>0],0,0);
qa('F38 incompleta mantiene bloqueo',!$gate['sin_bloqueos_detectados']);
$gate=a39_puerta([],[],[],['completa'=>true,'errores'=>2],0,0);
qa('F38 inconsistente mantiene bloqueo',!$gate['sin_bloqueos_detectados']);
$gate=a39_puerta([],[],[],['completa'=>true,'errores'=>0],1,0);
qa('Incidencias abiertas mantienen bloqueo',!$gate['sin_bloqueos_detectados']);
$gate=a39_puerta([],[],[],['completa'=>true,'errores'=>0],0,0);
qa('Sin hallazgos, candidato humano',$gate['sin_bloqueos_detectados']);
echo "TOTAL: $pass correctas, $fail incorrectas.\n";
exit($fail?1:0);
