<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403);exit('CLI únicamente'); }
$root=dirname(__DIR__);$ok=0;$fail=0;
function test40(bool $valid,string $name):void {global $ok,$fail; if($valid){$ok++;echo 'OK: '.$name.PHP_EOL;}else{$fail++;echo 'ERROR: '.$name.PHP_EOL;}}
$rules=json_decode((string)file_get_contents($root.'/data/cambios.json'),true);
test40(is_array($rules),'Reglas de actualización legibles');
foreach (['includes/arca27.php','arca32_auditoria.php','arca33_preparacion.php','arca34_calidad.php','arca35_pruebas.php','arca36_infraestructura.php'] as $file) {
 $ref=$root.'/referencia/'.$file;
 test40(is_file($ref),'Referencia presente: '.$file);
 if(is_file($ref)) {
  $text=file_get_contents($ref);
  test40($text!==false && str_starts_with($text,"<?php\n"),'Cabecera PHP: '.$file);
  if (function_exists('exec')) {
   $out=[];$status=1;@exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($ref).' 2>&1',$out,$status);
   test40($status===0,'Sintaxis PHP: '.$file);
  }
 }
}
test40(is_file($root.'/assets/css/arca40_corporativo.css'),'CSS corporativo presente');
test40(is_file($root.'/scripts/instalar.php'),'Instalador presente');
test40(is_array($rules)&&count($rules)===6,'6 archivos declarados para parcheo');
test40(is_file($root.'/LEEME_INSTALACION.md'),'Guía de instalación presente');
echo 'RESULTADO: '.$ok.' correctas, '.$fail.' incorrectas.'.PHP_EOL;exit($fail?1:0);
