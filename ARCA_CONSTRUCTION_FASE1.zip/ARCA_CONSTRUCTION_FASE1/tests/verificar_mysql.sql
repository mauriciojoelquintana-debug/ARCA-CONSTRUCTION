-- Consultas de solo lectura después de importar la migración.
SELECT DATABASE() AS base_actual;
SELECT TABLE_NAME FROM information_schema.TABLES
 WHERE TABLE_SCHEMA='arca_bd_fase1' AND TABLE_NAME IN ('arca29_documentos','arca30_demo_casos');
SELECT (SELECT COUNT(*) FROM arca29_documentos) AS documentos_f29,
       (SELECT COUNT(*) FROM arca30_demo_casos) AS casos_f30,
       (SELECT COUNT(*) FROM arca_contratos_laborales) AS contratos_reales,
       (SELECT COUNT(*) FROM arca27_responsables_obra) AS responsables_reales;
