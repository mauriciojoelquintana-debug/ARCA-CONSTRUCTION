<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca36_38_datos.php';
$db=a27_boot(a38_roles());
try {
    a36_pruebas_bd($db);
    if(!a38_instalado($db))throw new RuntimeException('El servicio de solicitudes no está configurado.');
    $rows=a38_listado($db,a38_codigos_autorizados($db));
}catch(Throwable $e){error_log('[ARCA F38 CSV] '.$e->getMessage());http_response_code(500);exit('No se pudo preparar la exportación.');}
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="arca_solicitudes_'.date('Ymd_His').'.csv"');
header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');
$out=fopen('php://output','wb');
fwrite($out,"\xEF\xBB\xBF"."sep=;\r\n");
$put=static function(array $v)use($out):void{fputcsv($out,array_map('a38_csv_safe',$v),';','"','');};
$put(['ARCA CONSTRUCTION','SOLICITUDES','SOLO REFERENCIAS','Perfil',arx_role()]);
$put(['Folio','Código obra','Tipo','Título','Referencia','Estado','Creación','Actualización']);
foreach($rows as $r)$put([$r['id_flujo'],$r['codigo_obra'],$r['tipo'],$r['titulo'],$r['referencia_origen'],$r['estado'],$r['creado_en'],$r['actualizado_en']]);
fclose($out);
