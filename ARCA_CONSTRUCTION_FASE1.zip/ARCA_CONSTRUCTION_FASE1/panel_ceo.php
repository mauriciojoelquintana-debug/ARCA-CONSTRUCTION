<?php
require_once __DIR__ . '/includes/seguridad.php';
arca_requerir_roles(['CEO', 'Director General']);
require __DIR__ . '/conexion.php';

function arca_escalar(?float $numero): string { return number_format(((float)$numero)/1000000, 1, '.', ','); }
function arca_total(mysqli $db, string $sql): float {
    $r = $db->query($sql)->fetch_row(); return (float)($r[0] ?? 0);
}
$nombre = (string)($_SESSION['nombre_usuario'] ?? 'Dirección General');
$idEmpleado = (string)($_SESSION['usuario_activo'] ?? '');
$inicial = strtoupper(substr($nombre,0,1));

// Todas las métricas provienen de la base de datos. Sin números simulados.
$totalObras = (int)arca_total($conectar, 'SELECT COUNT(*) FROM proyectos');
$totalPersonal = (int)arca_total($conectar, 'SELECT COUNT(*) FROM usuarios');
$totalGerencias = (int)arca_total($conectar, 'SELECT COUNT(*) FROM gerencias_arca');
$presupuesto = arca_total($conectar, 'SELECT COALESCE(SUM(presupuesto),0) FROM proyectos');
$totalAsignaciones = (int)arca_total($conectar, 'SELECT COUNT(*) FROM asignaciones_obra_arca');
$totalPuestos = (int)arca_total($conectar, 'SELECT COUNT(*) FROM catalogo_puestos_arca');
$direcciones = $conectar->query('SELECT codigo_dir, nombre_direccion, titular_cargo, tipo_area, total_gerencias, enfoque_control FROM direcciones_arca ORDER BY id_direccion')->fetch_all(MYSQLI_ASSOC);
$obras = $conectar->query('SELECT id_proyecto, nombre_obra, ubicacion, presupuesto, estado, categoria FROM proyectos ORDER BY id_proyecto')->fetch_all(MYSQLI_ASSOC);
$gerencias = $conectar->query('SELECT g.nombre_gerencia, d.titular_cargo FROM gerencias_arca g LEFT JOIN direcciones_arca d ON d.codigo_dir = g.codigo_dir ORDER BY g.id_gerencia LIMIT 6')->fetch_all(MYSQLI_ASSOC);
$tipos = $conectar->query('SELECT categoria, COUNT(*) AS total FROM proyectos GROUP BY categoria ORDER BY categoria')->fetch_all(MYSQLI_ASSOC);
$mapa = ['CFO'=>'panel_cfo.php','COO'=>'panel_coo.php','CIO'=>'panel_cio.php','CTO'=>'panel_cto.php','CCO'=>'panel_cco.php','CMO'=>'panel_cmo.php','CHRO'=>'panel_chro.php','CSO'=>'panel_cso.php'];
$explicacion = ['CFO'=>'Finanzas y control presupuestal','COO'=>'Operaciones, ejecución y obras','CIO'=>'Sistemas e información','CTO'=>'Tecnología e innovación','CCO'=>'Comercial y contratación','CMO'=>'Marketing y posicionamiento','CHRO'=>'Capital humano','CSO'=>'Estrategia y crecimiento'];
$principales = []; $apoyo = [];
foreach ($direcciones as $d) {
  if (isset($mapa[$d['titular_cargo']])) $principales[]=$d;
  elseif ($d['titular_cargo'] !== 'CEO') $apoyo[]=$d;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <title>Dirección general | ARCA CONSTRUCTION</title>
  <link rel="stylesheet" href="assets/css/arca.css">
</head>
<body>
<div class="app-layout">
  <aside class="app-sidebar">
    <div class="sidebar-brand">
      <span class="brand-mark" aria-hidden="true">A</span>
      <span><span class="brand-name">ARCA CONSTRUCTION</span><span class="brand-sub" style="display:block">Sistema de gestión ERP</span></span>
    </div>
    <span class="nav-label">Navegación principal</span>
    <nav class="app-nav" aria-label="Navegación principal">
      <a href="#resumen" aria-current="page"><span class="nav-icon">▦</span> Resumen general</a>
      <a href="#direcciones"><span class="nav-icon">▤</span> Direcciones</a>
      <a href="#obras"><span class="nav-icon">▥</span> Obras y proyectos</a>
      <a href="#estructura"><span class="nav-icon">▧</span> Estructura organizacional</a>
      <a href="panel_estructura_arca.php"><span class="nav-icon">♧</span> Personal en obra</a>
      <a href="panel_departamentos_arca.php"><span class="nav-icon">▣</span> Departamentos</a>
      <a href="panel_oficina_almacen.php"><span class="nav-icon">⌑</span> Oficina técnica y almacén</a>
    </nav>
    <div class="sidebar-end">
      <div class="sidebar-user">
        <span class="user-avatar"><?= arca_h($inicial) ?></span>
        <span><span class="user-identity" style="display:block" title="<?= arca_h($nombre) ?>"><?= arca_h($nombre) ?></span><span class="user-meta">Dirección general · <?= arca_h($idEmpleado) ?></span></span>
      </div>
      <a href="cerrar_sesion.php" class="sidebar-logout">↪ Cerrar sesión</a>
    </div>
  </aside>
  <main class="app-main" id="resumen">
    <header class="app-topbar">
      <div class="app-breadcrumb">ARCA CONSTRUCTION <span style="margin:0 9px;color:#b1bdc9">/</span><b>Dirección general</b></div>
      <div class="app-top-right"><span class="status-pill"><span class="status-dot"></span> Sistema conectado</span><span class="user-avatar" title="Sesión: <?= arca_h($idEmpleado) ?>"><?= arca_h($inicial) ?></span></div>
    </header>
    <section class="welcome">
      <div><span class="eyebrow">PANEL DE CONTROL EJECUTIVO</span><h1>Resumen corporativo</h1><p>Información consolidada de personas, áreas y proyectos de ARCA CONSTRUCTION.</p></div>
      <a href="panel_estructura_arca.php" class="btn btn-primary">Gestionar personal y obras <span aria-hidden="true">→</span></a>
    </section>
    <section class="stats-grid" aria-label="Indicadores corporativos">
      <article class="metric-card"><div class="metric-head"><span class="metric-label">Proyectos registrados</span><span class="metric-symbol">⌂</span></div><div class="metric-value"><?= number_format($totalObras) ?></div><div class="metric-detail">Obras en el catálogo de proyectos</div></article>
      <article class="metric-card"><div class="metric-head"><span class="metric-label">Cuentas de usuario</span><span class="metric-symbol">♙</span></div><div class="metric-value"><?= number_format($totalPersonal) ?></div><div class="metric-detail">Accesos registrados, no plantilla total</div></article>
      <article class="metric-card"><div class="metric-head"><span class="metric-label">Gerencias</span><span class="metric-symbol">▤</span></div><div class="metric-value"><?= number_format($totalGerencias) ?></div><div class="metric-detail">Unidades de gestión corporativa</div></article>
      <article class="metric-card"><div class="metric-head"><span class="metric-label">Presupuesto de proyectos</span><span class="metric-symbol">$</span></div><div class="metric-value">$<?= arca_h(arca_escalar($presupuesto)) ?> M</div><div class="metric-detail">Suma de presupuestos, en MXN</div></article>
    </section>
    <section class="content-section" id="direcciones">
      <div class="section-heading"><div><h2>Direcciones ejecutivas</h2><p>Acceso organizado a las ocho áreas responsables de ARCA.</p></div><a class="text-link" href="#estructura">Ver estructura completa →</a></div>
      <div class="direction-grid">
        <?php foreach ($principales as $d): $sigla=(string)$d['titular_cargo']; ?>
        <article class="direction-card">
          <div class="direction-card-top"><span class="dir-letter"><?= arca_h($sigla) ?></span><span class="dir-arrow">↗</span></div>
          <h3><?= arca_h($d['nombre_direccion']) ?></h3>
          <p><?= arca_h($explicacion[$sigla] ?? $d['enfoque_control']) ?></p>
          <a href="<?= arca_h($mapa[$sigla]) ?>">Abrir panel ejecutivo →</a>
        </article>
        <?php endforeach; ?>
      </div>
    </section>
    <div class="content-split">
      <section class="surface-panel" id="obras">
        <div class="surface-panel-header"><div><h3>Obras y proyectos</h3><div class="small" style="margin-top:5px">Listado basado en la tabla proyectos</div></div><span class="tag"><?= number_format($totalObras) ?> obras</span></div>
        <div style="padding:0 20px 16px"><input id="buscar-obra" aria-label="Buscar obra o ubicación" type="search" placeholder="Buscar obra o ubicación..." style="width:100%;border:1px solid var(--arca-line);border-radius:9px;padding:11px 13px;outline:none;background:#fcfdfe;color:var(--arca-ink)"></div>
        <div class="data-table-wrap"><table class="data-table" id="tabla-obras"><thead><tr><th>Obra</th><th>Ubicación</th><th>Presupuesto</th><th>Clasificación</th></tr></thead><tbody>
          <?php foreach($obras as $obra): ?>
          <tr><td><strong><?= arca_h($obra['nombre_obra']) ?></strong><div class="code-chip">#<?= (int)$obra['id_proyecto'] ?> · <?= arca_h($obra['estado']) ?></div></td><td><?= arca_h($obra['ubicacion']) ?></td><td>$<?= number_format((float)$obra['presupuesto']/1000000,1) ?> M</td><td><span class="tag <?= $obra['categoria']==='Federal' ? 'tag--federal':'' ?>"><?= arca_h($obra['categoria']) ?></span></td></tr>
          <?php endforeach; ?>
          </tbody></table></div>
      </section>
      <section class="surface-panel" aria-label="Resumen de la estructura">
        <div class="surface-panel-header"><h3>Estructura corporativa</h3></div>
        <div class="support-list">
          <div class="support-item"><span class="support-icon">▤</span><div><b><?= number_format(count($principales)) ?> direcciones ejecutivas</b><small>Coordinación estratégica y funcional</small></div></div>
          <div class="support-item"><span class="support-icon">▧</span><div><b><?= number_format($totalGerencias) ?> gerencias</b><small>Distribuidas entre las direcciones</small></div></div>
          <div class="support-item"><span class="support-icon">▩</span><div><b><?= number_format($totalPuestos) ?> puestos catalogados</b><small>Catálogo de la estructura actual</small></div></div>
          <div class="support-item"><span class="support-icon">♧</span><div><b><?= number_format($totalAsignaciones) ?> asignaciones de obra</b><small>Registros operativos; no personas únicas</small></div></div>
          <?php foreach($tipos as $tipo): ?><div class="support-item"><span class="support-icon">⌂</span><div><b><?= (int)$tipo['total'] ?> obras <?= arca_h(strtolower((string)$tipo['categoria'])) ?></b><small>Clasificación registrada en proyectos</small></div></div><?php endforeach; ?>
        </div>
      </section>
    </div>
    <section class="content-section" id="estructura">
      <div class="section-heading"><div><h2>Organización y áreas de apoyo</h2><p>Recursos corporativos para la operación y la supervisión.</p></div></div>
      <p style="margin:0 0 18px"><a href="panel_ceo_detalle_legacy.php" class="btn btn-secondary">Consultar catálogo jerárquico original →</a></p>
      <div class="org-row">
        <article class="org-tile"><span class="eyebrow">Nivel 2</span><h4>Gerencias y departamentos</h4><p><?= $totalGerencias ?> gerencias registradas, con sus departamentos y puestos subordinados.</p><a href="panel_departamentos_arca.php" class="text-link" style="display:inline-block;margin-top:12px">Acceder a departamentos →</a></article>
        <article class="org-tile"><span class="eyebrow">Operación</span><h4>Personal asignado a obra</h4><p>Consulta de equipos, jerarquías, frentes y cuadrillas por proyecto.</p><a href="panel_estructura_arca.php" class="text-link" style="display:inline-block;margin-top:12px">Ver asignaciones →</a></article>
        <article class="org-tile"><span class="eyebrow">Recursos</span><h4>Oficina técnica y almacén</h4><p>Gestión de documentos técnicos, planos, materiales y existencias.</p><a href="panel_oficina_almacen.php" class="text-link" style="display:inline-block;margin-top:12px">Abrir módulo →</a></article>
      </div>
      <?php if ($apoyo): ?><div class="section-heading" style="margin-top:26px"><div><h2>Áreas de apoyo</h2><p>Áreas del directorio corporativo, distintas de las ocho direcciones ejecutivas.</p></div></div>
      <div class="org-row"><?php foreach($apoyo as $area): ?><article class="org-tile"><span class="eyebrow"><?= arca_h($area['titular_cargo']) ?></span><h4><?= arca_h($area['nombre_direccion']) ?></h4><p><?= arca_h($area['enfoque_control']) ?></p></article><?php endforeach; ?></div><?php endif; ?>
    </section>
    <p class="section-footer">ARCA CONSTRUCTION · Datos consultados desde la base de ARCA · Plataforma interna</p>
  </main>
</div>
<script>
  const entrada=document.getElementById('buscar-obra');
  if(entrada){entrada.addEventListener('input',()=>{const s=entrada.value.toLocaleLowerCase('es');document.querySelectorAll('#tabla-obras tbody tr').forEach(tr=>tr.hidden=!tr.textContent.toLocaleLowerCase('es').includes(s));});}
</script>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>
