<?php
// ARCA CONSTRUCTION · Fase 2, dirección CCO.
$arca_area = 'CCO';
require __DIR__ . '/includes/panel_directivo.php';
