# ARCA CONSTRUCTION | Fase 40: presentación corporativa (menú + F32–F36)

## Contenido

Este paquete actualiza **solo presentación y navegación** de seis archivos existentes:

- `includes/arca27.php`: encabezado, pie de página, estilo compartido y enlaces del menú sujetos a los roles originales.
- `arca32_auditoria.php`: Auditoría integral.
- `arca33_preparacion.php`: Configuración operativa.
- `arca34_calidad.php`: Centro de calidad.
- `arca35_pruebas.php`: Verificación operativa.
- `arca36_infraestructura.php`: Infraestructura y continuidad.
- Nuevo CSS: `assets/css/arca40_corporativo.css`.

Los seis archivos PHP completos adaptados desde los paquetes originales están disponibles en `referencia/` **solo para comparación**. **No es seguro copiarlos manualmente sobre una versión personalizada del ERP**: podrían perderse cambios posteriores.

El instalador trabaja sobre los **archivos actuales en tu carpeta de Laragon** y sustituye únicamente cadenas de presentación identificadas. Preserva el resto del archivo original, las validaciones de permisos, los formularios, las consultas y la lógica de las fases anteriores. Si el menú no tiene una estructura reconocible, bloquea la actualización. No altera la base de datos.

## Preparación obligatoria

1. Respalda **toda** la carpeta `C:\laragon\www\ARCA_CONSTRUCTION_FASE1`, la base de datos `arca_bd_fase1` y el almacén privado documental. Verifica el respaldo antes de cambiar archivos.
2. Extrae este ZIP completo **en `C:\laragon`** y conserva la estructura interna.
3. Confirma que existe `C:\laragon\ARCA_FASE40_CORPORATIVA_F32_F36\scripts\instalar.php`.
4. Detén cualquier edición simultánea de estos seis archivos en Visual Studio Code mientras aplicas la actualización.

## 1. Vista previa (sin modificar nada)

Desde Cmder / Terminal de Laragon:

```bat
php "C:\laragon\ARCA_FASE40_CORPORATIVA_F32_F36\scripts\instalar.php" --project="C:\laragon\www\ARCA_CONSTRUCTION_FASE1"
```

Resultado esperado: `VISTA PREVIA CORRECTA` con siete rutas, o `BLOQUEADO` explicando el archivo que necesita revisión. **Si indica BLOQUEADO, no ejecutes `--apply`.**

## 2. Aplicación con respaldo adicional

Solo si la vista previa fue correcta y ya existe el respaldo completo del proyecto:

```bat
php "C:\laragon\ARCA_FASE40_CORPORATIVA_F32_F36\scripts\instalar.php" --project="C:\laragon\www\ARCA_CONSTRUCTION_FASE1" --apply
```

Se genera un respaldo adicional de **todos los archivos que se modifiquen** fuera de la carpeta `www` en:

`C:\laragon\ARCA_RESPALDO_F40_YYYYMMDD_HHMMSS_...`

El instalador hace una copia y verifica su huella SHA-256 antes de sobrescribir. Si el archivo CSS ya existe pero es distinto, detiene el proceso y requiere revisión manual. Ejecutarlo por segunda vez no duplica enlaces ni estilos.

## 3. Verificación de sintaxis

Ejecuta **un comando por línea** (o uno por uno):

```bat
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\includes\arca27.php"
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\arca32_auditoria.php"
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\arca33_preparacion.php"
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\arca34_calidad.php"
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\arca35_pruebas.php"
php -l "C:\laragon\www\ARCA_CONSTRUCTION_FASE1\arca36_infraestructura.php"
```

Los seis deben indicar `No syntax errors detected`.

## 4. Verificación funcional en Chrome

1. Inicia sesión con `CEO-001`.
2. Abre las cinco rutas directas:
   - `http://arca.test/arca32_auditoria.php`
   - `http://arca.test/arca33_preparacion.php`
   - `http://arca.test/arca34_calidad.php`
   - `http://arca.test/arca35_pruebas.php`
   - `http://arca.test/arca36_infraestructura.php`
3. Comprueba el menú lateral: enlaces corporativos a los módulos F32–F39, sin duplicaciones y sin rótulos de fase. Cambia de pantalla y verifica que la navegación y el logout funcionan.
4. Valida al menos una visualización con `CIO-001` y confirma que **no puede** consultar auditoría global F32, centro de calidad F34 ni validación global F39; sí puede acceder a su configuración operativa, verificación e infraestructura.
5. Prueba CHRO/CFO/COO: no deben recibir privilegios nuevos por el menú. Revisa las vistas F37/F38 según sus permisos existentes.
6. Consulta F39: la incidencia `BKP03-F33` y los pendientes documentados deben conservar sus estados y su bitácora.
7. Haz `Ctrl+Shift+R` para vaciar la caché si ves un CSS antiguo.

## Criterios de seguridad y honestidad operativa

- Se eliminan **leyendas técnicas innecesarias** de las pantallas de usuario, no registros ni condiciones pendientes.
- Los controles como `AVISO`, `PENDIENTE`, `HABILITACIÓN PENDIENTE`, `ABIERTA` y el resto de estados **permanecen**; el paquete no afirma una certificación que no existe.
- Los procedimientos exactos de respaldo y recuperación se documentan en guías de administración, no se muestran como rutas técnicas en la interfaz principal.
- La Fase 40 es una **actualización visual para presentación interna**. No implementa HTTPS, no corrige monedas sin soporte documental, no valida contratos ni convierte pruebas pendientes en aprobadas.
- La publicación real continúa condicionada a evidencias de restauración, seguridad, controles de acceso y aceptación. No habilites datos reales en producción sin ese proceso.

## Si aparece un error

- `BLOQUEADO: ...`: guarda una copia del resultado y compara el archivo indicado con el de `referencia/`. No lo reemplaces a ciegas.
- Si la vista se rompe, restaura primero el archivo afectado desde la carpeta `ARCA_RESPALDO_F40_...` o desde tu respaldo general.
- Este paquete no requiere comandos SQL, migraciones ni desinstalación de fases anteriores.
