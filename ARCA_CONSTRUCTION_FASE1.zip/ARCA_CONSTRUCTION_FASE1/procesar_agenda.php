<?php
// 1. Candado de seguridad RBAC para el área administrativa
session_start();
$roles_admin = ['Secretaria / Asistente', 'Secretaria'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_admin)) {
    header("Location: login.html");
    exit();
}

// 2. Conexión a la base de datos
include("conexion.php");

// 3. Verificamos que los datos del nuevo formulario hayan llegado por el método POST
if (isset($_POST['fecha']) && isset($_POST['asunto'])) {
    
    // Capturamos las variables enviadas por la Secretaria
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $asunto = $_POST['asunto'];
    $modalidad = $_POST['modalidad'];

    // 4. Sentencias Preparadas para inyectar los datos de forma segura
    $stmt = $conectar->prepare("INSERT INTO agenda_juntas (fecha, hora, asunto, modalidad) VALUES (?, ?, ?, ?)");
    
    // "ssss" indica que los 4 datos se envían como cadenas de texto (String)
    $stmt->bind_param("ssss", $fecha, $hora, $asunto, $modalidad);
    
    // 5. Interfaz gráfica de respuesta para el usuario
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Procesando Agenda</title>";
    echo "<style>body { font-family: Arial; text-align: center; padding: 50px; background-color: #f4f6f7; }</style></head><body>";
    
    if ($stmt->execute()) {
        echo "<h2 style='color: #8e44ad;'>✅ Junta Corporativa Agendada</h2>";
        echo "<p>La reunión sobre <b>$asunto</b> ha sido programada para el <b>$fecha</b> a las <b>$hora</b>.</p>";
        echo "<p>Modalidad: <b>$modalidad</b>.</p>";
    } else {
        echo "<h2 style='color: #e74c3c;'>❌ Error al agendar la reunión</h2>";
        echo "<p>Detalle técnico: " . $conectar->error . "</p>";
    }
    
    $stmt->close();
    
    echo "<br><br><a href='formulario_agenda.php' style='padding: 10px 20px; background: #8e44ad; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;'>Agendar otra reunión</a>";
    echo "<br><br><a href='panel_administrativo.php' style='color: #34495e; text-decoration: none; font-weight: bold; display: block; margin-top: 20px;'>← Volver al Panel Administrativo</a>";
    echo "</body></html>";
} else {
    echo "<h3>Error de sistema: No se recibieron los datos de la agenda.</h3>";
}

$conectar->close();
?>