<?php
declare(strict_types=1);
/** ARCA Fases 29 y 30. El circuito DEMO jamás escribe en tablas laborales reales. */
require_once __DIR__.'/arca28_rh.php';

function a30_db_demo(mysqli $db): bool {
    $r=arx_one($db,'SELECT DATABASE() AS base');
    return ($r['base']??'')==='arca_bd_fase1';
}
function a30_ensure_demo(mysqli $db): void {
    if (!a30_db_demo($db)) throw new DomainException('La demostración no está habilitada en esta instalación.');
}
function a30_fecha_activa(string $inicio, ?string $fin, ?string $hoy=null): bool {
    $hoy??=date('Y-m-d');
    return $inicio<=$hoy && (!$fin || $fin>=$hoy);
}
function a30_roles(): array { return ['CEO','Director General','CHRO','COO']; }
function a30_obra_autorizada(mysqli $db,string $code,string $nivel='consultar'): bool {
    return a28_obra_acceso($db,$code,$nivel);
}
function a30_no_duplicate(mysqli $db,string $obra,string $func,?int $exclude=null): bool {
    $sql='SELECT id_caso FROM arca30_demo_casos WHERE codigo_obra=? AND funcion=?'.($exclude!==null?' AND id_caso<>?':'').' LIMIT 1';
    return arx_one($db,$sql,$exclude!==null?[$obra,$func,$exclude]:[$obra,$func])!==null;
}
function a29_storage(): string {
    // En Laragon, carpeta privada fuera de C:\\laragon\\www.
    $path=(string)(getenv('ARCA_F29_DOCUMENT_DIR') ?: dirname(__DIR__,3).'/ARCA_DOCUMENTOS_PRIVADOS/ERP_F29');
    if(!is_dir($path) && !mkdir($path,0700,true) && !is_dir($path)) throw new RuntimeException('No se pudo crear el almacén privado de documentos.');
    $abs=realpath($path);$public=realpath(dirname(__DIR__,2));
    if(!$abs||!$public)throw new RuntimeException('No se pudo comprobar la ubicación del almacén privado.');
    $a=strtolower(str_replace('\\','/',$abs));$w=strtolower(str_replace('\\','/',$public));
    if($a===$w || str_starts_with($a,$w.'/'))throw new RuntimeException('La carpeta de documentos debe quedar fuera del directorio www.');
    return $abs;
}
function a29_validar_archivo(array $f): array {
    $err=(int)($f['error']??UPLOAD_ERR_NO_FILE);
    if($err!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Carga fallida. Revisa el límite upload_max_filesize/post_max_size de PHP.');
    $size=(int)($f['size']??0);$tmp=(string)($f['tmp_name']??'');
    if($size<10||$size>6*1024*1024||!is_uploaded_file($tmp))throw new InvalidArgumentException('Se requiere PDF válido de máximo 6 MB.');
    $fh=fopen($tmp,'rb');$magic=$fh?fread($fh,5):'';if($fh)fclose($fh);
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    if($magic!=='%PDF-'||$mime!=='application/pdf')throw new InvalidArgumentException('Solo archivos PDF válidos.');
    $name=trim((string)($f['name']??''));
    if(!preg_match('/\.pdf$/i',$name))throw new InvalidArgumentException('El documento debe tener extensión .pdf.');
    $name=basename(str_replace('\\','/',$name));
    $name=substr(preg_replace('/[^a-zA-Z0-9._-]/','_', $name),0,150);
    return [$tmp,$size,$name,hash_file('sha256',$tmp)];
}
function a30_flash(string $msg,bool $error=false): void {a27_alert($msg,$error);}
function a30_redirect(string $url):never {a27_redirect($url);}
function a30_case(mysqli $db,int $id,bool $lock=false):?array {
    return arx_one($db,'SELECT x.*,e.nombre_completo,e.numero_empleado FROM arca30_demo_casos x JOIN arca_empleados e ON e.id_empleado=x.id_empleado WHERE x.id_caso=?'.($lock?' FOR UPDATE':''),[$id]);
}
function a30_has_pdf(mysqli $db,int $id):bool {
    return arx_one($db,"SELECT id_documento FROM arca29_documentos WHERE origen='DEMO' AND id_demo_caso=? LIMIT 1",[$id])!==null;
}
function a30_can_read_document(mysqli $db,array $doc):bool {
    // Un expediente laboral o un PDF de la simulación solo puede descargarse con sesión CHRO.
    if(arx_role()!=='CHRO')return false;
    if($doc['origen']==='DEMO') {
        $case=a30_case($db,(int)$doc['id_demo_caso']);
        return $case && a30_db_demo($db) && a30_obra_autorizada($db,$case['codigo_obra'],'consultar');
    }
    return $doc['origen']==='REAL';
}
