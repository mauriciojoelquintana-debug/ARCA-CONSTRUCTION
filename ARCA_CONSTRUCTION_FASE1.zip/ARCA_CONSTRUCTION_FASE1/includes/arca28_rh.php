<?php
declare(strict_types=1);
/** ARCA RH F28. Utilidades reutilizables. No cambia registros por sí solo. */
require_once __DIR__.'/arca27.php';

function a28_functions(): array {
    return [
        'GERENTE_PROYECTO'=>'Gerente de Proyecto',
        'RESIDENTE_OBRA'=>'Residente de Obra',
        'ARQUITECTO'=>'Arquitecto',
        'INGENIERO_CIVIL'=>'Ingeniero Civil',
    ];
}
function a28_cargo_coincide(string $func, string $cargo): bool {
    $cargo=function_exists('mb_strtolower')?mb_strtolower($cargo,'UTF-8'):strtolower($cargo);
    return match ($func) {
        'GERENTE_PROYECTO' => str_contains($cargo,'gerente de proyecto'),
        'RESIDENTE_OBRA' => str_contains($cargo,'residente') || str_contains($cargo,'superintendente de obra'),
        'ARQUITECTO' => str_contains($cargo,'arquitect'),
        'INGENIERO_CIVIL' => str_contains($cargo,'ingeniero civil'),
        default => false,
    };
}
function a28_obra_acceso(mysqli $db, string $code, string $nivel='consultar'): bool {
    if(!a27_can_obra($db,$code,$nivel)) return false;
    // Obras clasificadas: no heredar el acceso universal de COO/CHRO.
    if(str_starts_with($code,'ARCA-SEC-') && !in_array(arx_role(),['CEO','Director General'],true)) {
        $row=arx_one($db,'SELECT nivel FROM arca_accesos_obra WHERE id_usuario=? AND codigo_obra=?',[arx_uid(),$code]);
        $niveles=['consultar'=>1,'operar'=>2,'aprobar'=>3];
        return $row!==null && ($niveles[(string)$row['nivel']]??0)>=($niveles[$nivel]??99);
    }
    return true;
}
function a28_fecha_vigente(?string $inicio, ?string $fin, ?string $estado, ?string $hoy=null): bool {
    $hoy??=date('Y-m-d');
    return $estado==='VIGENTE' && $inicio!==null && $inicio<=$hoy && ($fin===null||$fin===''||$fin>=$hoy);
}
function a28_asignacion_vigente(?string $inicio,?string $fin,?string $estado,?string $hoy=null): bool {
    $hoy??=date('Y-m-d');
    return $estado==='ACTIVA' && $inicio!==null && $inicio<=$hoy && ($fin===null||$fin===''||$fin>=$hoy);
}
function a28_contrato_vigente(mysqli $db,int $employee,?string $hoy=null,bool $lock=false): ?array {
    $hoy??=date('Y-m-d');
    return arx_one($db,"SELECT id_contrato,tipo,inicio,fin,estado FROM arca_contratos_laborales WHERE id_empleado=? AND estado='VIGENTE' AND inicio<=? AND (fin IS NULL OR fin>=?) ORDER BY inicio DESC,id_contrato DESC LIMIT 1".($lock?' FOR UPDATE':''),[$employee,$hoy,$hoy]);
}
function a28_validar_asignacion(mysqli $db,int $id,?string $expectedWork=null,?string $func=null,bool $lock=false): array {
    $sql="SELECT a.id_asignacion,a.id_empleado,a.codigo_obra,a.cargo_obra,a.fecha_inicio,a.fecha_fin,a.estado,e.nombre_completo,e.numero_empleado,e.tipo_personal,e.estado_laboral FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.id_asignacion=?".($lock?' FOR UPDATE':'');
    $a=arx_one($db,$sql,[$id]);
    if(!$a) throw new InvalidArgumentException('No existe la asignación de obra.');
    if($expectedWork!==null && $a['codigo_obra']!==$expectedWork)throw new InvalidArgumentException('La asignación no pertenece a la obra.');
    if($a['estado_laboral']!=='ACTIVO' || $a['tipo_personal']!=='PROPIO')throw new InvalidArgumentException('Expediente laboral propio no validado.');
    if(!arx_one($db,"SELECT entidad_id FROM arca_auditoria_modulos WHERE modulo='CHRO' AND entidad='arca_empleados' AND entidad_id=? AND accion='VALIDAR_DOCUMENTOS' LIMIT 1",[(int)$a['id_empleado']]))throw new InvalidArgumentException('La auditoría documental no está disponible.');
    if(!a28_asignacion_vigente($a['fecha_inicio'],$a['fecha_fin'],$a['estado']))throw new InvalidArgumentException('Asignación fuera de vigencia o finalizada.');
    if($func!==null && !a28_cargo_coincide($func,(string)$a['cargo_obra'])) throw new InvalidArgumentException('El cargo de obra no corresponde a la responsabilidad propuesta.');
    $c=a28_contrato_vigente($db,(int)$a['id_empleado'],null,$lock);
    if(!$c)throw new InvalidArgumentException('Empleado sin contrato registrado y vigente.');
    if($a['fecha_inicio']<$c['inicio']) throw new InvalidArgumentException('La asignación inicia antes del contrato vigente.');
    if($c['fin']!==null && ($a['fecha_fin']===null||$a['fecha_fin']>$c['fin']))throw new InvalidArgumentException('El periodo de asignación excede el contrato.');
    return $a;
}
/**
 * Bloquea las operaciones heredadas que permitían saltarse la validación documental.
 * La instalación incorpora esta función al principio de chro_guardar.php sin sustituirlo.
 */
function a28_guard_legacy(array $post):void {
    $act=(string)($post['accion']??'');
    $prohibida=$act==='asignacion'
        || ($act==='estado' && ($post['estado']??'')==='ACTIVO')
        || ($act==='contrato_estado' && ($post['estado']??'')==='VIGENTE');
    if($prohibida){
        http_response_code(409);
        exit('Utiliza el módulo de validación documental para realizar esta acción.');
    }
}
