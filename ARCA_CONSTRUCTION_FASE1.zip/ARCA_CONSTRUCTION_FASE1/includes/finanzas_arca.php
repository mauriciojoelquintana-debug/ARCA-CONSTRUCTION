<?php
/** ARCA · Finanzas con operaciones, filtros, CSV y bitácora. */
require_once __DIR__ . '/seguridad.php';
require_once __DIR__ . '/finanzas_utilidades.php';
arca_requerir_roles(['CFO','CEO','Director General']);
require __DIR__ . '/../conexion.php';

$modulos = arca_fin_modulos();
$modulo = (string)($_GET['modulo'] ?? 'presupuesto');
if (!isset($modulos[$modulo])) { http_response_code(404); exit('Módulo financiero no disponible.'); }
$codObra = arca_fin_filtrar_obra((string)($_GET['obra'] ?? ''));
$esCfo = trim((string)($_SESSION['rol_activo'] ?? '')) === 'CFO';
$nombre = (string)($_SESSION['nombre_usuario'] ?? 'Usuario ARCA');
$numero = (string)($_SESSION['usuario_activo'] ?? '');
$inicial = function_exists('mb_substr') ? mb_strtoupper(mb_substr($nombre,0,1,'UTF-8'),'UTF-8') : strtoupper(substr($nombre,0,1));
$token = arca_token();
$auditoriaDisponible = arca_fin_auditoria_disponible($conectar);
$filtrado = 'WHERE modulo = ?';
if ($codObra !== '') $filtrado .= ' AND codigo_obra = ?';
$consulta = function(string $sql) use ($conectar,$modulo,$codObra): mysqli_result {
    $stmt = $conectar->prepare($sql);
    if ($codObra !== '') $stmt->bind_param('ss',$modulo,$codObra); else $stmt->bind_param('s',$modulo);
    $stmt->execute();
    $r = $stmt->get_result();
    $stmt->close();
    return $r;
};
$errorLectura = false; $obras=[]; $filas=[]; $bitacora=[]; $monedasResumen=[]; $divisaUnica=null;
$resumen=['cantidad'=>0,'total'=>0,'por_resolver'=>0,'fecha_ultima'=>null];
try {
    $obras = $conectar->query('SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra')->fetch_all(MYSQLI_ASSOC);
    $r=$consulta("SELECT COUNT(*) AS cantidad, COALESCE(SUM(monto),0) AS total,
        COALESCE(SUM(CASE WHEN estado_pago IN ('Pendiente','Programado','Vencido') THEN monto ELSE 0 END),0) AS por_resolver,
        MAX(fecha_transaccion) AS fecha_ultima FROM finanzas_coo $filtrado");
    $resumen=$r->fetch_assoc() ?: $resumen;
    $m=$consulta("SELECT COALESCE(moneda,'SIN DEFINIR') AS moneda,COUNT(*) cantidad FROM finanzas_coo $filtrado GROUP BY COALESCE(moneda,'SIN DEFINIR')");
    $monedasResumen=$m->fetch_all(MYSQLI_ASSOC);
    if(count($monedasResumen)===1 && in_array($monedasResumen[0]['moneda'],['USD','MXN'],true)) $divisaUnica=$monedasResumen[0]['moneda'];
    $r=$consulta("SELECT id_finanza,codigo_obra,nombre_proyecto,concepto,monto,moneda,categoria_costo,estado_pago,fecha_transaccion
        FROM finanzas_coo $filtrado ORDER BY fecha_transaccion DESC,id_finanza DESC LIMIT 120");
    $filas=$r->fetch_all(MYSQLI_ASSOC);
    if ($auditoriaDisponible) {
        $r=$conectar->query('SELECT id_finanza,usuario_actor,accion,modulo,fecha_accion FROM arca_finanzas_bitacora ORDER BY id_bitacora DESC LIMIT 10');
        $bitacora=$r->fetch_all(MYSQLI_ASSOC);
    }
} catch (Throwable $e) {
    error_log('ARCA consulta CFO: '.$e->getMessage()); $errorLectura=true;
}
$notificacion = $_SESSION['arca_fin_flash'] ?? null;
unset($_SESSION['arca_fin_flash']);
$titulo=$modulos[$modulo]['titulo'];
$urlCSV='finanzas_exportar.php?modulo='.rawurlencode($modulo).($codObra!==''?'&obra='.rawurlencode($codObra):'');
$urlModulo=function(string $k) use ($codObra):string{return 'herramientas_cfo.php?modulo='.rawurlencode($k).($codObra!==''?'&obra='.rawurlencode($codObra):'');};
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title><?= arca_h($titulo) ?> · CFO | ARCA CONSTRUCTION</title>
<link rel="stylesheet" href="assets/css/arca.css?v=4">
<link rel="stylesheet" href="assets/css/arca-finanzas.css?v=4">
</head>
<body>
<div class="app-layout">
<aside class="app-sidebar fin-sidebar">
  <a href="panel_cfo.php" class="sidebar-brand"><span class="brand-mark">A</span><span><span class="brand-name">ARCA CONSTRUCTION</span><span class="brand-sub" style="display:block">Sistema de gestión ERP</span></span></a>
  <span class="nav-label">Dirección Financiera</span>
  <nav class="app-nav" aria-label="Secciones de Finanzas">
  <a href="panel_cfo.php"><span class="nav-icon">⌂</span> Resumen del CFO</a>
  <?php foreach ($modulos as $clave=>$op): ?>
  <a href="<?= arca_h($urlModulo($clave)) ?>" <?= $modulo===$clave?'aria-current="page"':'' ?>><span class="nav-icon">▤</span><?= arca_h($op['titulo']) ?></a>
  <?php endforeach; ?>
  </nav>
  <span class="nav-label">Herramientas</span><nav class="app-nav"><a href="finanzas_auditoria.php"><span class="nav-icon">▣</span> Auditoría por obra y divisa</a><a href="#movimientos"><span class="nav-icon">≡</span> Movimientos</a><a href="#bitacora"><span class="nav-icon">◷</span> Bitácora</a>
  <?php if (!$esCfo): ?><a href="panel_ceo.php"><span class="nav-icon">↩</span> Volver al CEO</a><?php endif; ?>
  </nav>
  <div class="sidebar-end"><div class="sidebar-user"><span class="user-avatar"><?= arca_h($inicial) ?></span><div><span class="user-identity" style="display:block"><?= arca_h($nombre) ?></span><span class="user-meta"><?= arca_h($numero) ?></span></div></div><a href="cerrar_sesion.php" class="sidebar-logout">↪ Cerrar sesión</a></div>
</aside>
<main class="app-main fin-main">
<header class="app-topbar"><div class="app-breadcrumb">ARCA CONSTRUCTION / <a href="panel_cfo.php">Finanzas</a> / <b><?= arca_h($titulo) ?></b></div><span class="status-pill"><span class="status-dot"></span> Gestión financiera</span></header>
<section class="fin-intro">
<div><span class="eyebrow">CFO · CONTROL FINANCIERO</span><h1><?= arca_h($titulo) ?></h1><p><?= arca_h($modulos[$modulo]['subtitulo']) ?></p></div>
<a class="btn btn-secondary" href="<?= arca_h($urlCSV) ?>">↓ Exportar CSV</a>
</section>
<div class="fin-legal-note"><b>Divisa real por transacción.</b> Los registros históricos sin moneda confirmada se muestran como SIN DEFINIR. No se suman divisas diferentes: usa <a href="finanzas_auditoria.php"><b>Conciliación por obra</b></a> para revisar importes por USD/MXN y clasificar costos.</div>
<?php if (!$esCfo): ?><div class="fin-flash">Vista de consulta de Dirección General: el registro y los cambios de estado están reservados al CFO.</div><?php endif; ?>
<?php if (!$auditoriaDisponible): ?><div class="fin-flash fin-warning"><b>Registro de operaciones deshabilitado.</b> Comunícate con el área de Sistemas para habilitar el registro con auditoría.</div><?php endif; ?>
<?php if ($errorLectura): ?><div class="fin-flash fin-warning">No fue posible cargar toda la información. Comunícate con el área de Sistemas.</div><?php endif; ?>
<?php if (is_array($notificacion)): ?><div role="status" class="fin-flash <?= ($notificacion[0] ?? '')==='error'?'fin-warning':'' ?>"><?= arca_h((string)($notificacion[1] ?? '')) ?></div><?php endif; ?>
<section class="fin-summary">
  <article class="fin-kpi"><span>Importe total del módulo</span><strong><?= arca_h($divisaUnica ? arca_fin_dinero_real($resumen['total'],$divisaUnica) : 'Ver desglose por moneda') ?></strong><small>Suma de registros mostrados y no mostrados</small></article>
  <article class="fin-kpi"><span>Pendiente / programado / vencido</span><strong><?= arca_h($divisaUnica ? arca_fin_dinero_real($resumen['por_resolver'],$divisaUnica) : 'Ver desglose por moneda') ?></strong><small>Compromisos sin estado final; no es saldo bancario</small></article>
  <article class="fin-kpi"><span>Movimientos registrados</span><strong><?= number_format((int)$resumen['cantidad'],0,'.',',') ?></strong><small>Registros del módulo y filtro de obra</small></article>
  <article class="fin-kpi"><span>Fecha más reciente registrada</span><strong class="fin-date"><?= $resumen['fecha_ultima'] ? arca_h(date('d/m/Y',strtotime((string)$resumen['fecha_ultima']))) : '—' ?></strong><small>Fecha del movimiento, no de actualización</small></article>
</section>
<section id="movimientos" class="fin-surface">
<div class="fin-section-title"><div><h2>Movimientos financieros</h2><p>Consulta los folios, filtra por obra y busca registros. Se muestran hasta 120 por página.</p></div><span class="fin-count"><?= number_format((int)$resumen['cantidad']) ?> registros</span></div>
<form action="herramientas_cfo.php" method="get" class="fin-filters"><input type="hidden" name="modulo" value="<?= arca_h($modulo) ?>">
<label>Obra<select name="obra"><option value="">Todas las obras</option><?php foreach ($obras as $obra): ?><option value="<?= arca_h($obra['codigo_obra']) ?>" <?= $codObra===$obra['codigo_obra']?'selected':'' ?>><?= arca_h($obra['codigo_obra'].' · '.$obra['nombre_proyecto']) ?></option><?php endforeach; ?></select></label>
<button type="submit" class="btn btn-primary">Aplicar filtro</button><a href="<?= arca_h($urlModulo($modulo)) ?>" class="btn btn-secondary">Recargar</a>
<label class="fin-search">Buscar en esta tabla<input type="search" id="fin-buscar" placeholder="Concepto, obra, estado..." autocomplete="off"></label>
</form>
<div class="fin-table-wrap"><table class="fin-table" id="fin-tabla"><thead><tr><th>Folio</th><th>Obra</th><th>Concepto</th><th>Importe</th><th>Fecha</th><th>Estado / Actualización</th></tr></thead><tbody>
<?php foreach($filas as $fila): ?><tr><td><span class="fin-folio">#<?= (int)$fila['id_finanza'] ?></span></td><td><b><?= arca_h($fila['codigo_obra']) ?></b><small><?= arca_h($fila['nombre_proyecto']) ?></small></td><td><?= arca_h($fila['concepto']) ?></td><td class="fin-money"><?= arca_h(arca_fin_dinero_real($fila['monto'],$fila['moneda'])) ?></td><td><?= arca_h(date('d/m/Y',strtotime((string)$fila['fecha_transaccion']))) ?></td><td>
<span class="fin-state <?= arca_h(arca_fin_estado_estilo((string)$fila['estado_pago'])) ?>"><?= arca_h($fila['estado_pago']) ?></span>
<?php if ($esCfo && $auditoriaDisponible): ?>
<form action="finanzas_guardar.php" method="post" class="fin-inline-form"><input type="hidden" name="csrf_token" value="<?= arca_h($token) ?>"><input type="hidden" name="accion" value="estado"><input type="hidden" name="modulo" value="<?= arca_h($modulo) ?>"><input type="hidden" name="obra_filtro" value="<?= arca_h($codObra) ?>"><input type="hidden" name="id_finanza" value="<?= (int)$fila['id_finanza'] ?>">
<select name="estado_pago" aria-label="Nuevo estado del folio <?= (int)$fila['id_finanza'] ?>"><?php foreach(arca_fin_estados($modulo) as $estado): ?><option value="<?= arca_h($estado) ?>" <?= $fila['estado_pago']===$estado?'selected':'' ?>><?= arca_h($estado) ?></option><?php endforeach; ?></select><button type="submit" title="Guardar cambio de estado">Guardar</button></form>
<?php endif; ?></td></tr><?php endforeach; ?>
<?php if (!$filas): ?><tr class="fin-empty"><td colspan="6">No existen movimientos para este módulo y filtro.</td></tr><?php endif; ?>
</tbody></table></div><p class="fin-note">Mostrando <?= count($filas) ?> de <?= (int)$resumen['cantidad'] ?> registros. Utiliza «Exportar CSV» para descargar todos los que correspondan al filtro.</p>
</section>
<?php if ($esCfo): ?><section class="fin-surface" id="registro"><div class="fin-section-title"><div><h2>Registrar nuevo movimiento</h2><p>Los datos se guardarán en <code>finanzas_coo</code> y en la bitácora de operaciones.</p></div></div>
<?php if ($auditoriaDisponible): ?><form action="finanzas_guardar.php" method="post" class="fin-entry-form">
<input type="hidden" name="csrf_token" value="<?= arca_h($token) ?>"><input type="hidden" name="accion" value="crear"><input type="hidden" name="modulo" value="<?= arca_h($modulo) ?>"><input type="hidden" name="obra_filtro" value="<?= arca_h($codObra) ?>">
<label>Obra<select name="codigo_obra" required><option value="">Selecciona la obra</option><?php foreach($obras as $obra): ?><option value="<?= arca_h($obra['codigo_obra']) ?>" <?= $codObra===$obra['codigo_obra']?'selected':'' ?>><?= arca_h($obra['codigo_obra'].' · '.$obra['nombre_proyecto']) ?></option><?php endforeach; ?></select></label>
<label class="fin-wide">Concepto<textarea name="concepto" maxlength="150" rows="2" placeholder="Descripción del movimiento" required></textarea></label>
<label>Importe<input type="number" name="monto" min="0.01" step="0.01" max="9999999999999.99" placeholder="0.00" required></label>
<label>Divisa real<select name="moneda" required><option value="">Selecciona</option><option value="USD">USD</option><option value="MXN">MXN</option></select></label><?php if ($modulo==='costos'): ?><label>Categoría de costo<select name="categoria_costo" required><option value="">Selecciona</option><?php foreach (['Materiales','Mano de obra','Maquinaria','Subcontratos','Transporte','Servicios','Indirectos','Otros'] as $categoria): ?><option value="<?= arca_h($categoria) ?>"><?= arca_h($categoria) ?></option><?php endforeach; ?></select></label><?php endif; ?><label>Fecha del movimiento<input type="date" name="fecha_transaccion" value="<?= date('Y-m-d') ?>" required></label>
<label>Estado inicial<select name="estado_pago" required><?php foreach(arca_fin_estados($modulo) as $estado): ?><option value="<?= arca_h($estado) ?>"><?= arca_h($estado) ?></option><?php endforeach; ?></select></label>
<div class="fin-wide fin-form-footer"><span>El registro no se elimina desde este módulo; los cambios de estado quedan auditados.</span><button class="btn btn-primary" type="submit">Guardar movimiento →</button></div>
</form><?php else: ?><div class="fin-inline-help">El registro de operaciones con auditoría no está disponible.</div><?php endif; ?></section><?php endif; ?>
<section id="bitacora" class="fin-surface"><div class="fin-section-title"><div><h2>Bitácora de actividad</h2><p>Últimas diez acciones registradas en Finanzas.</p></div></div>
<?php if ($auditoriaDisponible): ?><div class="fin-table-wrap"><table class="fin-table"><thead><tr><th>Movimiento</th><th>Usuario</th><th>Operación</th><th>Área</th><th>Fecha y hora</th></tr></thead><tbody><?php foreach($bitacora as $evento): ?><tr><td>#<?= (int)$evento['id_finanza'] ?></td><td><?= arca_h($evento['usuario_actor']) ?></td><td><?= arca_h($evento['accion']) ?></td><td><?= arca_h($evento['modulo']) ?></td><td><?= arca_h($evento['fecha_accion']) ?></td></tr><?php endforeach; ?><?php if (!$bitacora): ?><tr><td colspan="5">Todavía no se han registrado acciones desde esta versión.</td></tr><?php endif; ?></tbody></table></div>
<?php else: ?><div class="fin-inline-help">La bitácora no está disponible por el momento.</div><?php endif; ?></section>
<footer class="section-footer">ARCA CONSTRUCTION · Finanzas · Moneda por transacción</footer>
</main></div>
<script>(()=>{const q=document.getElementById('fin-buscar'),filas=[...document.querySelectorAll('#fin-tabla tbody tr:not(.fin-empty)')];if(q)q.addEventListener('input',()=>{const b=q.value.toLocaleLowerCase('es').trim();for(const tr of filas)tr.hidden=!tr.textContent.toLocaleLowerCase('es').includes(b);});})();</script>
</body></html>
