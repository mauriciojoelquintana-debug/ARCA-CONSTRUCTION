<?php
declare(strict_types=1);
/** ARCA · Fase 33: controles de configuración verificables desde el servidor. */
require_once __DIR__.'/arca32_auditoria.php';
function a33_roles(): array {return ['CEO','Director General','CIO'];}
function a33_control(string $area,string $nombre,string $estado,string $detalle,string $accion):array {return compact('area','nombre','estado','detalle','accion');}
function a33_comprobar(string $root, bool $enWeb = false): array {
    $items=[];
    $add=static function($area,$nombre,$estado,$detalle,$accion)use(&$items){$items[]=a33_control($area,$nombre,$estado,$detalle,$accion);};
    $ver=PHP_VERSION_ID>=80100;
    $add('Plataforma','Versión PHP',$ver?'OK':'CRITICO','PHP '.PHP_VERSION,'Utilizar una versión de PHP compatible y soportada.');
    foreach(['mysqli','fileinfo','openssl'] as $mod){
        $ok=extension_loaded($mod);$add('Plataforma',(['mysqli'=>'Acceso a información','fileinfo'=>'Reconocimiento de archivos','openssl'=>'Protección de comunicaciones'][$mod] ?? 'Componente de plataforma'),$ok?'OK':'CRITICO',$ok?'Habilitada':'No disponible','Configurar PHP para habilitar esta extensión.');
    }
    $zip=class_exists('ZipArchive');
    $add('Plataforma','Exportación ZIP',$zip?'OK':'AVISO',$zip?'ZipArchive disponible':'ZipArchive no está disponible','Instalar extensión zip si los módulos necesitan XLSX o ZIP.');
    $files=['conexion.php','ingreso.html','includes/arca27.php','includes/arca24_acceso_seguro.php','includes/arca29_30.php','includes/arca31_datos.php','arca29_documentos.php','arca30_demo.php','arca31_inteligencia.php','arca31_exportar.php','arca32_auditoria.php','arca33_preparacion.php'];
    $missing=[];foreach($files as $f)if(!is_file($root.'/'.$f))$missing[]=$f;
    $add('Archivos','Dependencias del ERP',$missing?'CRITICO':'OK',$missing?'Archivos ausentes: '.implode(', ',$missing):count($files).' archivos requeridos presentes','Conservar respaldos y no instalar piezas incompletas.');
    $exp=$root.'/arca31_exportar.php';$content=is_file($exp)?(string)file_get_contents($exp):'';
    $csv=(str_contains($content,'sep=;') && str_contains($content,'a31_csv_value'));
    $add('Reportes','CSV Excel y neutralización de fórmulas',$csv?'OK':'AVISO',$csv?'Reglas de exportación detectadas':'No se detectó una de las reglas esperadas','Revisar exportador antes de distribuir reportes.');
    $private=a32_almacen();$rootReal=realpath($root);$privReal=realpath($private);
    $public=$rootReal?realpath(dirname($rootReal)):false;
    $outside=$privReal && $public && !str_starts_with(strtolower(str_replace('\\','/',$privReal)).'/',strtolower(str_replace('\\','/',$public)).'/');
    $add('Documentos','Almacén fuera de www',!$privReal?'AVISO':($outside?'OK':'CRITICO'),
        !$privReal?'Almacén privado aún no encontrado':($outside?'Almacén no público verificado':'Carpeta dentro de un directorio público'),
        'Mantener documentos fuera de www con permisos mínimos; probar descarga CHRO y bloqueo de otros roles.');
    $dbg=filter_var(ini_get('display_errors'),FILTER_VALIDATE_BOOLEAN);
    $add('PHP','Mostrar errores al navegador',$dbg?'AVISO':'OK',$dbg?'display_errors está activo':'display_errors desactivado','En producción, desactivar display_errors y usar un registro protegido.');
    $httpOnly=filter_var(ini_get('session.cookie_httponly'),FILTER_VALIDATE_BOOLEAN);
    $add('Sesión','Cookie HttpOnly',$httpOnly?'OK':'AVISO',$httpOnly?'HttpOnly habilitado':'HttpOnly no habilitado','Configurar session.cookie_httponly=1 y verificar sesión real.');
    if($enWeb){
        $https=(!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS'])!=='off');
        $add('Transporte','HTTPS actual',$https?'OK':'AVISO',$https?'Solicitud con HTTPS':'Solicitud sin HTTPS','Configurar HTTPS y certificado válido antes de producción.');
        $secure=filter_var(ini_get('session.cookie_secure'),FILTER_VALIDATE_BOOLEAN);
        $add('Sesión','Cookie Secure',$secure?'OK':'AVISO',$secure?'Secure habilitado':'Secure no habilitado','Activar session.cookie_secure=1 en HTTPS de producción.');
    } else {
        $add('Transporte','HTTPS actual','PENDIENTE','La terminal no verifica el servidor web','Probar certificado TLS, redirección HTTPS y HSTS con un navegador y revisión de servidor.');
    }
    $add('Gobierno','Respaldos y restauración','PENDIENTE','No verificable con inspección del código','Respaldar la información y los archivos, comprobar su recuperación en un entorno aislado y documentar el resultado.');
    $add('Gobierno','Permisos de roles y pruebas negativas','PENDIENTE','Pruebas manuales aún necesarias','Probar URL directa, filtro obra clasificada, POST sin CSRF, descargas y CSV por perfil.');
    $add('Gobierno','Revisión de exposición y penetración','PENDIENTE','No se efectuó un pentest ni revisión independiente','Antes de producción realizar revisión de dependencias, configuración y pruebas de seguridad.');
    return $items;
}
