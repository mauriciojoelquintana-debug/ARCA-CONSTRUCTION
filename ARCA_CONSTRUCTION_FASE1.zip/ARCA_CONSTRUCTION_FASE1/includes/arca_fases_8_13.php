<?php
declare(strict_types=1);
require_once __DIR__.'/arca_core.php';
function af8_money($n,?string $currency=null): string {
    return $n===null?'—':'$'.number_format((float)$n,2,'.',',').' '.($currency?:'DIVISA NO CONFIRMADA');
}
function af8_menu(): array {
    $role=arx_role();
    $all=['arca_ceo_integrado.php'=>'Dirección general','arca_estructura.php'=>'Gerencias y departamentos','arca_expediente_obra.php'=>'Expediente de obra','arca_compras.php'=>'Compras y proveedores','arca_reportes.php'=>'Reportes ejecutivos','arca_validacion.php'=>'Auditoría y calidad'];
    if(in_array($role,['CEO','Director General'],true))return $all;
    if($role==='COO')return array_intersect_key($all,array_flip(['arca_expediente_obra.php','arca_compras.php','arca_reportes.php']));
    if($role==='CHRO')return array_intersect_key($all,array_flip(['arca_estructura.php','arca_expediente_obra.php']));
    if($role==='CIO')return ['arca_validacion.php'=>'Auditoría y calidad'];
    return ['arca_expediente_obra.php'=>'Expediente de obra'];
}
function af8_layout(string $title,string $subtitle,string $active): void {arx_layout_start($title,$subtitle,$active,'Reportes y gestión ejecutiva',af8_menu());echo '<link rel="stylesheet" href="assets/css/arca-fases-8-13.css?v=1">';}
function af8_count(mysqli $db,string $table,string $where='1=1'): int {
    // Únicamente nombres de tabla y WHERE literales que el desarrollador ha definido.
    return (int)(arx_one($db,"SELECT COUNT(*) n FROM $table WHERE $where")['n']??0);
}
function af8_error(Throwable $e): never {error_log('ARCA 8-13: '.$e->getMessage()); arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo completar la operación; consulta el registro del servidor.',true);arx_redirect('arca_compras.php');}
function af8_badge(string $v): string {return '<span class="arx-tag">'.arx_h($v).'</span>';}
function af8_table_rows(array $rows,array $fields): void {
    foreach($rows as $row){echo '<tr>';foreach($fields as $label=>$fn){echo '<td>'.($fn($row)).'</td>';}echo '</tr>';}
    if(!$rows)echo '<tr><td colspan="'.count($fields).'">No hay registros disponibles para esta consulta.</td></tr>';
}
