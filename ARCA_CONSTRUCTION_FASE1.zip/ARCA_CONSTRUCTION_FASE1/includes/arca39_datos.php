<?php
declare(strict_types=1);
/** ARCA F39: diagnóstico transversal de SOLO LECTURA y registro separado de incidencias. */
require_once __DIR__.'/arca36_38_datos.php';
require_once __DIR__.'/arca39_reglas.php';
function a39_base(mysqli $db): void {a34_base_pruebas($db);}
function a39_instalado(mysqli $db): bool {return a32_tabla($db,'arca39_incidencias') && a32_tabla($db,'arca39_eventos');}
function a39_incidencias(mysqli $db): array {
    return arx_rows($db,'SELECT id_incidencia,categoria,prioridad,titulo,descripcion,referencia_origen,estado,referencia_evidencia,observacion,creado_por,actualizado_por,creado_en,actualizado_en FROM arca39_incidencias ORDER BY CASE estado WHEN ? THEN 0 WHEN ? THEN 1 WHEN ? THEN 2 ELSE 3 END, id_incidencia DESC LIMIT 200',['ABIERTA','EN_PROCESO','EN_VALIDACION']);
}
function a39_historial(mysqli $db,array $issues): array {
    if(!$issues)return [];
    $ids=array_map(static fn($x)=>(int)$x['id_incidencia'],$issues);
    $q=implode(',',array_fill(0,count($ids),'?'));
    $rows=arx_rows($db,"SELECT id_incidencia,accion,estado_anterior,estado_nuevo,actor_id,nota,referencia_evidencia,registrado_en FROM arca39_eventos WHERE id_incidencia IN ($q) ORDER BY id_evento DESC LIMIT 700",$ids);
    $out=[];foreach($rows as $r)$out[(int)$r['id_incidencia']][]=$r;
    return $out;
}
function a39_integridad_f38(mysqli $db,array $codes): array {
    $result=['completa'=>false,'total'=>0,'eventos'=>0,'errores'=>0,'hallazgos'=>[],'limitado'=>false];
    if(!a38_instalado($db)){$result['hallazgos'][]='No se pudo consultar el historial de solicitudes. Comunícate con el área de Sistemas.';$result['errores']++;return $result;}
    if(!$codes){$result['hallazgos'][]='No hay obras autorizadas para este diagnóstico.';$result['errores']++;return $result;}
    $in=implode(',',array_fill(0,count($codes),'?'));
    $result['total']=(int)(arx_one($db,"SELECT COUNT(*) AS n FROM arca38_flujos WHERE codigo_obra IN ($in)",$codes)['n']??0);
    $result['eventos']=(int)(arx_one($db,"SELECT COUNT(*) AS n FROM arca38_eventos e JOIN arca38_flujos f ON f.id_flujo=e.id_flujo WHERE f.codigo_obra IN ($in)",$codes)['n']??0);
    $limit=500;
    $flows=arx_rows($db,"SELECT id_flujo,creado_por,estado FROM arca38_flujos WHERE codigo_obra IN ($in) ORDER BY id_flujo LIMIT $limit",$codes);
    $result['limitado']=$result['total']>count($flows);
    $ids=array_map(static fn($r)=>(int)$r['id_flujo'],$flows);
    $events=[];
    if($ids){
      $ins=implode(',',array_fill(0,count($ids),'?'));
      foreach(arx_rows($db,"SELECT id_flujo,accion,estado_anterior,estado_nuevo,actor_id FROM arca38_eventos WHERE id_flujo IN ($ins) ORDER BY id_flujo,id_evento",$ids) as $event){$events[(int)$event['id_flujo']][]=$event;}
    }
    foreach($flows as $f){
      $errs=a39_validar_eventos($f,$events[(int)$f['id_flujo']]??[]);
      if($errs){$result['errores']+=count($errs);foreach($errs as $reason){
        if(count($result['hallazgos'])<25)$result['hallazgos'][]='Solicitud #'.(int)$f['id_flujo'].': '.$reason;
      }}
    }
    $result['completa']=!$result['limitado'];
    if($result['limitado'])$result['hallazgos'][]='Diagnóstico parcial: se revisaron 500 flujos; resta revisión por lotes.';
    return $result;
}
function a39_panoramica(mysqli $db,string $root): array {
    a39_base($db);
    if(!a34_instalado($db))throw new RuntimeException('La verificación y el seguimiento de calidad no están disponibles.');
    $fresh=a34_actuales($db,$root);
    $f35=a35_guardados($db);
    $summary=a39_resumen_casos(a35_catalogo(),$f35);
    $scope=a38_codigos_autorizados($db);
    $integrity=a39_integridad_f38($db,$scope);
    $issues=a39_instalado($db)?a39_incidencias($db):[];
    $active=count(array_filter($issues,static fn($x)=>$x['estado']!=='CERRADA'));
    $gate=a39_puerta($fresh['f32'],$fresh['f33'],$summary,$integrity,$active,$summary['sin_aprobar']);
    return ['f32'=>$fresh['f32'],'f33'=>$fresh['f33'],'f35'=>$f35,'catalogo'=>a35_catalogo(),'pruebas'=>$summary,
        'f38'=>$integrity,'incidencias'=>$issues,'historial'=>a39_instalado($db)?a39_historial($db,$issues):[],
        'seguimientos_f34'=>a34_guardados($db),'pendientes_f39'=>$active,'puerta'=>$gate,'sql_ok'=>a39_instalado($db)];
}
function a39_crear(mysqli $db,array $p):void {
    a39_base($db);
    if(!a39_instalado($db))throw new RuntimeException('El registro de incidencias no está configurado.');
    $category=(string)($p['categoria']??'');$priority=(string)($p['prioridad']??'');
    if(!array_key_exists($category,a39_categorias())||!in_array($priority,a39_prioridades(),true))throw new InvalidArgumentException('Categoría o prioridad inválida.');
    $title=a39_texto($p['titulo']??null,160);
    $description=a39_texto($p['descripcion']??null,2000);
    $reference=a39_texto($p['referencia_origen']??'',120,false);
    $nonce=(string)($p['nonce']??'');if(!preg_match('/^[a-f0-9]{32}$/D',$nonce))throw new InvalidArgumentException('Formulario inválido.');
    $uid=arx_uid();if($uid<=0)throw new DomainException('Sesión incompleta.');
    $db->begin_transaction();
    try {
      if(arx_one($db,'SELECT id_incidencia FROM arca39_incidencias WHERE nonce=?',[$nonce]))throw new DomainException('Este formulario ya fue enviado. Recarga para crear otro.');
      arx_exec($db,'INSERT INTO arca39_incidencias(categoria,prioridad,titulo,descripcion,referencia_origen,estado,creado_por,actualizado_por,nonce) VALUES(?,?,?,?,?,?,?,?,?)',[$category,$priority,$title,$description,$reference?:null,'ABIERTA',$uid,$uid,$nonce]);
      $id=arx_one($db,'SELECT id_incidencia FROM arca39_incidencias WHERE nonce=?',[$nonce]);
      if(!$id)throw new RuntimeException('No fue posible recuperar la nueva incidencia.');
      arx_exec($db,'INSERT INTO arca39_eventos(id_incidencia,accion,estado_anterior,estado_nuevo,actor_id,nota,referencia_evidencia) VALUES(?,?,?,?,?,?,?)',[(int)$id['id_incidencia'],'CREAR',null,'ABIERTA',$uid,'Incidencia documentada; pendiente de análisis.',null]);
      $db->commit();
    }catch(Throwable $e){$db->rollback();throw $e;}
}
function a39_cambiar_estado(mysqli $db,array $p):void {
    a39_base($db);
    if(!a39_instalado($db))throw new RuntimeException('El seguimiento de incidencias no está configurado.');
    $id=filter_var($p['id_incidencia']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if($id===false)throw new InvalidArgumentException('Folio incorrecto.');
    $new=(string)($p['estado']??'');
    $note=a39_texto($p['observacion']??null,1500);
    $ref=a39_texto($p['referencia_evidencia']??'',180,false);
    a39_validar_cierre($new,$ref,$note);
    $uid=arx_uid();$db->begin_transaction();
    try{
      $row=arx_one($db,'SELECT id_incidencia,estado FROM arca39_incidencias WHERE id_incidencia=? FOR UPDATE',[$id]);
      if(!$row)throw new DomainException('Incidencia no encontrada.');
      $old=(string)$row['estado'];
      if(!a39_transicion($old,$new))throw new DomainException('Transición no permitida. Para corregir, sigue las etapas del proceso.');
      arx_exec($db,'UPDATE arca39_incidencias SET estado=?,referencia_evidencia=?,observacion=?,actualizado_por=? WHERE id_incidencia=?',[$new,$ref?:null,$note,$uid,$id]);
      arx_exec($db,'INSERT INTO arca39_eventos(id_incidencia,accion,estado_anterior,estado_nuevo,actor_id,nota,referencia_evidencia) VALUES(?,?,?,?,?,?,?)',[$id,'CAMBIAR_ESTADO',$old,$new,$uid,$note,$ref?:null]);
      $db->commit();
    }catch(Throwable $e){$db->rollback();throw $e;}
}
