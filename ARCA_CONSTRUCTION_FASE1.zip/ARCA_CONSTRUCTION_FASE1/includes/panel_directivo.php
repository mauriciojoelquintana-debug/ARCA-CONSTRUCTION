<?php
/**
 * ARCA CONSTRUCTION · Panel ejecutivo reutilizable.
 * PHP + mysqli. No realiza cambios en la base de datos.
 * $arca_area se define internamente en el archivo panel_CARGO.php (no proviene de GET).
 */
require_once __DIR__ . '/seguridad.php';
$configs = require __DIR__ . '/directivos_config.php';
$area = $arca_area ?? '';
if (!isset($configs[$area])) { http_response_code(404); exit('Panel no identificado.'); }
$conf = $configs[$area];
require_once __DIR__ . '/arca27_fichas.php';
arca_requerir_roles([$area, 'CEO', 'Director General']);
require __DIR__ . '/../conexion.php';

$esCEO = in_array(trim((string)($_SESSION['rol_activo'] ?? '')), ['CEO', 'Director General'], true);
$nombreUsuario = (string)($_SESSION['nombre_usuario'] ?? 'Colaborador ARCA');
$numeroEmpleado = (string)($_SESSION['usuario_activo'] ?? '');
$inicial = strtoupper(substr($nombreUsuario, 0, 1));
$archivoArea = 'panel_' . strtolower($area) . '.php';
$enlaces = ['CFO'=>'Finanzas','COO'=>'Operaciones','CIO'=>'Sistemas','CTO'=>'Tecnología','CCO'=>'Comercial','CMO'=>'Marketing','CHRO'=>'RR. HH.','CSO'=>'Estrategia'];

function arca_consulta_panel(mysqli $db, string $sql): array {
    try { return $db->query($sql)->fetch_all(MYSQLI_ASSOC); }
    catch (Throwable $e) {
        error_log('ARCA panel, consulta fallida: ' . $e->getMessage());
        return [];
    }
}
function arca_cifra_panel(mysqli $db, string $sql): ?float {
    try {
        $fila = $db->query($sql)->fetch_row();
        if (!isset($fila[0])) return null;
        return (float)$fila[0];
    } catch (Throwable $e) {
        error_log('ARCA panel, métrica fallida: ' . $e->getMessage());
        return null;
    }
}
function arca_formato_panel(?float $valor, string $tipo, bool $compacto = false): string {
    if ($valor === null) return '—';
    if ($tipo === 'porcentaje') return number_format($valor, 1, '.', ',') . '%';
    if ($tipo === 'dinero') return $compacto && abs($valor) >= 1000000 ? '$' . number_format($valor/1000000, 2, '.', ',') . ' M USD' : '$' . number_format($valor, 2, '.', ',') . ' USD';
    return number_format($valor, 0, '.', ',');
}
function arca_estado_clase(string $estado): string {
    $p = function_exists('mb_strtolower') ? mb_strtolower($estado, 'UTF-8') : strtolower($estado);
    if (str_contains($p, 'riesgo') || str_contains($p,'crític') || str_contains($p,'retras') || str_contains($p,'vencid') || str_contains($p,'urgente') || str_contains($p,'perdid')) return 'state-danger';
    if (str_contains($p,'pendiente') || str_contains($p,'en proceso') || str_contains($p,'programad') || str_contains($p,'prospecto')) return 'state-warn';
    return 'state-neutral';
}
$metricas = [];
foreach ($conf['metricas'] as $m) {
    $metricas[] = ['titulo'=>$m[0], 'valor'=>arca_cifra_panel($conectar,$m[1]), 'tipo'=>$m[2], 'nota'=>$m[3]];
}
$registros = arca_consulta_panel($conectar,$conf['reporte']);
$distribucion = arca_consulta_panel($conectar,$conf['distribucion']);
$maxTotal = max(array_merge([1],array_map(static fn($a)=>(float)($a['total'] ?? 0),$distribucion)));
$registroFaltante = array_reduce($metricas,static fn($carry,$v)=>$carry || $v['valor']===null,false);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <title><?= arca_h($area.' · '.$conf['nombre']) ?> | ARCA CONSTRUCTION</title>
  <link rel="stylesheet" href="assets/css/arca.css?v=2">
  <link rel="stylesheet" href="assets/css/arca-directivos.css?v=3">
</head>
<body>
<div class="app-layout">
  <aside class="app-sidebar">
    <div class="sidebar-brand">
      <span class="brand-mark" aria-hidden="true">A</span>
      <span><span class="brand-name">ARCA CONSTRUCTION</span><span class="brand-sub" style="display:block">Sistema de gestión ERP</span></span>
    </div>
    <span class="nav-label">Panel directivo</span>
    <nav class="app-nav" aria-label="Navegación del panel">
      <a href="#resumen" aria-current="page"><span class="nav-icon">▦</span> Resumen del área</a>
      <a href="#indicadores"><span class="nav-icon">▤</span> Indicadores</a>
      <a href="#registros"><span class="nav-icon">▥</span> Registros recientes</a>
      <a href="#modulos"><span class="nav-icon">▧</span> Módulos del área</a>
    </nav>
    <?php if ($esCEO): ?>
      <span class="nav-label">Dirección general</span>
      <nav class="app-nav" aria-label="Direcciones ejecutivas">
        <a href="panel_ceo.php"><span class="nav-icon">⌂</span> Volver al CEO</a>
        <?php foreach ($enlaces as $sigla=>$nombreArea): ?>
          <a href="panel_<?= arca_h(strtolower($sigla)) ?>.php" <?= $sigla===$area ? 'aria-current="page"' : '' ?>><span class="nav-icon" style="font-size:12px;font-weight:800"><?= arca_h($sigla) ?></span> <?= arca_h($nombreArea) ?></a>
        <?php endforeach; ?>
      </nav>
    <?php else: ?>
      <span class="nav-label">Cuenta</span>
      <nav class="app-nav"><a href="<?= arca_h($archivoArea) ?>"><span class="nav-icon">⌂</span> Inicio del área</a></nav>
    <?php endif; ?>
    <div class="sidebar-end">
      <div class="sidebar-user"><span class="user-avatar"><?= arca_h($inicial) ?></span><span><span class="user-identity" style="display:block"><?= arca_h($nombreUsuario) ?></span><span class="user-meta"><?= arca_h($numeroEmpleado) ?></span></span></div>
      <a class="sidebar-logout" href="cerrar_sesion.php">↪ Cerrar sesión</a>
    </div>
  </aside>
  <main class="app-main" id="resumen">
    <header class="app-topbar">
      <div class="app-breadcrumb">ARCA CONSTRUCTION <span class="bread-slash">/</span><b><?= arca_h($conf['cargo']) ?></b></div>
      <div class="app-top-right"><span class="status-pill"><span class="status-dot"></span> Consulta conectada</span><span class="user-avatar"><?= arca_h($inicial) ?></span></div>
    </header>
    <section class="welcome arca-directivo-welcome">
      <div>
        <span class="eyebrow">DIRECCIÓN EJECUTIVA · <?= arca_h($area) ?></span>
        <h1><?= arca_h($conf['nombre']) ?></h1>
        <p><?= arca_h($conf['descripcion']) ?></p>
      </div>
      <?php if ($esCEO): ?><a class="btn btn-secondary" href="panel_ceo.php">← Regresar al panel CEO</a><?php endif; ?>
    </section>
    <?php if ($esCEO): ?><div class="arca-notice arca-notice-info"><strong>Consulta de Dirección General:</strong> esta vista muestra información consolidada. Las acciones operativas están reservadas al responsable del área.</div><?php endif; ?>
    <?php if ($registroFaltante): ?><div class="arca-notice arca-notice-warn">No fue posible cargar todos los indicadores. Si el problema persiste, comunícate con el área de Sistemas.</div><?php endif; ?>
    <section id="indicadores" class="content-section" style="margin-top:20px">
      <div class="section-heading"><div><h2>Indicadores principales</h2><p>Resumen de los indicadores disponibles para tu área.</p></div><span class="arca-section-chip">Indicadores de gestión</span></div>
      <div class="stats-grid">
        <?php foreach($metricas as $m): ?>
        <article class="metric-card">
          <div class="metric-head"><span class="metric-label"><?= arca_h($m['titulo']) ?></span><span class="metric-symbol" aria-hidden="true">▦</span></div>
          <div class="metric-value arca-metric-value"><?= arca_h(arca_formato_panel($m['valor'],$m['tipo'],true)) ?></div>
          <div class="metric-detail"><?= arca_h($m['nota']) ?></div>
        </article>
        <?php endforeach; ?>
      </div>
    </section>
    <div class="arca-grid-analisis">
      <section class="surface-panel" aria-label="Distribución de registros">
        <div class="surface-panel-header"><div><h3>Distribución del área</h3><div class="small">Agrupación de los registros actuales.</div></div></div>
        <div class="arca-bars">
        <?php if (!$distribucion): ?><p class="arca-empty">Aún no hay registros para esta distribución.</p><?php endif; ?>
        <?php foreach($distribucion as $p): $total=(float)($p['total'] ?? 0); $ancho=max(0,min(100,100*$total/$maxTotal)); ?>
          <div class="arca-bar-item">
            <div class="arca-bar-label"><span><?= arca_h((string)($p['categoria'] ?? 'Sin clasificar')) ?></span><b><?= number_format($total,0,'.',',') ?></b></div>
            <div class="arca-bar-track" role="img" aria-label="<?= arca_h((string)($p['categoria'] ?? 'Sin clasificar')) ?>: <?= number_format($total,0) ?>"><div class="arca-bar-fill" style="width:<?= round($ancho,1) ?>%"></div></div>
          </div>
        <?php endforeach; ?>
        </div>
      </section>
      <section class="surface-panel">
        <?php $ficha27 = a27_ficha($area); ?>
        <div class="surface-panel-header"><h3><?= arca_h($ficha27[0]) ?></h3></div>
        <div class="arca-informacion">
          <?php foreach(array_slice($ficha27,1) as $nota27): ?><p><?= arca_h($nota27) ?></p><?php endforeach; ?>
          <p><b>Tabla de referencia:</b> <code><?= arca_h($conf['tabla']) ?></code></p>
        </div>
      </section>
    </div>
    <section class="content-section" id="registros">
      <div class="section-heading"><div><h2>Registros recientes</h2><p>Se muestran los 12 registros más recientes de esta consulta.</p></div><span class="arca-section-chip"><?= count($registros) ?> resultados</span></div>
      <div class="surface-panel">
        <div class="arca-search-wrap"><label for="buscar-registro">Buscar entre los registros mostrados</label><input id="buscar-registro" type="search" placeholder="Escribir para filtrar..." autocomplete="off"></div>
        <div class="data-table-wrap"><table class="data-table" id="tabla-registros"><thead><tr><?php foreach($conf['columnas'] as $c): ?><th scope="col"><?= arca_h($c[1]) ?></th><?php endforeach; ?></tr></thead><tbody>
          <?php foreach($registros as $r): ?><tr>
            <?php foreach($conf['columnas'] as $c):
              $valor=$r[$c[0]] ?? null; $formato=$c[2] ?? 'texto';
            ?><td>
              <?php if ($formato==='estado'): ?><span class="arca-state <?= arca_h(arca_estado_clase((string)$valor)) ?>"><?= arca_h((string)($valor ?? 'Sin estado')) ?></span>
              <?php elseif (($formato==='dinero' || $formato==='numero' || $formato==='porcentaje') && is_numeric($valor)): ?><?= arca_h(arca_formato_panel((float)$valor,$formato)) ?>
              <?php else: ?><?= arca_h((string)($valor ?? '—')) ?><?php endif; ?>
            </td><?php endforeach; ?>
          </tr><?php endforeach; ?>
          <?php if (!$registros): ?><tr><td colspan="<?= count($conf['columnas']) ?>" class="arca-empty">No hay registros disponibles.</td></tr><?php endif; ?>
        </tbody></table></div>
        <p class="arca-empty" id="sin-coincidencias" hidden>No hay coincidencias con el filtro.</p>
      </div>
    </section>
    <section class="content-section" id="modulos">
      <div class="section-heading"><div><h2>Módulos de <?= arca_h($conf['nombre']) ?></h2><p><?= $esCEO ? 'Listado de procesos a cargo de esta dirección.' : 'Accesos a las herramientas operativas que ya tiene ARCA.' ?></p></div></div>
      <div class="arca-module-grid">
      <?php foreach($conf['modulos'] as $i=>$m): ?>
        <?php if($esCEO): ?>
          <div class="arca-module-link arca-module-static"><span class="arca-module-number"><?= str_pad((string)($i+1),2,'0',STR_PAD_LEFT) ?></span><b><?= arca_h($m[0]) ?></b><span class="arca-module-arrow">Solo consulta</span></div>
        <?php else: ?>
          <a class="arca-module-link" href="<?= arca_h($m[1]) ?>"><span class="arca-module-number"><?= str_pad((string)($i+1),2,'0',STR_PAD_LEFT) ?></span><b><?= arca_h($m[0]) ?></b><span class="arca-module-arrow">↗</span></a>
        <?php endif; ?>
      <?php endforeach; ?>
      </div>
    </section>
    <footer class="section-footer">ARCA CONSTRUCTION · Plataforma interna de gestión · <?= arca_h($area) ?></footer>
  </main>
</div>
<script>
const entrada=document.getElementById('buscar-registro');
const filas=[...document.querySelectorAll('#tabla-registros tbody tr')];
entrada.addEventListener('input',()=>{
 const filtro=entrada.value.toLocaleLowerCase('es').trim();let visibles=0;
 filas.forEach(fila=>{const ok=fila.textContent.toLocaleLowerCase('es').includes(filtro);fila.hidden=!ok;if(ok)visibles++;});
 document.getElementById('sin-coincidencias').hidden=visibles!==0;
});
</script>
</body>
</html>
