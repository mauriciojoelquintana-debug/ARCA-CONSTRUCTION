<?php
declare(strict_types=1);
require_once __DIR__.'/arca_integracion.php';
function ax_report_types(): array {
 return [
 'obras'=>['Portafolio de obras',['Obra','Nombre','Tipo','Avance (%)','Estado'],[3]],
 'avances'=>['Último avance por obra',['Obra','Proyecto','Fecha de corte','Planeado (%)','Real (%)'],[3,4]],
 'finanzas'=>['Movimientos financieros',['Obra','Concepto','Módulo','Importe','Divisa','Estado','Fecha'],[3]],
 'personal'=>['Personal asignado',['Obra','Empleado','Código','Cargo','Inicio','Estado'],[]],
 'compras'=>['Solicitudes y órdenes',['Obra','Solicitud','Concepto','Estado solicitud','Orden','Estado orden','Total','Divisa'],[6]]
 ];
}
function ax_report_allowed(string $kind): bool {
 return match(arx_role()) {
 'CEO','Director General' => true,
 'CFO' => $kind==='finanzas' || $kind==='obras',
 'COO' => in_array($kind,['obras','avances','compras','personal'],true),
 'CHRO' => $kind==='personal' || $kind==='obras',
 default => false
 };
}
function ax_report_rows(mysqli $db,string $kind,string $obra=''): array {
 // Toda consulta es preparada cuando hay parámetros. No se interpolan nombres de tabla del usuario.
 [$sql,$args]=match($kind){
 'obras'=>['SELECT codigo_obra,nombre_proyecto,tipo_obra,avance_fisico,estado_tiempo FROM obras_coo ORDER BY codigo_obra',[]],
 'avances'=>['SELECT o.codigo_obra,o.nombre_proyecto,a.fecha_corte,a.avance_planeado,a.avance_real FROM obras_coo o LEFT JOIN arca_avances_cortes a ON a.id_corte=(SELECT x.id_corte FROM arca_avances_cortes x WHERE x.codigo_obra=o.codigo_obra ORDER BY x.fecha_corte DESC,x.id_corte DESC LIMIT 1) ORDER BY o.codigo_obra',[]],
 'finanzas'=>['SELECT codigo_obra,concepto,modulo,monto,COALESCE(moneda,\'SIN CONFIRMAR\') moneda,estado_pago,fecha_transaccion FROM finanzas_coo ORDER BY id_finanza DESC LIMIT 2000',[]],
 'personal'=>['SELECT a.codigo_obra,e.nombre_completo,e.numero_empleado,a.cargo_obra,a.fecha_inicio,a.estado FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado ORDER BY a.id_asignacion DESC LIMIT 2000',[]],
 'compras'=>['SELECT s.codigo_obra,s.id_solicitud,s.descripcion,s.estado,oc.id_orden,oc.estado estado_orden,oc.total,COALESCE(oc.moneda,s.moneda) divisa FROM arca_solicitudes_compra s LEFT JOIN arca_ordenes_compra oc ON oc.id_solicitud=s.id_solicitud ORDER BY s.id_solicitud DESC LIMIT 2000',[]],
 default=>throw new InvalidArgumentException('Reporte desconocido.')};
 $valid=array_flip(array_column(ax_obras($db),'codigo_obra'));
 $results=arx_rows($db,$sql,$args);
 return array_values(array_filter(array_map(static function($row)use($valid,$obra){$code=(string)($row['codigo_obra']??'');return isset($valid[$code]) && ($obra===''||$obra===$code)?array_values($row):null;},$results)));
}
