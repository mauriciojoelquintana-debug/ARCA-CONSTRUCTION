<?php
declare(strict_types=1);
/** ARCA F36-F38. Reglas puras, revisables y sin efectos secundarios. */
function a36_roles(): array { return ['CEO','Director General','CIO']; }
function a37_roles(): array { return ['CEO','Director General','CFO','COO','CHRO','CIO','CTO','CCO','CMO','CSO']; }
function a38_roles(): array { return ['CEO','Director General','CFO','COO','CHRO']; }
function a38_tipos(): array {
    return [
      'COMPRA'=>['nombre'=>'Solicitud de compra para revisión financiera','creadores'=>['CEO','Director General','COO'],'revisores'=>['CFO','CEO','Director General']],
      'PERSONAL'=>['nombre'=>'Validación de asignación laboral propuesta','creadores'=>['CEO','Director General','CHRO'],'revisores'=>['COO','CEO','Director General']],
      'DIVISA'=>['nombre'=>'Conciliación de divisa documental propuesta','creadores'=>['CEO','Director General','CFO'],'revisores'=>['CEO','Director General']],
      'INCIDENCIA'=>['nombre'=>'Incidencia operativa para revisión de dirección','creadores'=>['CEO','Director General','COO'],'revisores'=>['CEO','Director General']],
    ];
}
function a38_crear_permitido(string $rol,string $tipo): bool {
    return isset(a38_tipos()[$tipo]) && in_array($rol,a38_tipos()[$tipo]['creadores'],true);
}
function a38_revisar_permitido(string $rol,string $tipo): bool {
    return isset(a38_tipos()[$tipo]) && in_array($rol,a38_tipos()[$tipo]['revisores'],true);
}
function a38_transicion(string $estado,string $accion): string {
    if($estado==='PENDIENTE') return match($accion) {'APROBAR'=>'APROBADA','RECHAZAR'=>'RECHAZADA','DEVOLVER'=>'DEVUELTA',default=>throw new DomainException('Acción no permitida.')};
    if($estado==='DEVUELTA' && $accion==='REENVIAR') return 'PENDIENTE';
    throw new DomainException('Transición no permitida en este estado.');
}
function a38_texto(mixed $valor,int $max,bool $required=true): string {
    if(!is_string($valor)) throw new InvalidArgumentException('Formato de texto no válido.');
    $s=trim($valor);
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $s)) throw new InvalidArgumentException('Texto contiene caracteres de control.');
    $len=function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);
    if(($required && $s==='')||$len>$max)throw new InvalidArgumentException('Texto vacío o demasiado largo.');
    return $s;
}
function a38_referencia(mixed $s): string {
    $ref=a38_texto($s,80,false);
    if($ref!=='' && !preg_match('/^[\pL\pN _.,:()\/\-#]{1,80}$/uD',$ref))throw new InvalidArgumentException('Referencia no válida.');
    return $ref;
}
function a38_csv_safe(mixed $v): string {
    $s=str_replace(["\r","\n"],' ',(string)($v??''));
    if(preg_match('/^[\s\x00-\x1F]*[=+@\-]/u',$s))return "'".$s;
    return $s;
}
function a38_resumen_estado(array $rows): array {
    $v=['PENDIENTE'=>0,'DEVUELTA'=>0,'APROBADA'=>0,'RECHAZADA'=>0];
    foreach($rows as $r)if(isset($v[$r['estado']]))$v[$r['estado']]++;
    return $v;
}
