<?php
declare(strict_types=1);
/** Fuente común de reportes en vivo; cada consulta corresponde a tablas reales de ARCA. */
function af8_report_data(mysqli $db,string $kind): array {
 switch($kind){
 case 'portafolio':
  return ['Portafolio de obras','Base de prueba · Presupuestos sin divisa verificada',['Código','Obra','Tipo','Avance %','Estado','Presupuesto · divisa no confirmada'],
   arx_rows($db,'SELECT codigo_obra,nombre_proyecto,tipo_obra,avance_fisico,estado_tiempo,presupuesto FROM obras_coo ORDER BY codigo_obra')];
 case 'avances':
  return ['Avances físicos históricos','Cortes históricos de avance; etiqueta original del periodo',['Obra','Periodo','Planeado %','Real %','Diferencia (pp)'],
   arx_rows($db,'SELECT codigo_obra,periodo_corte,avance_planeado,avance_real,(avance_real-avance_planeado) diferencia FROM avance_operativo_coo ORDER BY codigo_obra,id_avance')];
 case 'fases':
  return ['Costos y fases de obra','Importes históricos sin divisa confirmada; no equivale a conciliación financiera',['Obra','Fase','Responsable','Presupuesto (sin moneda)','Gastado (sin moneda)','Avance %','Estado'],
   arx_rows($db,'SELECT codigo_obra,fase_sector,responsable,presupuesto,gastado,avance,estado FROM detalles_obra_coo ORDER BY codigo_obra,id_detalle')];
 case 'personal':
  return ['Asignaciones históricas','Una asignación no equivale necesariamente a un empleado único',['Obra','Identificador','Nombre','Puesto','Nivel','Área','Contratación'],
   arx_rows($db,'SELECT obra_asignada,num_empleado,nombre_personal,puesto_cargo,nivel_jerarquico,area_dentro_obra,tipo_contratacion FROM asignaciones_obra_arca ORDER BY obra_asignada,id_asignacion')];
 case 'materiales':
  return ['Inventario por obra','Existencias históricas en inventario_almacen_arca',['Obra','Código','Material','Categoría','Unidad','Existencia','Stock mínimo'],
   arx_rows($db,'SELECT codigo_obra,codigo_insumo,descripcion_recurso,categoria_recurso,unidad_medida,cantidad_actual,stock_minimo FROM inventario_almacen_arca ORDER BY codigo_obra,id_insumo')];
 default: throw new InvalidArgumentException('Reporte desconocido.');
 }
}
