<?php
declare(strict_types=1);
/** ARCA · Fase 31 | Tablero ejecutivo de solo lectura. */
require_once __DIR__.'/arca31_puro.php';
require_once __DIR__.'/arca29_30.php';
require_once __DIR__.'/arca24_acceso_seguro.php';

function a31_datos(mysqli $db,array $codes,string $role):array {
    $in=a26_sql_in($codes);
    $works=arx_rows($db,"SELECT codigo_obra,nombre_proyecto,COALESCE(avance_fisico,0) avance_fisico,COALESCE(estado_tiempo,'Sin estado') estado_tiempo FROM obras_coo WHERE codigo_obra IN ($in) ORDER BY codigo_obra",$codes);
    $result=['obras'=>[], 'finanzas'=>[], 'ordenes_divisa'=>[], 'totales'=>['obras'=>count($works),'avance_promedio'=>0.0,'en_riesgo'=>0,'asignaciones_verificadas'=>null,'stock_bajo'=>null,'articulos'=>null,'ordenes_emitidas'=>null,'demo_aprobados'=>null], 'consultado'=>date('Y-m-d H:i:s')];
    $avance=0.0;
    foreach($works as $w){
        $code=(string)$w['codigo_obra']; $p=a31_porcentaje($w['avance_fisico']);$avance+=$p;
        if(a31_riesgo((string)$w['estado_tiempo']))$result['totales']['en_riesgo']++;
        $result['obras'][$code]=['codigo'=>$code,'nombre'=>(string)$w['nombre_proyecto'],'avance'=>$p,'estado'=>(string)$w['estado_tiempo'],'personal'=>null,'articulos'=>null,'stock_bajo'=>null,'ordenes'=>null,'demo'=>null];
    }
    $result['totales']['avance_promedio']=$works?round($avance/count($works),1):0.0;
    // Personal confirmado: expediente activo, contrato vigente, asignación vigente y validación auditada F28.
    if(a31_es_personal($role)){
        $r=arx_rows($db,"SELECT a.codigo_obra,COUNT(*) cantidad FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.codigo_obra IN ($in) AND a.estado='ACTIVA' AND a.fecha_inicio<=CURRENT_DATE() AND (a.fecha_fin IS NULL OR a.fecha_fin>=CURRENT_DATE()) AND e.estado_laboral='ACTIVO' AND e.tipo_personal='PROPIO' AND EXISTS(SELECT 1 FROM arca_contratos_laborales c WHERE c.id_empleado=a.id_empleado AND c.estado='VIGENTE' AND c.inicio<=CURRENT_DATE() AND (c.fin IS NULL OR c.fin>=CURRENT_DATE())) AND EXISTS(SELECT 1 FROM arca_auditoria_modulos au WHERE au.modulo='CHRO' AND au.entidad='arca_empleados' AND au.entidad_id=a.id_empleado AND au.accion='VALIDAR_DOCUMENTOS') GROUP BY a.codigo_obra",$codes);
        $idx=a31_agrupar($r,'codigo_obra');$sum=0;
        foreach($result['obras'] as $code=>&$obra){$n=(int)($idx[$code]['cantidad']??0);$obra['personal']=$n;$sum+=$n;}unset($obra);
        $result['totales']['asignaciones_verificadas']=$sum;
    }
    if(a31_es_operaciones($role)){
        $stock=arx_rows($db,"SELECT codigo_obra,COUNT(*) articulos,SUM(CASE WHEN cantidad_actual<=stock_minimo THEN 1 ELSE 0 END) bajos FROM inventario_almacen_arca WHERE codigo_obra IN ($in) GROUP BY codigo_obra",$codes);
        $orders=arx_rows($db,"SELECT codigo_obra,COUNT(*) emitidas FROM arca_ordenes_compra WHERE codigo_obra IN ($in) AND estado='EMITIDA' GROUP BY codigo_obra",$codes);
        $s=a31_agrupar($stock,'codigo_obra');$o=a31_agrupar($orders,'codigo_obra');$sumS=0;$sumB=0;$sumO=0;
        foreach($result['obras'] as $code=>&$obra){
           $obra['articulos']=(int)($s[$code]['articulos']??0);$obra['stock_bajo']=(int)($s[$code]['bajos']??0);$obra['ordenes']=(int)($o[$code]['emitidas']??0);
           $sumS+=$obra['articulos'];$sumB+=$obra['stock_bajo'];$sumO+=$obra['ordenes'];
        }unset($obra);
        $result['totales']['articulos']=$sumS;$result['totales']['stock_bajo']=$sumB;$result['totales']['ordenes_emitidas']=$sumO;
        // Órdenes, en su propia moneda y con estado diferenciado. No se equiparan con pagos.
        $result['ordenes_divisa']=arx_rows($db,"SELECT COALESCE(NULLIF(UPPER(TRIM(moneda)),''),'SIN CONFIRMAR') moneda,estado,COUNT(*) cantidad,COALESCE(SUM(total),0) importe FROM arca_ordenes_compra WHERE codigo_obra IN ($in) GROUP BY COALESCE(NULLIF(UPPER(TRIM(moneda)),''),'SIN CONFIRMAR'),estado ORDER BY moneda,estado",$codes);
    }
    if(a31_es_finanzas($role)){
       $result['finanzas']=arx_rows($db,"SELECT COALESCE(NULLIF(UPPER(TRIM(moneda)),''),'SIN CONFIRMAR') moneda,modulo,estado_pago,COUNT(*) cantidad,COALESCE(SUM(monto),0) importe FROM finanzas_coo WHERE codigo_obra IN ($in) GROUP BY COALESCE(NULLIF(UPPER(TRIM(moneda)),''),'SIN CONFIRMAR'),modulo,estado_pago ORDER BY moneda,modulo,estado_pago",$codes);
    }
    // Fase 30 es SIMULACIÓN; nunca se suma a las asignaciones verificadas.
    if(a31_es_demo($role) && a30_db_demo($db)){
       $demo=arx_rows($db,"SELECT codigo_obra,COUNT(*) aprobados FROM arca30_demo_casos WHERE codigo_obra IN ($in) AND estado='APROBADO' AND inicio<=CURRENT_DATE() AND (fin IS NULL OR fin>=CURRENT_DATE()) GROUP BY codigo_obra",$codes);
       $d=a31_agrupar($demo,'codigo_obra');$sum=0;
       foreach($result['obras'] as $code=>&$obra){$obra['demo']=(int)($d[$code]['aprobados']??0);$sum+=$obra['demo'];}unset($obra);
       $result['totales']['demo_aprobados']=$sum;
    }
    $result['obras']=array_values($result['obras']);
    return $result;
}
