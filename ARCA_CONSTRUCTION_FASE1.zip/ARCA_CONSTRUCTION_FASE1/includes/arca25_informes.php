<?php
declare(strict_types=1);
require_once __DIR__.'/arca24_26.php';
require_once __DIR__.'/arca_reportes_binarios.php';

function a25_catalog(): array {return [
 'obras'=>['Portafolio de obras',['Código','Proyecto','Tipo','Avance físico (%)','Estado'],[3],''],
 'avances'=>['Cortes de avance',['Código','Proyecto','Fecha','Previsto (%)','Real (%)'],[3,4],'fecha_corte'],
 'finanzas'=>['Movimientos de Finanzas',['Obra','Concepto','Módulo','Importe','Divisa','Estado','Fecha'],[3],'fecha_transaccion'],
 'personal'=>['Personal asignado a obras',['Obra','Número de empleado','Nombre','Cargo obra','Inicio','Estado'],[],'fecha_inicio'],
 'compras'=>['Órdenes y compras',['Obra','Orden','Solicitud','Concepto','Estado','Importe','Divisa','Emisión'],[5],'emitida'],
 'materiales'=>['Movimientos de almacén',['Obra','Insumo','Tipo','Cantidad','Anterior','Posterior','Fecha'],[3,4,5],'fecha']
];}
function a25_filtros(array $input,string $role): array {
 $kind=(string)($input['tipo']??'');
 if(!isset(a25_catalog()[$kind]) || !in_array($kind,a26_reportes_por_rol($role),true))throw new InvalidArgumentException('Tipo de informe no autorizado.');
 $obra=trim((string)($input['obra']??''));
 if($obra!=='' && !preg_match('/^[A-Z0-9-]{4,30}$/D',$obra))throw new InvalidArgumentException('Código de obra incorrecto.');
 [$desde,$hasta]=a26_periodo($input['desde']??'', $input['hasta']??'');
 $moneda=a26_currency($input['moneda']??'');
 if($kind==='obras' && ($desde!==null || $hasta!==null))throw new InvalidArgumentException('El portafolio actual de obras no admite filtro de fecha.');
 if($moneda!=='' && !in_array($kind,['finanzas','compras'],true))throw new InvalidArgumentException('El informe seleccionado no tiene divisa para filtrar.');
 if($moneda==='SIN_CONFIRMAR' && $kind!=='finanzas')throw new InvalidArgumentException('Las órdenes de compra deben tener divisa confirmada.');
 return ['tipo'=>$kind,'obra'=>$obra,'desde'=>$desde,'hasta'=>$hasta,'moneda'=>$moneda];
}
function a25_date_scope(string $column,?string $from,?string $to,array &$params,bool $datetime=false):string {
    $q='';
    if($from!==null){$q.=' AND '.$column.' >= ?';$params[]=$from;}
    if($to!==null){
        if($datetime){$q.=' AND '.$column.' < ?';$params[]=(new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d');}
        else{$q.=' AND '.$column.' <= ?';$params[]=$to;}
    }
    return $q;
}
/** Todas las consultas quedan restringidas a códigos de obra autorizados. Sin acceso a sueldos de personal. */
function a25_data(mysqli $db,array $f,array $codes):array {
 $kind=$f['tipo'];$in=a26_sql_in($codes);$params=$codes;$period='';
 switch($kind) {
 case 'obras':
  $sql="SELECT codigo_obra,nombre_proyecto,tipo_obra,avance_fisico,estado_tiempo FROM obras_coo WHERE codigo_obra IN ($in) ORDER BY codigo_obra LIMIT 2500";
  break;
 case 'avances':
  $period=a25_date_scope('a.fecha_corte',$f['desde'],$f['hasta'],$params);
  $sql="SELECT a.codigo_obra,o.nombre_proyecto,a.fecha_corte,a.avance_planeado,a.avance_real FROM arca_avances_cortes a LEFT JOIN obras_coo o ON o.codigo_obra=a.codigo_obra WHERE a.codigo_obra IN ($in)$period ORDER BY a.fecha_corte DESC,a.id_corte DESC LIMIT 2500";
  break;
 case 'finanzas':
  $period=a25_date_scope('f.fecha_transaccion',$f['desde'],$f['hasta'],$params);
  $curr='';if($f['moneda']==='SIN_CONFIRMAR')$curr=" AND (f.moneda IS NULL OR f.moneda='')";
  elseif($f['moneda']!==''){$curr=' AND f.moneda=?';$params[]=$f['moneda'];}
  $sql="SELECT f.codigo_obra,f.concepto,f.modulo,f.monto,COALESCE(NULLIF(f.moneda,''),'SIN CONFIRMAR') AS moneda,f.estado_pago,f.fecha_transaccion FROM finanzas_coo f WHERE f.codigo_obra IN ($in)$period$curr ORDER BY f.fecha_transaccion DESC,f.id_finanza DESC LIMIT 2500";
  break;
 case 'personal':
  $period=a25_date_scope('a.fecha_inicio',$f['desde'],$f['hasta'],$params);
  $sql="SELECT a.codigo_obra,e.numero_empleado,e.nombre_completo,a.cargo_obra,a.fecha_inicio,a.estado FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.codigo_obra IN ($in)$period ORDER BY a.fecha_inicio DESC,a.id_asignacion DESC LIMIT 2500";
  break;
 case 'compras':
  $period=a25_date_scope('oc.emitida',$f['desde'],$f['hasta'],$params,true);
  $curr='';if($f['moneda']!==''){$curr=' AND oc.moneda=?';$params[]=$f['moneda'];}
  $sql="SELECT oc.codigo_obra,oc.id_orden,oc.id_solicitud,s.descripcion,oc.estado,oc.total,oc.moneda,DATE(oc.emitida) AS fecha FROM arca_ordenes_compra oc JOIN arca_solicitudes_compra s ON s.id_solicitud=oc.id_solicitud WHERE oc.codigo_obra IN ($in)$period$curr ORDER BY oc.emitida DESC,oc.id_orden DESC LIMIT 2500";
  break;
 case 'materiales':
  $period=a25_date_scope('m.fecha',$f['desde'],$f['hasta'],$params,true);
  $sql="SELECT m.codigo_obra,i.descripcion_recurso,m.tipo,m.cantidad,m.anterior,m.posterior,DATE(m.fecha) AS fecha FROM arca_movimientos_material m JOIN inventario_almacen_arca i ON i.id_insumo=m.id_insumo WHERE m.codigo_obra IN ($in)$period ORDER BY m.fecha DESC,m.id_movimiento DESC LIMIT 2500";
  break;
 default:throw new InvalidArgumentException('Informe no reconocido.');
 }
 $rows=arx_rows($db,$sql,$params);
 return array_map(static fn($r)=>array_values($r),$rows);
}
function a25_summary(array $f,int $n):string {
 $scope=$f['obra']!==''?$f['obra']:'obras autorizadas';
 $period=($f['desde']??'sin inicio').' a '.($f['hasta']??'sin fin');
 return 'Alcance: '.$scope.' | Periodo: '.$period.' | Divisa: '.($f['moneda']?:'sin filtro').' | Filas: '.$n.' | generado '.date('Y-m-d H:i');
}
