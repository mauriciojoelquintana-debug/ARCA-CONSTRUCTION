<?php
declare(strict_types=1);
/** Generadores de exportación sin dependencias Composer; los datos se consultan en tiempo de descarga. */
function ax_xml(string $s): string {return htmlspecialchars($s,ENT_QUOTES|ENT_XML1|ENT_SUBSTITUTE,'UTF-8');}

/** ZIP Store simple, compatible con OOXML, para PHP sin extensión zip. */
class AxZipBasic {
 private string $path='';private array $entries=[];
 public function open(string $path,int $flags=0): bool {$this->path=$path;return true;}
 public function addFromString(string $name,string $body): bool {$this->entries[$name]=$body;return true;}
 public function close(): bool {
  $body='';$cd='';$count=0;
  foreach($this->entries as $name=>$data){$name=(string)$name;$len=strlen($data);$crc=crc32($data);$offset=strlen($body);$nm=strlen($name);$mtime=0;$mdate=0;
   $body.=pack('VvvvvvVVVvv',0x04034b50,20,0,0,$mtime,$mdate,$crc,$len,$len,$nm,0).$name.$data;
   $cd.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,$mtime,$mdate,$crc,$len,$len,$nm,0,0,0,0,0,$offset).$name;$count++;
  }
  $pos=strlen($body);$end=pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($cd),$pos,0);
  return file_put_contents($this->path,$body.$cd.$end)!==false;
 }
}

function ax_excel_col(int $index): string { $v='';for($index++;$index>0;$index=intdiv($index-1,26))$v=chr(65+(($index-1)%26)).$v;return $v; }
function ax_xlsx(string $title,array $head,array $rows,array $numericIndices=[]): string {
 $tmp=tempnam(sys_get_temp_dir(),'arca_xlsx_');if($tmp===false)throw new RuntimeException('No se pudo preparar archivo temporal.');
 $zip=class_exists('ZipArchive')?new ZipArchive():new AxZipBasic();
 if($zip->open($tmp,$zip instanceof ZipArchive ? ZipArchive::OVERWRITE : 0)!==true){@unlink($tmp);throw new RuntimeException('No se pudo crear XLSX.');}
 $zip->addFromString('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
 $zip->addFromString('_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
 $zip->addFromString('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Informe ARCA" sheetId="1" r:id="rId1"/></sheets></workbook>');
 $zip->addFromString('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
 $zip->addFromString('xl/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><color rgb="FF263B53"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF263B53"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs></styleSheet>');
 $n=count($head);$last=ax_excel_col(max(0,$n-1));$max=max(2,count($rows)+2);
 $x='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>';
 for($i=0;$i<$n;$i++)$x.='<col min="'.($i+1).'" max="'.($i+1).'" width="'.($i===1?34:21).'" customWidth="1"/>';
 $x.='</cols><sheetData><row r="1"><c r="A1" t="inlineStr" s="1"><is><t>'.ax_xml($title.' | ARCA CONSTRUCTION').'</t></is></c></row><row r="2">';
 foreach($head as $c=>$h)$x.='<c r="'.ax_excel_col($c).'2" t="inlineStr" s="1"><is><t>'.ax_xml((string)$h).'</t></is></c>';
 $x.='</row>';
 foreach($rows as $i=>$row){$r=$i+3;$x.='<row r="'.$r.'">';foreach(array_values($row) as $j=>$val){$ref=ax_excel_col($j).$r;$val=$val===null?'':(string)$val;
 if(in_array($j,$numericIndices,true) && $val!=='' && is_numeric($val))$x.='<c r="'.$ref.'" s="2"><v>'.ax_xml($val).'</v></c>';
 else $x.='<c r="'.$ref.'" t="inlineStr"><is><t>'.ax_xml($val).'</t></is></c>';
 }$x.='</row>';}
 $x.='</sheetData><autoFilter ref="A2:'.$last.$max.'"/><pageMargins left="0.4" right="0.4" top="0.7" bottom="0.7" header="0.3" footer="0.3"/></worksheet>';
 $zip->addFromString('xl/worksheets/sheet1.xml',$x);$zip->close();return $tmp;
}
function ax_pdf_cp(string $v): string {
 $s=@iconv('UTF-8','Windows-1252//TRANSLIT',$v);if($s===false)$s=preg_replace('/[^\x20-\x7E]/','?', $v);
 return str_replace(['\\','(',')',"\r","\n"],['\\\\','\\(','\\)', '',' '],$s);
}
function ax_pdf_text(float $x,float $y,float $size,string $v): string {return "BT /F1 ".$size." Tf ".round($x,2).' '.round($y,2).' Td ('.ax_pdf_cp($v).") Tj ET\n";}
function ax_pdf(string $title,array $headers,array $rows): string {
 $n=count($headers);$pageRows=array_chunk($rows,29);if(!$pageRows)$pageRows=[[]];$streams=[];$maxText=max(8,(int)floor((760/max(1,$n))/4.7));
 foreach($pageRows as $page=>$list){$s="0.96 0.975 0.99 rg 0 560 842 35 re f\n0.15 0.23 0.33 rg\n";$s.=ax_pdf_text(33,572,15,'ARCA CONSTRUCTION  |  '.$title);
 $s.=ax_pdf_text(33,548,9,'Emisión: '.date('Y-m-d').' · Página '.($page+1).' / '.count($pageRows));
 $x0=32;$w=778/max(1,$n);$y=518;$s.="0.15 0.23 0.33 rg 32 497 778 26 re f\n1 1 1 rg\n";
 foreach($headers as $j=>$h)$s.=ax_pdf_text($x0+$j*$w+4,506,8,substr((string)$h,0,$maxText));
 $s.="0.15 0.23 0.33 rg\n";
 foreach($list as $i=>$row){$y=476-$i*15.1;if($i%2===0){$s.="0.96 0.97 0.98 rg 32 ".($y-5)." 778 15 re f\n0.15 0.23 0.33 rg\n";}
 foreach(array_values($row) as $j=>$v){$str=(string)($v??'');if(function_exists('mb_strimwidth'))$str=mb_strimwidth($str,0,$maxText,'…','UTF-8');else $str=substr($str,0,$maxText);$s.=ax_pdf_text($x0+$j*$w+4,$y,8,$str);}}
 $s.=ax_pdf_text(33,28,8,'Origen: base ARCA local. Divisas históricas no confirmadas se mantienen sin convertir.');$streams[]=$s;
 }
 $p=count($streams);$fontId=3+2*$p;$objects=[];$kids=[];$objects[1]='<< /Type /Catalog /Pages 2 0 R >>';
 foreach($streams as $i=>$stream){$cid=3+2*$i;$pid=$cid+1;$kids[]=$pid.' 0 R';$objects[$cid]='<< /Length '.strlen($stream)." >>\nstream\n".$stream."endstream";$objects[$pid]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 '.$fontId.' 0 R >> >> /Contents '.$cid.' 0 R >>';}
 $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.$p.' >>';$objects[$fontId]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
 ksort($objects);$pdf="%PDF-1.4\n";$offsets=[0=>0];foreach($objects as $id=>$obj){$offsets[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$obj."\nendobj\n";}
 $xrefPos=strlen($pdf);$pdf.="xref\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";for($i=1;$i<=count($objects);$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";
 $pdf.="trailer\n<< /Size ".(count($objects)+1)." /Root 1 0 R >>\nstartxref\n".$xrefPos."\n%%EOF\n";return $pdf;
}
