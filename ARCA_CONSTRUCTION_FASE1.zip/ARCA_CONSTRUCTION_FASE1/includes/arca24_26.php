<?php
declare(strict_types=1);
require_once __DIR__.'/arca22_accesos.php';
require_once __DIR__.'/arca24_26_puro.php';

function a26_db(?array $roles=null): mysqli { return arx_boot($roles??a26_roles_resumen()); }
function a26_codes(mysqli $db,string $requested=''): array {
    $rows=a22_obras_permitidas($db);
    $codes=array_values(array_unique(array_map(static fn($r)=>(string)$r['codigo_obra'],$rows)));
    if($requested!=='') {
        if(!in_array($requested,$codes,true)){http_response_code(403);exit('No tienes autorización para la obra solicitada.');}
        return [$requested];
    }
    if(!$codes){http_response_code(403);exit('Tu cuenta no tiene obras autorizadas.');}
    return $codes;
}
function a26_path(string $path): string {return 'assets/css/'.$path;}
function a26_menu(): array {
    $p=[];
    if(in_array(arx_role(),['CEO','Director General','CFO','COO','CHRO'],true)) {
        $p=['arca24_tablero.php'=>'Indicadores en seguimiento','arca25_reportes.php'=>'Reportes PDF / Excel'];
    }
    if(in_array(arx_role(),['CEO','Director General','CIO'],true))$p['arca26_seguridad.php']='Auditoría de calidad';
    return ['arca22_portal.php'=>'Menú general ARCA']+$p;
}
function a26_layout(string $title,string $sub,string $selected):void {
    arx_layout_start($title,$sub,$selected,'Indicadores, reportes y auditoría',a26_menu());
    echo '<link rel="stylesheet" href="assets/css/arca24-26.css?v=24.1">';
}
function a26_date_scope(string $column,?string $from,?string $to,array &$params): string {
    $q='';if($from!==null){$q.=' AND '.$column.' >= ?';$params[]=$from;}
    if($to!==null){$q.=' AND '.$column.' <= ?';$params[]=$to;}
    return $q;
}
