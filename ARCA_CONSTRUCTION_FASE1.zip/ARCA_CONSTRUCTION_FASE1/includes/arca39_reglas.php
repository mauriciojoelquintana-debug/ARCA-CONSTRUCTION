<?php
declare(strict_types=1);
/** Fase 39: reglas puras, sin sesiones ni consultas, para probar sin MySQL. */
function a39_roles(): array {return ['CEO','Director General'];}
function a39_categorias(): array {return ['SEGURIDAD'=>'Seguridad','DATOS'=>'Integridad de datos','OPERACIONES'=>'Operaciones','RESPALDOS'=>'Respaldos y restauración','RENDIMIENTO'=>'Rendimiento','DOCUMENTACION'=>'Documentación','OTRA'=>'Otra incidencia'];}
function a39_prioridades(): array {return ['BAJA','MEDIA','ALTA','CRITICA'];}
function a39_estados(): array {return ['ABIERTA'=>'Abierta','EN_PROCESO'=>'En proceso','EN_VALIDACION'=>'En validación','CERRADA'=>'Cerrada'];}
function a39_texto(mixed $value,int $max,bool $required=true): string {
    if(!is_string($value))throw new InvalidArgumentException('El campo debe ser texto.');
    if(preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/',$value))throw new InvalidArgumentException('El texto contiene caracteres no permitidos.');
    $s=trim($value);
    $len=function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);
    if(($required && $s==='')||$len>$max)throw new InvalidArgumentException('Campo vacío o demasiado largo.');
    return $s;
}
function a39_transicion(string $from,string $to): bool {
    if($from===$to)return false;
    return match($from){
      'ABIERTA'=>in_array($to,['EN_PROCESO'],true),
      'EN_PROCESO'=>in_array($to,['EN_VALIDACION'],true),
      'EN_VALIDACION'=>in_array($to,['EN_PROCESO','CERRADA'],true),
      'CERRADA'=>false,
      default=>false
    };
}
function a39_validar_cierre(string $state,string $reference,string $note): void {
    if(!array_key_exists($state,a39_estados()))throw new InvalidArgumentException('Estado no reconocido.');
    if(in_array($state,['EN_VALIDACION','CERRADA'],true) && ($reference==='' || $note==='')){
      throw new DomainException('La validación o el cierre requieren evidencia y observación.');
    }
}
function a39_csv_safe(mixed $value): string {
    $s=str_replace(["\r","\n"],' ',(string)($value??''));
    if(preg_match('/^[\s\x00-\x1F]*[=+@\-]/u',$s))return "'".$s;
    return $s;
}
function a39_resumen_casos(array $catalog,array $registrados): array {
    $passed=0;$failed=0;
    foreach($catalog as $id=>$v){
      $estado=(string)($registrados[$id]['resultado']??'NO_EJECUTADA');
      if($estado==='APROBADA')$passed++;
      if(in_array($estado,['FALLIDA','BLOQUEADA'],true))$failed++;
    }
    return ['total'=>count($catalog),'aprobadas'=>$passed,'fallidas_bloqueadas'=>$failed,'sin_aprobar'=>count($catalog)-$passed];
}
function a39_puerta(array $f32,array $f33,array $f35,array $f38,int $abiertas,int $noAprobadas): array {
    $c32=count(array_filter($f32,static fn($r)=>($r['estado']??'')!=='OK'));
    $c33=count(array_filter($f33,static fn($r)=>($r['estado']??'')!=='OK'));
    $integrityIssues=(int)($f38['errores']??0);
    $checked=(bool)($f38['completa']??false);
    $obstacles=[];
    if($c32)$obstacles[]="Auditoría: $c32 controles no correctos";
    if($c33)$obstacles[]="Infraestructura: $c33 controles no correctos";
    if($noAprobadas)$obstacles[]="Verificación operativa: $noAprobadas controles sin validación";
    if(!$checked)$obstacles[]='Solicitudes: verificación incompleta';
    if($integrityIssues)$obstacles[]="Solicitudes: $integrityIssues inconsistencias";
    if($abiertas)$obstacles[]="Seguimiento: $abiertas incidencias abiertas";
    return ['sin_bloqueos_detectados'=>!$obstacles,'obstaculos'=>$obstacles,'f32'=>$c32,'f33'=>$c33];
}
function a39_validar_eventos(array $flow,array $events): array {
    $issues=[];$estado=null;
    if(!$events){return ['Sin evento CREAR en bitácora'];}
    foreach($events as $index=>$ev){
      $accion=(string)($ev['accion']??'');
      $prev=$ev['estado_anterior']??null;
      $next=(string)($ev['estado_nuevo']??'');
      if($index===0){
        if($accion!=='CREAR'||$prev!==null||$next!=='PENDIENTE')$issues[]='Evento inicial inválido';
        $estado=$next;continue;
      }
      if($prev!==$estado)$issues[]='Estado anterior de evento no coincide';
      if(in_array($accion,['APROBAR','DEVOLVER','RECHAZAR'],true) && (int)$ev['actor_id']===(int)$flow['creado_por'])$issues[]='El creador resolvió su solicitud';
      if($accion==='REENVIAR' && (int)$ev['actor_id']!==(int)$flow['creado_por'])$issues[]='Un tercero reenvió la solicitud';
      try{$expected=a38_transicion((string)$estado,$accion);if($expected!==$next)$issues[]='Transición de estado inválida';}
      catch(Throwable $e){$issues[]='Acción no permitida en historial';}
      $estado=$next;
    }
    if($estado!==(string)$flow['estado'])$issues[]='Último evento no coincide con estado actual';
    return array_values(array_unique($issues));
}
