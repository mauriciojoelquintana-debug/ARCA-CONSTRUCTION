<?php
/**
 * Catálogo cerrado, administrado del lado del servidor.
 * Los identificadores de tabla y columna NUNCA provienen de GET.
 * Moneda USD: convención provisional para importes sin campo de divisa.
 */
return [
 'CFO' => [
  'titulo'=>'Finanzas', 'descripcion'=>'Presupuestos, costos, ingresos y obligaciones de las obras.',
  'tabla'=>'finanzas_coo', 'id'=>'id_finanza', 'filtra'=>true,
  'columnas'=>[
   ['codigo_obra','Código de obra','codigo'],['nombre_proyecto','Proyecto'],['concepto','Concepto'],['monto','Importe (USD)','dinero'],['fecha_transaccion','Fecha','fecha'],['estado_pago','Estado','estado']
  ],
  'modulos'=>[
   'presupuesto'=>['titulo'=>'Presupuestos de obras','descripcion'=>'Presupuestos registrados y su estado de autorización.'],
   'costos'=>['titulo'=>'Costos de construcción','descripcion'=>'Costos por partidas de obra, materiales y servicios.'],
   'ingresos'=>['titulo'=>'Ingresos y facturación','descripcion'=>'Cobros y facturación registrados en el ERP.'],
   'pagos'=>['titulo'=>'Cuentas por pagar','descripcion'=>'Compromisos financieros y fechas de pago.'],
   'impuestos'=>['titulo'=>'Contabilidad e impuestos','descripcion'=>'Registros fiscales y contables disponibles.'],
  ],
  'dinero'=>'monto','codigo'=>'codigo_obra','estado'=>'estado_pago','fecha'=>'fecha_transaccion',
  'aviso'=>'Se muestran importes en USD por configuración del proyecto. La tabla finanzas_coo no contiene divisa; no se aplica conversión monetaria.'
 ],
 'COO'=>[
  'titulo'=>'Operaciones y construcción','descripcion'=>'Ejecución, avances, materiales y seguimiento operativo de obras.',
  'modulos'=>[
   'obras'=>['titulo'=>'Obras y proyectos','descripcion'=>'Ficha de las obras, avances, recursos y responsables.', 'tabla'=>'detalles_obra_coo','id'=>'id_detalle','filtra'=>false,'fecha'=>'fecha_inicio',
     'columnas'=>[['codigo_obra','Código de obra','codigo'],['nombre_proyecto','Proyecto'],['ubicacion','Ubicación'],['fase_sector','Fase'],['avance','Avance','progreso'],['presupuesto','Presupuesto (USD)','dinero'],['gastado','Gastado (USD)','dinero'],['personal','Personal','numero'],['estado','Estado','estado']]],
   'avance'=>['titulo'=>'Avance físico de obra','descripcion'=>'Comparación de partidas y planeación según registros de corte.', 'tabla'=>'avance_operativo_coo','id'=>'id_avance','filtra'=>false,'fecha'=>null,
     'columnas'=>[['codigo_obra','Código de obra','codigo'],['nombre_proyecto','Proyecto'],['periodo_corte','Periodo'],['cimentacion','Cimentación','progreso'],['estructura','Estructura','progreso'],['instalaciones','Instalaciones','progreso'],['acabados','Acabados','progreso'],['avance_planeado','Planeado','progreso'],['avance_real','Real','progreso']]],
   'personal'=>['titulo'=>'Personal en campo','descripcion'=>'Registros operativos relativos a los equipos en obra.'],
   'maquinaria'=>['titulo'=>'Maquinaria','descripcion'=>'Control de disponibilidad y movimientos de maquinaria.'],
   'materiales'=>['titulo'=>'Materiales','descripcion'=>'Control de materiales y abastecimiento de obras.'],
   'compras'=>['titulo'=>'Compras','descripcion'=>'Compras y proveedores asociados a proyectos.'],
   'seguridad'=>['titulo'=>'Seguridad de obra','descripcion'=>'Incidencias y condiciones de seguridad registradas.'],
   'mantenimiento'=>['titulo'=>'Mantenimiento','descripcion'=>'Bitácoras y actividades de mantenimiento.'],
   'problemas'=>['titulo'=>'Riesgos y problemas','descripcion'=>'Situaciones críticas y acciones de seguimiento.'],
   'kpis'=>['titulo'=>'Indicadores operativos','descripcion'=>'Registros de indicadores del área de operaciones.'],
  ],
  'tabla'=>'registros_coo','id'=>'id_reg','filtra'=>true,
  'columnas'=>[['folio','Folio','codigo'],['descripcion','Descripción'],['fecha_registro','Fecha','fecha'],['estado','Estado','estado']],
  'estado'=>'estado', 'fecha'=>'fecha_registro',
  'aviso'=>'Los presupuestos sin campo de divisa se presentan provisionalmente en USD. No se ha realizado conversión de moneda.'
 ],
 'CIO'=>[
  'titulo'=>'Sistemas e información','descripcion'=>'Soporte a las operaciones, sistemas corporativos y controles informáticos.',
  'modulos'=>[
   'erp'=>['titulo'=>'Gestión del ERP','descripcion'=>'Registros del software empresarial.','tabla'=>'finanzas_coo','id'=>'id_finanza','columnas'=>[['codigo_obra','Obra','codigo'],['concepto','Concepto'],['monto','Importe (USD)','dinero'],['estado_pago','Estado','estado']]],
   'crm'=>['titulo'=>'CRM corporativo','descripcion'=>'Cartera de oportunidades y clientes registrados.','tabla'=>'comercial_cco','id'=>'id_comercial','columnas'=>[['cliente','Cliente'],['descripcion','Descripción'],['valor_estimado','Valor (USD)','dinero'],['etapa_comercial','Etapa','estado']]],
   'bd'=>['titulo'=>'Base de datos','descripcion'=>'Actividad registrada en el sistema empresarial.','tabla'=>'soporte_tickets','id'=>'id_ticket','columnas'=>[['id_ticket','Ticket','codigo'],['numero_empleado','Empleado'],['descripcion_falla','Solicitud'],['estado','Estado','estado']]],
   'kpi'=>['titulo'=>'Indicadores ERP','descripcion'=>'Referencias a proyectos registrados.','tabla'=>'proyectos','id'=>'id_proyecto','columnas'=>[['id_proyecto','ID','codigo'],['nombre_obra','Obra'],['ubicacion','Ubicación'],['estado','Estado','estado']]],
   'sync'=>['titulo'=>'Sincronización de paneles','descripcion'=>'Vista informativa: aún no existe un proceso de sincronización medido.'],
   'servidores'=>['titulo'=>'Estado de servidores','descripcion'=>'Vista informativa. No se ha conectado un sistema de telemetría a Apache/Laragon.'],
   'redes'=>['titulo'=>'Redes corporativas','descripcion'=>'Vista informativa. No se han integrado medidas de latencia ni disponibilidad.'],
   'equipos'=>['titulo'=>'Mantenimiento de equipos','descripcion'=>'Vista informativa; sin bitácora técnica conectada a este módulo.'],
   'conectividad'=>['titulo'=>'Conectividad en obras','descripcion'=>'Vista informativa; sin monitoreo de enlaces instalado.'],
   'backup'=>['titulo'=>'Respaldos de base de datos','descripcion'=>'Vista informativa. No confirma respaldos automáticos ni su integridad.'],
   'firewall'=>['titulo'=>'Seguridad informática','descripcion'=>'Vista informativa. No hay eventos de firewall conectados.'],
   'encriptacion'=>['titulo'=>'Protección de datos','descripcion'=>'Vista informativa. El estado criptográfico no se determina por este panel.'],
  ],
  'aviso'=>'Los módulos de infraestructura sin registros enlazados son informativos; no muestran diagnósticos simulados.'
 ],
 'CTO'=>[
  'titulo'=>'Tecnología e innovación','descripcion'=>'Requerimientos e iniciativas de tecnología aplicadas a construcción.',
  'tabla'=>'requerimientos_cto','id'=>'id_req','filtra'=>true,
  'columnas'=>[['folio','Folio','codigo'],['descripcion','Requerimiento'],['fecha_registro','Registro','fecha'],['estado','Estado','estado']],
  'modulos'=>[
   'tecnologias'=>['titulo'=>'Tecnologías','descripcion'=>'Requerimientos de las tecnologías implementadas.'],
   'drones'=>['titulo'=>'Drones','descripcion'=>'Control documental de solicitudes de drones.'],
   'iot'=>['titulo'=>'IoT y sensores','descripcion'=>'Requerimientos de telemetría y sensores.'],
   'ia'=>['titulo'=>'Inteligencia artificial','descripcion'=>'Iniciativas de inteligencia artificial registradas.'],
   'automatizacion'=>['titulo'=>'Automatización','descripcion'=>'Automatización de procesos registrada.'],
   'innovacion'=>['titulo'=>'Innovación','descripcion'=>'Proyectos piloto y pruebas de tecnología.'],
   'kpis'=>['titulo'=>'KPIs tecnológicos','descripcion'=>'Requerimientos relacionados con indicadores tecnológicos.'],
  ],
  'estado'=>'estado','fecha'=>'fecha_registro',
  'aviso'=>'La información proviene de requerimientos guardados; no representa lecturas en tiempo real de sensores o drones.'
 ],
 'CCO'=>[
  'titulo'=>'Comercial','descripcion'=>'Oportunidades, licitaciones, cotizaciones y relaciones comerciales.',
  'tabla'=>'comercial_cco','id'=>'id_comercial','filtra'=>true,
  'columnas'=>[['codigo_obra','Referencia','codigo'],['cliente','Cliente'],['descripcion','Descripción'],['valor_estimado','Valor estimado (USD)','dinero'],['fecha_cierre','Cierre previsto','fecha'],['etapa_comercial','Etapa','estado']],
  'modulos'=>[
   'oportunidades'=>['titulo'=>'Oportunidades','descripcion'=>'Oportunidades abiertas y nuevas negociaciones.'],
   'licitaciones'=>['titulo'=>'Licitaciones','descripcion'=>'Licitaciones y convocatorias registradas.'],
   'propuestas'=>['titulo'=>'Cotizaciones y propuestas','descripcion'=>'Cotizaciones, alcances y negociación comercial.'],
   'seguimiento'=>['titulo'=>'Seguimiento de clientes','descripcion'=>'Relación con clientes y compromisos comerciales.'],
   'contratos'=>['titulo'=>'Contratos','descripcion'=>'Contratos y adjudicaciones comerciales.'],
  ],
  'dinero'=>'valor_estimado','codigo'=>'codigo_obra','estado'=>'etapa_comercial','fecha'=>'fecha_cierre',
  'aviso'=>'Los valores estimados se presentan provisionalmente en USD según la configuración del proyecto.'
 ],
 'CMO'=>[
  'titulo'=>'Marketing','descripcion'=>'Campañas, contactos y resultados de promoción corporativa.',
  'tabla'=>'marketing_cmo','id'=>'id_marketing','filtra'=>true,
  'columnas'=>[['codigo_obra','Referencia','codigo'],['canal_origen','Canal'],['descripcion','Actividad'],['presupuesto_utilizado','Presupuesto (USD)','dinero'],['contactos_generados','Contactos','numero'],['fecha_registro','Registro','fecha'],['estado_campaña','Estado','estado']],
  'modulos'=>[
   'clientes'=>['titulo'=>'Clientes potenciales','descripcion'=>'Prospectos y origen de contacto.'],
   'campañas'=>['titulo'=>'Campañas','descripcion'=>'Marketing y captación de contactos.'],
   'licitaciones'=>['titulo'=>'Licitaciones','descripcion'=>'Difusión y coordinación de licitaciones.'],
   'redes'=>['titulo'=>'Redes y sitio web','descripcion'=>'Acciones digitales de comunicación.'],
   'estudios'=>['titulo'=>'Estudios de mercado','descripcion'=>'Investigación de mercado y segmentos objetivo.'],
  ],
  'dinero'=>'presupuesto_utilizado','codigo'=>'codigo_obra','estado'=>'estado_campaña','fecha'=>'fecha_registro',
  'aviso'=>'Los presupuestos se presentan provisionalmente en USD; la tabla no almacena divisa de origen.'
 ],
 'CHRO'=>[
  'titulo'=>'Recursos humanos','descripcion'=>'Personal, selección, formación y compromisos laborales.',
  'tabla'=>'rrhh_chro','id'=>'id_rrhh','filtra'=>true,
  'columnas'=>[['codigo_obra','Obra','codigo'],['descripcion','Descripción'],['metrica_1','Indicador'],['metrica_2','Detalle'],['fecha_registro','Registro','fecha'],['estado','Estado','estado']],
  'modulos'=>[
   'asignacion'=>['titulo'=>'Personal asignado a obra','descripcion'=>'Información sobre asignaciones de trabajadores.'],
   'reclutamiento'=>['titulo'=>'Reclutamiento','descripcion'=>'Vacantes y seguimiento de selección.'],
   'contratos'=>['titulo'=>'Contratos laborales','descripcion'=>'Documentación y vencimientos laborales.'],
   'capacitacion'=>['titulo'=>'Capacitación','descripcion'=>'Cursos y certificaciones de personal.'],
   'rotacion'=>['titulo'=>'Rotación y retención','descripcion'=>'Bajas y permanencia del personal.'],
  ],
  'estado'=>'estado','fecha'=>'fecha_registro',
  'aviso'=>'Estos son registros de gestión de RR. HH. No equivalen al número total de trabajadores únicos de ARCA.'
 ],
 'CSO'=>[
  'titulo'=>'Estrategia corporativa','descripcion'=>'Metas, iniciativas, riesgos y decisiones corporativas.',
  'tabla'=>'estrategia_cso','id'=>'id_estrategia','filtra'=>true,
  'columnas'=>[['codigo_obra','Ámbito','codigo'],['descripcion','Descripción'],['responsable','Responsable'],['fecha_limite','Fecha límite','fecha'],['indicador_avance','Avance','progreso'],['estado','Estado','estado']],
  'modulos'=>[
   'objetivos'=>['titulo'=>'Objetivos corporativos','descripcion'=>'Seguimiento de metas por área.'],
   'iniciativas'=>['titulo'=>'Iniciativas estratégicas','descripcion'=>'Crecimiento y transformación empresarial.'],
   'expansion'=>['titulo'=>'Expansión de mercado','descripcion'=>'Evaluación de nuevos mercados y regiones.'],
   'riesgos'=>['titulo'=>'Riesgos estratégicos','descripcion'=>'Riesgos y mitigación empresarial.'],
   'rendimiento'=>['titulo'=>'Rendimiento empresarial','descripcion'=>'Indicadores de desempeño organizacional.'],
   'decisiones'=>['titulo'=>'Seguimiento de decisiones','descripcion'=>'Acuerdos directivos, responsables y plazos.'],
  ],
  'estado'=>'estado','fecha'=>'fecha_limite',
  'aviso'=>'Las métricas de avance son las registradas en la tabla estratégica; no se calculan automáticamente en tiempo real.'
 ],
];
