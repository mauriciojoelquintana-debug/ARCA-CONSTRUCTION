<?php
declare(strict_types=1);
/** F34/F35: consultar controles existentes, registrar seguimiento SOLO en tablas nuevas. */
require_once __DIR__.'/arca33_preparacion.php';
require_once __DIR__.'/arca34_reglas.php';

function a34_base_pruebas(mysqli $db): void {
    $r=arx_one($db,'SELECT DATABASE() AS b');
    if (($r['b']??'')!=='arca_bd_fase1') throw new DomainException('El seguimiento de calidad no está habilitado para esta instalación.');
}
function a34_instalado(mysqli $db): bool {
    foreach(['arca34_hallazgos','arca35_pruebas','arca34_35_bitacora'] as $name) if (!a32_tabla($db,$name))return false;
    return true;
}
function a34_actuales(mysqli $db,string $base): array {
    // Se ejecuta únicamente en sesión CEO; F32 consulta el ámbito permitido.
    $a=a32_evaluar($db,a24_obras_autorizadas($db));
    $b=a33_comprobar($base,true);
    return ['f32'=>$a,'f33'=>$b,'controles'=>a34_controles($a,$b)];
}
function a34_guardados(mysqli $db): array {
    $rows=arx_rows($db,'SELECT codigo_control,fuente,area,control,responsable,prioridad,estado,referencia_evidencia,nota,fecha_compromiso,actualizado_en FROM arca34_hallazgos ORDER BY actualizado_en DESC');
    $out=[];foreach($rows as $row)$out[(string)$row['codigo_control']]=$row;
    return $out;
}
function a35_guardados(mysqli $db): array {
    $rows=arx_rows($db,'SELECT codigo_prueba,resultado,referencia_evidencia,observacion,ejecutado_en FROM arca35_pruebas ORDER BY codigo_prueba');
    $out=[];foreach($rows as $row)$out[(string)$row['codigo_prueba']]=$row;
    return $out;
}
function a34_bitacora(mysqli $db,string $modulo,string $key,string $accion,?array $old,array $new): void {
    $oldJson=$old===null?null:json_encode($old,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    $newJson=json_encode($new,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    arx_exec($db,'INSERT INTO arca34_35_bitacora(modulo,entidad_codigo,accion,anterior_json,nuevo_json,usuario_id) VALUES(?,?,?,?,?,?)',[$modulo,$key,$accion,$oldJson,$newJson,arx_uid()]);
}
function a34_responsable_sugerido(string $area): string {
    return match (strtoupper($area)) {'CHRO'=>'CHRO','CFO'=>'CFO','COO'=>'COO',default=>'CIO'};
}
function a34_fecha_opcional(string $s): ?string {
    if ($s==='')return null;
    return arx_date($s);
}
function a34_guardar_hallazgo(mysqli $db,array $post,string $base): void {
    if (!in_array(arx_role(),a34_roles(),true)) throw new DomainException('Sin permiso para modificar seguimiento.');
    a34_base_pruebas($db);
    if (!a34_instalado($db)) throw new RuntimeException('El seguimiento de calidad no está configurado.');
    $code=(string)($post['codigo_control']??'');
    $all=a34_actuales($db,$base)['controles'];
    if (!preg_match('/^[a-f0-9]{64}$/D',$code) || !isset($all[$code]))throw new InvalidArgumentException('El control no pertenece a la auditoría actual.');
    $item=$all[$code];
    $rol=(string)($post['responsable']??'');$priority=(string)($post['prioridad']??'');$state=(string)($post['estado']??'');
    if (!in_array($rol,a34_responsables(),true)||!in_array($priority,a34_prioridades(),true))throw new InvalidArgumentException('Responsable o prioridad incorrectos.');
    $ref=a34_texto($post['referencia_evidencia']??'',180);
    $note=a34_texto($post['nota']??'',1500);
    $date=a34_fecha_opcional(trim((string)($post['fecha_compromiso']??'')));
    a34_validar_cierre($state,$ref,$note);
    $new=['estado'=>$state,'responsable'=>$rol,'prioridad'=>$priority,'fecha_compromiso'=>$date,'referencia_evidencia'=>$ref,'nota'=>$note,'estado_automatico_actual'=>$item['estado_auto']];
    $db->begin_transaction();
    try {
        $prev=arx_one($db,'SELECT responsable,prioridad,estado,fecha_compromiso,referencia_evidencia,nota FROM arca34_hallazgos WHERE codigo_control=? FOR UPDATE',[$code]);
        if ($prev===null) {
            arx_exec($db,'INSERT INTO arca34_hallazgos(codigo_control,fuente,area,control,responsable,prioridad,estado,referencia_evidencia,nota,fecha_compromiso,actualizado_por) VALUES(?,?,?,?,?,?,?,?,?,?,?)',[$code,$item['fuente'],$item['area'],$item['control'],$rol,$priority,$state,$ref?:null,$note?:null,$date,arx_uid()]);
        } else {
            arx_exec($db,'UPDATE arca34_hallazgos SET responsable=?,prioridad=?,estado=?,referencia_evidencia=?,nota=?,fecha_compromiso=?,actualizado_por=? WHERE codigo_control=?',[$rol,$priority,$state,$ref?:null,$note?:null,$date,arx_uid(),$code]);
        }
        a34_bitacora($db,'F34',$code,$prev?'ACTUALIZAR':'CREAR',$prev,$new);
        $db->commit();
    } catch(Throwable $e) {$db->rollback();throw $e;}
}
function a35_guardar_prueba(mysqli $db,array $post): void {
    if (!in_array(arx_role(),a35_roles(),true))throw new DomainException('No autorizado.');
    a34_base_pruebas($db);
    if (!a34_instalado($db))throw new RuntimeException('El registro de verificaciones no está configurado.');
    $code=(string)($post['codigo_prueba']??'');
    $state=(string)($post['resultado']??'');
    $ref=a34_texto($post['referencia_evidencia']??'',180);
    $note=a34_texto($post['observacion']??'',1500);
    a35_validar_prueba($code,$state,$ref,$note);
    $new=['resultado'=>$state,'referencia_evidencia'=>$ref,'observacion'=>$note];
    $db->begin_transaction();
    try {
        $old=arx_one($db,'SELECT resultado,referencia_evidencia,observacion FROM arca35_pruebas WHERE codigo_prueba=? FOR UPDATE',[$code]);
        if($old)arx_exec($db,'UPDATE arca35_pruebas SET resultado=?,referencia_evidencia=?,observacion=?,ejecutado_por=? WHERE codigo_prueba=?',[$state,$ref?:null,$note?:null,arx_uid(),$code]);
        else arx_exec($db,'INSERT INTO arca35_pruebas(codigo_prueba,resultado,referencia_evidencia,observacion,ejecutado_por) VALUES(?,?,?,?,?)',[$code,$state,$ref?:null,$note?:null,arx_uid()]);
        a34_bitacora($db,'F35',$code,$old?'ACTUALIZAR':'CREAR',$old,$new);
        $db->commit();
    }catch(Throwable $e){$db->rollback();throw $e;}
}
