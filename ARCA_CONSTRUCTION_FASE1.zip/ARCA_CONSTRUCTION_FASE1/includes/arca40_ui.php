<?php
declare(strict_types=1);

/**
 * FASE 40
 * Configuración visual de publicación interna
 */

if (!defined('ARCA_UI_PUBLICACION')) {
    define('ARCA_UI_PUBLICACION', true);
}

if (!defined('ARCA_BASE_URL')) {
    define('ARCA_BASE_URL', 'http://arca.test/');
}

function arca_url(string $ruta = ''): string {
    return rtrim(ARCA_BASE_URL, '/') . '/' . ltrim($ruta, '/');
}

function arca_ui_texto(string $produccion, string $tecnico = ''): string {
    return ARCA_UI_PUBLICACION ? $produccion : ($tecnico !== '' ? $tecnico : $produccion);
}

function arca_ui_mostrar_fase(): bool {
    return !ARCA_UI_PUBLICACION;
}

function arca_ui_clase_tecnica(): string {
    return ARCA_UI_PUBLICACION ? 'arca-ui-oculto' : '';
}

function arca_ui_titulo(string $titulo, ?string $fase = null): string {
    if (ARCA_UI_PUBLICACION || !$fase) {
        return $titulo;
    }
    return $titulo . ' · ' . $fase;
}

function arca_ui_estado_banner(string $tipo): string {
    $tipo = strtolower(trim($tipo));
    return match ($tipo) {
        'success' => 'Información actualizada correctamente.',
        'warning' => 'Atención requerida en algunos elementos del módulo.',
        'danger'  => 'Se detectaron elementos que requieren revisión.',
        default   => 'Estado general del sistema.',
    };
}