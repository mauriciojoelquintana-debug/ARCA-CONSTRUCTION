<?php
declare(strict_types=1);
/** ARCA · Fase 32. Verificaciones limitadas, sin escrituras ni datos personales. */
require_once __DIR__ . '/arca31_datos.php';
require_once __DIR__ . '/arca32_puro.php';
function a32_tabla(mysqli $db, string $table): bool {
    return arx_one($db, 'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1', [$table]) !== null;
}
function a32_columnas(mysqli $db, string $table, array $columns): bool {
    if (!a32_tabla($db, $table)) return false;
    $rows = arx_rows($db, 'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?', [$table]);
    $has = array_column($rows, 'COLUMN_NAME');
    return !array_diff($columns, $has);
}
function a32_num(mysqli $db, string $sql, array $params = []): int {
    return (int) (arx_one($db, $sql, $params)['n'] ?? 0);
}
function a32_almacen(): string {
    $custom = getenv('ARCA_F29_DOCUMENT_DIR');
    return ($custom !== false && trim($custom) !== '') ? $custom : dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'ARCA_DOCUMENTOS_PRIVADOS' . DIRECTORY_SEPARATOR . 'ERP_F29';
}
function a32_archivos_integridad(mysqli $db, string $base, int $limit = 250): array {
    // Solo nombre interno aleatorio + huella. Nunca se muestra el nombre de una persona ni el PDF.
    $docs = arx_rows($db, 'SELECT archivo_privado,sha256,tamano_bytes FROM arca29_documentos ORDER BY id_documento LIMIT ' . (int)$limit);
    $faltan = 0; $alterados = 0; $revisados = 0;
    $root = realpath($base);
    foreach ($docs as $doc) {
        $revisados++;
        $name = (string) $doc['archivo_privado'];
        if (!preg_match('/^[a-f0-9]{48}\.bin$/D', $name) || !$root) { $faltan++; continue; }
        $file = realpath($root . DIRECTORY_SEPARATOR . $name);
        if (!$file || dirname($file) !== $root || !is_file($file)) { $faltan++; continue; }
        if ((int)filesize($file) !== (int)$doc['tamano_bytes'] || !hash_equals((string)$doc['sha256'], hash_file('sha256', $file))) $alterados++;
    }
    return ['revisados'=>$revisados, 'faltantes'=>$faltan, 'alterados'=>$alterados];
}
function a32_evaluar(mysqli $db, array $obras): array {
    $out = [];
    $add = static function (string $area, string $control, string $estado, string $dato, string $accion) use (&$out): void {
        $out[] = a32_fila($area, $control, $estado, $dato, $accion);
    };
    $needed = [
        'usuarios' => ['id_usuario'], 'obras_coo' => ['codigo_obra'],
        'arca_accesos_obra' => ['id_usuario','codigo_obra'], 'arca_empleados' => ['id_empleado','estado_laboral','tipo_personal'],
        'arca_contratos_laborales' => ['id_contrato','id_empleado','estado','inicio','fin'],
        'arca_asignaciones_personal' => ['id_empleado','codigo_obra','estado','fecha_inicio','fecha_fin'],
        'arca_auditoria_modulos' => ['modulo','accion'], 'arca29_documentos' => ['id_documento','origen','archivo_privado','sha256','tamano_bytes','id_contrato','id_demo_caso'],
        'arca30_demo_casos' => ['id_caso','estado','codigo_obra','inicio','fin','propuesto_por','revisado_por'],
        'finanzas_coo' => ['codigo_obra','moneda'], 'arca_ordenes_compra' => ['codigo_obra','estado','moneda'],
        'inventario_almacen_arca' => ['codigo_obra','cantidad_actual','stock_minimo']
    ];
    $valid = [];
    foreach ($needed as $t=>$cols) {
        $valid[$t] = a32_columnas($db, $t, $cols);
    }
    $missing = array_keys(array_filter($valid, static fn($yes)=>!$yes));
    $add('Estructura', 'Tablas y columnas necesarias', $missing?'CRITICO':'OK',
        $missing ? 'Faltan o difieren: '.implode(', ', $missing) : count($needed).' estructuras comprobadas',
        'Si faltan componentes, solicita su revisión al área de Sistemas.');
    if (!$obras) {
        $add('Seguridad', 'Ámbito de obras', 'CRITICO', 'Sin obras autorizadas en la sesión.', 'Revisa los permisos de consulta por obra.');
        return $out;
    }
    $codes = array_values(array_unique(array_map(static fn($o)=>(string)$o['codigo_obra'], $obras)));
    $in = implode(',', array_fill(0,count($codes),'?'));
    $add('Seguridad','Filtro por obra','OK', count($codes).' obras permitidas para este diagnóstico.','Las consultas operativas de este informe se limitan al ámbito autorizado.');
    if ($valid['arca_accesos_obra'] && $valid['usuarios'] && $valid['obras_coo']) {
        $n = a32_num($db, 'SELECT COUNT(*) n FROM arca_accesos_obra a LEFT JOIN usuarios u ON u.id_usuario=a.id_usuario LEFT JOIN obras_coo o ON o.codigo_obra=a.codigo_obra WHERE u.id_usuario IS NULL OR o.codigo_obra IS NULL');
        $add('Seguridad','Referencias de accesos',a32_nivel($n,'CRITICO'),"$n permisos con referencias faltantes.",'Revisar registros y claves antes de conceder accesos.');
    }
    if ($valid['arca_empleados']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM arca_empleados WHERE estado_laboral='POR_VERIFICAR' OR tipo_personal='POR_VERIFICAR'");
        $add('CHRO','Expedientes pendientes',a32_nivel($n),"$n expedientes pendientes de verificación.",'Validar identidad y soporte documental; no activarlos por lote.');
    }
    if ($valid['arca_contratos_laborales']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM arca_contratos_laborales WHERE estado='VIGENTE' AND fin IS NOT NULL AND fin<CURRENT_DATE()");
        $add('CHRO','Contratos vencidos aún vigentes',a32_nivel($n,'CRITICO'),"$n contratos con fecha vencida y estado VIGENTE.",'Revisar vigencia contractual con CHRO.');
    }
    if ($valid['arca_asignaciones_personal'] && $valid['arca_empleados'] && $valid['arca_contratos_laborales']) {
        $params = $codes;
        $sql = "SELECT COUNT(*) n FROM arca_asignaciones_personal a LEFT JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.codigo_obra IN ($in) AND a.estado='ACTIVA' AND a.fecha_inicio<=CURRENT_DATE() AND (a.fecha_fin IS NULL OR a.fecha_fin>=CURRENT_DATE()) AND (e.id_empleado IS NULL OR e.estado_laboral<>'ACTIVO' OR e.tipo_personal<>'PROPIO' OR NOT EXISTS(SELECT 1 FROM arca_contratos_laborales c WHERE c.id_empleado=a.id_empleado AND c.estado='VIGENTE' AND c.inicio<=CURRENT_DATE() AND (c.fin IS NULL OR c.fin>=CURRENT_DATE())))";
        $n = a32_num($db,$sql,$params);
        $add('CHRO','Asignaciones sin cobertura laboral',a32_nivel($n,'CRITICO'),"$n asignaciones activas sin expediente propio y contrato vigente.",'Revisa las asignaciones en Validación laboral. No incorpores registros históricos sin verificar.');
    }
    if ($valid['finanzas_coo']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM finanzas_coo WHERE codigo_obra IN ($in) AND (moneda IS NULL OR TRIM(moneda)='' OR UPPER(TRIM(moneda)) IN ('SIN CONFIRMAR','SIN_CONFIRMAR'))",$codes);
        $add('CFO','Moneda de movimientos',a32_nivel($n),"$n movimientos sin divisa confirmada.",'Conciliar con CFO antes de comparar importes o convertir monedas.');
    }
    if ($valid['arca_ordenes_compra']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM arca_ordenes_compra WHERE codigo_obra IN ($in) AND estado='EMITIDA' AND (moneda IS NULL OR TRIM(moneda)='')",$codes);
        $add('COO','Moneda de órdenes emitidas',a32_nivel($n),"$n órdenes emitidas sin divisa.",'Revisar divisa con Compras antes de conciliar con Finanzas.');
    }
    if ($valid['inventario_almacen_arca']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM inventario_almacen_arca WHERE codigo_obra IN ($in) AND cantidad_actual<0",$codes);
        $add('COO','Existencias negativas',a32_nivel($n,'CRITICO'),"$n artículos con existencia negativa.",'Verificar movimientos físicos y bitácora, sin ajustar existencias automáticamente.');
    }
    if ($valid['arca29_documentos']) {
        $orph = a32_num($db,"SELECT COUNT(*) n FROM arca29_documentos WHERE (origen='REAL' AND (id_contrato IS NULL OR id_demo_caso IS NOT NULL)) OR (origen='DEMO' AND (id_contrato IS NOT NULL OR id_demo_caso IS NULL))");
        $add('Documentos','Separación REAL / DEMO',a32_nivel($orph,'CRITICO'),"$orph documentos con origen y vínculo contradictorios.",'Revisar metadatos, nunca reclasificar automáticamente PDFs.');
        $base = a32_almacen();
        if (!is_dir($base)) $add('Documentos','Almacén privado','AVISO','Carpeta privada no encontrada.','Verificar ARCA_F29_DOCUMENT_DIR; no colocar PDFs dentro de www.');
        else {
            $check = a32_archivos_integridad($db,$base);
            $status = $check['alterados'] ? 'CRITICO' : ($check['faltantes'] ? 'AVISO':'OK');
            $add('Documentos','Integridad física de PDFs',$status,
                $check['revisados'].' revisados (máximo 250), '.$check['faltantes'].' ausentes y '.$check['alterados'].' modificados.',
                'Si hay faltantes o diferencias, preservar evidencia y restaurar desde respaldo verificado.');
        }
    }
    if ($valid['arca30_demo_casos'] && $valid['arca29_documentos']) {
        $n = a32_num($db,"SELECT COUNT(*) n FROM arca30_demo_casos c WHERE c.codigo_obra IN ($in) AND c.estado='APROBADO' AND (c.fin<CURRENT_DATE() OR c.propuesto_por=c.revisado_por OR NOT EXISTS(SELECT 1 FROM arca29_documentos d WHERE d.origen='DEMO' AND d.id_demo_caso=c.id_caso))",$codes);
        $add('DEMO','Aprobaciones inconsistentes',a32_nivel($n,'CRITICO'),"$n casos DEMO aprobados con vigencia, autoría o documento por revisar.",'Revisar con CHRO y COO. No convertir DEMO en personal real.');
    }
    if ($valid['arca_auditoria_modulos']) {
        $n = a32_num($db,'SELECT COUNT(*) n FROM arca_auditoria_modulos');
        $add('Auditoría','Registros de trazabilidad',$n===0?'AVISO':'OK',"$n eventos registrados en bitácora.",'Verificar que altas, decisiones y descargas queden auditadas.');
    }
    return $out;
}
