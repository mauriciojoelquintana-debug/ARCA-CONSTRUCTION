<?php
declare(strict_types=1);
/** Consultas F36-F38: reutiliza sesión y permisos de las fases probadas. */
require_once __DIR__.'/arca34_datos.php';
require_once __DIR__.'/arca36_38_reglas.php';
function a36_pruebas_bd(mysqli $db): void { a34_base_pruebas($db); }
function a38_instalado(mysqli $db): bool {
    return a32_tabla($db,'arca38_flujos') && a32_tabla($db,'arca38_eventos');
}
function a38_codigos_autorizados(mysqli $db): array {
    // Respetar ámbito de F24; jamás ampliar acceso por una URL.
    $works=a24_obras_autorizadas($db);
    return array_values(array_unique(array_map(static fn($w)=>(string)$w['codigo_obra'],$works)));
}
function a38_verificar_obra(array $codes,string $codigo): void {
    if(!in_array($codigo,$codes,true))throw new DomainException('Obra fuera del ámbito autorizado.');
}
function a38_listado(mysqli $db,array $codes): array {
    if(!$codes)return [];
    $in=implode(',',array_fill(0,count($codes),'?'));
    // Ocultar trámites de otras direcciones aun cuando compartan una obra.
    $role=arx_role();$types=[];
    foreach(a38_tipos() as $tipo=>$meta)if(a38_crear_permitido($role,$tipo) || a38_revisar_permitido($role,$tipo))$types[]=$tipo;
    if(!$types)return [];
    $tin=implode(',',array_fill(0,count($types),'?'));
    return arx_rows($db,"SELECT id_flujo,codigo_obra,tipo,titulo,detalle,referencia_origen,estado,creado_por,creado_en,actualizado_en FROM arca38_flujos WHERE codigo_obra IN ($in) AND tipo IN ($tin) ORDER BY id_flujo DESC LIMIT 150",array_merge($codes,$types));
}
function a38_historial(mysqli $db,array $rows): array {
    if(!$rows)return [];
    $ids=array_map(static fn($r)=>(int)$r['id_flujo'],$rows);
    $ins=implode(',',array_fill(0,count($ids),'?'));
    $events=arx_rows($db,"SELECT id_flujo,accion,estado_anterior,estado_nuevo,actor_id,nota,registrado_en FROM arca38_eventos WHERE id_flujo IN ($ins) ORDER BY id_evento DESC LIMIT 450",$ids);
    $result=[];
    foreach($events as $ev)$result[(int)$ev['id_flujo']][]=$ev;
    return $result;
}
function a38_alta(mysqli $db,array $post,array $codes): void {
    a36_pruebas_bd($db);
    if(!a38_instalado($db))throw new RuntimeException('El registro de solicitudes no está configurado.');
    $tipo=(string)($post['tipo']??'');$role=arx_role();
    if(!a38_crear_permitido($role,$tipo))throw new DomainException('Rol sin permiso para crear este tipo de solicitud.');
    $codigo=(string)($post['codigo_obra']??'');a38_verificar_obra($codes,$codigo);
    $titulo=a38_texto($post['titulo']??null,140);
    $detalle=a38_texto($post['detalle']??null,2000);
    $ref=a38_referencia($post['referencia_origen']??'');
    $nonce=(string)($post['nonce']??'');
    if(!preg_match('/^[a-f0-9]{32}$/D',$nonce))throw new InvalidArgumentException('Identificador de formulario inválido.');
    $uid=arx_uid();if($uid<=0)throw new DomainException('Sesión incompleta.');
    $db->begin_transaction();
    try {
       // La clave única impide crear el mismo caso dos veces por reenvío del navegador.
       $exists=arx_one($db,'SELECT id_flujo FROM arca38_flujos WHERE nonce=?',[$nonce]);
       if($exists)throw new DomainException('Este formulario ya fue procesado. Recarga la página.');
       arx_exec($db,'INSERT INTO arca38_flujos(codigo_obra,tipo,titulo,detalle,referencia_origen,estado,creado_por,nonce) VALUES(?,?,?,?,?,?,?,?)',[$codigo,$tipo,$titulo,$detalle,$ref?:null,'PENDIENTE',$uid,$nonce]);
       $new=arx_one($db,'SELECT id_flujo FROM arca38_flujos WHERE nonce=?',[$nonce]);
       if(!$new)throw new RuntimeException('No se pudo confirmar la solicitud.');
       arx_exec($db,'INSERT INTO arca38_eventos(id_flujo,accion,estado_anterior,estado_nuevo,actor_id,nota) VALUES(?,?,?,?,?,?)',[(int)$new['id_flujo'],'CREAR',null,'PENDIENTE',$uid,'Solicitud creada; revisión asignada por reglas del tipo.']);
       $db->commit();
    }catch(Throwable $e){$db->rollback();throw $e;}
}
function a38_decidir(mysqli $db,array $post,array $codes): void {
    a36_pruebas_bd($db);
    if(!a38_instalado($db))throw new RuntimeException('El registro de decisiones no está configurado.');
    $id=filter_var($post['id_flujo']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if($id===false)throw new InvalidArgumentException('Folio inválido.');
    $accion=(string)($post['accion']??'');$nota=a38_texto($post['nota']??null,1200);
    $uid=arx_uid();$role=arx_role();
    $db->begin_transaction();
    try {
       $r=arx_one($db,'SELECT id_flujo,codigo_obra,tipo,estado,creado_por FROM arca38_flujos WHERE id_flujo=? FOR UPDATE',[$id]);
       if(!$r)throw new DomainException('Folio no encontrado.');
       a38_verificar_obra($codes,(string)$r['codigo_obra']);
       $estado=(string)$r['estado'];$tipo=(string)$r['tipo'];
       if($accion==='REENVIAR') {
          if((int)$r['creado_por']!==$uid)throw new DomainException('Solo quien inició la solicitud puede reenviarla.');
       } else {
          if(!a38_revisar_permitido($role,$tipo))throw new DomainException('Tu rol no puede resolver este flujo.');
          if((int)$r['creado_por']===$uid)throw new DomainException('Quien inicia una solicitud no puede aprobarse a sí mismo.');
       }
       $next=a38_transicion($estado,$accion);
       arx_exec($db,'UPDATE arca38_flujos SET estado=?,actualizado_en=CURRENT_TIMESTAMP WHERE id_flujo=?',[$next,$id]);
       arx_exec($db,'INSERT INTO arca38_eventos(id_flujo,accion,estado_anterior,estado_nuevo,actor_id,nota) VALUES(?,?,?,?,?,?)',[$id,$accion,$estado,$next,$uid,$nota]);
       $db->commit();
    } catch(Throwable $e){$db->rollback();throw $e;}
}
function a38_puede_ver_resolver(array $row): bool {
    return ((int)$row['creado_por']===arx_uid() && $row['estado']==='DEVUELTA') || ($row['estado']==='PENDIENTE' && a38_revisar_permitido(arx_role(),(string)$row['tipo']) && (int)$row['creado_por']!==arx_uid());
}
