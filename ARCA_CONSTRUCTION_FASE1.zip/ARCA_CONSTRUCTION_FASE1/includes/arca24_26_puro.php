<?php
declare(strict_types=1);
/** Reglas puras, comprobables sin MySQL ni sesiones. */
function a26_roles_resumen(): array { return ['CEO','Director General','CFO','COO','CHRO']; }
function a26_rol_finanzas(string $role): bool { return in_array($role,['CEO','Director General','CFO'],true); }
function a26_reportes_por_rol(string $role): array {
    return match($role) {
       'CEO','Director General'=>['obras','avances','finanzas','personal','compras','materiales'],
       'CFO'=>['obras','finanzas'],
       'COO'=>['obras','avances','personal','compras','materiales'],
       'CHRO'=>['obras','personal'],
       default=>[]
    };
}
function a26_periodo(?string $from,?string $to): array {
    $dates=[];
    foreach([$from,$to] as $raw) {
        $v=trim((string)$raw);
        if($v==='') {$dates[]=null;continue;}
        $d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);
        if(!$d || $d->format('Y-m-d')!==$v)throw new InvalidArgumentException('Fecha inválida; utiliza AAAA-MM-DD.');
        $dates[]=$v;
    }
    if($dates[0]!==null && $dates[1]!==null && $dates[0]>$dates[1])throw new InvalidArgumentException('La fecha inicial es posterior a la final.');
    return $dates;
}
function a26_currency(?string $v): string {
    $v=strtoupper(trim((string)$v));
    if(!in_array($v,['','USD','MXN','SIN_CONFIRMAR'],true))throw new InvalidArgumentException('Divisa no permitida.');
    return $v;
}
function a26_sql_in(array $values): string {
    if(!$values)throw new InvalidArgumentException('No hay obras autorizadas.');
    return implode(',',array_fill(0,count($values),'?'));
}
function a26_format_money($amount,string $currency): string {
    if($amount===null)return '—';
    return '$'.number_format((float)$amount,2,'.',',').' '.($currency?:'DIVISA SIN CONFIRMAR');
}
