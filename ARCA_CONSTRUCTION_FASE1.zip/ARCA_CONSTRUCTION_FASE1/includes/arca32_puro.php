<?php
declare(strict_types=1);
/** ARCA F32 - funciones puras reutilizables en pruebas. */
function a32_roles(): array { return ['CEO', 'Director General']; }
function a32_nivel(int $count, string $ifNonzero = 'AVISO'): string {return $count > 0 ? $ifNonzero : 'OK';}
function a32_fila(string $modulo, string $control, string $estado, string $detalle, string $accion): array {
    return compact('modulo', 'control', 'estado', 'detalle', 'accion');
}
function a32_resumen(array $rows): array {
    $counts=['OK'=>0,'AVISO'=>0,'CRITICO'=>0];
    foreach($rows as $r) if (isset($counts[$r['estado']])) $counts[$r['estado']]++;
    return $counts;
}
