<?php
declare(strict_types=1);
/** Metadatos técnicos de las tarjetas directivas. No cambia consultas ni unidades registradas. */
function a27_ficha(string $area):array {
 $items=[
 'CFO'=>['Lectura financiera','Fuente: finanzas_coo y validaciones de divisa; ingresos/costos clasificados según módulo y estado_pago.','La unidad es la moneda confirmada por transacción. Los registros sin confirmar deben informarse por separado.','Actualización: consulta al recargar. No es conciliación bancaria ni estado financiero auditado.'],
 'COO'=>['Control de avance físico','Fuente: obras_coo, alertas_coo y cortes registrados por obra.','avance_fisico es un porcentaje por obra; el promedio simple no pondera presupuesto ni área.','La vigencia depende de la última captura; no equivale a telemetría en tiempo real.'],
 'CIO'=>['Operación de sistemas','Fuentes: usuarios, soporte_tickets y arca_auditoria_modulos.','Cuentas no equivalen a personal contratado; tickets abiertos ≠ disponibilidad de servidores.','Sin monitoreo externo, latencias y respaldos deben quedar como NO VERIFICADOS.'],
 'CTO'=>['Innovación tecnológica','Fuentes: innovacion_tecnologica y requerimientos_cto.','Los equipos registrados no prueban funcionamiento en campo; los ahorros requieren divisa confirmada.','El control considera fecha y estado de cada registro, no señales IoT en vivo.'],
 'CCO'=>['Embudo comercial','Fuente: comercial_cco; clasificación por modulo y etapa_comercial.','Los importes históricos carecen de divisa confirmada y no se deben totalizar como USD.','Relaciones oportunidad → propuesta → contrato solo cuando exista vínculo explícito.'],
 'CMO'=>['Desempeño de marketing','Fuente: marketing_cmo. Contactos generados y campañas por estado.','Los presupuestos registrados requieren confirmación de moneda; registros no equivalen a conversiones verificadas.','La actualización depende del último registro y no de redes sociales en directo.'],
 'CHRO'=>['Plantilla y asignaciones','Fuentes: arca_empleados, arca_asignaciones_personal y arca_contratos_laborales.','Una cuenta en usuarios no implica contratación, ni una asignación histórica prueba vigencia.','La cobertura de obra se verifica por asignaciones ACTIVAS y empleados ACTIVOS.'],
 'CSO'=>['Seguimiento estratégico','Fuente: estrategia_cso, metas y registros de planeación existentes.','El porcentaje estratégico representa el dato capturado: no una medida automática de ejecución.','Comparar fechas, responsables, estados de metas y desviaciones antes de aprobar acciones.'],
 ];
 return $items[$area]??['Metodología del tablero','Verificar fuentes y filtros usados.','Conservar unidades y divisas según cada registro.','Datos actualizados al volver a ejecutar la consulta.'];
}
