<?php
declare(strict_types=1);
/** ARCA31 · Reglas comprobables sin MySQL. */
function a31_roles(): array {return ['CEO','Director General','CFO','COO','CHRO'];}
function a31_es_finanzas(string $role): bool {return in_array($role,['CEO','Director General','CFO'],true);}
function a31_es_operaciones(string $role): bool {return in_array($role,['CEO','Director General','COO'],true);}
function a31_es_personal(string $role): bool {return in_array($role,['CEO','Director General','COO','CHRO'],true);}
function a31_es_demo(string $role): bool {return in_array($role,['CEO','Director General','COO','CHRO'],true);}
function a31_rol_alcance(string $role): string {
    return match($role) {
        'CEO','Director General'=>'Visión general · operaciones, personal y finanzas',
        'CFO'=>'Finanzas · movimientos por moneda y estado',
        'COO'=>'Operaciones · avance, materiales, compras y personal',
        'CHRO'=>'Recursos Humanos · personal y avance de obras autorizadas',
        default=>'Acceso no autorizado'
    };
}
function a31_elegir_codigos(array $rows,string $requested): array {
    $codes=array_values(array_unique(array_map(static fn($r)=>(string)$r['codigo_obra'],$rows)));
    if(!$codes)throw new DomainException('No tienes obras autorizadas para este módulo.');
    if($requested==='')return $codes;
    if(!preg_match('/^[A-Z0-9-]{4,30}$/D',$requested))throw new InvalidArgumentException('Código de obra inválido.');
    if(!in_array($requested,$codes,true))throw new DomainException('No tienes permiso para consultar esta obra.');
    return [$requested];
}
function a31_moneda(?string $raw): string {
    $v=strtoupper(trim((string)$raw));
    return $v==='' || $v==='SIN_CONFIRMAR' || $v==='SIN CONFIRMAR' ? 'SIN CONFIRMAR' : $v;
}
function a31_riesgo(string $estado): bool {
    $s=function_exists('mb_strtolower')?mb_strtolower(trim($estado),'UTF-8'):strtolower(trim($estado));
    return in_array($s,['riesgo','retraso','atraso','en riesgo'],true);
}
function a31_dinero($importe,string $divisa): string {
    return '$'.number_format((float)$importe,2,'.',',').' '.a31_moneda($divisa);
}
function a31_porcentaje($valor): float {return max(0,min(100,(float)$valor));}
function a31_agrupar(array $rows,string $key): array {
    $out=[]; foreach($rows as $row)$out[(string)$row[$key]]=$row; return $out;
}
function a31_csv_value($v): string {
    $s=str_replace(["\r","\n"],' ',(string)($v??''));
    if(preg_match('/^[\s\x00-\x1F]*[=+@\-]/u',$s))$s="'".$s;
    return $s;
}
