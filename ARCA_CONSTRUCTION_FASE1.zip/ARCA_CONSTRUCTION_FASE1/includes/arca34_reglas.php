<?php
declare(strict_types=1);
/** ARCA F34-35: reglas puras, sin acceso a datos ni sesiones. */
function a34_roles(): array { return ['CEO','Director General']; }
function a35_roles(): array { return ['CEO','Director General','CIO']; }
function a34_codigo(string $fuente, string $area, string $control): string {
    if (!in_array($fuente,['F32','F33'],true)) throw new InvalidArgumentException('Fuente no admitida.');
    return hash('sha256',$fuente.'|'.$area.'|'.$control);
}
function a34_etapas(): array {
    return ['ABIERTO'=>'Abierto','EN_PROCESO'=>'En proceso','EN_VALIDACION'=>'En validación','CERRADO'=>'Cerrado','NO_APLICA'=>'No aplica'];
}
function a34_responsables(): array { return ['CEO','CIO','CFO','COO','CHRO']; }
function a34_prioridades(): array { return ['BAJA','MEDIA','ALTA','CRITICA']; }
function a34_texto(mixed $v, int $limite, bool $obligatorio = false): string {
    $s=trim((string)$v);
    if (str_contains($s,"\0") || preg_match('/[\x01-\x08\x0B\x0C\x0E-\x1F]/', $s)) throw new InvalidArgumentException('Caracteres no válidos.');
    $length=function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);
    if ($length>$limite || ($obligatorio && $length===0)) throw new InvalidArgumentException('Completa el campo respetando su longitud.');
    return $s;
}
function a34_validar_cierre(string $estado, string $evidencia, string $nota): void {
    if (!array_key_exists($estado,a34_etapas())) throw new InvalidArgumentException('Estado incorrecto.');
    if (in_array($estado,['CERRADO','NO_APLICA'],true) && (trim($evidencia)==='' || trim($nota)==='')) {
        throw new InvalidArgumentException('Para cerrar o declarar no aplicable, escribe evidencia y justificación.');
    }
}
function a34_csv_seguro(mixed $v): string {
    $s=str_replace(["\r","\n"],' ',(string)($v??''));
    if (preg_match('/^[\s\x00-\x1f]*[=+@\-]/u',$s)) $s="'".$s;
    return $s;
}
function a34_controles(array $rows32, array $rows33): array {
    $result=[];
    foreach($rows32 as $x) {
        $fuente='F32';$area=(string)$x['modulo'];$nombre=(string)$x['control'];
        $id=a34_codigo($fuente,$area,$nombre);
        $result[$id]=['codigo'=>$id,'fuente'=>$fuente,'area'=>$area,'control'=>$nombre,
            'estado_auto'=>(string)$x['estado'],'detalle'=>(string)$x['detalle'],'accion'=>(string)$x['accion']];
    }
    foreach($rows33 as $x) {
        $fuente='F33';$area=(string)$x['area'];$nombre=(string)$x['nombre'];
        $id=a34_codigo($fuente,$area,$nombre);
        $result[$id]=['codigo'=>$id,'fuente'=>$fuente,'area'=>$area,'control'=>$nombre,
            'estado_auto'=>(string)$x['estado'],'detalle'=>(string)$x['detalle'],'accion'=>(string)$x['accion']];
    }
    return $result;
}
function a35_catalogo(): array {
    return [
        'SEG01'=>['Seguridad','Restricción de acceso al Centro de calidad para CHRO','Comprobar que CHRO no pueda acceder directamente al Centro de calidad.'],
        'SEG02'=>['Seguridad','Restricción de acceso a Verificación operativa para CFO','Comprobar que CFO no pueda acceder directamente a Verificación operativa.'],
        'SEG03'=>['Seguridad','Acceso de CIO a Verificación operativa','Confirmar que CIO puede consultar las verificaciones, sin acceder a las observaciones reservadas del Centro de calidad.'],
        'SEG04'=>['Seguridad','Permisos para obra clasificada','Con un rol sin permiso explícito, intentar URL y filtro a una obra SEC; debe negar datos.'],
        'SEG05'=>['Seguridad','Protección de formularios de calidad y verificación','Verificar que los formularios rechacen solicitudes sin el control de seguridad y no guarden cambios.'],
        'SEG06'=>['Seguridad','Operación con sesión caducada','Cerrar sesión y usar URL directa POST/descarga; acceso denegado.'],
        'SEG07'=>['Seguridad','Descarga de documentos privados','Comprobar que CHRO autorizado descarga PDF; otro rol recibe denegación. No copiar PDF como evidencia.'],
        'SEG08'=>['Seguridad','Exportaciones CSV por perfil','Comprobar que CFO exporta finanzas y CHRO no obtiene columnas financieras ni URL de exportación directa.'],
        'SEG09'=>['Seguridad','CSV sin ejecución de fórmulas','Probar en ambiente local un valor de prueba con prefijo =; al exportar no debe interpretarse como fórmula.'],
        'DAT01'=>['Integridad','Contratos y personal reales separados de DEMO','Verificar que los casos de demostración no generan empleados activos ni contratos reales.'],
        'DAT02'=>['Integridad','Monedas no confirmadas','Conciliar con CFO los movimientos sin divisa; nunca marcar USD/MXN por suposición.'],
        'DAT03'=>['Integridad','Expedientes CHRO','Verificar soporte de los expedientes pendientes; no activarlos automáticamente.'],
        'DAT04'=>['Integridad','Vigencia laboral por obra','Probar rechazo de asignación sin contrato propio y vigente desde Validación laboral.'],
        'DOC01'=>['Documentos','Integridad SHA-256 PDF','Confirmar existencia, huella y acceso autorizado de PDFs; no adjuntar documentos personales a evidencias.'],
        'BKP01'=>['Respaldos','Respaldo fechado de la información','Generar una copia de la información y registrar su referencia y fecha sin incluir credenciales.'],
        'BKP02'=>['Respaldos','Respaldo de código y almacén privado','Respaldar carpeta ERP y almacén documental fuera de www, con control de acceso.'],
        'BKP03'=>['Respaldos','Restauración aislada probada','Restaurar base y archivos en entorno separado; probar login, integridad y reportes. Nunca restaurar sobre base activa.'],
        'DEP01'=>['Producción','HTTPS y cookies seguras','Validar TLS válido, redirección, Secure, HttpOnly y sesiones en entorno de preproducción.'],
        'DEP02'=>['Producción','Errores y registros protegidos','Desactivar display_errors en producción y comprobar logs con acceso restringido.'],
        'DEP03'=>['Producción','Revisión independiente','Registrar revisión externa de código, dependencias y pruebas de exposición antes de publicar.'],
    ];
}
function a35_resultados(): array { return ['NO_EJECUTADA','APROBADA','FALLIDA','BLOQUEADA']; }
function a35_validar_prueba(string $id,string $resultado,string $referencia,string $observacion): void {
    if (!isset(a35_catalogo()[$id]) || !in_array($resultado,a35_resultados(),true)) throw new InvalidArgumentException('Caso o resultado no reconocido.');
    if ($resultado==='APROBADA' && ($referencia==='' || $observacion==='')) throw new InvalidArgumentException('Una prueba aprobada exige referencia de evidencia y observación.');
    if (in_array($resultado,['FALLIDA','BLOQUEADA'],true) && $observacion==='') throw new InvalidArgumentException('Indica el fallo o bloqueo encontrado.');
}
function a35_puerta(array $rows32, array $rows33, array $states): array {
    $findings32=count(array_filter($rows32,static fn($r)=>($r['estado']??'')!=='OK'));
    $findings33=count(array_filter($rows33,static fn($r)=>($r['estado']??'')!=='OK'));
    $pending=[];
    foreach(a35_catalogo() as $id=>$case) if (($states[$id]??'NO_EJECUTADA')!=='APROBADA') $pending[]=$id;
    return ['apto'=>($findings32===0 && $findings33===0 && !$pending),
            'auditoria_pendiente'=>$findings32,'configuracion_pendiente'=>$findings33,
            'pruebas_pendientes'=>count($pending),'total'=>count(a35_catalogo())];
}
