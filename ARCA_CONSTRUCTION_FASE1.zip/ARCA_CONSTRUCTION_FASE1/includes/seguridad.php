<?php
// Utilidades de sesión, controles de acceso y escape HTML.
function arca_iniciar_sesion(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function arca_h(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function arca_requerir_roles(array $roles): void {
    arca_iniciar_sesion();
    if (empty($_SESSION['id_usuario']) || empty($_SESSION['rol_activo'])) {
        header('Location: ingreso.html'); exit;
    }
    if (!in_array(trim((string)$_SESSION['rol_activo']), $roles, true)) {
        http_response_code(403);
        exit('Acceso restringido: no tienes permisos para esta sección.');
    }
}
function arca_token(): string {
    arca_iniciar_sesion();
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function arca_verificar_token(): void {
    arca_iniciar_sesion();
    if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf_token'])) {
        http_response_code(403); exit('Solicitud inválida. Actualiza la página e inténtalo nuevamente.');
    }
}
