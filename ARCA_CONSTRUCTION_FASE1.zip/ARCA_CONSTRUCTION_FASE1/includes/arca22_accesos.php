<?php
declare(strict_types=1);
/** ARCA 22-23: índice de navegación / barrera central; no asigna permisos ni modifica MySQL. */
require_once __DIR__ . '/arca_core.php';

function a22_catalogo(): array {
    $ceo=['CEO','Director General'];
    $alto=['CEO','Director General','CFO','COO','CIO','CTO','CCO','CMO','CHRO','CSO'];
    $obra=array_merge($alto,['Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén']);
    return [
        'arca24_tablero.php'=>['nombre'=>'Indicadores de gestión','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CFO','COO','CHRO'],'obra'=>false],
        'arca25_reportes.php'=>['nombre'=>'Reportes filtrados PDF y Excel','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CFO','COO','CHRO'],'obra'=>false],
        'arca26_seguridad.php'=>['nombre'=>'Auditoría y verificaciones','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CIO'],'obra'=>false],
        'arca_integracion.php' => ['nombre'=>'Integración empresarial','grupo'=>'Dirección general','roles'=>array_merge($ceo,['CFO','COO','CHRO']),'obra'=>false],
        'arca_ceo_integrado.php'=>['nombre'=>'Panel CEO integrado','grupo'=>'Dirección general','roles'=>$ceo,'obra'=>false],
        'panel_ceo.php'=>['nombre'=>'Resumen del CEO','grupo'=>'Dirección general','roles'=>$ceo,'obra'=>false],
        'panel_cfo.php'=>['nombre'=>'CFO · Finanzas','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CFO']),'obra'=>false],
        'panel_coo.php'=>['nombre'=>'COO · Operaciones','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['COO']),'obra'=>false],
        'panel_cio.php'=>['nombre'=>'CIO · Sistemas','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CIO']),'obra'=>false],
        'panel_cto.php'=>['nombre'=>'CTO · Innovación','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CTO']),'obra'=>false],
        'panel_cco.php'=>['nombre'=>'CCO · Comercial','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CCO']),'obra'=>false],
        'panel_cmo.php'=>['nombre'=>'CMO · Marketing','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CMO']),'obra'=>false],
        'panel_chro.php'=>['nombre'=>'CHRO · Recursos humanos','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CHRO']),'obra'=>false],
        'panel_cso.php'=>['nombre'=>'CSO · Estrategia','grupo'=>'Direcciones ejecutivas','roles'=>array_merge($ceo,['CSO']),'obra'=>false],
        'finanzas_auditoria.php'=>['nombre'=>'Conciliación y divisas','grupo'=>'Finanzas','roles'=>array_merge($ceo,['CFO']),'obra'=>false],
        'herramientas_cfo.php'=>['nombre'=>'Operaciones financieras','grupo'=>'Finanzas','roles'=>array_merge($ceo,['CFO']),'obra'=>false],
        'coo_control.php'=>['nombre'=>'Control de obras','grupo'=>'Operaciones','roles'=>array_merge($obra,['Seguridad']),'obra'=>false],
        'arca_obra_360.php'=>['nombre'=>'Expediente Obra 360','grupo'=>'Operaciones','roles'=>$obra,'obra'=>true],
        'panel_oficina_almacen.php'=>['nombre'=>'Oficina técnica y almacén','grupo'=>'Operaciones','roles'=>$obra,'obra'=>true],
        'arca_recepcion.php'=>['nombre'=>'Recepción de materiales','grupo'=>'Operaciones','roles'=>['COO','Almacenista','Jefe de Almacén'],'obra'=>true],
        'arca_autorizaciones.php'=>['nombre'=>'Autorizaciones por obra','grupo'=>'Operaciones','roles'=>$obra,'obra'=>true],
        'arca_compras.php'=>['nombre'=>'Compras y proveedores','grupo'=>'Operaciones','roles'=>array_merge($ceo,['COO']),'obra'=>false],
        'chro_personal.php'=>['nombre'=>'Expedientes de empleados','grupo'=>'Recursos humanos','roles'=>array_merge($ceo,['CHRO']),'obra'=>false],
        'arca_estructura.php'=>['nombre'=>'Gerencias y departamentos','grupo'=>'Recursos humanos','roles'=>array_merge($ceo,['CHRO']),'obra'=>false],
        'arca_reportes_vivos.php'=>['nombre'=>'Reportes PDF y Excel','grupo'=>'Reportes y control','roles'=>array_merge($ceo,['CFO','COO','CHRO']),'obra'=>false],
        'arca_reportes.php'=>['nombre'=>'Reportes ejecutivos','grupo'=>'Reportes y control','roles'=>array_merge($ceo,['COO']),'obra'=>false],
        'arca_seguridad.php'=>['nombre'=>'Auditoría técnica','grupo'=>'Reportes y control','roles'=>array_merge($ceo,['CIO']),'obra'=>false],
        'arca_validacion.php'=>['nombre'=>'Auditoría de integridad','grupo'=>'Reportes y control','roles'=>array_merge($ceo,['CIO']),'obra'=>false],
        'arca_lanzamiento.php'=>['nombre'=>'Preparación de despliegue','grupo'=>'Reportes y control','roles'=>array_merge($ceo,['CIO']),'obra'=>false],
        'arca27_apoyos.php'=>['nombre'=>'Áreas de apoyo','grupo'=>'Dirección general','roles'=>['CEO','Director General','COO','CFO','CHRO'],'obra'=>false],
        'arca27_soporte.php'=>['nombre'=>'Mesa de soporte','grupo'=>'Sistemas','roles'=>['CEO','Director General','CIO'],'obra'=>false],
        'arca27_sql.php'=>['nombre'=>'Reportes de sistemas','grupo'=>'Sistemas','roles'=>['CEO','Director General','CIO'],'obra'=>false],
        'arca27_ti.php'=>['nombre'=>'Controles TI verificables','grupo'=>'Sistemas','roles'=>['CEO','Director General','CIO'],'obra'=>false],
        'arca27_comercial.php'=>['nombre'=>'Embudo comercial','grupo'=>'Comercial','roles'=>['CEO','Director General','CCO'],'obra'=>false],
        'arca27_equipo_obra.php'=>['nombre'=>'Responsables de obra','grupo'=>'Recursos humanos','roles'=>['CEO','Director General','COO','CHRO','Gerente de Proyecto','Residente de Obra','Arquitecto','Ingeniero Civil'],'obra'=>false],
        'arca27_documentos.php'=>['nombre'=>'Planos y renders','grupo'=>'Operaciones','roles'=>['CEO','Director General','COO','CTO','CIO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén'],'obra'=>false],
        'arca27_auditoria.php'=>['nombre'=>'Verificación de seguridad','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CIO'],'obra'=>false],    ];
}
function a22_rol_permitido(string $ruta, ?string $rol=null): bool {
    $meta=a22_catalogo()[$ruta]??null;
    return $meta!==null && in_array($rol??arx_role(),$meta['roles'],true);
}
function a22_permiso_obra(mysqli $db,string $codigo,string $accion='consultar'): bool {
    if(!arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=?',[$codigo]))return false;
    // Coincide con el diseño anterior: CFO y CHRO solo pueden consultar obras.
    if(in_array(arx_role(),['CFO','CHRO'],true))return $accion==='consultar';
    if(arx_role()==='CTO' && $accion==='consultar')return true;
    return arx_permission($db,$codigo,$accion);
}
function a22_modulo_permitido(mysqli $db,string $ruta,?string $codigoObra=null):bool {
    if(!a22_rol_permitido($ruta))return false;
    $meta=a22_catalogo()[$ruta];
    if(!empty($meta['obra'])) {
        if($codigoObra!==null && $codigoObra!=='')return a22_permiso_obra($db,$codigoObra);
        $obras=arx_rows($db,'SELECT codigo_obra FROM obras_coo ORDER BY codigo_obra');
        foreach($obras as $o){if(a22_permiso_obra($db,(string)$o['codigo_obra']))return true;}
        return false;
    }
    return true;
}
function a22_obras_permitidas(mysqli $db):array {
    $rows=arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra');
    return array_values(array_filter($rows,fn($row)=>a22_permiso_obra($db,(string)$row['codigo_obra'])));
}
function a22_url(string $ruta,?string $obra=null):string {
    // Solo rutas del catálogo, jamás URLs arbitrarias.
    if(!isset(a22_catalogo()[$ruta]))throw new InvalidArgumentException('Ruta no reconocida');
    $params=['modulo'=>$ruta];if($obra!==null && $obra!=='')$params['obra']=$obra;
    return 'arca22_abrir.php?'.http_build_query($params,'','&',PHP_QUERY_RFC3986);
}
function a22_guardar_error_log(string $texto):void {error_log('[ARCA22] '.$texto);}
function a22_barra_flotante():void {
    // En páginas legadas se inserta solo un enlace visible; los permisos se revisan en arca22_portal.php.
    echo '<link rel="stylesheet" href="assets/css/arca22.css?v=22">';
    echo '<a class="arca22-boton-global" href="arca22_portal.php" aria-label="Abrir menú general de ARCA">⌂ Menú ARCA</a>';
}
function a22_guard_legacy(string $archivo):void {
    arca_iniciar_sesion();
    if(empty($_SESSION['id_usuario']) || empty($_SESSION['rol_activo'])){header('Location: ingreso.html',true,302);exit;}
    $reglas=[
        'reportes_sql.php'=>['CEO','Director General','CIO'],
        'soporte_tecnico.php'=>['CEO','Director General','CIO'],
        'desglose_federal.php'=>['CEO','Director General','CFO'],
        'panel_ejecutivo.php'=>['CEO','Director General'],
        'panel_ingenieria.php'=>['CEO','Director General','COO','CTO','Ingeniero Civil','Ingeniero','Arquitecto','Gerente de Proyecto','Residente de Obra'],
    ];
    if(!isset($reglas[$archivo])){http_response_code(403);exit('Ruta heredada no autorizada por el control de acceso.');}
    if(!in_array(arx_role(),$reglas[$archivo],true)){http_response_code(403);exit('Acceso no autorizado para tu cargo.');}
}
