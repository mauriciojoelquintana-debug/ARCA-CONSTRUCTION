<?php
declare(strict_types=1);
require_once __DIR__ . '/arca24_indicadores.php';
/**
 * Mantiene el ámbito ordinario de la Fase 22, pero exige una concesión explícita
 * para consultar obras clasificadas desde cualquier cargo distinto del CEO.
 * No realiza cambios en la base de datos.
 */
function a24_obras_autorizadas(mysqli $db): array {
    $rows = a22_obras_permitidas($db);
    if (in_array(arx_role(), ['CEO', 'Director General'], true)) {
        return $rows;
    }
    $autorizadas = [];
    foreach ($rows as $obra) {
        $codigo = (string)($obra['codigo_obra'] ?? '');
        if ($codigo === '') continue;
        if (str_starts_with($codigo, 'ARCA-SEC-')) {
            $concesion = arx_one(
                $db,
                'SELECT nivel FROM arca_accesos_obra WHERE id_usuario=? AND codigo_obra=? LIMIT 1',
                [arx_uid(), $codigo]
            );
            if (!$concesion || !in_array((string)$concesion['nivel'], ['consultar','operar','aprobar'], true)) {
                continue;
            }
        }
        $autorizadas[] = $obra;
    }
    return $autorizadas;
}
