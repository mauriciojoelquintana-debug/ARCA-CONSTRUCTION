<?php
declare(strict_types=1);
require_once __DIR__.'/arca_fases_8_13.php';

function ax_roles(): array {
 return ['CEO','Director General','CFO','COO','CHRO','CIO','CTO','CCO','CMO','CSO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén'];
}
function ax_exec_roles(): array { return ['CEO','Director General','CFO','COO','CHRO']; }
function ax_global_role(): bool {return in_array(arx_role(),['CEO','Director General','COO','CFO','CHRO'],true);}
function ax_can_obra(mysqli $db,string $obra,string $action='consultar'): bool {
 if(arx_role()==='CFO')return $action==='consultar' && (bool)arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=?',[$obra]);
 if(arx_role()==='CHRO')return $action==='consultar' && (bool)arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=?',[$obra]);
 return arx_permission($db,$obra,$action);
}
function ax_require_obra(mysqli $db,string $obra,string $action='consultar'): void {
 if(!arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=?',[$obra]) || !ax_can_obra($db,$obra,$action)){http_response_code(403);exit('No tienes autorización para consultar o modificar esta obra.');}
}
function ax_obras(mysqli $db): array {
 $rows=arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo WHERE codigo_obra IS NOT NULL ORDER BY codigo_obra');
 return array_values(array_filter($rows,static fn($r)=>ax_can_obra($db,(string)$r['codigo_obra'])));
}
function ax_selected_obra(mysqli $db,?string $requested=null): string {
 $opts=ax_obras($db);$code=$requested?:($opts[0]['codigo_obra']??'');
 if($code===''){http_response_code(403);exit('No tienes obras autorizadas.');}
 ax_require_obra($db,$code);return $code;
}
function ax_money($amount,$currency): string {return '$'.number_format((float)$amount,2,'.',',').' '.($currency?:'DIVISA SIN CONFIRMAR');}
function ax_menu(): array {
 $r=arx_role();
 $menu=['arca_integracion.php'=>'Vista integrada','arca_obra_360.php'=>'Obra 360','arca_autorizaciones.php'=>'Autorizaciones','arca_recepcion.php'=>'Recepciones de almacén','arca_reportes_vivos.php'=>'Reportes automáticos','arca_seguridad.php'=>'Verificación y calidad','arca_lanzamiento.php'=>'Preparación versión 1.0'];
 if(!in_array($r,['COO','Almacenista','Jefe de Almacén'],true))unset($menu['arca_recepcion.php']);
 if(!in_array($r,['CEO','Director General','CIO'],true))unset($menu['arca_seguridad.php']);
 if(!in_array($r,['CEO','Director General','CIO'],true))unset($menu['arca_lanzamiento.php']);
 if(!in_array($r,['CEO','Director General','COO','CFO','CHRO'],true))unset($menu['arca_integracion.php']);
 if(!in_array($r,['CEO','Director General','COO','CFO','CHRO'],true))unset($menu['arca_reportes_vivos.php']);
 if($r==='CIO')return array_intersect_key($menu,array_flip(['arca_seguridad.php','arca_lanzamiento.php']));
 if(in_array($r,['CTO','CCO','CMO','CSO'],true))return [];
 return $menu;
}
function ax_layout(string $heading,string $desc,string $active): void {
 arx_layout_start($heading,$desc,$active,'Gestión integrada',ax_menu());
 echo '<link rel="stylesheet" href="assets/css/arca-integracion.css?v=1">';
}
function ax_fail(Throwable $e,string $route): never {
 error_log('ARCA INTEGRACION: '.$e->getMessage());
 arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No fue posible guardar; revisa el log de PHP.',true);
 arx_redirect($route);
}
function ax_obras_selector(array $rows,string $selected,string $param='obra'): void {
 echo '<select name="'.arx_h($param).'" required>';
 foreach($rows as $r)echo '<option value="'.arx_h($r['codigo_obra']).'" '.($selected===$r['codigo_obra']?'selected':'').'>'.arx_h($r['codigo_obra'].' · '.$r['nombre_proyecto']).'</option>';
 echo '</select>';
}
function ax_partition_finances(mysqli $db,string $obra): array {
 return arx_rows($db,"SELECT COALESCE(moneda,'SIN CONFIRMAR') divisa,modulo,estado_pago, COUNT(*) cantidad, SUM(monto) importe FROM finanzas_coo WHERE codigo_obra=? GROUP BY COALESCE(moneda,'SIN CONFIRMAR'),modulo,estado_pago ORDER BY divisa,modulo,estado_pago",[$obra]);
}
