<?php
declare(strict_types=1);
require_once __DIR__.'/arca_core.php';

function a20_user_roles(): array {
 return ['CEO','Director General','COO','CTO','CIO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén'];
}
function a20_boot(): mysqli {return arx_boot(a20_user_roles());}
function a20_global_read(): bool { return in_array(arx_role(),['CEO','Director General','COO','CTO'],true); }
function a20_can(mysqli $db,string $obra,string $action='consultar',string $resource='general'):bool {
 if(!arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=?',[$obra])) return false;
 if($action==='consultar' && a20_global_read())return true;
 if($action!=='consultar'){
  $role=arx_role();
  if(in_array($role,['CEO','Director General','CIO'],true))return false;
  if($resource==='planos' && in_array($role,['Almacenista','Jefe de Almacén'],true))return false;
  if($resource==='materiales' && in_array($role,['Arquitecto','Topógrafo'],true))return false;
  if($role==='CTO')return arx_permission($db,$obra,'operar');
 }
 return arx_permission($db,$obra,$action==='consultar'?'consultar':'operar');
}
function a20_require(mysqli $db,string $obra,string $need='consultar',string $type='general'):void {
 if(!a20_can($db,$obra,$need,$type)) {http_response_code(403);exit('Acceso denegado para esta obra y operación.');}
}
function a20_obras(mysqli $db):array {
 return array_values(array_filter(arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra'),static fn(array $r)=>a20_can($db,(string)$r['codigo_obra'])));
}
function a20_obras_options(array $rows,string $selected='',bool $all=false):void {
 if($all)echo '<option value="TODAS"'.($selected==='TODAS'?' selected':'').'>Todas las obras autorizadas</option>';
 foreach($rows as $r){$c=(string)$r['codigo_obra'];echo '<option value="'.arx_h($c).'"'.($selected===$c?' selected':'').'>'.arx_h($c.' · '.$r['nombre_proyecto']).'</option>';}
}
function a20_flash():?array { $f=$_SESSION['a20_flash']??null;unset($_SESSION['a20_flash']);return is_array($f)?$f:null; }
function a20_notice(string $s,bool $error=false):void { $_SESSION['a20_flash']=['text'=>$s,'error'=>$error]; }
function a20_page_url(string $vista,string $obra):string {return 'panel_oficina_almacen.php?vista='.rawurlencode($vista).'&obra='.rawurlencode($obra);}
function a20_private_directory():string {
 // Fuera de C:/laragon/www y por tanto del DocumentRoot de arca.test.
 $path=(string)(getenv('ARCA_PRIVATE_PLANOS')?:dirname(__DIR__,3).DIRECTORY_SEPARATOR.'arca_archivos_privados'.DIRECTORY_SEPARATOR.'planos');
 return rtrim($path,'/\\');
}
function a20_extension(string $name):string {return strtolower((string)pathinfo($name,PATHINFO_EXTENSION));}
function a20_validate_upload(array $up):string {
 if(($up['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || !is_uploaded_file((string)$up['tmp_name']))throw new InvalidArgumentException('Adjunta un archivo válido.');
 if((int)$up['size']<=0 || (int)$up['size']>25*1024*1024)throw new InvalidArgumentException('El tamaño máximo por archivo es 25 MB.');
 $ext=a20_extension((string)$up['name']);
 if(!in_array($ext,['pdf','jpg','jpeg','png','dwg','rvt','ifc'],true)) throw new InvalidArgumentException('Tipo de archivo no permitido.');
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file((string)$up['tmp_name']) ?: '';
 if($ext==='pdf' && $mime!=='application/pdf') throw new InvalidArgumentException('El PDF no parece válido.');
 if(in_array($ext,['jpg','jpeg','png'],true)){
  $t=@getimagesize((string)$up['tmp_name']);
  if(!$t || !in_array($t['mime'],['image/jpeg','image/png'],true) || ($ext==='png' && $t['mime']!=='image/png'))throw new InvalidArgumentException('La imagen no es válida.');
 }
 // DWG/RVT/IFC se guardan como adjuntos no ejecutables fuera del webroot.
 return $ext;
}
function a20_safe_upload(array $up):array {
 $ext=a20_validate_upload($up);$dir=a20_private_directory();
 if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('No se pudo crear el directorio privado.');
 if(!is_writable($dir))throw new RuntimeException('El directorio privado no permite escritura.');
 $web=realpath(dirname(__DIR__));$real=realpath($dir);
 if($web!==false&&$real!==false&&str_starts_with(strtolower($real.DIRECTORY_SEPARATOR),strtolower($web.DIRECTORY_SEPARATOR)))throw new RuntimeException('Los planos deben guardarse fuera de la carpeta pública del ERP.');
 $name=bin2hex(random_bytes(18)).'.'.$ext;
 $dest=$dir.DIRECTORY_SEPARATOR.$name;
 if(!move_uploaded_file((string)$up['tmp_name'],$dest))throw new RuntimeException('No se pudo guardar el archivo adjunto.');
 return ['db'=>'privado:'.$name,'abs'=>$dest];
}
function a20_operation(mysqli $db,array $p,array $files):void {
 arx_check_post();
 $type=(string)($p['accion']??'');
 if(!in_array($type,['subir_plano','registrar_insumo','ajustar_stock'],true))throw new InvalidArgumentException('Operación no reconocida.');
 if(arx_uid()<1)throw new RuntimeException('La sesión no contiene ID de usuario. Inicia sesión otra vez.');
 if($type==='subir_plano'){
  $obra=arx_code($p['codigo_obra']??'');a20_require($db,$obra,'operar','planos');
  $codigo=arx_text($p['codigo_plano']??'',50);$titulo=arx_text($p['titulo_documento']??'',200);
  $especialidad=arx_text($p['especialidad_tecnica']??'',100);$revision=arx_text($p['version_rev']??'',30);
  $estado=(string)($p['estado_revision']??'');
  if(!in_array($estado,['Aprobado Construcción','En Revisión Técnica','Validado sin Choques'],true))throw new InvalidArgumentException('Estado no reconocido.');
  $up=$files['archivo_plano']??[];$archive=a20_safe_upload($up);$db->begin_transaction();
  try{
   arx_exec($db,'INSERT INTO planos_oficina_tecnica(codigo_plano,codigo_obra,especialidad_tecnica,titulo_documento,version_rev,archivo_ruta,autor_responsable,estado_revision,fecha_actualizacion) VALUES(?,?,?,?,?,?,?,?,CURDATE())',[$codigo,$obra,$especialidad,$titulo,$revision,$archive['db'],arx_name().' ('.($_SESSION['usuario_activo']??'').')',$estado]);
   $id=(int)$db->insert_id; arx_audit($db,'oficina_tecnica','plano',$id,'CREAR',null,['codigo_obra'=>$obra,'codigo_plano'=>$codigo,'archivo'=>$archive['db']]);
   $db->commit();a20_notice('Documento '.$codigo.' registrado en '.$obra.'.');
  }catch(Throwable $e){$db->rollback();@unlink($archive['abs']);throw $e;}return;
 }
 if($type==='registrar_insumo'){
  $obra=arx_code($p['codigo_obra']??'');a20_require($db,$obra,'operar','materiales');
  $codigo=arx_text($p['codigo_insumo']??'',50);$desc=arx_text($p['descripcion_recurso']??'',200);
  $cat=arx_text($p['categoria_recurso']??'',80);$unidad=arx_text($p['unidad_medida']??'',40);
  $ubic=arx_text($p['ubicacion_almacen']??'',120);
  if(!in_array($cat,['Materiales Críticos','Materiales Especiales','Logística y Herramienta','Equipamiento Especial','Materiales Clasificados'],true))throw new InvalidArgumentException('Categoría no permitida. La maquinaria se gestiona en COO.');
  $cantidad=arx_decimal($p['cantidad_actual']??'',true);$min=arx_decimal($p['stock_minimo']??'',true);
  $db->begin_transaction();try{
   if(arx_one($db,'SELECT id_insumo FROM inventario_almacen_arca WHERE codigo_insumo=? AND codigo_obra=?',[$codigo,$obra])) throw new InvalidArgumentException('Ya existe ese código para esta obra.');
   $status=(float)$cantidad<=(float)$min?'Stock Bajo (Reordenar)':'Stock Óptimo';
   arx_exec($db,'INSERT INTO inventario_almacen_arca(codigo_insumo,codigo_obra,categoria_recurso,descripcion_recurso,unidad_medida,cantidad_actual,stock_minimo,ubicacion_almacen,responsable_resguardo,estado_inventario) VALUES(?,?,?,?,?,?,?,?,?,?)',[$codigo,$obra,$cat,$desc,$unidad,$cantidad,$min,$ubic,arx_name(),$status]);
   $id=(int)$db->insert_id; arx_audit($db,'almacen','insumo',$id,'CREAR',null,['codigo_obra'=>$obra,'codigo_insumo'=>$codigo,'cantidad'=>$cantidad]);
   $db->commit(); a20_notice('Recurso '.$codigo.' registrado en el almacén.');
  }catch(Throwable $e){$db->rollback();throw $e;} return;
 }
 $id=arx_int($p['id_insumo']??null);$qty=arx_decimal($p['cantidad_mov']??'');$mov=(string)($p['tipo_movimiento']??'');
 if(!in_array($mov,['ENTRADA','SALIDA'],true))throw new InvalidArgumentException('Movimiento incorrecto.');
 $db->begin_transaction();try{
  $row=arx_one($db,'SELECT * FROM inventario_almacen_arca WHERE id_insumo=? FOR UPDATE',[$id]);
  if(!$row)throw new InvalidArgumentException('Recurso no encontrado.');
  $obra=(string)$row['codigo_obra'];a20_require($db,$obra,'operar','materiales');
  if($row['categoria_recurso']==='Maquinaria Pesada')throw new InvalidArgumentException('La maquinaria se controla en el módulo COO.');
  $antes=number_format((float)$row['cantidad_actual'],2,'.','');
  if($mov==='SALIDA' && (float)$qty>(float)$antes)throw new InvalidArgumentException('Existencias insuficientes. No se realizó el despacho.');
  $despues=number_format($mov==='ENTRADA'?(float)$antes+(float)$qty:(float)$antes-(float)$qty,2,'.','');
  $estado=(float)$despues<=(float)$row['stock_minimo']?'Stock Bajo (Reordenar)':'Stock Óptimo';
  arx_exec($db,'UPDATE inventario_almacen_arca SET cantidad_actual=?,estado_inventario=? WHERE id_insumo=?',[$despues,$estado,$id]);
  arx_exec($db,'INSERT INTO arca_movimientos_material(id_insumo,codigo_obra,tipo,cantidad,anterior,posterior,observaciones,usuario_id) VALUES(?,?,?,?,?,?,?,?)',[$id,$obra,$mov,$qty,$antes,$despues,'Vale de almacén',arx_uid()]);
  arx_audit($db,'almacen','insumo',$id,$mov,['cantidad_actual'=>$antes],['cantidad_actual'=>$despues]);
  $db->commit();a20_notice('Movimiento '.$mov.' confirmado. Saldo: '.$despues.' '.$row['unidad_medida'].'.');
 }catch(Throwable $e){$db->rollback();throw $e;}
}
