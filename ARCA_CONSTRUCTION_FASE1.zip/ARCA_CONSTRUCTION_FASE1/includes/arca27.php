<?php
declare(strict_types=1);
/** ARCA 27: funciones transversales; sin credenciales ni variables globales del login. */
require_once __DIR__.'/arca_core.php';
function a27_boot(array $roles): mysqli {
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    return arx_boot($roles);
}
function a27_h(mixed $v): string {return arx_h($v);}
function a27_die(string $message='Operación no autorizada.',int $status=403): never {http_response_code($status);exit(a27_h($message));}
function a27_alert(string $message,bool $error=false): void {$_SESSION['arca27_flash']=[$message,$error];}
function a27_flash(): void {
 $f=$_SESSION['arca27_flash']??null;unset($_SESSION['arca27_flash']);
 if(is_array($f))echo '<div class="a27-alert '.(!empty($f[1])?'warn':'ok').'">'.a27_h($f[0]).'</div>';
}
function a27_post():void {arx_check_post();if(arx_uid()<=0)a27_die('Sesión de usuario incompleta.',401);}
function a27_redirect(string $url):never {header('Location: '.$url,true,303);exit;}
function a27_can_obra(mysqli $db,string $codigo,string $accion='consultar'): bool {
 if(!arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=?',[$codigo]))return false;
 return arx_permission($db,$codigo,$accion);
}
function a27_obras_lectura(mysqli $db):array {return arx_obras($db);}
function a27_comercial_obras(mysqli $db): array {
 $r=arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra');
 if(in_array(arx_role(),['CEO','Director General'],true))return $r;
 // El CCO solo ve el ámbito declarado por RR. HH. y los permisos explícitos.
 $a=arx_one($db,'SELECT obra_asignada FROM usuarios WHERE id_usuario=?',[arx_uid()]);
 $scope=trim((string)($a['obra_asignada']??''));
 return array_values(array_filter($r,static function(array $o)use($scope,$db):bool{
  $code=(string)$o['codigo_obra'];
  $explicit=arx_one($db,'SELECT nivel FROM arca_accesos_obra WHERE id_usuario=? AND codigo_obra=?',[arx_uid(),$code]);
  if($explicit)return true;
  if(str_starts_with($code,'ARCA-SEC-'))return false; // Clasificado: solo concesión explícita.
  return preg_match('/^GLOBAL\b/i',$scope)===1 || $scope===$code;
 }));
}
function a27_comercial_can(mysqli $db,string $code):bool {
 foreach(a27_comercial_obras($db) as $o)if($o['codigo_obra']===$code)return true;
 return false;
}
function a27_opt(array $values,string $chosen=''):void {foreach($values as $val=>$label)echo '<option value="'.a27_h($val).'"'.((string)$val===$chosen?' selected':'').'>'.a27_h($label).'</option>';}
function a27_layout(string $heading,string $subtitle,string $active):void {
 echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>'.a27_h($heading).' | ARCA</title><link rel="stylesheet" href="assets/css/arca27.css?v=1"></head><body><div class="a27-shell"><aside class="a27-sidebar"><div class="a27-logo">A <span>ARCA CONSTRUCTION<small>Operación corporativa</small></span></div><nav>';
 $links=[
  'arca22_portal.php'=>['Menú ARCA',[]],
  'arca27_apoyos.php'=>['Áreas de apoyo',['CEO','Director General','COO','CFO','CHRO']],
  'arca27_soporte.php'=>['Soporte TI',['CEO','Director General','CIO']],
  'arca27_sql.php'=>['Reportes TI',['CEO','Director General','CIO']],
  'arca27_ti.php'=>['Controles CIO',['CEO','Director General','CIO']],
  'arca27_comercial.php'=>['Comercial',['CEO','Director General','CCO']],
  'arca28_validacion.php'=>['Validación laboral',['CHRO']],
  'arca31_inteligencia.php'=>['Inteligencia empresarial',['CEO','Director General','CFO','COO','CHRO']],
  'arca32_auditoria.php'=>['Auditoría integral',['CEO','Director General']],
  'arca33_preparacion.php'=>['Configuración operativa',['CEO','Director General','CIO']],
  'arca27_equipo_obra.php'=>['Responsables de obra',['CEO','Director General','COO','CHRO','Gerente de Proyecto','Residente de Obra','Arquitecto','Ingeniero Civil']],
  'arca27_documentos.php'=>['Planos y renders',['CEO','Director General','COO','CTO','CIO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén']],
  'arca27_auditoria.php'=>['Verificación',['CEO','Director General','CIO']]
 ];
 foreach($links as $url=>$v){if($v[1]&&!in_array(arx_role(),$v[1],true))continue;echo '<a href="'.a27_h($url).'"'.($url===$active?' class="selected"':'').'>'.a27_h($v[0]).'</a>';}
 echo '</nav><div class="a27-bottom"><strong>'.a27_h(arx_name()).'</strong><small>'.a27_h(arx_role()).'</small><a href="cerrar_sesion.php">Cerrar sesión</a></div></aside><main class="a27-main"><header class="a27-top"><span>ARCA / Plataforma corporativa</span><span>Gestión corporativa</span></header><div class="a27-heading"><div><span class="a27-kicker">ARCA CONSTRUCTION · GESTIÓN INTEGRADA</span><h1>'.a27_h($heading).'</h1><p>'.a27_h($subtitle).'</p></div><a class="a27-btn secondary" href="arca22_portal.php">Menú ARCA</a></div>';
 a27_flash();
}
function a27_end():void {echo '<footer class="a27-foot">© ARCA CONSTRUCTION · Plataforma interna de gestión</footer></main></div></body></html>';}
