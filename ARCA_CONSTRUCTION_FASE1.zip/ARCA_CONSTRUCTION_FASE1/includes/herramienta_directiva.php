<?php
/**
 * ARCA · Plantilla de herramientas ejecutivas.
 * Acceso controlado por rol, consultas de solo lectura, variables vinculadas.
 * $arca_area proviene únicamente del archivo PHP del módulo.
 */
require_once __DIR__ . '/seguridad.php';
$opciones = require __DIR__ . '/herramientas_config.php';
$area = (string)($arca_area ?? '');
if (!array_key_exists($area, $opciones)) { http_response_code(404); exit('Área no encontrada.'); }
arca_requerir_roles([$area, 'CEO', 'Director General']);
require __DIR__ . '/../conexion.php';

$conf = $opciones[$area];
$modulo = (string)($_GET['modulo'] ?? '');
if ($modulo === '') {
    $modulo = (string)array_key_first($conf['modulos']);
    header('Location: herramientas_' . strtolower($area) . '.php?modulo=' . rawurlencode($modulo));
    exit;
}
if (!array_key_exists($modulo, $conf['modulos'])) { http_response_code(404); exit('Este módulo no existe.'); }
$modconf = $conf['modulos'][$modulo];
$tabla = $modconf['tabla'] ?? $conf['tabla'] ?? null;
$pk = $modconf['id'] ?? $conf['id'] ?? null;
$columnas = $modconf['columnas'] ?? $conf['columnas'] ?? [];
$filtra = $modconf['filtra'] ?? $conf['filtra'] ?? false;
$dineroCol = array_key_exists('dinero',$modconf) ? $modconf['dinero'] : ($conf['dinero'] ?? null);
$fechaCol = array_key_exists('fecha',$modconf) ? $modconf['fecha'] : ($conf['fecha'] ?? null);
$estadoCol = $modconf['estado'] ?? $conf['estado'] ?? null;
$codigoCol = $modconf['codigo'] ?? $conf['codigo'] ?? null;
$esCEO = in_array(trim((string)($_SESSION['rol_activo'] ?? '')), ['CEO','Director General'], true);
$nombre = (string)($_SESSION['nombre_usuario'] ?? 'Colaborador ARCA');
$numero = (string)($_SESSION['usuario_activo'] ?? '');
$inicial = function_exists('mb_substr') ? mb_strtoupper(mb_substr($nombre,0,1,'UTF-8'),'UTF-8') : strtoupper(substr($nombre,0,1));
$registros = [];
$totalRegistros = 0;
$totalMonto = null;
$ultimaFecha = null;
$errorLectura = false;

// Solo identificadores fijos del catálogo, nunca interpolados desde el navegador.
if ($tabla !== null) {
    try {
        $where = $filtra ? ' WHERE modulo = ?' : '';
        $sumSelect = $dineroCol !== null ? ', COALESCE(SUM(`'.$dineroCol.'`),0) AS monto_total' : '';
        $fechaSelect = $fechaCol !== null ? ', MAX(`'.$fechaCol.'`) AS fecha_max' : '';
        $sqlResumen = 'SELECT COUNT(*) AS cantidad'.$sumSelect.$fechaSelect.' FROM `'.$tabla.'`'.$where;
        $stmt = $conectar->prepare($sqlResumen);
        if ($filtra) { $stmt->bind_param('s', $modulo); }
        $stmt->execute();
        $resumen = $stmt->get_result()->fetch_assoc() ?: [];
        $stmt->close();
        $totalRegistros = (int)($resumen['cantidad'] ?? 0);
        $totalMonto = $dineroCol !== null ? (float)($resumen['monto_total'] ?? 0) : null;
        $ultimaFecha = $fechaCol !== null ? ($resumen['fecha_max'] ?? null) : null;
        $sqlDatos = 'SELECT * FROM `'.$tabla.'`'.$where.' ORDER BY `'.$pk.'` DESC LIMIT 150';
        $stmt = $conectar->prepare($sqlDatos);
        if ($filtra) { $stmt->bind_param('s', $modulo); }
        $stmt->execute();
        $registros = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } catch (Throwable $e) {
        error_log('ARCA Herramientas ['.$area.'/'.$modulo.']: '.$e->getMessage());
        $errorLectura = true;
    }
}

function arca_moneda_h(float $n, bool $compacto = false): string {
    if ($compacto && abs($n) >= 1000000) return '$'.number_format($n/1000000,2,'.',',').' M USD';
    if ($compacto && abs($n) >= 10000) return '$'.number_format($n/1000,1,'.',',').' mil USD';
    return '$'.number_format($n,2,'.',',').' USD';
}
function arca_celda_h(mixed $valor, string $tipo): string {
    if ($valor === null || $valor === '') return '—';
    if ($tipo === 'dinero' && is_numeric($valor)) return arca_moneda_h((float)$valor);
    if ($tipo === 'numero' && is_numeric($valor)) return number_format((float)$valor,0,'.',',');
    if ($tipo === 'progreso' && is_numeric($valor)) return number_format((float)$valor,1,'.',',').'%';
    if ($tipo === 'fecha') { $fecha = strtotime((string)$valor); return $fecha ? date('d/m/Y',$fecha) : (string)$valor; }
    return (string)$valor;
}
function arca_estado_h(string $estado): string {
    $v = function_exists('mb_strtolower') ? mb_strtolower($estado,'UTF-8') : strtolower($estado);
    if (preg_match('/riesgo|retras|vencid|crític|perdid|urgente|rechaz|cancelad/u',$v)) return 'status-danger';
    if (preg_match('/pendiente|programad|proceso|prospecto|revision|revisión|cotización|negociación/u',$v)) return 'status-pending';
    if (preg_match('/aprob|pagad|cobrad|ganad|complet|óptim|vigente|activo|normal|cerrad/u',$v)) return 'status-success';
    return 'status-neutral';
}
$cuentaMostrada = count($registros);
$numeroModulos = count($conf['modulos']);
$codigoArea = $area;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <title><?= arca_h($modconf['titulo'].' · '.$area) ?> | ARCA CONSTRUCTION</title>
  <link rel="stylesheet" href="assets/css/arca.css?v=3">
  <link rel="stylesheet" href="assets/css/arca-herramientas.css?v=3">
</head>
<body>
  <div class="app-layout">
    <aside class="app-sidebar module-sidebar">
      <a class="sidebar-brand" href="panel_<?= arca_h(strtolower($area)) ?>.php" aria-label="Regresar al panel de <?= arca_h($area) ?>">
        <span class="brand-mark" aria-hidden="true">A</span>
        <span><span class="brand-name">ARCA CONSTRUCTION</span><span class="brand-sub" style="display:block">Sistema de gestión ERP</span></span>
      </a>
      <span class="nav-label">Dirección <?= arca_h($area) ?></span>
      <nav class="app-nav" aria-label="Módulos de <?= arca_h($area) ?>">
        <a href="panel_<?= arca_h(strtolower($area)) ?>.php"><span class="nav-icon">⌂</span> Resumen del área</a>
        <?php foreach ($conf['modulos'] as $clave=>$item): ?>
        <a <?= $clave === $modulo ? 'aria-current="page"' : '' ?> href="herramientas_<?= arca_h(strtolower($area)) ?>.php?modulo=<?= rawurlencode((string)$clave) ?>"><span class="nav-icon module-nav-index"><?= str_pad((string)(array_search($clave,array_keys($conf['modulos']),true)+1),2,'0',STR_PAD_LEFT) ?></span><?= arca_h($item['titulo']) ?></a>
        <?php endforeach; ?>
      </nav>
      <?php if ($esCEO): ?>
      <span class="nav-label">Dirección general</span>
      <nav class="app-nav"><a href="panel_ceo.php"><span class="nav-icon">↩</span> Volver al CEO</a></nav>
      <?php endif; ?>
      <div class="sidebar-end">
        <div class="sidebar-user"><span class="user-avatar"><?= arca_h($inicial) ?></span><span><span class="user-identity" style="display:block"><?= arca_h($nombre) ?></span><span class="user-meta"><?= arca_h($numero) ?></span></span></div>
        <a class="sidebar-logout" href="cerrar_sesion.php">↪ Cerrar sesión</a>
      </div>
    </aside>
    <main class="app-main module-main">
      <header class="app-topbar">
        <div class="app-breadcrumb">ARCA CONSTRUCTION <span class="bread-slash">/</span> <a href="panel_<?= arca_h(strtolower($area)) ?>.php"><?= arca_h($conf['titulo']) ?></a> <span class="bread-slash">/</span> <b><?= arca_h($modconf['titulo']) ?></b></div>
        <span class="status-pill"><span class="status-dot"></span> Gestión corporativa</span>
      </header>
      <div class="module-heading" id="inicio">
        <div><span class="eyebrow">HERRAMIENTAS DEL ÁREA · <?= arca_h($codigoArea) ?></span>
          <h1><?= arca_h($modconf['titulo']) ?></h1>
          <p><?= arca_h($modconf['descripcion']) ?></p>
        </div>
        <a href="panel_<?= arca_h(strtolower($area)) ?>.php" class="btn btn-secondary">← Volver a <?= arca_h($area) ?></a>
      </div>
      <div class="module-context-row">
        <span class="module-chip"><span class="context-dot"></span> <?= arca_h($area) ?> · Módulo <?= str_pad((string)(array_search($modulo,array_keys($conf['modulos']),true)+1),2,'0',STR_PAD_LEFT) ?> / <?= str_pad((string)$numeroModulos,2,'0',STR_PAD_LEFT) ?></span>
        <?php if ($totalMonto !== null): ?><span class="module-chip module-chip-usd">Moneda de presentación: USD</span><?php endif; ?>
      </div>
      <?php if ($esCEO): ?><div class="module-notice">Vista de consulta de Dirección General. No hay funciones de modificación en esta pantalla.</div><?php endif; ?>
      <?php if (!empty($conf['aviso'])): ?><div class="module-notice"><?= arca_h($conf['aviso']) ?></div><?php endif; ?>
      <?php if ($errorLectura): ?><div class="module-notice module-notice-error">No fue posible consultar este módulo. Comprueba la tabla y revisa el registro de errores PHP.</div><?php endif; ?>
      <?php if ($tabla === null): ?>
      <section class="module-empty-feature">
        <div class="module-empty-icon" aria-hidden="true">i</div>
        <h2>Herramienta informativa</h2>
        <p>Este módulo conserva su lugar en el catálogo del CIO, pero todavía no está conectado a datos operativos verificables. No se muestran porcentajes, velocidades, respaldos o auditorías simulados.</p>
        <a class="btn btn-primary" href="panel_cio.php">Volver al panel de Sistemas</a>
      </section>
      <?php else: ?>
      <section class="module-kpis" aria-label="Resumen del módulo">
        <article class="module-stat"><span>Registros de este módulo</span><strong><?= number_format($totalRegistros,0,'.',',') ?></strong><small><?= arca_h($tabla) ?></small></article>
        <article class="module-stat"><span>Registros en la tabla</span><strong><?= number_format($cuentaMostrada,0,'.',',') ?></strong><small>Mostrados en esta vista (máximo 150)</small></article>
        <?php if ($totalMonto !== null): ?>
          <article class="module-stat module-stat-wide"><span>Importe acumulado</span><strong><?= arca_h(arca_moneda_h($totalMonto,true)) ?></strong><small>Se suman los importes de este módulo, independientemente de su estado</small></article>
        <?php else: ?>
          <article class="module-stat"><span><?= $ultimaFecha !== null ? 'Último registro' : 'Tipo de información' ?></span><strong class="module-stat-nonmoney"><?= arca_h($ultimaFecha !== null ? arca_celda_h($ultimaFecha,'fecha') : 'Consulta de información') ?></strong><small><?= arca_h($ultimaFecha !== null ? 'Fecha del último registro' : 'Consulta sin modificaciones') ?></small></article>
        <?php endif; ?>
      </section>
      <section class="module-records" id="registros">
        <div class="module-records-top"><div><h2>Detalle de registros</h2><p>Información guardada en <code><?= arca_h($tabla) ?></code>. Actualiza la página para volver a consultar.</p></div>
          <label class="module-search"><span>Buscar en esta página</span><input id="filtro-tabla" type="search" placeholder="Obra, concepto o estado..." autocomplete="off"></label></div>
        <div class="module-table-scroll"><table class="module-table" id="tabla-modulo"><thead><tr>
          <?php foreach ($columnas as $col): ?><th scope="col"><?= arca_h($col[1]) ?></th><?php endforeach; ?>
        </tr></thead><tbody>
          <?php foreach ($registros as $fila): ?><tr>
            <?php foreach ($columnas as $col): $tipo = $col[2] ?? 'texto'; $valor = $fila[$col[0]] ?? null; ?>
              <td>
                <?php if ($tipo === 'estado'): ?><span class="module-state <?= arca_h(arca_estado_h((string)$valor)) ?>"><?= arca_h(arca_celda_h($valor,'texto')) ?></span>
                <?php elseif ($tipo === 'codigo'): ?><strong class="module-code"><?= arca_h(arca_celda_h($valor,'texto')) ?></strong>
                <?php elseif ($tipo === 'dinero'): ?><strong class="module-money"><?= arca_h(arca_celda_h($valor,'dinero')) ?></strong>
                <?php elseif ($tipo === 'progreso' && is_numeric($valor)): $pct = max(0, min(100, (float)$valor)); ?><span class="module-progress"><span class="module-progress-track"><span style="width:<?= round($pct,1) ?>%"></span></span><b><?= arca_h(arca_celda_h($valor,'progreso')) ?></b></span>
                <?php else: ?><?= arca_h(arca_celda_h($valor,(string)$tipo)) ?><?php endif; ?>
              </td>
            <?php endforeach; ?></tr><?php endforeach; ?>
          <?php if (!$registros): ?><tr class="module-empty-row"><td colspan="<?= count($columnas) ?>"><?= $errorLectura ? 'Consulta no disponible.' : 'No hay registros guardados para este módulo.' ?></td></tr><?php endif; ?>
        </tbody></table></div>
        <div class="module-bottomline"><span>Mostrando <?= $cuentaMostrada ?> de <?= $totalRegistros ?> registros</span><span id="sin-resultados" hidden>No hay coincidencias con la búsqueda.</span></div>
      </section>
      <?php endif; ?>
      <section class="module-navigation" id="secciones"><h2>Explorar otros módulos de <?= arca_h($conf['titulo']) ?></h2><div class="module-quicklinks">
        <?php foreach ($conf['modulos'] as $clave=>$item): ?><a class="module-quicklink <?= $clave===$modulo?'module-quicklink-active':'' ?>" href="herramientas_<?= arca_h(strtolower($area)) ?>.php?modulo=<?= rawurlencode((string)$clave) ?>"><span><?= arca_h($item['titulo']) ?></span><span aria-hidden="true">↗</span></a><?php endforeach; ?>
      </div></section>
      <footer class="section-footer">ARCA CONSTRUCTION · <?= arca_h($area) ?> · Entorno local de pruebas</footer>
    </main>
  </div>
  <script>
  (()=>{ const entrada=document.getElementById('filtro-tabla'), filas=[...document.querySelectorAll('#tabla-modulo tbody tr:not(.module-empty-row)')], aviso=document.getElementById('sin-resultados');
    if (!entrada || !aviso) return;
    entrada.addEventListener('input',()=>{const q=entrada.value.trim().toLocaleLowerCase('es');let n=0;for(const fila of filas){const ok=fila.textContent.toLocaleLowerCase('es').includes(q);fila.hidden=!ok;if(ok)n++}aviso.hidden=n>0 || q==='';});
  })();
  </script>
</body>
</html>
