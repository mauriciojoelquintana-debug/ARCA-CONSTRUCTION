<?php
/** ARCA · utilidades financieras. No contienen credenciales ni inician sesiones. */
function arca_fin_modulos(): array {
    return [
        'presupuesto' => ['titulo'=>'Presupuestos', 'subtitulo'=>'Autorizaciones y control presupuestal'],
        'costos' => ['titulo'=>'Costos', 'subtitulo'=>'Materiales, servicios y costos de obra'],
        'ingresos' => ['titulo'=>'Ingresos', 'subtitulo'=>'Estimaciones, cobros e ingresos pendientes'],
        'pagos' => ['titulo'=>'Cuentas por pagar', 'subtitulo'=>'Obligaciones y programación de pagos'],
        'impuestos' => ['titulo'=>'Impuestos', 'subtitulo'=>'Obligaciones fiscales y contribuciones']
    ];
}
function arca_fin_estados(string $modulo): array {
    return match($modulo) {
        'presupuesto' => ['Borrador', 'Pendiente', 'Aprobado', 'Rechazado'],
        'ingresos' => ['Pendiente', 'Programado', 'Cobrado', 'Vencido', 'Cancelado'],
        'costos', 'pagos', 'impuestos' => ['Pendiente', 'Programado', 'Pagado', 'Vencido', 'Cancelado'],
        default => []
    };
}
function arca_fin_estado_estilo(string $estado): string {
    return match($estado) {
        'Pagado', 'Cobrado', 'Aprobado' => 'fin-status-ok',
        'Vencido', 'Rechazado', 'Cancelado' => 'fin-status-danger',
        'Pendiente', 'Programado' => 'fin-status-wait',
        default => 'fin-status-muted'
    };
}
function arca_fin_usd($importe): string {
    return '$' . number_format((float)$importe,2,'.',',') . ' USD';
}
function arca_fin_dinero_breve($importe): string {
    $num = (float)$importe;
    if (abs($num) >= 1000000) return '$' . number_format($num/1000000,2,'.',',') . ' M USD';
    return arca_fin_usd($num);
}
function arca_fin_fecha(string $fecha): bool {
    $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
    return $dt !== false && $dt->format('Y-m-d') === $fecha;
}
function arca_fin_auditoria_disponible(mysqli $conectar): bool {
    try {
        $r = $conectar->query('SELECT id_bitacora FROM arca_finanzas_bitacora LIMIT 0');
        $r->free();
        return true;
    } catch (Throwable $e) { return false; }
}
function arca_fin_filtrar_obra(string $codigo): string {
    $codigo = trim($codigo);
    return preg_match('/^[A-Z0-9\-]{1,20}$/D', $codigo) ? $codigo : '';
}
function arca_fin_csv_seguro(?string $valor): string {
    $valor = (string)($valor ?? '');
    // Evita que Excel interprete texto no confiable como fórmula.
    return preg_match('/^[\s\x00-\x1F]*[=+\-@]/u', $valor) ? "'" . $valor : $valor;
}
function arca_fin_redirigir(string $modulo, string $obra = ''): never {
    $ruta = 'herramientas_cfo.php?modulo=' . rawurlencode($modulo);
    if ($obra !== '') $ruta .= '&obra=' . rawurlencode($obra);
    header('Location: ' . $ruta, true, 303);
    exit;
}

/** Importes nuevos: solo divisas confirmadas por usuario. */
function arca_fin_moneda(string $m): string {
    if (!in_array($m,['USD','MXN'],true)) throw new InvalidArgumentException('Selecciona la divisa real: USD o MXN.');
    return $m;
}
function arca_fin_categoria(string $c): string {
    $c=trim($c);
    $validas=['Materiales','Mano de obra','Maquinaria','Subcontratos','Transporte','Servicios','Indirectos','Otros'];
    if (!in_array($c,$validas,true)) throw new InvalidArgumentException('Selecciona una categoría de costo válida.');
    return $c;
}
function arca_fin_dinero_real($valor,?string $moneda): string {
    return '$'.number_format((float)$valor,2,'.',',').' '.($moneda?:'SIN DEFINIR');
}
