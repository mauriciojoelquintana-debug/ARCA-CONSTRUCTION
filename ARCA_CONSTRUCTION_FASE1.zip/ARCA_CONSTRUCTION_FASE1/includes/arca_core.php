<?php
declare(strict_types=1);
/** ARCA Fases 5-7: reutiliza la sesión existente sin sobrescribir variables del login. */
require_once __DIR__ . '/seguridad.php';

function arx_boot(array $roles): mysqli {
    arca_requerir_roles($roles);
    // require se ejecuta dentro de esta función, para aislar $usuario/$password de conexión.php.
    require __DIR__ . '/../conexion.php';
    if (!isset($conectar) || !($conectar instanceof mysqli)) throw new RuntimeException('El servicio de información no está disponible.');
    $conectar->set_charset('utf8mb4');
    return $conectar;
}
function arx_h(mixed $v): string { return htmlspecialchars((string)($v??''),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function arx_role(): string { return trim((string)($_SESSION['rol_activo']??'')); }
function arx_uid(): int { return (int)($_SESSION['id_usuario']??0); }
function arx_name(): string { return (string)($_SESSION['nombre_usuario']??'Colaborador'); }
function arx_token(): string { return arca_token(); }
function arx_check_post(): void {
    if (($_SERVER['REQUEST_METHOD']??'')!=='POST') { http_response_code(405); exit('Método no permitido'); }
    arca_verificar_token();
}
function arx_query(mysqli $db, string $sql, array $args=[]): mysqli_stmt {
    $stmt=$db->prepare($sql);
    if ($args) {
        $types=''; foreach ($args as $v) $types.=is_int($v)?'i':(is_float($v)?'d':'s');
        $stmt->bind_param($types,...$args);
    }
    $stmt->execute(); return $stmt;
}
function arx_rows(mysqli $db,string $sql,array $args=[]): array {
    $st=arx_query($db,$sql,$args);$rows=$st->get_result()->fetch_all(MYSQLI_ASSOC);$st->close();return $rows;
}
function arx_one(mysqli $db,string $sql,array $args=[]): ?array {
    $st=arx_query($db,$sql,$args);$r=$st->get_result()->fetch_assoc();$st->close();return $r?:null;
}
function arx_exec(mysqli $db,string $sql,array $args=[]): int {
    $st=arx_query($db,$sql,$args);$n=$st->affected_rows;$st->close();return $n;
}
function arx_int(mixed $v,int $min=1,int $max=2147483647): int {
    $i=filter_var($v,FILTER_VALIDATE_INT);
    if ($i===false || $i<$min || $i>$max) throw new InvalidArgumentException('Número fuera de rango.');return $i;
}
function arx_decimal(mixed $v,bool $allowZero=false): string {
    $s=trim((string)$v);
    if (!preg_match('/^(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,2})?$/D',$s) || (!$allowZero && (float)$s<=0)) throw new InvalidArgumentException('Importe o cantidad no válida.');
    return $s;
}
function arx_date(string $s): string {
    $d=DateTimeImmutable::createFromFormat('!Y-m-d',$s);
    if (!$d || $d->format('Y-m-d')!==$s) throw new InvalidArgumentException('Fecha incorrecta.');return $s;
}
function arx_code(mixed $v): string {
    $s=trim((string)$v);
    if (!preg_match('/^[A-Z0-9-]{4,30}$/D',$s)) throw new InvalidArgumentException('Código de obra inválido.');return $s;
}
function arx_text(mixed $v,int $max=200): string {
    $s=trim((string)$v);$len=function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);
    if (!$s || $len>$max) throw new InvalidArgumentException('Texto obligatorio o demasiado largo.');return $s;
}
function arx_currency(mixed $v): string {
    $s=(string)$v;if (!in_array($s,['USD','MXN'],true)) throw new InvalidArgumentException('Selecciona USD o MXN.');return $s;
}
function arx_money(?string $amt,?string $currency): string {
    if ($amt===null) return '—';return '$'.number_format((float)$amt,2,'.',',').' '.($currency??'SIN DEFINIR');
}
function arx_flash(string $text,bool $error=false): void {$_SESSION['arx_flash']=[$error?'error':'ok',$text];}
function arx_redirect(string $url): never {header('Location: '.$url,true,303);exit;}
function arx_audit(mysqli $db,string $module,string $entity,int $id,string $action,?array $before,?array $after): void {
    $actor=arx_uid(); $b=$before===null?null:json_encode($before,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    $a=$after===null?null:json_encode($after,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    arx_exec($db,'INSERT INTO arca_auditoria_modulos(modulo,entidad,entidad_id,usuario_id,accion,anterior,nuevo) VALUES(?,?,?,?,?,?,?)',[$module,$entity,$id,$actor,$action,$b,$a]);
}
function arx_permission(mysqli $db,string $obra,string $need='consultar'): bool {
    $role=arx_role();
    if ($role==='CEO' || $role==='Director General') return $need==='consultar';
    if ($role==='COO') return true;
    if ($role==='CHRO') return $need==='consultar';
    $record=arx_one($db,'SELECT nivel FROM arca_accesos_obra WHERE id_usuario=? AND codigo_obra=?',[arx_uid(),$obra]);
    if (!$record) return false;
    $lvl=['consultar'=>1,'operar'=>2,'aprobar'=>3];
    return ($lvl[(string)$record['nivel']]??0)>=($lvl[$need]??99);
}
function arx_require_obra(mysqli $db,string $obra,string $need='consultar'): void {
    $exists=arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=?',[$obra]);
    if (!$exists || !arx_permission($db,$obra,$need)) { http_response_code(403); exit('No tienes permiso para esta obra.'); }
}
function arx_obras(mysqli $db): array {
    $r=arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra');
    return array_values(array_filter($r,fn($row)=>arx_permission($db,(string)$row['codigo_obra'])));
}
function arx_select(string $name,array $options,?string $selected=null,string $extra=''): string {
    $html='<select name="'.arx_h($name).'" '.$extra.'>';
    foreach($options as $key=>$caption) {$html.='<option value="'.arx_h($key).'"'.((string)$key===$selected?' selected':'').'>'.arx_h($caption).'</option>';}
    return $html.'</select>';
}
function arx_layout_start(string $heading,string $description,string $active,string $division,array $items): void {
    $flash=$_SESSION['arx_flash']??null;unset($_SESSION['arx_flash']);
    $urls=['Finanzas'=>'panel_cfo.php','Operaciones'=>'panel_coo.php','Recursos humanos'=>'panel_chro.php'];
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<meta name="referrer" content="no-referrer"><title>'.arx_h($heading).' · ARCA CONSTRUCTION</title>';
    echo '<link rel="stylesheet" href="assets/css/arca-nuevos.css?v=1"></head><body><div class="arx-shell"><aside class="arx-sidebar">';
    echo '<div class="arx-logo"><span>A</span><div><strong>ARCA CONSTRUCTION</strong><small>Plataforma de gestión ERP</small></div></div>';
    echo '<p class="arx-nav-label">'.arx_h($division).'</p><nav>';
    foreach($items as $url=>$label)echo '<a '.($url===$active?'class="selected" ':'').'href="'.arx_h($url).'">'.arx_h($label).'</a>';
    echo '</nav><div class="arx-profile"><b>'.arx_h(arx_name()).'</b><small>'.arx_h(arx_role()).'</small><a href="cerrar_sesion.php">Cerrar sesión</a></div></aside>';
    echo '<main class="arx-main"><div class="arx-top"><span>ARCA / '.arx_h($division).'</span><span>Gestión corporativa</span></div>';
    echo '<header class="arx-heading"><p class="arx-eyebrow">GESTIÓN CORPORATIVA</p><h1>'.arx_h($heading).'</h1><p>'.arx_h($description).'</p></header>';
    if (is_array($flash))echo '<div class="arx-alert '.($flash[0]==='error'?'warn':'good').'">'.arx_h((string)$flash[1]).'</div>';
}
function arx_layout_end():void { echo '<footer class="arx-footer">ARCA CONSTRUCTION · Plataforma interna de gestión</footer></main></div></body></html>'; }
