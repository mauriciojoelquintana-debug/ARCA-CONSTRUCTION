<?php
declare(strict_types=1);
require_once __DIR__.'/arca24_26.php';
/** Sin copias intermedias: todos los totales se recalculan desde tablas existentes. */
function a24_estado(mysqli $db,array $codes):array {
    $in=a26_sql_in($codes);
    $works=arx_rows($db,"SELECT codigo_obra,nombre_proyecto,COALESCE(avance_fisico,0) avance_fisico,estado_tiempo FROM obras_coo WHERE codigo_obra IN ($in) ORDER BY codigo_obra",$codes);
    $qty=count($works);
    $stock=arx_one($db,"SELECT COUNT(*) total, SUM(CASE WHEN cantidad_actual <= stock_minimo THEN 1 ELSE 0 END) bajos FROM inventario_almacen_arca WHERE codigo_obra IN ($in)",$codes);
    $staff=arx_one($db,"SELECT COUNT(*) total FROM arca_asignaciones_personal WHERE estado='ACTIVA' AND codigo_obra IN ($in)",$codes);
    $orders=arx_one($db,"SELECT COUNT(*) total FROM arca_ordenes_compra WHERE estado='EMITIDA' AND codigo_obra IN ($in)",$codes);
    $recent=arx_one($db,"SELECT MAX(fecha) fecha FROM arca_movimientos_material WHERE codigo_obra IN ($in)",$codes);
    $finance=[];
    if(a26_rol_finanzas(arx_role())){
        $finance=arx_rows($db,"SELECT COALESCE(moneda,'SIN CONFIRMAR') moneda,modulo,estado_pago,COUNT(*) cantidad,ROUND(SUM(monto),2) monto FROM finanzas_coo WHERE codigo_obra IN ($in) GROUP BY COALESCE(moneda,'SIN CONFIRMAR'),modulo,estado_pago ORDER BY moneda,modulo,estado_pago",$codes);
    }
    $list=[]; foreach($works as $w)$list[]=['codigo'=>(string)$w['codigo_obra'],'nombre'=>(string)$w['nombre_proyecto'],'avance'=>(float)$w['avance_fisico'],'estado'=>(string)($w['estado_tiempo']??'Sin estado')];
    return [
       'consultado'=>date('Y-m-d H:i:s'),'fuente'=>'Registros disponibles al momento de la consulta',
       'indicadores'=>[
         'obras'=>$qty,'avance_promedio'=>$qty?round(array_sum(array_column($list,'avance'))/$qty,1):0,
         'asignaciones_activas'=>(int)($staff['total']??0),'materiales_registrados'=>(int)($stock['total']??0),
         'alertas_stock'=>(int)($stock['bajos']??0),'ordenes_emitidas'=>(int)($orders['total']??0)
       ],
       'ultimo_movimiento_material'=>$recent['fecha']??null,'obras'=>$list,'finanzas'=>$finance,
       'nota_finanzas'=>'Movimientos por módulo, estado y moneda; no son saldos bancarios ni deben sumarse entre divisas.'
    ];
}
