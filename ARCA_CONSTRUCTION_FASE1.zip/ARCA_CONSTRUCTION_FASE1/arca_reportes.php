<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_fases_8_13.php';$db=arx_boot(['CEO','Director General','COO']);
$reports=[
 'portafolio'=>['Portafolio de obras','10 obras, estados y presupuestos históricos sin divisa confirmada.'],
 'avances'=>['Avances y desviaciones','Comparación entre el avance programado y el registrado.'],
 'fases'=>['Presupuestos por fase','20 fases, responsables, avances y costos registrados.'],
 'personal'=>['Personal asignado a obra','28 asignaciones históricas; no confundir con nómina ni empleados únicos.'],
 'materiales'=>['Materiales en almacén','Materiales, cantidades y stocks mínimos por obra.']
];
af8_layout('Reportes ejecutivos','Consulta los informes disponibles, descárgalos para Excel o utiliza la vista de impresión para guardarlos en PDF.','arca_reportes.php');
?>
<section class="arx-card"><h2>Centro de reportes</h2><p class="arx-sub">Los informes muestran los registros disponibles al momento de la consulta.</p><div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Reporte</th><th>Descripción</th><th>Acciones</th></tr></thead><tbody>
<?php foreach($reports as $slug=>$r):?><tr><td><strong><?=arx_h($r[0])?></strong></td><td><?=arx_h($r[1])?></td><td><div class="af8-links"><a href="arca_reporte_descargar.php?tipo=<?=arx_h($slug)?>&formato=csv" class="arx-btn">CSV / Excel</a><a href="arca_reporte_descargar.php?tipo=<?=arx_h($slug)?>&formato=imprimir" class="arx-btn" target="_blank" rel="noopener">Vista PDF (imprimir)</a></div></td></tr><?php endforeach;?></tbody></table></div></section>
<section class="arx-card"><h2>Auditoría y origen de la información</h2><p>Los reportes disponibles en el portal requieren sesión CEO o COO. Los informes pueden exportarse para Excel o guardarse como PDF desde la vista de impresión.</p><p class="arx-sub">Verifica el origen, la confidencialidad y la moneda de los datos antes de distribuir un informe.</p></section>
<?php arx_layout_end(); ?>
