<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca20.php';
$db=a20_boot();$id=arx_int($_GET['id']??null);
$pl=arx_one($db,'SELECT codigo_obra,archivo_ruta,codigo_plano FROM planos_oficina_tecnica WHERE id_plano=?',[$id]);
if(!$pl){http_response_code(404);exit('Documento no encontrado.');}
a20_require($db,(string)$pl['codigo_obra']);
$path=(string)$pl['archivo_ruta'];
if(str_starts_with($path,'privado:')){
 $fn=substr($path,8);
 if(!preg_match('/^[a-f0-9]{36}\.(pdf|jpg|jpeg|png|dwg|rvt|ifc)$/D',$fn)){http_response_code(404);exit('Documento inválido.');}
 $file=a20_private_directory().DIRECTORY_SEPARATOR.$fn;
}else{
 // Compatibilidad para documentos históricos, sin permitir rutas arbitrarias.
 if(!preg_match('~^planos_obras/[a-zA-Z0-9_.-]+$~D',$path)){http_response_code(404);exit('Ruta de documento no admitida.');}
 $file=__DIR__.DIRECTORY_SEPARATOR.$path;
}
if(!is_file($file)||!is_readable($file)){http_response_code(404);exit('El archivo no está disponible. Su registro histórico se conserva.');}
$ext=a20_extension($file);if(!in_array($ext,['pdf','jpg','jpeg','png','dwg','rvt','ifc'],true)){http_response_code(404);exit('Archivo no admitido.');}
// Nunca mostrar directamente el adjunto ni permitir que el navegador lo ejecute.
header('Content-Type: application/octet-stream');header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, private');header('Content-Disposition: attachment; filename="'.preg_replace('/[^a-zA-Z0-9._-]/','_',((string)$pl['codigo_plano']).'.'.$ext).'"');
header('Content-Length: '.(string)filesize($file));
readfile($file);
