<?php
// 1. Validamos la sesión para mantener la seguridad RBAC
session_start();
if (!isset($_SESSION['rol_activo']) || ($_SESSION['rol_activo'] != 'Ingeniero' && $_SESSION['rol_activo'] != 'Arquitecto')) {
    header("Location: login.html");
    exit(); 
}

// 2. Incluimos el archivo de conexión
include("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Obras - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #eef2f3; padding: 20px; }
        .header { background-color: #34495e; color: white; padding: 15px; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #f39c12; color: white; }
        .btn-volver { background-color: #e74c3c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <h2>Proyectos Asignados: <?php echo $_SESSION['usuario_activo']; ?></h2>
        <a href="panel_operativo.php" class="btn-volver">Regresar al Panel</a>
    </div>

    <!-- Estructura de la tabla HTML -->
    <table>
        <tr>
            <th>Nombre de la Obra</th>
            <th>Ubicación</th>
            <th>Presupuesto Asignado</th>
            <th>Estado Actual</th>
        </tr>

        <?php
        // 3. Consulta SQL usando INNER JOIN para cruzar la tabla proyectos con la de usuarios
        // Filtramos estrictamente por el nombre del usuario activo en la sesión
        $nombre_ingeniero = $_SESSION['usuario_activo'];
        
        $sql = "SELECT p.nombre_obra, p.ubicacion, p.presupuesto, p.estado 
                FROM proyectos p 
                INNER JOIN usuarios u ON p.numero_empleado = u.numero_empleado 
                WHERE u.nombre = ?";
                
        $stmt = $conectar->prepare($sql);
        $stmt->bind_param("s", $nombre_ingeniero);
        $stmt->execute();
        $resultado = $stmt->get_result();

        // 4. Automatización de reportes con el ciclo WHILE
        // El ciclo se repetirá imprimiendo filas <tr> por cada proyecto encontrado
        if ($resultado->num_rows > 0) {
            while($obra = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $obra['nombre_obra'] . "</td>";
                echo "<td>" . $obra['ubicacion'] . "</td>";
                // La función number_format le da formato de moneda al presupuesto
                echo "<td>$" . number_format($obra['presupuesto'], 2) . " MXN</td>";
                echo "<td><b>" . $obra['estado'] . "</b></td>";
                echo "</tr>";
            }
        } else {
            // Si el ingeniero no tiene obras asignadas, la instrucción echo muestra este mensaje en pantalla
            echo "<tr><td colspan='4'>No tienes obras asignadas en este momento.</td></tr>";
        }
        
        $stmt->close();
        ?>
    </table>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>