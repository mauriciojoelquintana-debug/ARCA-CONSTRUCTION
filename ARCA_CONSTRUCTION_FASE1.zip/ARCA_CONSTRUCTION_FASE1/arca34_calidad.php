<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a34_roles());
$error='';$data=['f32'=>[],'f33'=>[],'controles'=>[]];$saved=[];$ready=false;
try {
  a34_base_pruebas($db);
  $data=a34_actuales($db,__DIR__);
  $ready=a34_instalado($db);
  if($ready)$saved=a34_guardados($db);
}catch(Throwable $e){error_log('[ARCA34 PANEL] '.$e->getMessage());$error='No se pudo consultar los controles. Revisa las dependencias y el log de PHP.';}
$alertas=count(array_filter($data['controles'],static fn($v)=>$v['estado_auto']!=='OK'));
$open=count(array_filter($saved,static fn($v)=>!in_array($v['estado'],['CERRADO','NO_APLICA'],true)));
$ids=array_filter($data['controles'],static fn($v)=>$v['estado_auto']!=='OK' || false);
// Mostrar también registros gestionados aunque el control pase automáticamente a OK.
foreach($saved as $code=>$entry)if(isset($data['controles'][$code]))$ids[$code]=$data['controles'][$code];
a27_layout('Centro de calidad','Gestión de observaciones, responsables y acciones correctivas.','arca34_calidad.php');
?>
<link rel="stylesheet" href="assets/css/arca34-35.css?v=1">
<section class="qa-banner"><strong>SEGUIMIENTO DE CALIDAD</strong><p>Las observaciones proceden de controles internos y su seguimiento corresponde a personal autorizado. Cerrar un registro no elimina una condición pendiente; la evidencia permanece resguardada.</p></section>
<div class="qa-tools"><a href="arca32_auditoria.php">Auditoría integral</a><a href="arca33_preparacion.php">Configuración operativa</a><a href="arca35_pruebas.php">Verificación operativa</a><a href="arca34_exportar.php">Exportar seguimiento CSV</a></div>
<?php if($error):?><div role="alert" class="qa-alert"><?=a27_h($error)?></div><?php else:?>
<div class="qa-stats"><article><span>Controles revisados</span><strong><?=count($data['controles'])?></strong></article><article><span>Alertas y tareas automáticas</span><strong><?=$alertas?></strong></article><article><span>Seguimientos en curso</span><strong><?=$open?></strong></article><article><span>Seguimientos registrados</span><strong><?=count($saved)?></strong></article></div>
<?php if(!$ready):?><div role="alert" class="qa-alert">El registro de seguimientos no está disponible. Comunícate con el área de Sistemas para verificar la configuración antes de continuar.</div><?php endif;?>
<section class="qa-card"><h2>Hallazgos y acciones</h2><p>Se muestran los controles con advertencias, críticos o pendientes, además de los que ya tienen seguimiento. Las cifras se recalculan al actualizar la página; no se modifican registros de las áreas.</p>
<?php if(!$ids):?><p>No hay controles pendientes en esta vista. Consulta también las verificaciones operativas.</p><?php endif;?>
<?php foreach($ids as $key=>$item):
 $v=$saved[$key]??null;$step=(string)($v['estado']??'ABIERTO');$owner=(string)($v['responsable']??a34_responsable_sugerido($item['area']));$priority=(string)($v['prioridad']??($item['estado_auto']==='CRITICO'?'CRITICA':'ALTA'));
?>
<details class="qa-panel"><summary><?=a27_h((['F32'=>'Auditoría','F33'=>'Infraestructura'][$item['fuente']] ?? 'Control interno').' · '.$item['area'].' · '.$item['control'])?> <span class="qa-status <?=strtolower(a27_h($item['estado_auto']))?>"><?=a27_h($item['estado_auto'])?></span> <span class="qa-muted"><?=a27_h($v['estado']??'Sin seguimiento')?></span></summary>
<p><strong>Resultado:</strong> <?=a27_h($item['detalle'])?></p><p><strong>Acción recomendada:</strong> <?=a27_h($item['accion'])?></p>
<?php if($v && in_array($step,['CERRADO','NO_APLICA'],true) && $item['estado_auto']!=='OK'):?><p class="qa-alert">El seguimiento figura como <?=a27_h($step)?>, pero el diagnóstico automático continúa en <?=a27_h($item['estado_auto'])?>. Requiere revisión.</p><?php endif;?>
<?php if($ready):?><form method="post" action="arca34_guardar.php" class="qa-grid">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>">
<input type="hidden" name="codigo_control" value="<?=a27_h($key)?>">
<label>Responsable<select name="responsable" required><?php foreach(a34_responsables() as $r):?><option value="<?=a27_h($r)?>" <?=$owner===$r?'selected':''?>><?=a27_h($r)?></option><?php endforeach;?></select></label>
<label>Prioridad<select name="prioridad" required><?php foreach(a34_prioridades() as $p):?><option value="<?=a27_h($p)?>" <?=$priority===$p?'selected':''?>><?=a27_h($p)?></option><?php endforeach;?></select></label>
<label>Estado de seguimiento<select name="estado" required><?php foreach(a34_etapas() as $s=>$sname):?><option value="<?=a27_h($s)?>" <?=$step===$s?'selected':''?>><?=a27_h($sname)?></option><?php endforeach;?></select></label>
<label>Fecha compromiso<input type="date" name="fecha_compromiso" value="<?=a27_h($v['fecha_compromiso']??'')?>"></label>
<label class="qa-wide">Referencia de evidencia (sin contraseñas ni datos personales)<input name="referencia_evidencia" maxlength="180" placeholder="Ej.: CONTROL-CHRO-2026-01 / acta firmada en repositorio privado" value="<?=a27_h($v['referencia_evidencia']??'')?>"></label>
<label class="qa-wide">Nota de seguimiento<textarea name="nota" maxlength="1500" placeholder="Qué se revisó, qué falta y quién validó."><?=a27_h($v['nota']??'')?></textarea></label>
<div class="qa-wide"><button class="qa-btn" type="submit">Guardar seguimiento</button></div>
</form><?php endif;?></details>
<?php endforeach;?></section><?php endif; ?>
<section class="qa-card"><h2>Criterios de integridad</h2><p>Los expedientes de personal y las divisas requieren respaldo documental individual. Los registros de capacitación no constituyen contratación. El seguimiento documentado no sustituye la autorización formal ni la revisión independiente.</p></section>
<?php a27_end(); ?>
