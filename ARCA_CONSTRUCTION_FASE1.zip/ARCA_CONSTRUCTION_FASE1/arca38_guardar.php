<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca36_38_datos.php';
$db=a27_boot(a38_roles());
a27_post();
try {
  $codes=a38_codigos_autorizados($db);
  $op=(string)($_POST['operacion']??'');
  if($op==='CREAR') {a38_alta($db,$_POST,$codes);a27_alert('Solicitud creada. El siguiente paso requiere una cuenta revisora distinta.');}
  elseif($op==='DECIDIR') {a38_decidir($db,$_POST,$codes);a27_alert('Decisión registrada en la bitácora. No se modificaron módulos operativos.');}
  else throw new InvalidArgumentException('Operación desconocida.');
}catch(Throwable $e) {
  error_log('[ARCA F38 GUARDAR] '.$e->getMessage());
  a27_alert($e instanceof InvalidArgumentException||$e instanceof DomainException?$e->getMessage():'No se pudo guardar la solicitud. Comunícate con el área de Sistemas.',true);
}
a27_redirect('arca38_flujos.php');
