<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca39_datos.php';
$db=a27_boot(a39_roles());
a27_post(); // Requiere sesión activa, POST y token CSRF.
try{
  $action=(string)($_POST['operacion']??'');
  if($action==='CREAR') {a39_crear($db,$_POST);a27_alert('Incidencia registrada con su evento de auditoría.');}
  elseif($action==='ESTADO'){a39_cambiar_estado($db,$_POST);a27_alert('Seguimiento documentado; no se modificaron los datos originales del ERP.');}
  else throw new InvalidArgumentException('Operación no reconocida.');
}catch(Throwable $e){
  error_log('[ARCA39 GUARDAR] '.$e->getMessage());
  a27_alert($e instanceof InvalidArgumentException||$e instanceof DomainException?$e->getMessage():'No fue posible guardar la incidencia. Comunícate con el área de Sistemas.',true);
}
a27_redirect('arca39_validacion.php');
