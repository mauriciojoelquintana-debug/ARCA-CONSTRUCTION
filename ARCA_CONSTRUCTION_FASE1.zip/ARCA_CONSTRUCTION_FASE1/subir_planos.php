<?php
declare(strict_types=1);
/* La subida heredada guardaba archivos sin autorización por obra. Se retira de servicio. */
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){
 http_response_code(405);header('Allow: GET');exit('Utiliza el formulario seguro de Oficina Técnica para subir documentos.');
}
header('Location: panel_oficina_almacen.php?vista=planos',true,302);exit;
