<?php
require_once __DIR__ . '/includes/seguridad.php';
arca_iniciar_sesion();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', ['expires'=>time()-42000, 'path'=>$p['path'], 'domain'=>$p['domain'], 'secure'=>$p['secure'], 'httponly'=>$p['httponly'], 'samesite'=>'Lax']);
}
session_destroy();
// Un parametro distinto en cada salida evita reutilizar el HTML antiguo de la cache.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Location: ingreso.html?v=' . bin2hex(random_bytes(6)), true, 303);
exit;