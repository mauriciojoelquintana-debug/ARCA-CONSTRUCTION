<?php
$arca_area = 'CMO';
require __DIR__ . '/includes/herramienta_directiva.php';
