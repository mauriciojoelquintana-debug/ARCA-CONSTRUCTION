<?php
require_once __DIR__.'/includes/seguridad.php';
arca_requerir_roles(['CEO','Director General','CIO','COO','CHRO','Secretaria','Secretaria / Asistente','Director de RR.HH.','Departamento RRHH']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: formulario_alta_empleado.php'); exit; }
require __DIR__.'/conexion.php';
$numero_empleado=trim((string)($_POST['numero_empleado']??''));
$nombre=trim((string)($_POST['nombre']??''));
$password=(string)($_POST['password']??'');
$cargo=trim((string)($_POST['cargo']??''));
$mensaje='';$ok=false;
if ($numero_empleado==='' || $nombre==='' || strlen($password)<12 || $cargo==='') {
 $mensaje='Todos los datos son obligatorios. La contraseña debe tener al menos 12 caracteres.';
} else {
 try {
  $hash=password_hash($password,PASSWORD_DEFAULT);
  $stmt=$conectar->prepare('INSERT INTO usuarios (numero_empleado,password,nombre_completo,cargo) VALUES (?,?,?,?)');
  $stmt->bind_param('ssss',$numero_empleado,$hash,$nombre,$cargo);
  $stmt->execute();$stmt->close();$ok=true;
  $mensaje='Se registró la cuenta. Revisa después el nivel y las asignaciones del empleado.';
 } catch(Throwable $e) { error_log($e->getMessage());$mensaje='No fue posible registrar la cuenta. Comprueba que el identificador no exista.'; }
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alta de empleado | ARCA</title><link rel="stylesheet" href="assets/css/arca.css"></head>
<body style="display:grid;place-items:center;min-height:100vh"><main class="metric-card" style="max-width:500px;width:calc(100% - 30px)"><span class="eyebrow">RECURSOS HUMANOS</span><h1 style="font-size:22px;color:var(--arca-navy)"><?= $ok?'Cuenta registrada':'No se completó el registro' ?></h1><p style="font-size:14px;line-height:1.6"><?= arca_h($mensaje) ?></p><a class="btn btn-primary" href="panel_administrativo.php">Volver a administración →</a></main></body></html>
