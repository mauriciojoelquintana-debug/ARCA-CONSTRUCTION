<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca32_auditoria.php';
$db=a27_boot(a32_roles());
try { $items=a32_evaluar($db,a24_obras_autorizadas($db)); }
catch(Throwable $e) {error_log('[ARCA32 EXPORT] '.$e->getMessage());http_response_code(500);exit('No fue posible generar el informe.');}
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="arca_auditoria_auditoria_'.date('Ymd_His').'.csv"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
$out=fopen('php://output','wb');
fwrite($out,"\xEF\xBB\xBF");fwrite($out,"sep=;\r\n");
$put=static function(array $vals)use($out):void {fputcsv($out,array_map('a31_csv_value',$vals),';','"','');};
$put(['ARCA CONSTRUCTION','AUDITORÍA INTEGRAL','Auditoría de solo lectura','Perfil',arx_role(),'Fecha',date('Y-m-d H:i:s')]);
$put(['Área','Comprobación','Estado','Evidencia agregada','Acción recomendada']);
foreach($items as $r)$put([$r['modulo'],$r['control'],$r['estado'],$r['detalle'],$r['accion']]);
fclose($out);
