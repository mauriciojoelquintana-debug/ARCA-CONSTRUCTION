<?php
session_start();
if (empty($_SESSION['id_usuario']) || empty($_SESSION['rol_activo'])) {
    header("Location: ingreso.html");
    exit();
}

$rol = trim($_SESSION['rol_activo']);

// NIVEL 0: Dirección General
if ($rol === 'CEO' || $rol === 'Director General') {
    $_SESSION['depto_autorizado'] = 'CONTADORES';
    header("Location: panel_ceo.php");
    exit();

// NIVEL 1: Las 8 Direcciones Ejecutivas (C-Level)
} elseif ($rol === 'CFO') {
    header("Location: panel_cfo.php");
    exit();
} elseif ($rol === 'COO') {
    header("Location: panel_coo.php");
    exit();
} elseif ($rol === 'CIO') {
    header("Location: panel_cio.php");
    exit();
} elseif ($rol === 'CTO') {
    header("Location: panel_cto.php");
    exit();
} elseif ($rol === 'CCO') {
    header("Location: panel_cco.php");
    exit();
} elseif ($rol === 'CMO') {
    header("Location: panel_cmo.php");
    exit();
} elseif ($rol === 'CHRO') {
    header("Location: panel_chro.php");
    exit();
} elseif ($rol === 'CSO') {
    header("Location: panel_cso.php");
    exit();

// ÁREA ADMINISTRATIVA
} elseif ($rol === 'Secretaria' || $rol === 'Secretaria / Asistente') {
    header('Location: panel_administrativo.php');
    exit();

// LOS 7 DEPARTAMENTOS ESPECIALIZADOS (Enrutamiento interno por $_SESSION sin exponer la URL)
} elseif ($rol === 'Departamento RRHH' || $rol === 'Enlace RH') {
    $_SESSION['depto_autorizado'] = 'RRHH';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Almacenista' || $rol === 'Jefe de Almacén') {
    $_SESSION['depto_autorizado'] = 'ALMACEN';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Arquitecto') {
    $_SESSION['depto_autorizado'] = 'ARQUITECTOS';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Ingeniero Civil' || $rol === 'Ingeniero') {
    $_SESSION['depto_autorizado'] = 'INGENIEROS';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Abogado' || $rol === 'Gerente Jurídico') {
    $_SESSION['depto_autorizado'] = 'ABOGADOS';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Contador') {
    $_SESSION['depto_autorizado'] = 'CONTADORES';
    header("Location: panel_departamentos_arca.php");
    exit();
} elseif ($rol === 'Seguridad') {
    $_SESSION['depto_autorizado'] = 'SEGURIDAD';
    header("Location: panel_departamentos_arca.php");
    exit();

// GERENTES DE PROYECTO Y RESIDENTES DE OBRA
} else {
    header("Location: panel_estructura_arca.php");
    exit();
}
?>