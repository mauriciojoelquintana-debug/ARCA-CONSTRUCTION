<?php
// 1. Validamos la sesión segura para el rol de Secretaría
session_start();
if (!isset($_SESSION['rol_activo']) || $_SESSION['rol_activo'] != 'Secretaria') {
    header("Location: login.html");
    exit(); 
}

// 2. Incluimos el archivo de conexión a la base de datos
include("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agenda Corporativa - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9ebf2; padding: 20px; }
        .header { background-color: #8e44ad; color: white; padding: 15px; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #9b59b6; color: white; }
        .btn-volver { background-color: #e74c3c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <h2>Juntas Programadas por: <?php echo $_SESSION['usuario_activo']; ?></h2>
        <a href="panel_administrativo.php" class="btn-volver">Regresar al Panel</a>
    </div>

    <!-- Estructura visual de la tabla HTML -->
    <table>
        <tr>
            <th>Asunto de la Reunión</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Modalidad</th>
            <th>Estado</th>
        </tr>

        <?php
        // 3. Consulta SQL con INNER JOIN para cruzar la agenda con el usuario activo
        $nombre_secretaria = $_SESSION['usuario_activo'];
        
        $sql = "SELECT a.asunto, a.fecha_reunion, a.hora_reunion, a.modalidad, a.estado 
                FROM agenda_juntas a 
                INNER JOIN usuarios u ON a.numero_empleado = u.numero_empleado 
                WHERE u.nombre = ?";
                
        $stmt = $conectar->prepare($sql);
        $stmt->bind_param("s", $nombre_secretaria);
        $stmt->execute();
        $resultado = $stmt->get_result();

        // 4. Automatización con ciclo WHILE
        // Se repetirá imprimiendo una nueva fila <tr> por cada junta encontrada
        if ($resultado->num_rows >= 1) {
            while($junta = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $junta['asunto'] . "</td>";
                echo "<td>" . $junta['fecha_reunion'] . "</td>";
                echo "<td>" . $junta['hora_reunion'] . "</td>";
                echo "<td><b>" . $junta['modalidad'] . "</b></td>";
                echo "<td style='color: #8e44ad;'><b>" . $junta['estado'] . "</b></td>";
                echo "</tr>";
            }
        } else {
            // Si la secretaria no ha registrado reuniones, se muestra este mensaje
            echo "<tr><td colspan='5'>No hay juntas programadas en este momento.</td></tr>";
        }
        
        // Cerramos la conexión para liberar memoria
        $stmt->close();
        ?>
    </table>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>