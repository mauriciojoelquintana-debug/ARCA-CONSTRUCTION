<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca28_rh.php';
$db=a27_boot(['CHRO']);
$roles=a28_functions();
$empleados=arx_rows($db,'SELECT id_empleado,numero_empleado,nombre_completo,tipo_personal,estado_laboral,fecha_ingreso,id_puesto,id_gerencia FROM arca_empleados ORDER BY nombre_completo');
$contratos=arx_rows($db,"SELECT c.id_contrato,c.id_empleado,c.tipo,c.inicio,c.fin,c.estado,e.numero_empleado FROM arca_contratos_laborales c JOIN arca_empleados e ON e.id_empleado=c.id_empleado WHERE c.estado IN('BORRADOR','VIGENTE') ORDER BY e.numero_empleado,c.inicio DESC");
$puestos=arx_rows($db,'SELECT id_puesto,nombre_cargo FROM catalogo_puestos_arca ORDER BY nombre_cargo');
$gerencias=arx_rows($db,'SELECT id_gerencia,nombre_gerencia FROM gerencias_arca ORDER BY nombre_gerencia');
$obras=array_values(array_filter(arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra'),static fn($r)=>a28_obra_acceso($db,(string)$r['codigo_obra'],'consultar')));
$obrasVisibles=array_column($obras,'codigo_obra');
$hist=arx_rows($db,"SELECT h.id_asignacion,h.num_empleado,h.nombre_personal,h.puesto_cargo,h.obra_asignada,e.id_empleado,e.estado_laboral,e.tipo_personal FROM asignaciones_obra_arca h LEFT JOIN arca_empleados e ON e.numero_empleado=h.num_empleado ORDER BY h.obra_asignada,h.id_asignacion");
$candidatos=array_values(array_filter($hist,static function($h)use($roles,$obrasVisibles){if(!in_array($h['obra_asignada'],$obrasVisibles,true))return false;foreach(array_keys($roles) as $func)if(a28_cargo_coincide($func,(string)$h['puesto_cargo']))return true;return false;}));
$asignaciones=arx_rows($db,"SELECT a.id_asignacion,a.codigo_obra,a.cargo_obra,a.fecha_inicio,a.fecha_fin,a.estado,e.nombre_completo,e.numero_empleado,e.id_empleado,e.estado_laboral FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado ORDER BY a.id_asignacion DESC LIMIT 200");
$asignaciones=array_values(array_filter($asignaciones,static fn($a)=>in_array($a['codigo_obra'],$obrasVisibles,true)));
$pendientes=0;foreach($empleados as $e)if($e['estado_laboral']==='POR_VERIFICAR')$pendientes++;
a27_layout('Conciliación laboral y contratos','Validación documentada para CHRO. No se crean empleados ni contratos ficticios a partir del historial.','arca28_validacion.php');
?>
<section class="a27-grid">
  <article class="a27-card"><div class="a27-sub">Expedientes de RH</div><div class="a27-metric"><?=count($empleados)?></div></article>
  <article class="a27-card"><div class="a27-sub">Empleados por verificar</div><div class="a27-metric"><?=$pendientes?></div></article>
  <article class="a27-card"><div class="a27-sub">Candidatos históricos de funciones obligatorias</div><div class="a27-metric"><?=count($candidatos)?></div><div class="a27-sub">No equivalen a responsables confirmados</div></article>
</section>
<section class="a27-card"><h2>1. Conciliación con historial de obra</h2>
  <p class="a27-muted">Se compara por <code>numero_empleado</code>, no por coincidencia de nombres. Se conservan los 28 registros históricos originales.</p>
  <div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Obra</th><th>Persona histórica</th><th>Cargo en obra</th><th>RH</th><th>Resultado</th></tr></thead><tbody>
  <?php foreach($candidatos as $h):?><tr><td><?=a27_h($h['obra_asignada'])?></td><td><strong><?=a27_h($h['nombre_personal'])?></strong><div class="a27-sub"><?=a27_h($h['num_empleado'])?></div></td><td><?=a27_h($h['puesto_cargo'])?></td><td><?=a27_h($h['id_empleado']===null?'No registrado':'#'.$h['id_empleado'].' · '.$h['estado_laboral'])?></td><td><span class="a27-label warn"><?= $h['id_empleado']===null?'Revisar identidad':'Validar contrato y función' ?></span></td></tr><?php endforeach;?>
  <?php if(!$candidatos):?><tr><td colspan="5">Todavía no hay candidatos históricos identificados en las obras autorizadas.</td></tr><?php endif;?></tbody></table></div>
</section>
<section class="a27-card"><h2>2. Validación documental de un expediente</h2>
<p class="a27-muted">Primero registra el contrato real como <strong>BORRADOR</strong> en <a href="chro_personal.php#contratos">Contratos laborales</a>. Después de comprobar los documentos, indica un puesto, gerencia y fecha de ingreso reales. Se activa el contrato y el expediente en una única transacción auditada. Esta vía acepta personal <strong>PROPIO</strong>; la validación de subcontratistas requiere su expediente de proveedor y se tramitará por separado.</p>
<form method="post" action="arca28_guardar.php" class="a27-form">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="verificar_expediente">
<label>Empleado<select name="id_empleado" required><?php foreach($empleados as $e):?><option value="<?=(int)$e['id_empleado']?>"><?=a27_h($e['numero_empleado'].' · '.$e['nombre_completo'].' · '.$e['estado_laboral'])?></option><?php endforeach;?></select></label>
<label>Contrato real (borrador/vigente)<select name="id_contrato" required><option value="">Selecciona un contrato...</option><?php foreach($contratos as $c):?><option value="<?=(int)$c['id_contrato']?>"><?=a27_h('#'.$c['id_contrato'].' · '.$c['numero_empleado'].' · '.$c['tipo'].' · '.$c['estado'].' · '.$c['inicio'])?></option><?php endforeach;?></select></label>
<label>Puesto corporativo<select name="id_puesto" required><option value="">Seleccionar...</option><?php foreach($puestos as $p):?><option value="<?=(int)$p['id_puesto']?>"><?=a27_h($p['nombre_cargo'])?></option><?php endforeach;?></select></label>
<label>Gerencia corporativa<select name="id_gerencia" required><option value="">Seleccionar...</option><?php foreach($gerencias as $g):?><option value="<?=(int)$g['id_gerencia']?>"><?=a27_h($g['nombre_gerencia'])?></option><?php endforeach;?></select></label>
<label>Fecha real de ingreso<input type="date" name="fecha_ingreso" required max="<?=a27_h(date('Y-m-d'))?>"></label>
<label>Referencia documental de RH<input name="referencia_verificacion" maxlength="120" placeholder="Folio interno del expediente verificado" required></label>
<label class="a27-wide"><input type="checkbox" name="evidencia_revisada" value="1" required> Confirmo que revisé la identidad y el contrato auténticos, y que tengo autorización de RH para validarlos.</label>
<button>Validar expediente y activar contrato</button></form>
</section>
<section class="a27-card"><h2>3. Asignación laboral validada</h2>
<p class="a27-muted">Solo personal propio con expediente y contrato vigentes. El inicio no puede ser anterior al contrato ni al ingreso, ni pueden existir periodos superpuestos del mismo empleado en una obra.</p>
<form method="post" action="arca28_guardar.php" class="a27-form">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="crear_asignacion">
<label>Empleado<select name="id_empleado" required><?php foreach($empleados as $e):if($e['estado_laboral']!=='ACTIVO'||$e['tipo_personal']!=='PROPIO')continue;?><option value="<?=(int)$e['id_empleado']?>"><?=a27_h($e['numero_empleado'].' · '.$e['nombre_completo'])?></option><?php endforeach;?></select></label>
<label>Obra autorizada<select name="codigo_obra" required><?php foreach($obras as $o):?><option value="<?=a27_h($o['codigo_obra'])?>"><?=a27_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></option><?php endforeach;?></select></label>
<label>Función dentro de la obra<input name="cargo_obra" maxlength="90" required placeholder="Ej. Gerente de Proyecto / Ingeniero Civil"></label>
<label>Frente o cuadrilla (opcional)<input name="frente" maxlength="100"></label>
<label>Inicio real<input name="fecha_inicio" type="date" required max="<?=a27_h(date('Y-m-d'))?>"></label>
<label>Fin (si corresponde)<input name="fecha_fin" type="date"></label>
<button>Guardar asignación validada</button>
</form>
<div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Empleado</th><th>Obra</th><th>Cargo</th><th>Periodo</th><th>Estado</th></tr></thead><tbody>
<?php foreach($asignaciones as $a):?><tr><td><?=a27_h($a['nombre_completo'])?></td><td><?=a27_h($a['codigo_obra'])?></td><td><?=a27_h($a['cargo_obra'])?></td><td><?=a27_h($a['fecha_inicio'].' – '.($a['fecha_fin']??'Abierto'))?></td><td><?=a27_h($a['estado'])?></td></tr><?php endforeach;?>
<?php if(!$asignaciones):?><tr><td colspan="5">Sin asignaciones integradas. Los registros históricos permanecen sin modificar.</td></tr><?php endif;?></tbody></table></div>
</section>
<p class="a27-muted">Paso siguiente: <a href="arca27_equipo_obra.php">proponer los responsables</a>. El COO confirma por separado. El CEO observa la cobertura, sin permisos de escritura.</p>
<?php a27_end(); ?>
