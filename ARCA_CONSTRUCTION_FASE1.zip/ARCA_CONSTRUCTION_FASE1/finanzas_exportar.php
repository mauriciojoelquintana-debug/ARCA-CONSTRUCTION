<?php
require_once __DIR__ . '/includes/seguridad.php';
require_once __DIR__ . '/includes/finanzas_utilidades.php';
arca_requerir_roles(['CFO','CEO','Director General']);
require __DIR__ . '/conexion.php';
$modulo = (string)($_GET['modulo'] ?? 'presupuesto');
if (!array_key_exists($modulo, arca_fin_modulos())) { http_response_code(400); exit('Módulo inválido.'); }
$obra = arca_fin_filtrar_obra((string)($_GET['obra'] ?? ''));
$sql = 'SELECT id_finanza,codigo_obra,nombre_proyecto,modulo,concepto,monto,moneda,categoria_costo,estado_pago,fecha_transaccion FROM finanzas_coo WHERE modulo=?';
if ($obra !== '') $sql .= ' AND codigo_obra=?';
$sql .= ' ORDER BY fecha_transaccion DESC,id_finanza DESC';
$stmt = $conectar->prepare($sql);
if ($obra !== '') $stmt->bind_param('ss',$modulo,$obra); else $stmt->bind_param('s',$modulo);
$stmt->execute();
$resultado = $stmt->get_result();
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="ARCA_'.$modulo.'_'.date('Ymd_His').'.csv"');
header('Cache-Control: no-store, private');
$salida = fopen('php://output','wb');
fwrite($salida,"\xEF\xBB\xBF");
fputcsv($salida,['Folio','Código de obra','Obra','Módulo','Concepto','Importe','Moneda real','Categoría de costo','Estado','Fecha'],';');
while ($r = $resultado->fetch_assoc()) {
    fputcsv($salida,[
        (int)$r['id_finanza'], arca_fin_csv_seguro($r['codigo_obra']), arca_fin_csv_seguro($r['nombre_proyecto']),
        arca_fin_csv_seguro($r['modulo']),arca_fin_csv_seguro($r['concepto']),
        number_format((float)$r['monto'],2,'.',''),arca_fin_csv_seguro($r['moneda']??'SIN DEFINIR'),arca_fin_csv_seguro($r['categoria_costo']),arca_fin_csv_seguro($r['estado_pago']),$r['fecha_transaccion']
    ],';');
}
fclose($salida); $stmt->close();
