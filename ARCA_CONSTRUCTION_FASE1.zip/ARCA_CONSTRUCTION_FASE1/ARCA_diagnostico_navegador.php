<?php
/**
 * ARCA CONSTRUCTION - Diagnóstico temporal desde navegador.
 * Copiar a la RAÍZ de ARCA_CONSTRUCTION_FASE1.
 * IMPORTANTE: usar solo en localhost y eliminar este archivo al terminar.
 * No guarda, imprime ni registra contraseñas; no cambia la base de datos.
 */
if (PHP_SAPI === 'cli' || !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Acceso permitido únicamente desde el navegador local del equipo.');
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

require_once __DIR__ . '/includes/seguridad.php';
arca_iniciar_sesion();

function arca_diag_html($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
$resultados = [];
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $numero = trim((string)($_POST['num_empleado'] ?? ''));
    $clave = (string)($_POST['password'] ?? '');
    if ($numero === '' || $clave === '' || strlen($numero) > 30 || strlen($clave) > 1024) {
        $error = 'Escribe el número de empleado y la contraseña para probarlos.';
    } else {
        try {
            require __DIR__ . '/conexion.php';
            $sqlInfo = $conectar->query('SELECT DATABASE() AS bd, @@port AS puerto, @@hostname AS servidor')->fetch_assoc();
            $stmt = $conectar->prepare('SELECT numero_empleado, cargo, password FROM usuarios WHERE numero_empleado = ? LIMIT 1');
            $stmt->bind_param('s', $numero);
            $stmt->execute();
            $fila = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $esValida = $fila ? password_verify($clave, (string)$fila['password']) : false;
            $bloqueo = max(0, (int)($_SESSION['login_bloqueado_hasta'] ?? 0) - time());
            $resultados = [
                'Base utilizada por Apache' => (string)($sqlInfo['bd'] ?? '(desconocida)'),
                'Puerto MySQL usado por Apache' => (string)($sqlInfo['puerto'] ?? '?'),
                'PHP del navegador' => PHP_VERSION . ' (' . PHP_SAPI . ')',
                'Cuenta encontrada' => $fila ? 'SÍ' : 'NO',
                'Cargo leído' => $fila ? (string)$fila['cargo'] : '(sin cuenta)',
                'Tipo de contraseña almacenada' => $fila && password_get_info((string)$fila['password'])['algoName'] !== 'unknown' ? 'Hash compatible' : 'Sin hash compatible o cuenta ausente',
                'password_verify en navegador' => $esValida ? 'CORRECTA' : 'NO COINCIDE',
                'Bloqueo de esta sesión' => $bloqueo > 0 ? "$bloqueo segundos restantes" : 'Sin bloqueo activo',
                'Archivo del login actual' => is_file(__DIR__.'/procesar_ingreso.php') && strpos((string)file_get_contents(__DIR__.'/procesar_ingreso.php'), 'password_verify(') !== false ? 'Versión con password_verify' : 'Revisar: versión inesperada',
            ];
            $conectar->close();
        } catch (Throwable $e) {
            $error = 'PHP de Apache no logró completar la conexión o la consulta. Revisa el archivo de registro de errores de Apache/Laragon.';
            error_log('ARCA diagnóstico HTTP: ' . $e->getMessage());
        } finally {
            unset($clave, $esValida, $fila);
        }
    }
}
?><!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Diagnóstico local de acceso | ARCA CONSTRUCTION</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fa;color:#24384f;font:15px/1.55 system-ui,-apple-system,'Segoe UI',sans-serif;padding:32px 16px}
main{max-width:700px;margin:0 auto;background:white;border:1px solid #e4e9ef;box-shadow:0 12px 35px rgba(27,45,70,.05);border-radius:16px;padding:30px}
h1{font-size:25px;line-height:1.25;margin:0 0 7px}p{color:#6f8193;margin:0 0 20px}.eyebrow{font-size:11px;letter-spacing:.16em;color:#a57d4f;font-weight:700}label{display:block;margin:12px 0 6px;font-weight:600;font-size:13px}input{width:100%;padding:12px;border:1px solid #ccd6e0;border-radius:8px;font-size:15px;background:#fafbfd;color:#24384f}button{margin-top:18px;background:#263b53;color:white;border:0;border-radius:8px;padding:12px 17px;font-weight:700;cursor:pointer}table{width:100%;border-collapse:collapse;margin-top:18px}td{padding:11px 7px;border-bottom:1px solid #ebeff3;vertical-align:top}td:first-child{color:#66798d;width:54%}.good{color:#21735c;font-weight:700}.bad{color:#af4743;font-weight:700}.note{background:#f6f8fa;padding:13px;border-radius:8px;font-size:13px;margin-top:18px}.error{color:#af4743;font-weight:600}
</style>
</head>
<body><main>
<span class="eyebrow">ARCA CONSTRUCTION · SOPORTE LOCAL</span>
<h1>Diagnóstico de inicio de sesión</h1>
<p>Esta prueba utiliza <strong>el mismo PHP de Apache y la misma conexión del sitio web</strong>. No modifica usuarios, no crea sesiones de acceso y no muestra ni guarda contraseñas.</p>
<form method="post" action="ARCA_diagnostico_navegador.php" autocomplete="off">
<label for="num_empleado">Número de empleado</label><input type="text" id="num_empleado" name="num_empleado" placeholder="CEO-001" required maxlength="30" autocomplete="off">
<label for="password">Contraseña para verificar</label><input type="password" id="password" name="password" required autocomplete="off">
<button type="submit">Comprobar desde el navegador</button>
</form>
<?php if ($error !== ''): ?><p class="error" role="alert" style="margin-top:18px"><?=arca_diag_html($error)?></p><?php endif; ?>
<?php if ($resultados): ?>
<h2 style="font-size:17px;margin:26px 0 0">Resultado de Apache</h2>
<table><tbody><?php foreach ($resultados as $etiqueta => $dato): ?>
<tr><td><?=arca_diag_html($etiqueta)?></td><td class="<?= $etiqueta === 'password_verify en navegador' ? ($dato === 'CORRECTA' ? 'good' : 'bad') : '' ?>"><?=arca_diag_html($dato)?></td></tr>
<?php endforeach; ?></tbody></table>
<?php endif; ?>
<div class="note"><strong>Seguridad:</strong> El archivo funciona únicamente en este equipo mediante localhost. Elimínalo de la carpeta del proyecto al terminar. No envíes capturas que incluyan contraseñas.</div>
</main></body></html>
