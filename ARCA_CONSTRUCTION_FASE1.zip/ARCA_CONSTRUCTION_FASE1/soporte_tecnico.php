<?php /* ARCA27 REDIRECT: destino con guardia de rol */
header('Location: arca27_soporte.php',true,302); exit; ?>
<?php
/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('soporte_tecnico.php');

require_once __DIR__ . '/includes/seguridad.php';
arca_requerir_roles(['CIO', 'CEO', 'Director General']);
include('conexion.php');
$query_tickets = $conectar->query("SELECT * FROM soporte_tickets");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Help Desk - ARCA</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #0d1117; color: #c9d1d9; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #30363d; padding: 12px; text-align: left; }
        th { background-color: #161b22; color: #58a6ff; }
        .btn-volver { background: #3fb950; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">
    <h2>Bandeja de Soporte Técnico (Help Desk)</h2>
    <a href="panel_cio.php" class="btn-volver">Volver al Panel CIO</a>
    <table>
        <tr>
            <th>ID Ticket</th>
            <th>Empleado (Falla)</th>
            <th>Descripción del Problema</th>
            <th>Estado</th>
            <th>Fecha de Reporte</th>
        </tr>
        <?php while($row = $query_tickets->fetch_assoc()) { ?>
        <tr>
            <td>#<?php echo $row['id_ticket']; ?></td>
            <td><?php echo $row['numero_empleado']; ?></td>
            <td><?php echo $row['descripcion_falla']; ?></td>
            <td style="color: #ff7b72; font-weight: bold;"><?php echo $row['estado']; ?></td>
            <td><?php echo $row['fecha_reporte']; ?></td>
        </tr>
        <?php } ?>
    </table>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>