<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/arca_fases_8_13.php';
$db = arx_boot(['CEO', 'Director General', 'CIO']);

$tests = [
 'Obras sin código relacionado' => 'SELECT COUNT(*) n FROM arca_solicitudes_compra s LEFT JOIN obras_coo o ON o.codigo_obra=s.codigo_obra WHERE o.codigo_obra IS NULL',
 'Movimientos financieros sin divisa' => "SELECT COUNT(*) n FROM finanzas_coo WHERE moneda IS NULL OR moneda NOT IN ('USD','MXN')",
 'Asignaciones con empleado inactivo' => "SELECT COUNT(*) n FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.estado='ACTIVA' AND e.estado_laboral<>'ACTIVO'",
 'Solicitudes aprobadas sin revisor' => "SELECT COUNT(*) n FROM arca_solicitudes_compra WHERE estado='APROBADA' AND revisado_por IS NULL",
 'Solicitudes autoaprobadas' => 'SELECT COUNT(*) n FROM arca_solicitudes_compra WHERE solicitado_por=revisado_por',
 'Órdenes sin solicitud aprobada' => "SELECT COUNT(*) n FROM arca_ordenes_compra o JOIN arca_solicitudes_compra s ON s.id_solicitud=o.id_solicitud WHERE s.estado<>'APROBADA'",
 'Departamentos sin gerencia' => 'SELECT COUNT(*) n FROM arca_departamentos_gerencias d LEFT JOIN gerencias_arca g ON g.id_gerencia=d.id_gerencia WHERE g.id_gerencia IS NULL',
];
$checks = [];
foreach ($tests as $name=>$sql) {
    try { $checks[$name] = (int)(arx_one($db, $sql)['n'] ?? 0); }
    catch (Throwable $e) { error_log('Auditoría ARCA: ' . $e->getMessage()); $checks[$name] = null; }
}
$monedas = arx_rows($db, "SELECT COALESCE(moneda,'SIN CONFIRMAR') AS moneda,COUNT(*) AS total FROM finanzas_coo GROUP BY COALESCE(moneda,'SIN CONFIRMAR') ORDER BY moneda");
$auditoriaTotal = (int)(arx_one($db, 'SELECT COUNT(*) n FROM arca_auditoria_modulos')['n'] ?? 0);
$auditoria = arx_rows($db, 'SELECT modulo,entidad,accion,fecha FROM arca_auditoria_modulos ORDER BY id_evento DESC LIMIT 20');
$pendientes = $checks['Movimientos financieros sin divisa'];

// No cambia montos, monedas, permisos ni registros. Solo representa su estado real.
af8_layout('Auditoría y control de calidad', 'Integridad de datos y trazabilidad de las operaciones.', 'arca_validacion.php');
?>
<div class="arx-note">
 <strong>¿Qué significan los resultados?</strong> «Sin hallazgos» significa que una comprobación concreta no detectó inconsistencias; <strong>no es una certificación global de seguridad</strong>. Los importes antiguos sin moneda son una tarea de revisión documental, no un fallo del servidor.
</div>
<?php if ($pendientes !== null && $pendientes > 0): ?>
 <div class="arx-alert warn">
  <strong><?= (int)$pendientes ?> movimientos financieros pendientes de identificar.</strong>
  Las transacciones históricas sin respaldo documental conservan su moneda sin confirmar. Verifica la divisa de cada movimiento antes de clasificarlo.
  <div class="af8-links"><a class="arx-btn" href="finanzas_auditoria.php">Abrir conciliación por obra</a><span class="arx-tag">Solo CFO puede confirmar USD/MXN; CEO consulta</span></div>
 </div>
<?php endif; ?>
<section class="arx-card">
 <h2>Comprobaciones de integridad</h2><p class="arx-sub">Las verificaciones se actualizan al recargar la página.</p>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Control</th><th>Registros por revisar</th><th>Interpretación</th></tr></thead><tbody>
 <?php foreach ($checks as $name=>$qty): ?>
 <?php $isMoney = $name==='Movimientos financieros sin divisa'; ?>
 <tr><td><?= arx_h($name) ?></td><td><strong><?= $qty === null ? 'No evaluado' : (int)$qty ?></strong></td><td>
 <?php if ($qty === null): ?>Revisar consulta o tabla en el log de Apache.
 <?php elseif ($qty === 0): ?>Sin hallazgos en este control.
 <?php elseif ($isMoney): ?>Clasificación documental pendiente; no cambiar divisas automáticamente.
 <?php else: ?>Requiere revisión de registros y permisos.
 <?php endif; ?>
 </td></tr>
 <?php endforeach; ?>
 </tbody></table></div>
</section>
<section class="arx-card">
 <h2>Distribución de movimientos por divisa</h2><p class="arx-sub">Los registros sin confirmar se mantienen separados de USD y MXN. Estos valores representan cantidad de movimientos, no montos.</p>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Divisa registrada</th><th>Movimientos</th><th>Acción requerida</th></tr></thead><tbody>
 <?php foreach ($monedas as $m): ?><tr><td><?= arx_h($m['moneda']) ?></td><td><?= (int)$m['total'] ?></td><td><?= $m['moneda']==='SIN CONFIRMAR' ? 'Revisar cada folio con su documento de origen' : 'Sin acción de divisa' ?></td></tr><?php endforeach; ?>
 <?php if (!$monedas): ?><tr><td colspan="3">No hay movimientos financieros registrados.</td></tr><?php endif; ?>
 </tbody></table></div>
</section>
<section class="arx-card">
 <h2>Bitácora reciente</h2><p class="arx-sub"><?= $auditoriaTotal ?> eventos registrados en la bitácora de módulos de las fases nuevas; se muestran los 20 más recientes.</p>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Módulo</th><th>Entidad</th><th>Acción</th><th>Fecha</th></tr></thead><tbody>
 <?php foreach ($auditoria as $a): ?><tr><td><?= arx_h($a['modulo']) ?></td><td><?= arx_h($a['entidad']) ?></td><td><?= arx_h($a['accion']) ?></td><td><?= arx_h($a['fecha']) ?></td></tr><?php endforeach; ?>
 <?php if (!$auditoria): ?><tr><td colspan="4">Aún no se han registrado eventos en esta bitácora. Aparecerán cuando se creen proveedores, solicitudes, cotizaciones, órdenes u otras operaciones integradas. La bitácora financiera de fases anteriores es independiente.</td></tr><?php endif; ?>
 </tbody></table></div>
</section>
<section class="arx-card">
 <h2>Alcance de seguridad</h2><p>Las páginas de las fases nuevas comprueban roles y permisos por obra. Esta pantalla no verifica automáticamente todos los archivos históricos de ARCA. Antes de publicar el ERP en Internet, audita los formularios anteriores, el inicio de sesión, la protección CSRF, las rutas de archivos, HTTPS y los respaldos.</p>
 <p class="arx-sub">Pruebas manuales: acceso sin sesión (403), solicitud propia (sin autoaprobación), stock insuficiente, cotización vencida y exportaciones protegidas.</p>
</section>
<?php arx_layout_end(); ?>
