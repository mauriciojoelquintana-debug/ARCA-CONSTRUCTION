<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca24_acceso_seguro.php';
$db=a26_db();$accessible=a24_obras_autorizadas($db);
if(!$accessible){http_response_code(403);exit('Sin obras autorizadas.');}
$role=arx_role();$canFinance=a26_rol_finanzas($role);
a26_layout('Indicadores corporativos actualizados','Visión del estado actual de las obras con actualización controlada cada 45 segundos.','arca24_tablero.php');
?>
<section class="arx-card">
 <div class="a26-toolbar"><label>Ámbito de consulta <select id="a24-obra"><option value="">Todas mis obras autorizadas</option><?php foreach($accessible as $o):?><option value="<?=arx_h($o['codigo_obra'])?>"><?=arx_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></option><?php endforeach;?></select></label><button class="arx-btn primary" id="a24-refresh" type="button">Actualizar ahora</button><span id="a24-stamp" role="status">Esperando primera actualización…</span></div>
 <p class="ax-muted">Los indicadores se actualizan al pulsar Actualizar. Las cifras operativas cuentan registros, no necesariamente personas distintas.</p>
</section>
<section class="a26-cards" aria-label="Indicadores actuales">
 <?php foreach(['obras'=>'Obras consultadas','avance_promedio'=>'Avance promedio (%)','asignaciones_activas'=>'Asignaciones activas','materiales_registrados'=>'Artículos de almacén','alertas_stock'=>'Artículos en stock bajo','ordenes_emitidas'=>'Órdenes emitidas'] as $key=>$label):?>
 <article class="a26-stat"><span><?=arx_h($label)?></span><strong id="a24-<?=arx_h($key)?>">—</strong></article><?php endforeach;?>
</section>
<section class="arx-card"><h2>Avance por obra</h2><div class="ax-scroll"><table class="ax-table"><thead><tr><th>Código</th><th>Obra</th><th>Avance</th><th>Estado</th></tr></thead><tbody id="a24-tabla-obras"><tr><td colspan="4">Cargando datos…</td></tr></tbody></table></div></section>
<?php if($canFinance):?><section class="arx-card"><h2>Movimientos financieros por divisa</h2><p class="ax-muted">Se muestran las monedas por separado; los registros sin moneda confirmada no se convierten a USD.</p><div class="ax-scroll"><table class="ax-table"><thead><tr><th>Moneda</th><th>Módulo</th><th>Estado</th><th>Movimientos</th><th>Importe</th></tr></thead><tbody id="a24-finanzas"></tbody></table></div></section><?php endif;?>
<script>
(()=>{'use strict';
 const $=id=>document.getElementById(id);let loading=false;
 function cell(row,text){const td=document.createElement('td');td.textContent=String(text??'—');row.appendChild(td);}
 function clear(tb){tb.replaceChildren();}
 const money=(n,c)=>new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(n||0))+' '+c;
 async function refresh(){if(loading)return;loading=true;$('a24-stamp').textContent='Actualizando indicadores…';
 try{const url='arca24_estado.php?obra='+encodeURIComponent($('a24-obra').value);const res=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});const tipo=(res.headers.get('content-type')||'').toLowerCase();
 if(!tipo.includes('application/json')) {
   if(res.redirected || /ingreso\.html(?:[?#]|$)/i.test(res.url)) {
     throw new Error('La sesión no es válida para esta dirección. Ingresa desde el mismo dominio y vuelve a abrir el tablero.');
   }
   throw new Error('El servidor respondió HTML o texto (HTTP '+res.status+') en lugar de JSON. Revisa arca24_estado.php.');
 }
 const body=await res.json();if(!res.ok||!body.ok)throw new Error(body.error||'Sesión finalizada o consulta no autorizada');
 const d=body.data;Object.entries(d.indicadores).forEach(([key,v])=>{const el=$('a24-'+key);if(el)el.textContent=String(v);});
 const tb=$('a24-tabla-obras');clear(tb);d.obras.forEach(w=>{const tr=document.createElement('tr');cell(tr,w.codigo);cell(tr,w.nombre);const td=document.createElement('td');td.textContent=w.avance.toFixed(1)+' %';const bar=document.createElement('div');bar.className='a26-bar';const fill=document.createElement('i');fill.style.width=Math.min(100,Math.max(0,w.avance))+'%';bar.appendChild(fill);td.appendChild(bar);tr.appendChild(td);cell(tr,w.estado);tb.appendChild(tr);});
 <?php if($canFinance):?>const fb=$('a24-finanzas');clear(fb);d.finanzas.forEach(f=>{const tr=document.createElement('tr');cell(tr,f.moneda);cell(tr,f.modulo);cell(tr,f.estado_pago);cell(tr,f.cantidad);cell(tr,money(f.monto,f.moneda));fb.appendChild(tr);});<?php endif;?>
 $('a24-stamp').textContent='Actualizado: '+d.consultado+' (hora del servidor)';
 }catch(e){$('a24-stamp').textContent='No se pudo actualizar: '+e.message;const tb=$('a24-tabla-obras');if(tb)tb.replaceChildren();const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=4;td.textContent='Indicadores no disponibles; no se han modificado datos.';tr.appendChild(td);if(tb)tb.appendChild(tr);}finally{loading=false;}}
 $('a24-refresh').addEventListener('click',refresh);$('a24-obra').addEventListener('change',refresh);refresh();window.setInterval(()=>{if(document.visibilityState==='visible')refresh();},45000);
})();
</script>
<?php arx_layout_end(); ?>
