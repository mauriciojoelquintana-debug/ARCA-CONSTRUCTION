<?php
session_start();
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';
$roles_tecnicos = [
    'Ingeniero Civil', 'Arquitecto', 'Residente de Obra', 'Supervisor de Obra', 
    'Ingeniero', 'Topógrafo', 'CTO', 'COO', 'Director de Construcción', 'Gerente de Proyectos'
];

if (!in_array($rol_limpio, $roles_tecnicos)) {
    header("Location: ingreso.html");
    exit();
}

include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Auditoría de Almacén - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; padding: 20px; text-align: center; }
        table { width: 90%; margin: 20px auto; border-collapse: collapse; background: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-top: 4px solid #f39c12; }
        th { background-color: #34495e; color: white; padding: 15px; }
        td { padding: 12px; border-bottom: 1px solid #ddd; }
        tr:hover { background-color: #f9f9f9; }
        .btn-volver { display: inline-block; background: #f39c12; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 15px; }
        .btn-volver:hover { background: #d68910; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">
    <h2 style="color: #f39c12;">Historial Global de Movimientos en Almacén</h2>
    <p>Auditor técnico en turno: <b><?php echo $_SESSION['usuario_activo']; ?></b></p>
    
    <table>
        <tr>
            <th>ID Registro</th>
            <th>Material / Maquinaria</th>
            <th>Cantidad</th>
            <th>Tipo de Movimiento</th>
            <th>Fecha y Hora</th>
            <th>Técnico (No. Empleado)</th>
        </tr>

        <?php
        $consulta = $conectar->query("SELECT * FROM inventario");

        if ($consulta && $consulta->num_rows > 0) {
            while($fila = $consulta->fetch_assoc()) {
                echo "<tr>";
                echo "<td><b>" . $fila['id_registro'] . "</b></td>";
                echo "<td>" . $fila['nombre_material'] . "</td>";
                echo "<td style='color:#27ae60; font-weight:bold;'>" . $fila['cantidad'] . "</td>";
                
                if($fila['tipo_movimiento'] == 'Entrada' || $fila['tipo_movimiento'] == 'entrada') {
                    echo "<td style='color: green; font-weight: bold;'>" . $fila['tipo_movimiento'] . "</td>";
                } else {
                    echo "<td style='color: red; font-weight: bold;'>" . $fila['tipo_movimiento'] . "</td>";
                }
                
                echo "<td>" . $fila['fecha_registro'] . "</td>";
                echo "<td>" . $fila['numero_empleado'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No hay registros de materiales en la base de datos.</td></tr>";
        }
        $conectar->close();
        ?>
    </table>
    <a href="panel_ingenieria.php" class="btn-volver">← Volver al Panel de Ingeniería</a>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>