<?php
$arca_area = 'CHRO';
require __DIR__ . '/includes/herramienta_directiva.php';
