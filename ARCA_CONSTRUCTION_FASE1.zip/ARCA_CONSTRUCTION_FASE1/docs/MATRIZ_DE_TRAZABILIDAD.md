# Matriz de trazabilidad F36–F38

| Fase | Función | Origen / destino | Permisos | Impacto |
| --- | --- | --- | --- | --- |
| 36 | Diagnóstico de PHP y seguridad | Reutiliza `a33_comprobar` | CEO/CIO | Solo lectura |
| 36 | Respaldo del código desde CLI | ZIP con SHA-256 fuera de `www` | Operador con acceso al equipo | Archivos solo en carpeta externa elegida |
| 37 | Estado de obras y finanzas/personal/materiales | `a31_datos`, `a24_obras_autorizadas` | Rol y obra | Solo lectura |
| 37 | Navegación ejecutiva | Paneles existentes | Cada destino confirma permisos | Ningún dato modificado |
| 38 | Solicitud nueva | `arca38_flujos` | CEO/COO/CHRO/CFO según tipo | Alta solo en tabla F38 |
| 38 | Aprobación por otra dirección | `arca38_flujos`, `arca38_eventos` | Revisor distinto del autor | Solo estado F38 y evento inmutable |
| 38 | Exportación CSV | Vista de trámites autorizados | Rol, obra y tipo | Solo lectura |

**No incluido:** actualización automática de `arca_ordenes_compra`, `finanzas_coo`, `inventario_almacen_arca`, `arca_empleados` y `arca_asignaciones_personal` ni resolución autónoma de los 52 movimientos sin divisa o los 18 expedientes pendientes. Es deliberado: faltan reglas de negocio verificadas e información documental.
