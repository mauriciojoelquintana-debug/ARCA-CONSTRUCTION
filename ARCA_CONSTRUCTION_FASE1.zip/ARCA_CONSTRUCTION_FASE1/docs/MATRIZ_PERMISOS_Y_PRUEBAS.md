# ARCA Fase 23 — matriz base de pruebas

| Cargo | CEO/Direcciones | Finanzas | Operaciones | CHRO | Seguridad | Obras |
|---|---|---|---|---|---|---|
| CEO | Consulta consolidada | Consulta | Consulta | Consulta | Consulta | Consulta global |
| CFO | Panel CFO | Gestión según controles internos | Sin acceso a Compras | No | No | Consulta de obra |
| COO | Panel COO | No | Gestión COO | No | No | Global operativo |
| CHRO | Panel CHRO | No | Consulta contextual | Gestión CHRO | No | Consulta |
| CIO | Panel CIO | No | No | No | Auditoría | Según módulos CIO |
| CTO/CCO/CMO/CSO | Solo dirección correspondiente | No | Según su módulo especializado | No | No | Solo si existe permiso explícito |
| Residente/Ingeniero/Almacén | No | No | Módulos permitidos | No | No | Según `arca_accesos_obra` |

**Nota:** para rutas de campo, el nivel individual (`consultar`, `operar`, `aprobar`) se valida contra `arca_accesos_obra`. Los paneles antiguos conservan además sus propias reglas, que pueden ser más restrictivas.

## Casos a registrar antes de seguir

- Denegación 403 al alterar el parámetro `obra`.
- Denegación al entrar por URL directa en archivos antiguos (pendiente de auditoría completa).
- Denegación al enviar POST sin token CSRF.
- El CEO ve información sin poder autorizar su propia solicitud ni editar almacén.
- El CFO no puede registrar entrada de maquinaria.
- Ninguna salida de inventario debe generar saldo negativo.
- No aparecen contraseñas ni salarios en auditoría general.
- Cerrar sesión invalida la sesión de trabajo.

**Estado:** documentación y pruebas estáticas. El comportamiento final debe validarse con cuentas de prueba en Laragon.
