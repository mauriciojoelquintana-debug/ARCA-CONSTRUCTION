# Matriz de cambios — Fase 40 (menú + F32–F36)

| Archivo | Presentación anterior | Presentación actual | Protección |
|---|---|---|---|
| includes/arca27.php | Fase 27 / entorno local / pie técnico | Plataforma corporativa, cabecera y menú por rol | No cambia `a27_boot`, filtros, funciones de permiso ni sesión |
| arca32_auditoria.php | Diagnóstico / fase | Auditoría integral / estado de auditoría | Conserva las consultas y hallazgos |
| arca33_preparacion.php | Entorno de pruebas / preparación | Configuración operativa y criterios de habilitación | No convierte advertencias en OK |
| arca34_calidad.php | Leyenda técnica de certificación | Seguimiento de calidad | Formularios, CSRF, estado y bitácoras intactos |
| arca35_pruebas.php | Plan de pruebas / etiqueta de fase | Verificación operativa | F35 sigue exigiendo evidencia y no aprueba casos |
| arca36_infraestructura.php | Entorno local / mensaje de publicación | Estado de infraestructura | No aplica cambios a servidores ni respaldos |
| assets/css/arca40_corporativo.css | — | Estilo adicional neutro, responsive, foco accesible | No oculta botones, alertas ni resultados |

**Importante:** los códigos internos de auditoría (F32, F33, SEG01, BKP03) pueden seguir visibles en registros y evidencias cuando permiten identificar técnicamente el hallazgo. No se borran referencias ni datos del sistema.

**Si el usuario personalizó las leyendas anteriores con otros textos, el instalador no adivina el reemplazo.** Se deben revisar las pantallas y corregir específicamente los rótulos restantes con un cambio manual controlado.
