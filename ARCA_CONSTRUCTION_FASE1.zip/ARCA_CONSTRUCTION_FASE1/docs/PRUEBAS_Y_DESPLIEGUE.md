# ARCA CONSTRUCTION — Protocolo de pruebas y despliegue (Fases 14–19)

## Banco de pruebas

Entorno local, base `arca_bd_fase1`, respaldo verificable del código y SQL antes de comenzar. No uses cuentas reales ni documentos confidenciales en las pruebas. Conserva evidencias (capturas sin contraseñas, números personales o importes no públicos).

## Pruebas funcionales, paso a paso

1. **CEO (F14)**: entra a `arca_integracion.php`; cuenta obras, personal asignado y solicitudes pendientes y compáralos con `obras_coo`, `arca_asignaciones_personal`, `arca_solicitudes_compra`. Crea una operación en COO o CHRO, recarga el resumen y verifica que cambia sin copiar manualmente registros.
2. **Usuario de campo (F15)**: abre `arca_obra_360.php?obra=CODIGO_PERMITIDO`; luego cambia manualmente a una obra no concedida en `arca_accesos_obra`. Debe responder **HTTP 403**. Un CFO solo puede consultar, no registrar riesgos. Un empleado no asignado no debe entrar.
3. **Solicitudes (F16)**: crea `GASTO_EXTRAORDINARIO` desde COO en obra permitida. Valida importe/divisa obligatorios. Intenta decidir con la misma cuenta: debe fallar. Entra con CFO y aprueba; el estado y usuario revisor aparecen en MySQL y en la bitácora. Confirma que **no** apareció una transacción nueva en `finanzas_coo`.
4. **Cambios de alcance (F16)**: crea desde gerente autorizado, decide desde COO diferente del solicitante. Intenta autorizar desde CHRO o alterar el ID de obra desde URL: debe fallar.
5. **Recepción (F14/16)**: registra solicitud y orden completa desde COO. En `arca_recepcion.php` selecciona un artículo de la misma obra con unidad coincidente. Verifica **un solo** movimiento en `arca_movimientos_material`, aumento exacto de `inventario_almacen_arca`, orden `RECIBIDA` y una fila en `arca_recepciones_integradas`. Repite la operación: debe rechazarse, sin doble incremento. Prueba también elegir artículo de otra obra/unidad distinta: debe cancelar sin cambios.
6. **Revisión de importes (F14–17)**: compara compras con finanzas. Una orden emitida no equivale a una factura pagada; no se debe registrar automáticamente un segundo costo. Verifica que divisas USD/MXN/SIN CONFIRMAR aparecen separadas.
7. **PDF + Excel (F17)**: entra como CEO, descarga cada uno de los **5 tipos** en PDF y XLSX (10 descargas). Abre una hoja en Excel, valida 5 registros contra MySQL. Abre los PDF; confirma título y formato. Con CHRO prueba acceder a exportación `finanzas`: debe devolver **403**.
8. **CSRF (F18)**: intenta POST sin token a `arca_integracion_guardar.php` o `arca_lanzamiento_guardar.php`: debe responder **403**, sin crear filas. Un GET a esos archivos no debe modificar datos.
9. **Auditoría (F18)**: revisa `arca_seguridad.php` como CEO/CIO. Verifica las entradas recientes en `arca_auditoria_modulos`; prueba como rol de campo: debe responder **403**.
10. **Preparación (F19)**: entra como CEO/CIO a `arca_lanzamiento.php`, registra evidencia **de prueba** para un control. Comprueba la fila en `arca_revision_despliegue` y en la bitácora. La pantalla **no certifica** estado productivo aunque los controles estén completos.

## Lista mínima para infraestructura de producción (NO realizada en esta entrega)

- Dominio real y certificado TLS / HTTPS con renovación.
- Configuración correcta del encabezado HSTS después de verificar HTTPS.
- Usuario MySQL no-root de privilegios mínimos, contraseña secreta en configuración fuera de `www` y política de rotación.
- Protección de inicio de sesión, intentos, sesiones, logout, tiempo de inactividad, contraseñas únicas y restablecimiento seguro.
- Auditoría de **todos los archivos PHP heredados** por autorizaciones inconsistentes, consultas SQL concatenadas y XSS.
- CSRF en cada formulario que cambia estado; verificación por obra para cada objeto identificado por ID.
- Subidas de documentos en directorio privado, validación de extensión/MIME/tamaño, protección contra ejecución y acceso por permisos.
- Separación entre datos históricos de ejemplo y operaciones reales; clasificación documental de las divisas.
- Backups cifrados automáticos + prueba de restauración completa, alertas y retención.
- Política de datos personales, contratos, documentos financieros e informes (incluyendo PDFs y XLSX).
- Registros de auditoría con retención e integridad verificable; monitorizar fallas.
- Pruebas de concurrencia, fallos de red/energía, cálculos de importes sin flotantes y revisión fiscal aplicable.
- Prueba piloto con CEO, CFO, COO, CIO, CHRO, residentes y almacén. Acta de aceptación.
- Revisión independiente de seguridad. **No publicar hasta aprobarla.**

**Estado de la Fase 19:** candidata a pruebas (RC). No existe despliegue verificado en nube ni certificación de seguridad.
