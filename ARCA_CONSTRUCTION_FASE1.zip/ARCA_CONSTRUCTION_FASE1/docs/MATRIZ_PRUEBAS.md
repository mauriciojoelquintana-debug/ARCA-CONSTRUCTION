# Plan de pruebas — Fases 32 y 33

| ID | Control | Responsable | Evidencia | Criterio |
|---|---|---|---|---|
| S32-01 | CEO acceso F32 | CIO/CEO | Captura sesión CEO | 200, matriz sin datos personales |
| S32-02 | CFO/COO/CHRO bloqueados F32 | CIO | HTTP status/URL | No accesos a matriz global |
| S32-03 | CIO acceso F33, no F32 | CIO | HTTP status | 200 a F33 y rechazo F32 |
| S32-04 | CSV solo CEO | CIO/CEO | Descarga + HTTP status | Excel abre, otro rol bloqueado |
| S32-05 | Documentos privados íntegros | CHRO/CIO | Conteos, descarga autorizada | No exponer PDFs en www |
| S32-06 | Separar REAL y DEMO | CHRO | Captura + SQL lectura | DEMO no suma personal |
| S32-07 | Divisa sin confirmar | CFO | Captura F31+F32 | No convertir monedas |
| S32-08 | Roles por obra clasificada | CIO | Prueba con URL y CSV | No ver ARCA-SEC sin acceso |
| S33-01 | HTTPS, cookies, errores | CIO | Config y cabeceras | Configuración apta para producción |
| S33-02 | Respaldo/restauración | CIO/DBA | Registro restauración de prueba | Recuperación comprobada |
| S33-03 | Pruebas negativas CSRF | CIO | Informe de pruebas | Operaciones POST protegidas |
| S33-04 | Auditoría independiente | Seguridad | Reporte técnico | Sin vulnerabilidades críticas abiertas |

No incluir contraseñas, números de identificación personal ni contenidos de contratos en las capturas de evidencia.
