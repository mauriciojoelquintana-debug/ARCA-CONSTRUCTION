# Matriz de aceptación técnica — ARCA F34/F35

## Alcance automatizado comprobable sin la base real

- Sintaxis PHP de cada archivo y lectura de la migración SQL.
- Pruebas puras del catálogo, códigos SHA-256, controles de formularios y neutralización de CSV.
- Vista previa, aplicación controlada, idempotencia y conflicto simulado del instalador.

Estas pruebas **no** demuestran acceso seguro a MySQL ni verificación HTTP de roles. Las pruebas de navegador deberán registrarse en F35 con evidencia privada.

## Pruebas de operación en Laragon (NO simuladas)

1. CEO accede a F34 y ve controles agregados de F32/F33 (18 expedientes y movimientos sin divisa, según estado real). Verifica que los contadores de F32 no cambien tras guardar un seguimiento.
2. CEO guarda seguimiento CFO «Moneda de movimientos» como EN_PROCESO, responsable CFO y fecha compromiso; verifica su persistencia tras actualizar.
3. CEO intenta CERRADO sin evidencia y sin nota: la operación debe rechazarse.
4. CEO/CIO acceden a F35, registran una prueba NO_EJECUTADA, luego FALLIDA con motivo; verifica bitácora.
5. CIO intenta entrar a F34 por URL directa: acceso denegado; CFO y CHRO tampoco tienen acceso a F35.
6. POST sin `csrf_token` a `arca34_guardar.php` debe rechazarse; GET directo no puede modificar nada.
7. CSV de F34/F35 en Excel: columnas separadas, UTF-8, sin ejecución de fórmulas.
8. Verifica 3 nuevas tablas y entradas en `arca34_35_bitacora` para guardados.
9. Ejecuta pruebas negativas por obra clasificada y descarga privada F29 en cuentas de prueba.
10. Respaldos/restauración: ejecutar exclusivamente en una **copia aislada**; no usar la base activa. Registrar hash de copia y acta interna.

## Estado de producto

El panel F35 solo puede indicar un candidato a **revisión final** cuando controles F32/F33 y todas las pruebas manuales figuren sin pendientes. No constituye certificación, autorización de publicación ni pentest independiente.
