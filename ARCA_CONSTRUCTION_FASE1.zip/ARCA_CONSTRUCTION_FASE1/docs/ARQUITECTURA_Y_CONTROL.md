# Arquitectura, límites y correlación — ARCA Fases 29 y 30

## Tablas existentes sin escrituras en DEMO

- `arca_empleados`: referencias de empleados de ejemplo, no se cambia su `estado_laboral`.
- `arca_contratos_laborales`: contratos reales; F29 los referencia con `id_contrato`, F30 no escribe allí.
- `arca_asignaciones_personal`: asignaciones reales F28; F30 no escribe allí.
- `arca27_responsables_obra`: responsabilidades reales F27; F30 no escribe allí.
- `arca_accesos_obra`: permisos efectivos por usuario y obra; el filtro se vuelve a aplicar en cada POST.

## Tablas nuevas

- `arca29_documentos`: documentos PDF privados vinculados **o** a `id_contrato` real **o** a `id_demo_caso`; distingue `origen` REAL/DEMO y registra SHA-256.
- `arca30_demo_casos`: fila por obra+función simulada. Guarda el empleado de muestra, contrato simulado, fechas, estado, autor de propuesta y revisor COO. Tiene `UNIQUE(codigo_obra,funcion)`.

## Rol y operación

| Rol | F29 PDF privado | F30 crear/documentar/proponer | F30 aprobar | F30 consultar |
|---|---|---|---|---|
| CHRO | Subir, listar y descargar | Sí, en obras autorizadas | No | Sí |
| COO | No | No | Sí, en obras autorizadas | Sí |
| CEO | No | No | No | Sí |

Todos los POST tienen validación CSRF, permisos y bitácora. Se recomienda HTTPS y una revisión del resto del ERP antes de publicar.

## Estados de F30

BORRADOR (creado) → DOCUMENTADO (hay PDF marcado DEMO) → ASIGNADO (periodo válido) → PROPUESTO (CHRO) → APROBADO/RECHAZADO (COO). Rechazados pueden reabrirse mediante CHRO para repetir el proceso sin borrar auditoría.

Las fechas vencidas no cuentan como cobertura activa, aunque la aprobación quede registrada en el historial.

## Separación

F30 no equivale a acreditación laboral ni firma electrónica y la pantalla lo recalca. No existe mecanismo automático para «pasar» una aprobación DEMO a `arca27_responsables_obra`. El flujo real F28 conserva sus verificaciones documentales.
