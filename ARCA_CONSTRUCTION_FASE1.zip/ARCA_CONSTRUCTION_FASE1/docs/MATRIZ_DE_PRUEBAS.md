# Matriz de aceptación — ARCA Fases 24–26

| Caso | Perfil | Procedimiento | Resultado esperado |
|---|---|---|---|
| Indicadores globales | CEO | Abrir `arca24_tablero.php` | Todas las obras autorizadas y finanzas separadas por divisa |
| Actualización periódica | COO | Registrar movimiento de inventario y volver a panel | Conteos cambian en próxima consulta; sin duplicar movimiento |
| Lectura financiera | CHRO | Abrir tablero y revisar respuesta JSON | No existe clave de importes financieros con movimientos |
| Acceso sin sesión | Anónimo | Abrir panel/JSON y exportación | Redirige o deniega, sin información |
| Acceso obra ajena | Residente | Abrir URL con código fuera de `arca_accesos_obra` | 403 en los módulos con contexto de obra |
| Reporte financiero | CFO | Exportar USD y luego MXN | Montos solo de moneda seleccionada; no convierte |
| Reporte sin divisa | CFO | Exportar `SIN_CONFIRMAR` | Valores históricos separados, sin atribución USD |
| Informe personal | CHRO | Descargar asignaciones | Sin salarios, credenciales ni datos privados |
| Informe personal prohibido | CFO | Exportar `tipo=personal` directamente | 422/403 y sin datos |
| Informe fecha imposible | CFO | Poner fecha 2026-02-30 | Petición rechazada |
| Informe fecha final | COO | Exportar movimientos con último día | Incluye todos los movimientos del día final |
| Descarga ZIP/PDF | CEO | Abrir XLSX y PDF reales | Archivos válidos, sin warnings PHP mezclados |
| SQL no autorizado | Todos | Probar inyección textual en `obra` | Entrada denegada, sin concatenación en consultas |
| Calidad de datos | CEO/CIO | Abrir `arca26_seguridad.php` | Conteos precisos, sin modificaciones automáticas |
| Archivos antiguos | CIO | Ejecutar inventario CLI | Registro de hallazgos para revisión manual |
| CSRF y POST | Cada rol | Probar cada formulario heredado con token inválido | 403 y transacción cancelada |
| Respaldo | Administrador | Restaurar copia SQL en BD separada | Recuperación verificada, sin afectar `arca_bd_fase1` |

**Criterio de salida:** no declarar producción lista hasta que se documenten y firmen todas las pruebas de alta prioridad, se revise código heredado y se verifique seguridad HTTPS y respaldos restaurables.
