# Matriz de trazabilidad - Software de ARCA CONSTRUCTION.pdf (11 páginas)

Documento de origen: especificaciones de revisión de 30/10/2026. Los capturas son evidencia de solicitudes, no de que las funciones ya estén operativas.

| Página | Hallazgo del documento | Corrección de esta entrega | Pendiente para integración/validación |
|---|---|---|---|
| 1 | Catálogo jerárquico duplicado CEO | Portal de apoyos usa áreas existentes `direcciones_arca` y solicitudes con folio | Instalador quita el enlace literal si reconoce su formato; otros formatos quedan para revisión manual |
| 1 | Botones de cuatro áreas de apoyo inactivos | `arca27_apoyos.php` crea solicitudes auditadas por área | Bandejas por responsable/estados cuando existan permisos verificados |
| 2 | Menu ARCA con botones sin contenido | Instalador integra enlaces de nuevos módulos en catálogo; auditor de rutas detecta faltantes | Verificar todos los 28 enlaces preexistentes, no se certifican con esta entrega |
| 3, 5, 6 | CFO, COO, CMO, CHRO, CSO: 'Información del reporte' genérica | Fichas técnicas `includes/arca27_fichas.php`; parche opcional de `panel_directivo.php` | Revisar consulta, moneda y periodicidad por área contra MySQL real |
| 4 | CIO Help Desk y reportes SQL poco profesionales | `arca27_soporte.php`, `arca27_sql.php` con tema corporativo; SQL predefinido | Verificar roles CIO/CEO y permisos de cada reporte |
| 4 | Ocho funciones CIO con errores | `arca27_ti.php` con estados/evidencias reales; sin métricas simuladas | Monitorización de servicios externa requiere integración propia |
| 5 | CCO cinco botones 404 | `arca27_comercial.php` cinco vistas + registro y vínculo explícito | Confirmar divisas antiguas y relaciones documentales históricas |
| 7-10 | Diferentes perfiles y ámbitos globales/una obra | Nuevas páginas validan rol y obra en servidor | Auditar todos los scripts heredados, también direct URL/POST |
| 10-11 | Planos/render descargables y subida de cimentaciones | `arca27_documentos.php` para nuevas revisiones + descarga de fase20 | Subir **archivos reales** faltantes, no crearlos de ejemplo |
| 11 | 4 responsables por obra | `arca27_equipo_obra.php` muestra pendientes y exige asignación laboral activa | CHRO debe designar funciones reales en cada obra |
| 11 | Ciberseguridad y protección URL/BD | Guardias, CSRF, SQL parametrizado, auditoría para nuevos módulos | Auditoría total legacy, TLS, red, servidor, cuentas DB y pentest |

## Correlación de datos

- `obras_coo.codigo_obra` identifica una obra y filtra todos los módulos por la misma clave.
- `arca_empleados.id_empleado` define empleado; `usuarios.id_usuario` define cuenta de acceso; `arca_empleado_usuario` vincula ambas sin asumir identidad.
- `arca_asignaciones_personal.id_asignacion` define asignación temporal a obra; `arca27_responsables_obra` solo designa cuatro funciones sobre asignaciones reales.
- `comercial_cco.id_comercial` representa oportunidad / licitación / propuesta / seguimiento / contrato; `arca27_comercial_relaciones` conecta expedientes del mismo cliente y obra; `arca27_comercial_monedas` confirma moneda, sin modificar historia.
- `planos_oficina_tecnica.id_plano` registra versión y obra; `arca27_clasificacion_plano` indica tipo documental; el archivo privado nunca se expone por ruta pública.
- `arca27_controles_ti` exige evidencia humana; no presenta una cifra inventada como medición en vivo.
- `arca_auditoria_modulos` recibe cambios relevantes de los nuevos módulos dentro de transacciones.

## Clasificación de entrega

- Código disponible y validado estáticamente: módulos nuevos de apoyo, CIO, CCO, RH y planos.
- Integraciones: posibles con catálogo Fase 22 y paneles Fase 2, condicionadas a reconocer el texto de las versiones existentes.
- No se altera la base sin importación SQL explícita. No se cambian `conexion.php`, `ingreso.html`, `procesar_ingreso.php` o `cerrar_sesion.php`.
- No se afirma seguridad empresarial completa, funcionalidad demostrada en Laragon ni cobertura laboral total hasta verificar operaciones reales.
