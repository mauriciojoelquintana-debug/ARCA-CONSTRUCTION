# Fase 39 · Matriz de aceptación y hallazgos

**Naturaleza:** control de calidad previo a la Fase 40. No es autorización para producción.

## Verificaciones automáticas read-only

| Fuente | Acción | Persistencia de origen | Responsable |
|---|---|---|---|
| F32 | Recalcular integridad de empleados, vigencia laboral, accesos, monedas y documentos | Ningún cambio | CEO consulta; CHRO/CFO corrigen en sus módulos |
| F33 / F36 | Inspeccionar plataforma, HTTPS, cookies, dependencias y tareas de respaldo | Ningún cambio | CIO / infraestructura |
| F34 | Leer las incidencias ya documentadas | Ningún cambio | CEO |
| F35 | Leer resultados reales de las 20 pruebas, sin elevarlos a aprobados | Ningún cambio | CEO / CIO ejecutan pruebas por permisos |
| F38 | Verificar orden y consistencia de los eventos, integridad de los estados y separación solicitante/revisor | Ningún cambio | CEO consulta; COO/CFO revisan en módulos permitidos |
| F39 | Registrar incidentes distintos a F34 con estado, evidencia referencial y eventos de seguimiento | Solo `arca39_incidencias` y `arca39_eventos` | CEO |

## Reglas de puerta

No se considera candidato a evaluación humana si existe alguna de estas condiciones: hallazgos automáticos F32/F33 no correctos, pruebas F35 sin aprobar, inconsistencias detectadas en el historial F38, lectura parcial por límite de 500, incidencias manuales F39 sin cerrar o migración F39 ausente. Incluso si todas esas comprobaciones son correctas, falta validación independiente de exposición, restauración y autorización formal antes de publicar.

## Pruebas pendientes conocidas en el sistema del usuario

- 18 expedientes de RH marcados `POR_VERIFICAR`, sujetos a evidencia contractual real. No activar por lote.
- 52 movimientos financieros históricos sin moneda confirmada. No asignar USD ni convertir sin documento fuente.
- F35: SEG01 y SEG02 constan aprobadas en capturas previas; otros 18 casos permanecían sin aprobación. El panel recupera el valor actual de MySQL en cada consulta.
- F33/F36: HTTPS, Secure Cookie, display_errors, respaldos y restauración, evaluación externa y otras condiciones requieren intervención humana.
- F38: la solicitud #1 quedó APROBADA después de la decisión CFO; existen dos eventos. El módulo F39 comprueba su consistencia sin intervenirlo.

## Procedimiento de corrección recomendado

1. Reproducir el problema sobre `arca_bd_fase1` y registrar referencia en F39 o en F34 si corresponde al hallazgo de F32/F33.
2. Respaldar código, MySQL y almacén privado; redactar plan de reversión.
3. Corregir en el módulo responsable y/o en una copia de trabajo fuera de producción.
4. Ejecutar pruebas específicas, negativas y de regresión. Evidencia privada: número de caso, fecha, cuenta de prueba y resultado, sin credenciales ni PDFs sensibles.
5. Registrar `EN_VALIDACION` con referencia de evidencia; cerrar la incidencia documental solo tras verificación. Los controles automáticos tienen que actualizarse por sus propias consultas.

## Pruebas adicionales manuales

- Acceso directo prohibido a una obra clasificada SEC con usuarios sin concesión explícita.
- CSRF en acciones F34, F35, F38 y F39; no guardar solicitudes sin token válido.
- Revisión e intento de autoaprobación en F38.
- Recuperación desde un respaldo fuera de `www` hacia entorno aislado, no base activa.
- Exportación de CSV por perfil y ausencia de ejecución de fórmulas.
- Almacén documental F29 fuera de la raíz pública, integridad SHA-256, acceso mínimo a descargas.

**No adjuntar información sensible** en notas, referidos o evidencias públicas. Los registros de F39 documentan cambios, pero no sustituyen auditoría independiente.
