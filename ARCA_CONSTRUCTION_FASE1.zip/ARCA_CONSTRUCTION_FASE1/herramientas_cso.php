<?php
$arca_area = 'CSO';
require __DIR__ . '/includes/herramienta_directiva.php';
