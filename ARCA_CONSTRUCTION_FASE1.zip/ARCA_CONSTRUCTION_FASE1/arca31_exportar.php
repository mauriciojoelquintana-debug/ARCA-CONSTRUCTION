<?php
declare(strict_types=1);

// ARCA CONSTRUCTION
// FASE 31 - EXPORTACIÓN CSV COMPATIBLE CON EXCEL

require_once __DIR__ . '/includes/arca31_datos.php';

// Iniciar conexión y comprobar el perfil autorizado.
$db = a27_boot(a31_roles());

$role = arx_role();
$tipo = (string) ($_GET['tipo'] ?? 'resumen');

// Permisos de exportación según dirección ejecutiva.
if (
    !in_array($tipo, ['resumen', 'finanzas', 'ordenes'], true)
    || ($tipo === 'finanzas' && !a31_es_finanzas($role))
    || ($tipo === 'ordenes' && !a31_es_operaciones($role))
) {
    http_response_code(403);
    exit('Exportación no autorizada.');
}

try {
    // Consultar únicamente las obras autorizadas.
    $codes = a31_elegir_codigos(
        a24_obras_autorizadas($db),
        trim((string) ($_GET['obra'] ?? ''))
    );

    // Obtener información directamente de MySQL.
    $d = a31_datos($db, $codes, $role);

} catch (InvalidArgumentException | DomainException $e) {

    http_response_code(403);
    exit('No tienes acceso al filtro solicitado.');

} catch (Throwable $e) {

    error_log('[ARCA31 CSV] ' . $e->getMessage());

    http_response_code(500);
    exit('No se pudo generar el informe.');
}

// ENCABEZADOS DE DESCARGA
header('Content-Type: text/csv; charset=UTF-8');

header(
    'Content-Disposition: attachment; filename="arca_indicadores_' .
    $tipo . '_' . date('Ymd_His') . '.csv"'
);

header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

// ABRIR ARCHIVO CSV
$out = fopen('php://output', 'wb');

// Codificación UTF-8 para conservar acentos y caracteres especiales.
fwrite($out, "\xEF\xBB\xBF");

// CORRECCIÓN PERMANENTE:
// Microsoft Excel reconocerá automáticamente el punto y coma
// como separador de columnas.
fwrite($out, "sep=;\r\n");

// Función para escribir filas de manera segura.
// a31_csv_value evita la interpretación de valores como fórmulas.
$put = static function (array $row) use ($out): void {
    fputcsv(
        $out,
        array_map('a31_csv_value', $row),
        ';',
        '"',
        ''
    );
};

// INFORMACIÓN GENERAL DEL REPORTE
$put([
    'ARCA CONSTRUCTION',
    'INTELIGENCIA EMPRESARIAL',
    'SOLO LECTURA',
    'Perfil',
    $role,
    'Consulta',
    $d['consultado']
]);

$put([
    'Alcance',
    count($d['obras']) . ' obra(s)',
    'Los importes no se convierten entre monedas'
]);

// EXPORTAR RESUMEN EMPRESARIAL
if ($tipo === 'resumen') {

    $head = [
        'Código',
        'Obra',
        'Avance (%)',
        'Estado'
    ];

    if (a31_es_personal($role)) {
        $head[] = 'Asignaciones verificadas';
    }

    if (a31_es_operaciones($role)) {
        array_push(
            $head,
            'Artículos',
            'Stock bajo',
            'Órdenes emitidas'
        );
    }

    if (
        a31_es_demo($role)
        && $d['totales']['demo_aprobados'] !== null
    ) {
        $head[] = 'Aprobaciones DEMO';
    }

    $put($head);

    foreach ($d['obras'] as $w) {

        $row = [
            $w['codigo'],
            $w['nombre'],
            $w['avance'],
            $w['estado']
        ];

        if (a31_es_personal($role)) {
            $row[] = $w['personal'];
        }

        if (a31_es_operaciones($role)) {
            array_push(
                $row,
                $w['articulos'],
                $w['stock_bajo'],
                $w['ordenes']
            );
        }

        if (
            a31_es_demo($role)
            && $d['totales']['demo_aprobados'] !== null
        ) {
            $row[] = $w['demo'];
        }

        $put($row);
    }

// EXPORTAR FINANZAS
} elseif ($tipo === 'finanzas') {

    $put([
        'Divisa',
        'Módulo',
        'Estado de pago',
        'Movimientos',
        'Importe (divisa original)'
    ]);

    foreach ($d['finanzas'] as $row) {

        $put([
            a31_moneda($row['moneda']),
            $row['modulo'],
            $row['estado_pago'],
            $row['cantidad'],
            $row['importe']
        ]);
    }

// EXPORTAR ÓRDENES DE COMPRA
} else {

    $put([
        'Divisa',
        'Estado de orden',
        'Órdenes',
        'Importe (divisa original)'
    ]);

    foreach ($d['ordenes_divisa'] as $row) {

        $put([
            a31_moneda($row['moneda']),
            $row['estado'],
            $row['cantidad'],
            $row['importe']
        ]);
    }
}

// CERRAR ARCHIVO
fclose($out);
