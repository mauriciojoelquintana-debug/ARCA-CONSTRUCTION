<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca27.php';$db=a27_boot(['CEO','Director General','CIO']);
$reports=[
 'incidencias'=>['Tickets por estado',"SELECT estado AS categoria,COUNT(*) AS registros FROM soporte_tickets GROUP BY estado ORDER BY registros DESC"],
 'operacion'=>['Obras por estado de tiempo',"SELECT estado_tiempo AS categoria,COUNT(*) AS registros FROM obras_coo GROUP BY estado_tiempo ORDER BY registros DESC"],
 'usuarios'=>['Cuentas por cargo',"SELECT cargo AS categoria,COUNT(*) AS registros FROM usuarios GROUP BY cargo ORDER BY registros DESC"],
 'auditoria'=>['Eventos por módulo',"SELECT modulo AS categoria,COUNT(*) AS registros FROM arca_auditoria_modulos GROUP BY modulo ORDER BY registros DESC LIMIT 30"],
];
$key=(string)($_GET['reporte']??'incidencias');if(!isset($reports[$key]))a27_die('Reporte no permitido.',400);
$rows=arx_rows($db,$reports[$key][1]);
a27_layout('Reportes de sistemas','Informes predefinidos de solo lectura.','arca27_sql.php');
?><section class="a27-card"><div class="a27-actions"><?php foreach($reports as $k=>$d):?><a class="a27-btn <?=$key===$k?'':'secondary'?>" href="?reporte=<?=a27_h($k)?>"><?=a27_h($d[0])?></a><?php endforeach;?></div></section><section class="a27-card"><h2><?=a27_h($reports[$key][0])?></h2><p class="a27-muted">Los resultados son resumidos y no sustituyen el monitoreo de infraestructura ni la conciliación financiera.</p><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Categoría</th><th>Registros</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=a27_h($r['categoria']??'Sin clasificar')?></td><td><?= (int)$r['registros']?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="2">Sin registros.</td></tr><?php endif;?></tbody></table></div></section><?php a27_end();
