<?php
$arca_area = 'CTO';
require __DIR__ . '/includes/herramienta_directiva.php';
