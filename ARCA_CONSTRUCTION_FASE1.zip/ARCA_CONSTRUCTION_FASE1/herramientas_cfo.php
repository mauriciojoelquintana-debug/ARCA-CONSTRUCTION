<?php
// Fase 4: Gestión financiera integral sobre la tabla existente finanzas_coo.
require __DIR__ . '/includes/finanzas_arca.php';
