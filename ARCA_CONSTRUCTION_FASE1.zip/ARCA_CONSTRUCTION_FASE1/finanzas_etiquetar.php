<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_core.php';
$db=arx_boot(['CFO']); arx_check_post();
$obra=(string)($_POST['obra']??'');$url='finanzas_auditoria.php'.($obra!==''?'?obra='.rawurlencode($obra):'');
try {
    $id=arx_int($_POST['id']??null);
    $moneda=arx_currency($_POST['moneda']??'');
    $categoria=(string)($_POST['categoria_costo']??'');
    $validas=['Materiales','Mano de obra','Maquinaria','Subcontratos','Transporte','Servicios','Indirectos','Otros'];
    $db->begin_transaction();
    $row=arx_one($db,'SELECT id_finanza,modulo,moneda,categoria_costo FROM finanzas_coo WHERE id_finanza=? FOR UPDATE',[$id]);
    if(!$row) throw new InvalidArgumentException('Folio inexistente.');
    if($row['modulo']==='costos') {
        if(!in_array($categoria,$validas,true)) throw new InvalidArgumentException('Clasifica el costo antes de guardar.');
    } else $categoria='';
    $before=['moneda'=>$row['moneda'],'categoria_costo'=>$row['categoria_costo']];
    $new=['moneda'=>$moneda,'categoria_costo'=>$categoria?:null];
    if($before!==$new) {
        arx_exec($db,'UPDATE finanzas_coo SET moneda=?,categoria_costo=? WHERE id_finanza=?',[$moneda,$new['categoria_costo'],$id]);
        // Fase 4 tenía ya su propia bitácora; esta operación usa auditoría unificada.
        arx_audit($db,'CFO','finanzas_coo',$id,'CLASIFICAR',$before,$new);
    }
    $db->commit();arx_flash('Divisa/categoría guardadas para folio #'.$id.'.');
} catch(Throwable $e){try{$db->rollback();}catch(Throwable $ignored){}error_log('ARCA clasificacion: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No se guardó la clasificación.',true);}
arx_redirect($url);
