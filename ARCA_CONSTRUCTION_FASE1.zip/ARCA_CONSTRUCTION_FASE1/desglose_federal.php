<?php
/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('desglose_federal.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';

// CIBERSEGURIDAD: Solo la Alta Dirección puede ver el presupuesto del Gobierno
$roles_permitidos = ['Ejecutivo', 'Director General / CEO'];

if (!in_array($rol_limpio, $roles_permitidos)) {
    die("<div style='text-align:center; margin-top:50px; font-family:Arial;'>
            <h2 style='color:#e74c3c;'>ACCESO RESTRINGIDO - INFORMACIÓN CLASIFICADA</h2>
            <p>Las Obras Federales son confidenciales. Tu rol actual no tiene los permisos necesarios.</p>
            <a href='cerrar_sesion.php'>Cerrar sesión</a>
         </div>");
}

include("conexion.php");
// Extraemos únicamente los 5 proyectos clasificados como 'Federal'
$consulta = $conectar->query("SELECT * FROM proyectos WHERE categoria = 'Federal'");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Obras Federales - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 20px; text-align: center; }
        table { width: 90%; margin: 20px auto; border-collapse: collapse; background: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        th { background-color: #c0392b; color: white; padding: 15px; }
        td { padding: 12px; border-bottom: 1px solid #ddd; }
        tr:hover { background-color: #f2f2f2; }
        .btn-volver { display: inline-block; background: #2c3e50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 15px; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">
    <h2 style="color: #c0392b;">Desglose de Obras Federales</h2>
    <p>Auditor con autorización ejecutiva: <b><?php echo $_SESSION['usuario_activo']; ?></b></p>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre de la Obra</th>
            <th>Ubicación</th>
            <th>Presupuesto (MXN)</th>
            <th>Estado</th>
            <th>Resp.</th>
        </tr>
        <?php
        while($fila = $consulta->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $fila['id_proyecto'] . "</td>";
            echo "<td><b>" . $fila['nombre_obra'] . "</b></td>";
            echo "<td>" . $fila['ubicacion'] . "</td>";
            echo "<td style='color:#27ae60; font-weight:bold;'>$" . number_format($fila['presupuesto'], 2) . "</td>";
            echo "<td>" . $fila['estado'] . "</td>";
            echo "<td>" . $fila['numero_empleado'] . "</td>";
            echo "</tr>";
        }
        $conectar->close();
        ?>
    </table>
    <a href="panel_ejecutivo.php" class="btn-volver">← Volver al Dashboard</a>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>