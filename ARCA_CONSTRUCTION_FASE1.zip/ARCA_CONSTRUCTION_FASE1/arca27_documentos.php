<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca20.php';require_once __DIR__.'/includes/arca27.php';
$db=a20_boot();$categories=['CIMENTACION'=>'Cimentación','RENDER'=>'Render de arquitectura','ARQUITECTURA'=>'Planos arquitectónicos','INGENIERIA'=>'Ingeniería civil','BIM'=>'Modelo BIM','OTRO'=>'Otros'];
$works=a20_obras($db);$selected=(string)($_GET['obra']??($works[0]['codigo_obra']??''));
if($selected && !in_array($selected,array_column($works,'codigo_obra'),true))a27_die('Obra fuera de tus permisos.');
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 a27_post();$stored=null;
 try{
  $obra=arx_code($_POST['codigo_obra']??'');a20_require($db,$obra,'operar','planos');
  $codigo=arx_text($_POST['codigo_plano']??'',50);$titulo=arx_text($_POST['titulo_documento']??'',200);
  $category=(string)($_POST['categoria']??'');if(!isset($categories[$category]))throw new InvalidArgumentException('Categoría no válida.');
  $revision=arx_text($_POST['version_rev']??'',30);
  if(!isset($_FILES['archivo_plano']))throw new InvalidArgumentException('Adjunta un archivo.');
  $stored=a20_safe_upload($_FILES['archivo_plano']);
  $db->begin_transaction();try{
   arx_exec($db,'INSERT INTO planos_oficina_tecnica(codigo_plano,codigo_obra,especialidad_tecnica,titulo_documento,version_rev,archivo_ruta,autor_responsable,estado_revision,fecha_actualizacion) VALUES(?,?,?,?,?,?,?,?,CURDATE())',[$codigo,$obra,$categories[$category],$titulo,$revision,$stored['db'],arx_name(),'En Revisión Técnica']);
   $id=(int)$db->insert_id;
   arx_exec($db,'INSERT INTO arca27_clasificacion_plano(id_plano,categoria,cargado_por) VALUES(?,?,?)',[$id,$category,arx_uid()]);
   arx_audit($db,'oficina_tecnica','plano',$id,'CARGAR',null,['obra'=>$obra,'categoria'=>$category,'archivo'=>$stored['db']]);$db->commit();
  }catch(Throwable $e){$db->rollback();@unlink($stored['abs']);throw $e;}
  a27_alert('Documento registrado en revisión técnica.');
 }catch(Throwable $e){error_log('[ARCA27_DOCUMENTOS] '.$e->getMessage());a27_alert($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo registrar el documento.',true);}
 a27_redirect('arca27_documentos.php?obra='.rawurlencode((string)($_POST['codigo_obra']??$selected)));
}
$files=$selected?arx_rows($db,'SELECT p.id_plano,p.codigo_obra,p.codigo_plano,p.titulo_documento,p.version_rev,p.estado_revision,p.archivo_ruta,p.fecha_actualizacion,c.categoria FROM planos_oficina_tecnica p LEFT JOIN arca27_clasificacion_plano c ON c.id_plano=p.id_plano WHERE p.codigo_obra=? ORDER BY p.fecha_actualizacion DESC,p.id_plano DESC',[$selected]):[];
function a27_file_status(string $path): bool {
 if(str_starts_with($path,'privado:')){$name=substr($path,8);return (bool)preg_match('/^[a-f0-9]{36}\.(pdf|jpg|jpeg|png|dwg|rvt|ifc)$/D',$name)&&is_readable(a20_private_directory().DIRECTORY_SEPARATOR.$name);}
 if(!preg_match('~^planos_obras/[A-Za-z0-9_.-]+$~D',$path))return false;
 return is_readable(__DIR__.DIRECTORY_SEPARATOR.$path);
}
a27_layout('Repositorio de planos y renders','Cimentación, imágenes, arquitectura e ingeniería vinculadas a obra, revisión y usuario responsable.','arca27_documentos.php');
?><section class="a27-card"><form method="get" class="a27-form"><label>Obra autorizada<select name="obra"><?php foreach($works as $w):?><option value="<?=a27_h($w['codigo_obra'])?>" <?=$w['codigo_obra']===$selected?'selected':''?>><?=a27_h($w['codigo_obra'].' · '.$w['nombre_proyecto'])?></option><?php endforeach;?></select></label><button>Consultar</button></form></section>
<section class="a27-card"><h2>Documentos por obra</h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Código</th><th>Tipo</th><th>Título</th><th>Revisión</th><th>Estado</th><th>Archivo</th></tr></thead><tbody><?php foreach($files as $f):?><tr><td><?=a27_h($f['codigo_plano'])?></td><td><?=a27_h($categories[$f['categoria']??'']??$f['categoria']??'Histórico sin clasificar')?></td><td><?=a27_h($f['titulo_documento'])?></td><td><?=a27_h($f['version_rev'])?></td><td><?=a27_h($f['estado_revision'])?></td><td><?php if(a27_file_status((string)$f['archivo_ruta'])):?><a href="arca20_descargar_plano.php?id=<?=(int)$f['id_plano']?>">Descargar protegido</a><?php else:?><span class="a27-label warn">Archivo faltante · requiere reposición</span><?php endif;?></td></tr><?php endforeach;?><?php if(!$files):?><tr><td colspan="6">Aún no se han cargado documentos para esta obra.</td></tr><?php endif;?></tbody></table></div><p class="a27-muted">Las rutas antiguas apuntan a archivos que quizá no están físicamente en el servidor. No se crean planos de muestra ni enlaces ficticios: se requiere subir la revisión real.</p></section>
<?php if($selected&&a20_can($db,$selected,'operar','planos')):?><section class="a27-card"><h2>Cargar plano de cimentación, render o modelo</h2><form method="post" enctype="multipart/form-data" class="a27-form"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="codigo_obra" value="<?=a27_h($selected)?>"><label>Tipo de documento<select name="categoria"><?php a27_opt($categories);?></select></label><label>Código único<input name="codigo_plano" required maxlength="50"></label><label>Revisión<input name="version_rev" value="Rev. 1.0" required></label><label class="a27-wide">Título del documento<input name="titulo_documento" maxlength="200" required></label><label class="a27-wide">Archivo (PDF, JPG, PNG, DWG, RVT, IFC; máx. 25 MB)<input type="file" name="archivo_plano" accept=".pdf,.png,.jpg,.jpeg,.dwg,.rvt,.ifc" required></label><button>Registrar versión en revisión</button></form><p class="a27-sub">La carga se guarda fuera del directorio público. El documento no queda aprobado automáticamente; debe revisarlo el responsable técnico.</p></section><?php endif; a27_end();
