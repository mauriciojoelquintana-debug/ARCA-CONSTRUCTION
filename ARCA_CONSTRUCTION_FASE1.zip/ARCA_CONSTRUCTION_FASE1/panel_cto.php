<?php
// ARCA CONSTRUCTION · Fase 2, dirección CTO.
$arca_area = 'CTO';
require __DIR__ . '/includes/panel_directivo.php';
