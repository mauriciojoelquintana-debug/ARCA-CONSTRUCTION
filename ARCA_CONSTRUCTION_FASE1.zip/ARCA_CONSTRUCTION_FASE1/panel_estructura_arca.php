<?php
session_start();
if (!isset($_SESSION['rol_activo'])) {
    header("Location: ingreso.html");
    exit();
}
include("conexion.php");

$obra_sesion  = $_SESSION['obra_asignada'] ?? 'ARCA-PUB-01';
$nivel_sesion = $_SESSION['nivel_jerarquico'] ?? 'Nivel 4';
$rol_sesion   = $_SESSION['rol_activo'] ?? 'Especialista';

// Validamos quién tiene permiso de GESTIONAR asignaciones según la Sección 9 del documento (Niveles 0, 1, 2 y 3)
$puede_gestionar = in_array($nivel_sesion, ['Nivel 0', 'Nivel 1', 'Nivel 2', 'Nivel 3']);

$mensaje_alerta = "";

// PROCESAMIENTO DEL FORMULARIO POST PARA NUEVA ASIGNACIÓN A OBRA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'asignar_personal' && $puede_gestionar) {
    $num_emp     = $conectar->real_escape_string(trim($_POST['num_empleado']));
    $nombre      = $conectar->real_escape_string(trim($_POST['nombre_personal']));
    $puesto      = $conectar->real_escape_string(trim($_POST['puesto_cargo']));
    $nivel       = $conectar->real_escape_string(trim($_POST['nivel_jerarquico']));
    $dependencia = $conectar->real_escape_string(trim($_POST['dependencia_organizacional']));
    $obra_dest   = $conectar->real_escape_string(trim($_POST['obra_asignada']));
    $rama_obra   = $conectar->real_escape_string(trim($_POST['area_dentro_obra']));
    $cuadrilla   = $conectar->real_escape_string(trim($_POST['frente_cuadrilla']));
    $tipo_cont   = $conectar->real_escape_string(trim($_POST['tipo_contratacion']));

    if (!empty($num_emp) && !empty($nombre) && !empty($puesto)) {
        $sql_insert = "INSERT INTO asignaciones_obra_arca 
            (num_empleado, nombre_personal, puesto_cargo, nivel_jerarquico, dependencia_organizacional, obra_asignada, area_dentro_obra, frente_cuadrilla, tipo_contratacion)
            VALUES ('$num_emp', '$nombre', '$puesto', '$nivel', '$dependencia', '$obra_dest', '$rama_obra', '$cuadrilla', '$tipo_cont')";
        
        if ($conectar->query($sql_insert)) {
            $mensaje_alerta = "✅ Asignación registrada correctamente en la obra $obra_dest ($rama_obra).";
        } else {
            $mensaje_alerta = "⚠️ Error al guardar la asignación: " . $conectar->error;
        }
    }
}

// ELIMINAR O LIBERAR ASIGNACIÓN (Solo Niveles 0, 1, 2 y 3)
if (isset($_GET['eliminar']) && $puede_gestionar) {
    $id_borrar = intval($_GET['eliminar']);
    $conectar->query("DELETE FROM asignaciones_obra_arca WHERE id_asignacion = $id_borrar");
    header("Location: panel_estructura_arca.php");
    exit();
}

// PARÁMETROS DE FILTRADO Y BÚSQUEDA
$filtro_obra = isset($_GET['obra']) ? $conectar->real_escape_string($_GET['obra']) : ($puede_gestionar ? 'TODAS' : $obra_sesion);
$filtro_rama = isset($_GET['rama']) ? $conectar->real_escape_string($_GET['rama']) : 'TODAS';
$filtro_tipo = isset($_GET['tipo']) ? $conectar->real_escape_string($_GET['tipo']) : 'TODOS';
$busqueda    = isset($_GET['q']) ? $conectar->real_escape_string(trim($_GET['q'])) : '';

// Construcción dinámica de la consulta SQL
$condiciones = [];

// Si el empleado es Nivel 4 o 5, solo ve su obra asignada (a menos que sea soporte corporativo)
if (!$puede_gestionar && $obra_sesion !== 'CORPORATIVO' && strpos($obra_sesion, 'GLOBAL') === false) {
    $condiciones[] = "obra_asignada LIKE '%$obra_sesion%'";
} elseif ($filtro_obra !== 'TODAS') {
    $condiciones[] = "obra_asignada LIKE '%$filtro_obra%'";
}

if ($filtro_rama !== 'TODAS') {
    $condiciones[] = "area_dentro_obra = '$filtro_rama'";
}
if ($filtro_tipo !== 'TODOS') {
    $condiciones[] = "tipo_contratacion = '$filtro_tipo'";
}
if (!empty($busqueda)) {
    $condiciones[] = "(nombre_personal LIKE '%$busqueda%' OR num_empleado LIKE '%$busqueda%' OR puesto_cargo LIKE '%$busqueda%' OR frente_cuadrilla LIKE '%$busqueda%' OR dependencia_organizacional LIKE '%$busqueda%')";
}

$where_sql = count($condiciones) > 0 ? "WHERE " . implode(" AND ", $condiciones) : "";
$q_equipo  = $conectar->query("SELECT * FROM asignaciones_obra_arca $where_sql ORDER BY area_dentro_obra ASC, nivel_jerarquico ASC");

// Contadores rápidos por cada una de las 6 ramas
$conteos_ramas = [
    '6.1 Producción y Construcción' => 0,
    '6.2 Oficina Técnica de Obra' => 0,
    '6.3 Planeación, Costos y Control' => 0,
    '6.4 Calidad y Seguridad Laboral' => 0,
    '6.5 Materiales, Almacén y Maquinaria' => 0,
    '6.6 Administración y Servicios de Obra' => 0
];
$q_count = $conectar->query("SELECT area_dentro_obra, COUNT(*) as total FROM asignaciones_obra_arca GROUP BY area_dentro_obra");
if ($q_count) {
    while ($c = $q_count->fetch_assoc()) {
        if (isset($conteos_ramas[$c['area_dentro_obra']])) {
            $conteos_ramas[$c['area_dentro_obra']] = $c['total'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión Operativa de Obra - ARCA CONSTRUCTION</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #070b14; color: #e2e8f0; margin: 0; padding: 25px 35px; }
        
        /* CABECERA */
        .header {
            display: flex; justify-content: space-between; align-items: center;
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%);
            padding: 20px 28px; border-radius: 12px; border: 1px solid #334155; margin-bottom: 25px;
        }
        .badge { background: #f59e0b; color: #000; padding: 4px 10px; border-radius: 4px; font-weight: bold; font-size: 12px; display: inline-block; }
        .btn-logout { background: #dc2626; color: #fff; text-decoration: none; padding: 10px 18px; border-radius: 6px; font-weight: bold; font-size: 13px; transition: 0.2s; }
        .btn-logout:hover { background: #b91c1c; }
        .btn-ceo { background: #2563eb; color: #fff; text-decoration: none; padding: 10px 18px; border-radius: 6px; font-weight: bold; font-size: 13px; margin-right: 10px; }

        /* ALERTA DE CONFIRMACIÓN */
        .alert-box { background: #064e3b; border: 1px solid #10b981; color: #a7f3d0; padding: 14px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; }

        /* TARJETAS INTERACTIVAS DE LAS 6 RAMAS DE OBRA */
        .seis-areas-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .area-card {
            background: #0f172a; border: 1px solid #1e293b; border-top: 3px solid #3b82f6;
            border-radius: 10px; padding: 16px 20px; text-decoration: none; color: inherit;
            transition: 0.2s; display: block;
        }
        .area-card:hover, .area-card.active-card {
            border-color: #f59e0b; border-top-color: #f59e0b; background: #131c31; transform: translateY(-2px);
        }
        .area-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .area-top h3 { margin: 0; font-size: 15px; color: #60a5fa; }
        .area-count { background: #1e293b; color: #f8fafc; font-size: 11px; font-weight: bold; padding: 3px 9px; border-radius: 12px; }
        .area-card p { margin: 0; font-size: 12px; color: #94a3b8; line-height: 1.45; }

        /* BARRA DE FILTROS Y BUSCADOR */
        .filter-bar {
            background: #0f172a; border: 1px solid #1e293b; border-radius: 10px;
            padding: 18px 20px; margin-bottom: 25px; display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end;
        }
        .filter-group { display: flex; flex-direction: column; gap: 5px; flex: 1; min-width: 170px; }
        .filter-group label { font-size: 11px; color: #94a3b8; font-weight: bold; text-transform: uppercase; }
        .filter-group input, .filter-group select {
            background: #1e293b; border: 1px solid #334155; color: #f8fafc;
            padding: 9px 12px; border-radius: 6px; font-size: 13px;
        }
        .btn-filtrar { background: #3b82f6; color: #fff; border: none; padding: 10px 20px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 13px; }
        .btn-filtrar:hover { background: #2563eb; }
        .btn-limpiar { background: #334155; color: #cbd5e1; text-decoration: none; padding: 10px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; }

        /* PANEL DE ASIGNACIÓN DINÁMICA (SOLO NIVELES 0 AL 3) */
        .form-panel {
            background: #0f172a; border: 1px solid #1e3a8a; border-left: 4px solid #f59e0b;
            border-radius: 10px; padding: 22px; margin-bottom: 30px;
        }
        .form-panel h3 { margin: 0 0 15px 0; font-size: 16px; color: #f8fafc; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; }
        .btn-guardar {
            background: #10b981; color: #000; border: none; padding: 11px 24px;
            border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 13px; margin-top: 15px;
        }
        .btn-guardar:hover { background: #059669; color: #fff; }

        /* TABLA DE RESULTADOS */
        .table-container { background: #0f172a; border: 1px solid #1e293b; border-radius: 10px; overflow: hidden; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { background: #1e293b; color: #93c5fd; padding: 13px 15px; text-align: left; }
        td { padding: 12px 15px; border-bottom: 1px solid #1e293b; color: #cbd5e1; }
        tr:hover td { background: #131c31; }
        .tag-arca { background: #064e3b; color: #34d399; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .tag-sub { background: #78350f; color: #fcd34d; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .btn-del { color: #ef4444; text-decoration: none; font-weight: bold; font-size: 12px; }
        .btn-del:hover { text-decoration: underline; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <div>
            <span class="badge"><?php echo $nivel_sesion; ?> • <?php echo $rol_sesion; ?></span>
            <h1 style="margin: 8px 0 4px 0; font-size: 22px; color: #fff;">Control Organizacional y Frentes de Obra — <?php echo $_SESSION['nombre_usuario']; ?></h1>
            <span style="color: #94a3b8; font-size: 13px;">
                Dependencia Corporativa: <b style="color:#93c5fd;"><?php echo $_SESSION['direccion_area'] ?? 'Operaciones'; ?></b> |
                Asignación Operativa: <b style="color: #34d399;"><?php echo $obra_sesion; ?></b>
            </span>
        </div>
        <div>
            <?php if ($rol_sesion === 'CEO' || $rol_sesion === 'Director General') { ?>
                <a href="panel_ceo.php" class="btn-ceo">← Volver a Gobierno Corporativo</a>
            <?php } ?>
            <a href="cerrar_sesion.php" class="btn-logout">Cerrar Sesión</a>
        </div>
    </div>

    <?php if (!empty($mensaje_alerta)) { ?>
        <div class="alert-box"><?php echo $mensaje_alerta; ?></div>
    <?php } ?>

    <!-- 1. TARJETAS FILTRO DE LAS 6 ÁREAS PRINCIPALES DE UNA OBRA (SECCIÓN 6 DEL DOCUMENTO) -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h2 style="font-size: 17px; color: #f8fafc; margin: 0;">1. Las 6 Ramas Operativas de la Obra (Haz clic en una tarjeta para filtrar su plantilla)</h2>
        <a href="panel_estructura_arca.php" style="color:#60a5fa; font-size:13px; text-decoration:none;">Ver todas las ramas (<?php echo array_sum($conteos_ramas); ?> registros)</a>
    </div>

    <div class="seis-areas-grid">
        <a href="?rama=<?php echo urlencode('6.1 Producción y Construcción'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.1 Producción y Construcción') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.1 Producción y Construcción</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.1 Producción y Construcción']; ?> asignados</span>
            </div>
            <p>Residente → Jefes de Frente → Supervisores → Maestros de Obra → 7 Cuadrillas (Obra civil, Estructuras, Eléctricas, Hidrosanitarias, Especiales, Acabados, Urbanización).</p>
        </a>

        <a href="?rama=<?php echo urlencode('6.2 Oficina Técnica de Obra'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.2 Oficina Técnica de Obra') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.2 Oficina Técnica de Obra</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.2 Oficina Técnica de Obra']; ?> asignados</span>
            </div>
            <p>Jefe de Oficina Técnica → Coordinadores de Ingeniería (Civil, Estructural, Instalaciones), Arquitectura (CAD), Modelado BIM y Topografía.</p>
        </a>

        <a href="?rama=<?php echo urlencode('6.3 Planeación, Costos y Control'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.3 Planeación, Costos y Control') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.3 Planeación, Costos y Control</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.3 Planeación, Costos y Control']; ?> asignados</span>
            </div>
            <p>Coordinador de Planeación → Planificador, Programador, Ingeniero de Costos, Analista de Avances, Estimador y Cuantificador.</p>
        </a>

        <a href="?rama=<?php echo urlencode('6.4 Calidad y Seguridad Laboral'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.4 Calidad y Seguridad Laboral') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.4 Calidad y Seguridad (SST/HSE)</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.4 Calidad y Seguridad Laboral']; ?> asignados</span>
            </div>
            <p>Responsable de Calidad (Inspectores, Laboratorio de Materiales) y Responsable SST/HSE (Supervisores SST, Prevención y Emergencias).</p>
        </a>

        <a href="?rama=<?php echo urlencode('6.5 Materiales, Almacén y Maquinaria'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.5 Materiales, Almacén y Maquinaria') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.5 Materiales, Almacén y Maquinaria</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.5 Materiales, Almacén y Maquinaria']; ?> asignados</span>
            </div>
            <p>Responsable de Almacén (Almacenistas, Despacho), Coordinador de Logística (Choferes) y Responsable de Maquinaria (Operadores y Mecánicos).</p>
        </a>

        <a href="?rama=<?php echo urlencode('6.6 Administración y Servicios de Obra'); ?>&obra=<?php echo urlencode($filtro_obra); ?>" class="area-card <?php echo ($filtro_rama === '6.6 Administración y Servicios de Obra') ? 'active-card' : ''; ?>">
            <div class="area-top">
                <h3>6.6 Administración y Servicios</h3>
                <span class="area-count"><?php echo $conteos_ramas['6.6 Administración y Servicios de Obra']; ?> asignados</span>
            </div>
            <p>Administrador de Obra, Enlace de RH en Obra (CHRO), Controlador Documental, Soporte TI de Obra (CIO) y Seguridad Patrimonial.</p>
        </a>
    </div>

    <!-- 2. FORMULARIO DINÁMICO DE ASIGNACIÓN DE PERSONAL / CUADRILLAS (SOLO NIVELES 0, 1, 2 Y 3) -->
    <?php if ($puede_gestionar) { ?>
    <div class="form-panel">
        <h3>➕ Asignar Especialista, Cuadrilla o Subcontratista a Obra (Permiso de Gestión Activo: <?php echo $nivel_sesion; ?>)</h3>
        <form method="POST" action="panel_estructura_arca.php">
            <input type="hidden" name="accion" value="asignar_personal">
            <div class="form-grid">
                <div class="filter-group">
                    <label>ID Empleado / Subcontrato</label>
                    <input type="text" name="num_empleado" placeholder="Ej. CUA-015 o SUB-009" required>
                </div>
                <div class="filter-group">
                    <label>Nombre o Empresa Contratista</label>
                    <input type="text" name="nombre_personal" placeholder="Ej. Ing. Luis Mora / AceroMex SA" required>
                </div>
                <div class="filter-group">
                    <label>Puesto / Cargo en Obra</label>
                    <input type="text" name="puesto_cargo" placeholder="Ej. Jefe de Estructuras / Maestro" required>
                </div>
                <div class="filter-group">
                    <label>Nivel Jerárquico</label>
                    <select name="nivel_jerarquico">
                        <option value="Nivel 2">Nivel 2 — Gerencia</option>
                        <option value="Nivel 3">Nivel 3 — Jefatura / Coordinación</option>
                        <option value="Nivel 4" selected>Nivel 4 — Supervisor / Especialista</option>
                        <option value="Nivel 5">Nivel 5 — Técnico / Maestro / Operativo</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Dependencia Organizacional (Corporativo)</label>
                    <select name="dependencia_organizacional">
                        <option value="COO -> Dirección de Construcción">COO -> Dirección de Construcción</option>
                        <option value="COO -> Ingeniería y Soporte Técnico">COO -> Ingeniería y Soporte Técnico</option>
                        <option value="COO -> Planeación y Control de Proyectos">COO -> Planeación y Control de Proyectos</option>
                        <option value="COO -> Gerencia Control de Calidad">COO -> Gerencia Control de Calidad</option>
                        <option value="COO -> Gerencia SST / HSE">COO -> Gerencia SST / HSE</option>
                        <option value="COO -> Gerencia Almacenes y Logística">COO -> Gerencia Almacenes y Logística</option>
                        <option value="COO -> Gerencia Maquinaria y Mantenimiento">COO -> Gerencia Maquinaria y Mantenimiento</option>
                        <option value="COO -> Compras y Subcontratación">COO -> Compras y Subcontratación</option>
                        <option value="CTO -> Gerencia BIM y Modelado Digital">CTO -> Gerencia BIM y Modelado Digital</option>
                        <option value="CIO -> Gerencia de Soporte Técnico">CIO -> Gerencia de Soporte Técnico</option>
                        <option value="CFO -> Costos y Presupuestos">CFO -> Costos y Presupuestos</option>
                        <option value="CHRO -> Administración de Personal">CHRO -> Administración de Personal</option>
                        <option value="Apoyo -> Seguridad Patrimonial">Apoyo -> Seguridad Patrimonial</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Asignación Operativa (10 Obras)</label>
                    <select name="obra_asignada">
                        <option value="ARCA-PUB-01">ARCA-PUB-01 — Torre ARCA 1</option>
                        <option value="ARCA-PUB-02">ARCA-PUB-02 — Residencial Norte</option>
                        <option value="ARCA-PUB-03">ARCA-PUB-03 — Plaza Comercial Puebla</option>
                        <option value="ARCA-PUB-04">ARCA-PUB-04 — Edificio Corporativo Sur</option>
                        <option value="ARCA-PUB-05">ARCA-PUB-05 — Ampliación Puerto Manzanillo</option>
                        <option value="ARCA-SEC-06">ARCA-SEC-06 — [CONFIDENCIAL] Base Aérea V</option>
                        <option value="ARCA-SEC-07">ARCA-SEC-07 — [CONFIDENCIAL] Hospital Federal S-9</option>
                        <option value="ARCA-SEC-08">ARCA-SEC-08 — [CONFIDENCIAL] Búnker CNI</option>
                        <option value="ARCA-SEC-09">ARCA-SEC-09 — [CONFIDENCIAL] Red C5</option>
                        <option value="ARCA-SEC-10">ARCA-SEC-10 — [CONFIDENCIAL] Puente Fronterizo</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Rama dentro de la Obra (6 Áreas)</label>
                    <select name="area_dentro_obra">
                        <option value="6.1 Producción y Construcción">6.1 Producción y Construcción</option>
                        <option value="6.2 Oficina Técnica de Obra">6.2 Oficina Técnica de Obra</option>
                        <option value="6.3 Planeación, Costos y Control">6.3 Planeación, Costos y Control</option>
                        <option value="6.4 Calidad y Seguridad Laboral">6.4 Calidad y Seguridad Laboral</option>
                        <option value="6.5 Materiales, Almacén y Maquinaria">6.5 Materiales, Almacén y Maquinaria</option>
                        <option value="6.6 Administración y Servicios de Obra">6.6 Administración y Servicios de Obra</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Frente de Trabajo / Cuadrilla Específica</label>
                    <select name="frente_cuadrilla">
                        <option value="Obra civil y cimentación (Albañiles y excavadores)">Cuadrilla 1: Obra civil y cimentación</option>
                        <option value="Estructuras (Fierreros, armadores y soldadores)">Cuadrilla 2: Estructuras metálicas y concreto</option>
                        <option value="Instalaciones eléctricas (Electricistas e instaladores)">Cuadrilla 3: Instalaciones eléctricas</option>
                        <option value="Instalaciones hidrosanitarias (Plomeros y tuberos)">Cuadrilla 4: Instalaciones hidrosanitarias</option>
                        <option value="Instalaciones especiales (HVAC, contra incendio, voz y datos)">Cuadrilla 5: Instalaciones especiales (HVAC/IoT)</option>
                        <option value="Acabados (Yeseros, pintores, pisos y carpinteros)">Cuadrilla 6: Acabados e interiores</option>
                        <option value="Urbanización y exteriores (Pavimentación y jardinería)">Cuadrilla 7: Urbanización y exteriores</option>
                        <option value="Coordinación de Ingeniería, Planos CAD y BIM">Oficina Técnica: Planos CAD / Modelos BIM</option>
                        <option value="Control Presupuestal, Cronograma y Estimaciones">Planeación: Costos, Avances y Estimaciones</option>
                        <option value="Inspección de Calidad y Prevención SST/HSE">Calidad y SST: Laboratorio y Seguridad</option>
                        <option value="Recepción de Materiales y Operación de Maquinaria">Logística: Almacén y Maquinaria Pesada</option>
                        <option value="Asistencia RH, Control Documental y Soporte TI">Administración: RH, Documentos y TI</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Vínculo Laboral</label>
                    <select name="tipo_contratacion">
                        <option value="Planta ARCA">Planta ARCA (Empleado Interno)</option>
                        <option value="Subcontratista Autorizado">Subcontratista Autorizado (Externo)</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn-guardar">Registrar Asignación en Base de Datos</button>
        </form>
    </div>
    <?php } ?>

    <!-- 3. BUSCADOR Y FILTROS MULTICRITERIO -->
    <form method="GET" action="panel_estructura_arca.php" class="filter-bar">
        <div class="filter-group" style="flex: 2;">
            <label>🔍 Buscar por Nombre, ID, Cargo o Cuadrilla</label>
            <input type="text" name="q" value="<?php echo htmlspecialchars($busqueda); ?>" placeholder="Ej. Fierreros, BIM, HVAC, Soto, Subcontratista...">
        </div>

        <div class="filter-group">
            <label>🏗️ Filtrar por Obra</label>
            <select name="obra">
                <option value="TODAS" <?php echo ($filtro_obra === 'TODAS') ? 'selected' : ''; ?>>Todas las Obras Autorizadas</option>
                <option value="ARCA-PUB-01" <?php echo ($filtro_obra === 'ARCA-PUB-01') ? 'selected' : ''; ?>>ARCA-PUB-01 (Torre ARCA 1)</option>
                <option value="ARCA-PUB-02" <?php echo ($filtro_obra === 'ARCA-PUB-02') ? 'selected' : ''; ?>>ARCA-PUB-02 (Residencial Norte)</option>
                <option value="ARCA-PUB-03" <?php echo ($filtro_obra === 'ARCA-PUB-03') ? 'selected' : ''; ?>>ARCA-PUB-03 (Plaza Puebla)</option>
                <option value="ARCA-PUB-04" <?php echo ($filtro_obra === 'ARCA-PUB-04') ? 'selected' : ''; ?>>ARCA-PUB-04 (Corporativo Sur)</option>
                <option value="ARCA-PUB-05" <?php echo ($filtro_obra === 'ARCA-PUB-05') ? 'selected' : ''; ?>>ARCA-PUB-05 (Puerto Manzanillo)</option>
                <option value="ARCA-SEC-06" <?php echo ($filtro_obra === 'ARCA-SEC-06') ? 'selected' : ''; ?>>ARCA-SEC-06 (Base Aérea V)</option>
                <option value="ARCA-SEC-07" <?php echo ($filtro_obra === 'ARCA-SEC-07') ? 'selected' : ''; ?>>ARCA-SEC-07 (Hospital Federal)</option>
                <option value="ARCA-SEC-08" <?php echo ($filtro_obra === 'ARCA-SEC-08') ? 'selected' : ''; ?>>ARCA-SEC-08 (Búnker CNI)</option>
                <option value="ARCA-SEC-09" <?php echo ($filtro_obra === 'ARCA-SEC-09') ? 'selected' : ''; ?>>ARCA-SEC-09 (Red C5)</option>
                <option value="ARCA-SEC-10" <?php echo ($filtro_obra === 'ARCA-SEC-10') ? 'selected' : ''; ?>>ARCA-SEC-10 (Puente Fronterizo)</option>
            </select>
        </div>

        <div class="filter-group">
            <label>📂 Filtrar por Rama de Obra</label>
            <select name="rama">
                <option value="TODAS" <?php echo ($filtro_rama === 'TODAS') ? 'selected' : ''; ?>>Todas las 6 Ramas</option>
                <option value="6.1 Producción y Construcción" <?php echo ($filtro_rama === '6.1 Producción y Construcción') ? 'selected' : ''; ?>>6.1 Producción y Construcción</option>
                <option value="6.2 Oficina Técnica de Obra" <?php echo ($filtro_rama === '6.2 Oficina Técnica de Obra') ? 'selected' : ''; ?>>6.2 Oficina Técnica de Obra</option>
                <option value="6.3 Planeación, Costos y Control" <?php echo ($filtro_rama === '6.3 Planeación, Costos y Control') ? 'selected' : ''; ?>>6.3 Planeación, Costos y Control</option>
                <option value="6.4 Calidad y Seguridad Laboral" <?php echo ($filtro_rama === '6.4 Calidad y Seguridad Laboral') ? 'selected' : ''; ?>>6.4 Calidad y Seguridad Laboral</option>
                <option value="6.5 Materiales, Almacén y Maquinaria" <?php echo ($filtro_rama === '6.5 Materiales, Almacén y Maquinaria') ? 'selected' : ''; ?>>6.5 Materiales, Almacén y Maquinaria</option>
                <option value="6.6 Administración y Servicios de Obra" <?php echo ($filtro_rama === '6.6 Administración y Servicios de Obra') ? 'selected' : ''; ?>>6.6 Administración y Servicios</option>
            </select>
        </div>

        <div class="filter-group">
            <label>🤝 Tipo de Personal</label>
            <select name="tipo">
                <option value="TODOS" <?php echo ($filtro_tipo === 'TODOS') ? 'selected' : ''; ?>>Planta ARCA + Subcontratistas</option>
                <option value="Planta ARCA" <?php echo ($filtro_tipo === 'Planta ARCA') ? 'selected' : ''; ?>>Solo Planta ARCA</option>
                <option value="Subcontratista Autorizado" <?php echo ($filtro_tipo === 'Subcontratista Autorizado') ? 'selected' : ''; ?>>Solo Subcontratistas</option>
            </select>
        </div>

        <button type="submit" class="btn-filtrar">Aplicar Filtros</button>
        <a href="panel_estructura_arca.php" class="btn-limpiar">Limpiar</a>
    </form>

    <!-- 4. TABLA DE RELACIÓN: DEPENDENCIA ORGANIZACIONAL VS ASIGNACIÓN EN OBRA -->
    <div class="table-container">
        <table>
            <tr>
                <th>ID / Personal o Contratista</th>
                <th>Cargo y Nivel Jerárquico</th>
                <th>Dependencia Organizacional (Corporativo)</th>
                <th>Obra Asignada</th>
                <th>Rama de la Obra (Sección 6)</th>
                <th>Frente de Trabajo / Cuadrilla</th>
                <th>Vínculo</th>
                <?php if ($puede_gestionar) { echo "<th>Acción</th>"; } ?>
            </tr>
            <?php if ($q_equipo && $q_equipo->num_rows > 0) {
                while ($row = $q_equipo->fetch_assoc()) {
                    $clase_tag = ($row['tipo_contratacion'] === 'Planta ARCA') ? 'tag-arca' : 'tag-sub';
            ?>
            <tr>
                <td>
                    <b style="color: #fff;"><?php echo $row['nombre_personal']; ?></b><br>
                    <span style="font-size: 11px; color: #64748b; font-family: monospace;"><?php echo $row['num_empleado']; ?></span>
                </td>
                <td>
                    <?php echo $row['puesto_cargo']; ?><br>
                    <span style="font-size: 11px; color: #f59e0b; font-weight: bold;"><?php echo $row['nivel_jerarquico']; ?></span>
                </td>
                <td style="color: #93c5fd;"><?php echo $row['dependencia_organizacional']; ?></td>
                <td><b style="color: #34d399;"><?php echo $row['obra_asignada']; ?></b></td>
                <td style="color: #f8fafc; font-weight: 600;"><?php echo $row['area_dentro_obra']; ?></td>
                <td><?php echo $row['frente_cuadrilla']; ?></td>
                <td><span class="<?php echo $clase_tag; ?>"><?php echo $row['tipo_contratacion']; ?></span></td>
                <?php if ($puede_gestionar) { ?>
                    <td><a href="?eliminar=<?php echo $row['id_asignacion']; ?>" class="btn-del" onclick="return confirm('¿Liberar a este personal del frente de obra?');">Liberar</a></td>
                <?php } ?>
            </tr>
            <?php } } else { ?>
            <tr>
                <td colspan="8" style="text-align: center; padding: 30px; color: #94a3b8;">
                    No se encontraron registros para los filtros seleccionados.
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>