<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca39_datos.php';
$db=a27_boot(a39_roles()); // Diagnóstico transversal solo para CEO, no para direcciones sectoriales.
$report=null;$error='';
try{$report=a39_panoramica($db,__DIR__);}catch(Throwable $e){error_log('[ARCA39 PANEL] '.$e->getMessage());$error='No fue posible completar el seguimiento. Comunícate con el área de Sistemas.';}
a27_layout('Centro de validación y calidad','Integridad, seguimiento de incidencias y control de acciones correctivas.','arca39_validacion.php');
?>
<link rel="stylesheet" href="assets/css/arca39.css?v=1">
<div class="v39-banner"><strong>SEGUIMIENTO DE CALIDAD Y CUMPLIMIENTO</strong><p>Consulta el estado de las verificaciones y registra las acciones correctivas. Las incidencias se documentan con trazabilidad; los procesos de personal, finanzas y operaciones conservan sus controles de autorización.</p></div>
<div class="v39-links"><a href="arca32_auditoria.php">Auditoría integral</a><a href="arca33_preparacion.php">Configuración operativa</a><a href="arca34_calidad.php">Seguimiento de calidad</a><a href="arca35_pruebas.php">Verificación operativa</a><a href="arca36_infraestructura.php">Infraestructura</a><a href="arca38_flujos.php">Flujos de revisión</a><a href="arca39_exportar.php">Exportar resumen CSV</a></div>
<?php if($error):?><div class="v39-error" role="alert"><?=a27_h($error)?></div><?php else:$tests=$report['pruebas'];$f38=$report['f38'];$gate=$report['puerta'];?>
<div class="v39-metrics">
 <article><span>Observaciones de auditoría</span><strong><?=$gate['f32']?></strong></article>
 <article><span>Validaciones de infraestructura</span><strong><?=$gate['f33']?></strong></article>
 <article><span>Verificaciones completadas</span><strong><?=$tests['aprobadas']?> / <?=$tests['total']?></strong></article>
 <article><span>Inconsistencias en solicitudes</span><strong><?=$f38['errores']?></strong></article>
 <article><span>Incidencias abiertas</span><strong><?=$report['pendientes_f39']?></strong></article>
</div>
<section class="v39-card"><h2>Estado de habilitación operativa</h2>
<p class="v39-error"><strong><?= $gate['sin_bloqueos_detectados'] && $report['sql_ok'] ? 'REVISIÓN FINAL REQUERIDA' : 'LIBERACIÓN PENDIENTE DE VALIDACIONES' ?></strong>. La habilitación de un entorno operativo requiere controles de acceso, recuperación de respaldos, transporte seguro y revisión independiente. Las observaciones abiertas no deben darse por resueltas sin evidencia.</p>
<?php if(!$report['sql_ok']):?><p class="v39-error">El registro de incidencias no está disponible. Comunícate con el área de Sistemas.</p><?php endif;?>
<ul>
<?php if((int)$gate['f32']>0):?><li>Auditoría: <?= (int)$gate['f32'] ?> controles requieren atención.</li><?php endif;?>
<?php if((int)$gate['f33']>0):?><li>Infraestructura: <?= (int)$gate['f33'] ?> controles requieren atención.</li><?php endif;?>
<?php if((int)$tests['sin_aprobar']>0):?><li>Verificación operativa: <?= (int)$tests['sin_aprobar'] ?> controles aún no acreditados.</li><?php endif;?>
<?php if(!$f38['completa']):?><li>La revisión del historial de solicitudes aún no cubre todo el alcance.</li><?php endif;?>
<?php if((int)$f38['errores']>0):?><li>Solicitudes: <?= (int)$f38['errores'] ?> inconsistencias detectadas.</li><?php endif;?>
<?php if((int)$report['pendientes_f39']>0):?><li>Incidencias abiertas: <?= (int)$report['pendientes_f39'] ?>.</li><?php endif;?>
</ul>
<?php if($gate['sin_bloqueos_detectados'] && $report['sql_ok']):?><p>Los controles automáticos revisados no presentan bloqueos; continúa pendiente la autorización humana de seguridad y continuidad.</p><?php endif;?>
</section>
<section class="v39-card"><h2>Trazabilidad de solicitudes y decisiones</h2><p>Se comprueba la correspondencia entre cada solicitud y su historial: registro inicial, cambios de estado, revisión por una persona distinta del solicitante y estado vigente.</p>
<div class="v39-meta"><span>Solicitudes revisadas: <strong><?=$f38['total']?></strong></span><span>Eventos: <strong><?=$f38['eventos']?></strong></span><span>Alcance: <strong><?=$f38['completa']?'Cobertura de consulta completa (máx. 500)':'Cobertura parcial o no disponible'?></strong></span></div>
<?php if($f38['hallazgos']):?><ul><?php foreach($f38['hallazgos'] as $x):?><li><?=a27_h($x)?></li><?php endforeach;?></ul><?php else:?><p>No se detectaron diferencias en los registros consultados. La revisión de seguridad independiente se gestiona por separado.</p><?php endif;?></section>
<section class="v39-card"><h2>Observaciones de auditoría e infraestructura</h2><p>Los resultados se actualizan desde los controles de cada área. Una observación se mantiene hasta que la condición que la originó haya sido verificada y corregida.</p>
<div class="v39-scroll"><table class="v39-table"><thead><tr><th>Origen</th><th>Área</th><th>Control</th><th>Estado automático</th><th>Acción recomendada</th></tr></thead><tbody>
<?php foreach($report['f32'] as $r):if($r['estado']==='OK')continue;?><tr><td>Auditoría</td><td><?=a27_h($r['modulo'])?></td><td><?=a27_h($r['control'])?></td><td><span class="v39-tag"><?=a27_h($r['estado'])?></span></td><td><?=a27_h($r['accion'])?></td></tr><?php endforeach;?>
<?php foreach($report['f33'] as $r):if($r['estado']==='OK')continue;?><tr><td>Infraestructura</td><td><?=a27_h($r['area'])?></td><td><?=a27_h($r['nombre'])?></td><td><span class="v39-tag"><?=a27_h($r['estado'])?></span></td><td><?=a27_h($r['accion'])?></td></tr><?php endforeach;?>
</tbody></table></div></section>
<section class="v39-card"><h2>Verificaciones de aceptación</h2><p>Consulta los resultados registrados de controles de seguridad, integridad y operación. Cada verificación se documenta y valida en su sección correspondiente.</p>
<div class="v39-scroll"><table class="v39-table"><thead><tr><th>Código</th><th>Tipo</th><th>Verificación</th><th>Resultado registrado</th></tr></thead><tbody><?php foreach($report['catalogo'] as $id=>$item):$status=$report['f35'][$id]['resultado']??'NO_EJECUTADA';?><tr><td><strong><?=a27_h($id)?></strong></td><td><?=a27_h($item[0])?></td><td><?=a27_h($item[1])?></td><td><span class="v39-tag <?= $status==='APROBADA'?'v39-good':''?>"><?=a27_h(['APROBADA'=>'Validada','NO_EJECUTADA'=>'Pendiente','FALLIDA'=>'Con observaciones','BLOQUEADA'=>'Bloqueada'][$status]??$status)?></span></td></tr><?php endforeach;?></tbody></table></div>
</section>
<section class="v39-card"><h2>Seguimiento de acciones correctivas</h2><p>Consulta las acciones documentadas por las áreas responsables. El historial permanece asociado a sus controles de origen.</p>
<?php if(!$report['seguimientos_f34']):?><p>No existen seguimientos registrados.</p><?php else:?><div class="v39-scroll"><table class="v39-table"><thead><tr><th>Área</th><th>Control</th><th>Responsable</th><th>Seguimiento</th></tr></thead><tbody><?php foreach($report['seguimientos_f34'] as $r):?><tr><td><?=a27_h($r['area'])?></td><td><?=a27_h($r['control'])?></td><td><?=a27_h($r['responsable'])?></td><td><?=a27_h($r['estado'])?></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section>
<section class="v39-card"><h2>Incidencias y acciones correctivas</h2><p>Registra situaciones detectadas, su prioridad, el seguimiento y las referencias de evidencia. No incluyas contraseñas, documentos laborales ni información restringida en descripciones. La verificación de datos financieros y laborales corresponde a sus áreas responsables.</p>
<?php if($report['sql_ok']):?>
<h3>Registrar nueva incidencia</h3>
<form method="post" action="arca39_guardar.php" class="v39-form">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="operacion" value="CREAR"><input type="hidden" name="nonce" value="<?=bin2hex(random_bytes(16))?>">
<label>Categoría<select name="categoria" required><?php foreach(a39_categorias() as $code=>$name):?><option value="<?=a27_h($code)?>"><?=a27_h($name)?></option><?php endforeach;?></select></label>
<label>Prioridad<select name="prioridad" required><?php foreach(a39_prioridades() as $p):?><option value="<?=a27_h($p)?>" <?=$p==='MEDIA'?'selected':''?>><?=a27_h($p)?></option><?php endforeach;?></select></label>
<label>Título<input name="titulo" required maxlength="160" placeholder="Ej. Ajuste de permiso en módulo de reportes"></label>
<label>Referencia de control / incidencia<input name="referencia_origen" maxlength="120" placeholder="Ej. SEG04 o DEP01"></label>
<label class="v39-wide">Descripción reproducible<textarea name="descripcion" maxlength="2000" required placeholder="Cómo reproducir, resultado esperado y resultado observado; sin datos personales"></textarea></label>
<div class="v39-wide"><button type="submit">Registrar incidencia</button></div>
</form>
<h3>Incidencias registradas</h3>
<?php if(!$report['incidencias']):?><p>No existen incidencias documentadas. Las observaciones de los controles pueden consultarse en la sección anterior.</p><?php endif;?>
<?php foreach($report['incidencias'] as $r):$id=(int)$r['id_incidencia'];?><details class="v39-panel"><summary><strong>#<?=$id?> · <?=a27_h($r['titulo'])?></strong> <span class="v39-tag"><?=a27_h($r['estado'])?></span> <small><?=a27_h($r['categoria'].' · '.$r['prioridad'])?></small></summary>
<p><?=a27_h($r['descripcion'])?></p><p>Referencia: <?=a27_h($r['referencia_origen']??'Sin referencia')?> · Creada: <?=a27_h($r['creado_en'])?></p>
<?php if(!empty($report['historial'][$id])):?><h4>Bitácora de seguimiento</h4><?php foreach($report['historial'][$id] as $ev):?><p class="v39-timeline"><strong><?=a27_h($ev['accion'].' · '.$ev['estado_nuevo'])?></strong> · <?=a27_h($ev['registrado_en'])?> · Usuario #<?=(int)$ev['actor_id']?> · <?=a27_h($ev['nota'])?></p><?php endforeach;endif;?>
<?php if($r['estado']!=='CERRADA'):?><form class="v39-form" action="arca39_guardar.php" method="post"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="operacion" value="ESTADO"><input type="hidden" name="id_incidencia" value="<?=$id?>">
<label>Próximo estado<select name="estado" required><?php foreach(a39_estados() as $s=>$label):if(!a39_transicion((string)$r['estado'],$s))continue;?><option value="<?=a27_h($s)?>"><?=a27_h($label)?></option><?php endforeach;?></select></label>
<label>Referencia de evidencia (no adjuntar archivos)<input name="referencia_evidencia" maxlength="180" placeholder="Ej. REPORTE/QA/ACTA-003"></label>
<label class="v39-wide">Observación y validación<textarea name="observacion" required maxlength="1500" placeholder="Acción realizada y cómo se verificó; sin datos personales"></textarea></label>
<div class="v39-wide"><button type="submit">Registrar cambio auditado</button></div></form><?php else:?><p class="v39-goodtxt">Seguimiento cerrado y documentado. La eficacia de la corrección debe mantenerse bajo supervisión.</p><?php endif;?></details><?php endforeach;?>
<?php endif;?></section>
<section class="v39-card"><h2>Requisitos para habilitación operativa</h2><p>Se requiere evidencia de restauración de respaldos, revisión de accesos y sesiones, protección de formularios, conexión segura, conciliación documental de divisas y evaluación independiente. La habilitación final depende de Dirección General y las áreas responsables.</p></section>
<?php endif;?>
<?php a27_end(); ?>
