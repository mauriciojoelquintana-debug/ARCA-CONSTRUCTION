<?php
require_once __DIR__.'/includes/seguridad.php';
arca_requerir_roles(['CEO','Director General','CIO','CHRO','Secretaria','Secretaria / Asistente','Director de RR.HH.']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: actualiza.html'); exit; }
$numero_empleado=trim((string)($_POST['numero_empleado']??''));
$password=(string)($_POST['nueva_password']??'');
$cargo=trim((string)($_POST['nuevo_cargo']??''));
if ($numero_empleado==='' || strlen($password)<12 || $cargo==='') { http_response_code(422); exit('Datos incompletos. La nueva contraseña debe tener al menos 12 caracteres.'); }
// Solo el CEO autoriza ascensos a puestos ejecutivos.
if (in_array($cargo,['CEO','CFO','COO','CIO','CTO','CCO','CMO','CHRO','CSO'],true) && !in_array($_SESSION['rol_activo'],['CEO','Director General'],true)) { http_response_code(403); exit('Solo Dirección General puede asignar puestos ejecutivos.'); }
require __DIR__.'/conexion.php';
$hash=password_hash($password,PASSWORD_DEFAULT);
$stmt=$conectar->prepare('UPDATE usuarios SET password=?, cargo=? WHERE numero_empleado=?');
$stmt->bind_param('sss',$hash,$cargo,$numero_empleado);
$ok=$stmt->execute();$affected=$stmt->affected_rows;$stmt->close();
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actualizar empleado | ARCA</title><link rel="stylesheet" href="assets/css/arca.css"></head>
<body style="min-height:100vh;display:grid;place-items:center"><main class="metric-card" style="max-width:500px;width:calc(100% - 30px)"><span class="eyebrow">RECURSOS HUMANOS</span><h1 style="font-size:22px;color:var(--arca-navy)"><?= $ok&&$affected?'Empleado actualizado':'No se realizaron cambios' ?></h1><p style="font-size:14px">Empleado: <?= arca_h($numero_empleado) ?> · Cargo solicitado: <?= arca_h($cargo) ?></p><a class="btn btn-primary" href="panel_administrativo.php">Volver al panel →</a></main></body></html>
