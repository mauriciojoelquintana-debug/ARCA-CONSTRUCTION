<?php
// SOLO CONSOLA. Ejecutar una vez DESPUÉS de crear una copia de arca_bd.
// Uso desde C:\laragon\www\arca: php scripts\migrar_passwords.php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Acceso denegado'); }
require dirname(__DIR__) . '/conexion.php';
try {
    $conectar->begin_transaction();
    $usuarios = $conectar->query('SELECT id_usuario, password FROM usuarios FOR UPDATE');
    $update = $conectar->prepare('UPDATE usuarios SET password = ? WHERE id_usuario = ?');
    $migrados = 0; $yaProtegidos = 0; $sinClave = 0;
    while ($fila = $usuarios->fetch_assoc()) {
        $actual = (string)($fila['password'] ?? '');
        if ($actual === '') { $sinClave++; continue; }
        if (password_get_info($actual)['algoName'] !== 'unknown') { $yaProtegidos++; continue; }
        $hash = password_hash($actual, PASSWORD_DEFAULT);
        $id = (int)$fila['id_usuario'];
        $update->bind_param('si', $hash, $id);
        $update->execute(); $migrados++;
    }
    $update->close();
    $conectar->commit();
    echo "Migración terminada: $migrados protegidas, $yaProtegidos ya protegidas, $sinClave sin contraseña.\n";
    if ($sinClave) echo "Atención: las cuentas sin contraseña requieren restablecimiento manual.\n";
    echo "Recomendación: cambiar todas las contraseñas iniciales antes de usar datos reales.\n";
} catch (Throwable $e) {
    $conectar->rollback();
    fwrite(STDERR, 'No se completó la migración: ' . $e->getMessage() . "\n");
    exit(1);
}
