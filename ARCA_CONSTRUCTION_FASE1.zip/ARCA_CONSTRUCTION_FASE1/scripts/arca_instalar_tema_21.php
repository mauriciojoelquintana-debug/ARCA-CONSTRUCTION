<?php
declare(strict_types=1);
/* ARCA fase 21: instala capa de diseño en las páginas existentes, sin cambiar su PHP. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal.');}
$root=dirname(__DIR__);
$list=[
 'panel_estructura_arca.php','panel_departamentos_arca.php','panel_ingenieria.php',
 'panel_administrativo.php','historial_materiales.php','formulario_inventario.php',
 'mis_obras.php','soporte_tecnico.php','reportes_sql.php','ver_agenda.php',
 'buscador_agenda.php','resultados_agenda.php','formulario_agenda.php',
 'formulario_alta_empleado.php','desglose_federal.php',
 'panel_operativo.php','panel_ejecutivo.php','subir_planos.php'
];
if(!in_array('--apply',$argv,true)){echo "ARCA 21 · Vista previa. Para instalar, ejecuta: php scripts/arca_instalar_tema_21.php --apply\n";}
$apply=in_array('--apply',$argv,true);
$backup=dirname($root,2).DIRECTORY_SEPARATOR.'arca_respaldos_fase21_'.date('Ymd_His');
$changed=0;$skipped=0;
foreach($list as $file){
 $path=$root.DIRECTORY_SEPARATOR.$file;
 if(!is_file($path)){echo "No encontrado: $file\n";$skipped++;continue;}
 $original=file_get_contents($path);
 if($original===false || !preg_match('~</head>~i',$original) || !preg_match('~<body\b[^>]*>~i',$original)){echo "Omitido (HTML no convencional): $file\n";$skipped++;continue;}
 if(str_contains($original,'ARCA_FASE21_CSS')){echo "Ya estilizado: $file\n";$skipped++;continue;}
 $modified=preg_replace('~</head>~i','<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>',$original,1);
 $modified=preg_replace_callback('~<body\b([^>]*)>~i',static function($m){
   $attrs=$m[1];
   if(preg_match('~\bclass\s*=\s*([\"\'])(.*?)\1~i',$attrs)){
    $attrs=preg_replace_callback('~\bclass\s*=\s*([\"\'])(.*?)\1~i',static fn($x)=>'class='.$x[1].$x[2].' arca21-legacy'.$x[1],$attrs,1);
   }else{$attrs.=' class="arca21-legacy"';}
   return '<body'.$attrs.'>';
 },$modified,1);
 if($file==='panel_ingenieria.php'){
   $modified=str_replace('href="historial_materiales.php"','href="panel_oficina_almacen.php?vista=movimientos"',$modified);
   $modified=str_replace('href="registro_material.php"','href="panel_oficina_almacen.php?vista=materiales"',$modified);
   $modified=str_replace('href="#" class="btn-action btn-inventario"','href="arca_obra_360.php" class="btn-action btn-inventario"',$modified);
 }
 if($apply){
   if(!is_dir($backup)&&!mkdir($backup,0700,true)&&!is_dir($backup))exit('No pude crear la carpeta de respaldo.');
   if(file_put_contents($backup.DIRECTORY_SEPARATOR.$file,$original,LOCK_EX)===false)exit('No pude crear el respaldo de '.$file);
   if(file_put_contents($path,$modified,LOCK_EX)===false)exit('No pude guardar '.$file);
 }
 echo ($apply?'Estilo instalado: ':'Se puede actualizar: ').$file."\n";$changed++;
}
echo "\nTotal: $changed listo(s); $skipped omitido(s).\n";
if($apply)echo "Respaldo original fuera de www: $backup\n";
