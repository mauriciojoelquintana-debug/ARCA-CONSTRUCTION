<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
$root=dirname(__DIR__);
$required=['includes/arca22_accesos.php','arca22_portal.php','arca22_abrir.php','arca22_mis_permisos.php','arca22_pruebas.php','assets/css/arca22.css'];
$ok=true;
foreach($required as $path){$exists=is_file($root.DIRECTORY_SEPARATOR.$path);echo ($exists?'OK: ':'FALTA: ').$path."\n";$ok=$ok&&$exists;}
// Conexión dentro de función: no contaminar variables ni sesiones de otros archivos.
function a22_check_db(): array {
 require dirname(__DIR__).'/conexion.php';
 if(!isset($conectar)||!($conectar instanceof mysqli))throw new RuntimeException('Sin conexión mysqli');
 $base=$conectar->query('SELECT DATABASE() nombre')->fetch_assoc()['nombre'];
 $tables=['usuarios','obras_coo','arca_accesos_obra'];
 $result=[];
 foreach($tables as $name){$s=$conectar->prepare('SELECT COUNT(*) n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$s->bind_param('s',$name);$s->execute();$result[$name]=(int)$s->get_result()->fetch_assoc()['n'];$s->close();}
 return [$base,$result];
}
try{[$db,$tables]=a22_check_db();echo 'Base utilizada: '.$db."\n";if($db!=='arca_bd_fase1'){$ok=false;echo "ADVERTENCIA: no es la base de pruebas.\n";}foreach($tables as $name=>$present){echo ($present===1?'OK: ':'FALTA: ').$name."\n";if($present!==1)$ok=false;}}catch(Throwable $e){echo 'ERROR MySQL: '.$e->getMessage()."\n";$ok=false;}
echo $ok?"Preflight de Fases 22–23 correcto. Faltan pruebas funcionales por cuenta.\n":"Preflight incompleto; no aplicar cambios hasta revisar.\n";
exit($ok?0:1);
