<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit('Solo CLI');
require_once dirname(__DIR__).'/includes/arca22_accesos.php';
$casos=[
 ['panel_cfo.php','CEO',true],
 ['panel_cfo.php','CFO',true],
 ['panel_cfo.php','CHRO',false],
 ['arca_compras.php','COO',true],
 ['arca_compras.php','CFO',false],
 ['arca_recepcion.php','CEO',false],
 ['arca_recepcion.php','Almacenista',true],
 ['chro_personal.php','CHRO',true],
 ['chro_personal.php','Ingeniero Civil',false],
 ['arca_obra_360.php','Residente de Obra',true],
 ['arca_seguridad.php','CIO',true],
 ['arca_seguridad.php','Almacenista',false],
 ['ruta_inventada.php','CEO',false],
];
$failed=0;
foreach($casos as [$ruta,$rol,$esperado]){
 $actual=a22_rol_permitido($ruta,$rol);$ok=$actual===$esperado;
 echo ($ok?'OK':'FALLO').' '.$rol.' -> '.$ruta.' ('.($actual?'permitido':'denegado').")\n";
 if(!$ok)$failed++;
}
echo $failed===0?"Políticas base: correctas. Requiere verificar obra real en Laragon.\n":"Políticas base con fallos.\n";
exit($failed?1:0);
