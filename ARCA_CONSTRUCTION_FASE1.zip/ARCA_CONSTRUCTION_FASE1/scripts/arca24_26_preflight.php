<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
$root=dirname(__DIR__);$ok=true;
$files=['includes/arca_core.php','includes/arca22_accesos.php','includes/arca24_26_puro.php','includes/arca24_26.php','includes/arca24_indicadores.php','includes/arca25_informes.php','includes/arca_reportes_binarios.php','arca24_tablero.php','arca24_estado.php','arca25_reportes.php','arca25_exportar.php','arca26_seguridad.php'];
foreach($files as $f){$present=is_file($root.'/'.$f);echo ($present?'OK':'FALTA')." archivo $f\n";$ok=$present&&$ok;}
try {
 function a26_connection():mysqli {require dirname(__DIR__).'/conexion.php';if(!isset($conectar)||!$conectar instanceof mysqli)throw new RuntimeException('MySQL no conectado');return $conectar;}
 $db=a26_connection();$used=$db->query('SELECT DATABASE() nombre')->fetch_assoc()['nombre']??'';echo "Base actual: $used\n";
 if($used!=='arca_bd_fase1'){echo "ADVERTENCIA: No es la base de pruebas.\n";$ok=false;}
 $tables=['obras_coo','finanzas_coo','arca_accesos_obra','arca_asignaciones_personal','inventario_almacen_arca','arca_avances_cortes','arca_ordenes_compra','arca_movimientos_material','arca_recepciones_integradas'];
 $columns=['finanzas_coo'=>['moneda'],'arca_ordenes_compra'=>['moneda','emitida']];
 foreach($tables as $t){$st=$db->prepare('SELECT COUNT(*) n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$st->bind_param('s',$t);$st->execute();$v=(int)($st->get_result()->fetch_assoc()['n']??0);$st->close();echo ($v?'OK':'FALTA')." tabla $t\n";if(!$v)$ok=false;}
 foreach($columns as $table=>$names)foreach($names as $col){$st=$db->prepare('SELECT COUNT(*) n FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?');$st->bind_param('ss',$table,$col);$st->execute();$v=(int)($st->get_result()->fetch_assoc()['n']??0);$st->close();echo ($v?'OK':'FALTA')." campo $table.$col\n";if(!$v)$ok=false;}
}catch(Throwable $e){echo 'ERROR CONEXION: '.$e->getMessage()."\n";$ok=false;}
echo 'PHP ZIP: '.(class_exists('ZipArchive')?'ZipArchive disponible':'Se usará generador XLSX alternativo')."\n";
echo $ok?"Comprobación de archivos y tablas satisfactoria. Pendientes pruebas por perfil y navegador.\n":"Faltan requisitos. No iniciar pruebas de exportación.\n";
exit($ok?0:1);
