<?php
declare(strict_types=1);
/** Aplica un parche mínimo al catálogo anterior. Simulación por defecto, respaldo fuera de www. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
$root=dirname(__DIR__);$target=$root.'/includes/arca22_accesos.php';
if(!is_file($target)){fwrite(STDERR,"FALTA arca22_accesos.php: instala primero Fase 22.\n");exit(1);}
$src=file_get_contents($target);if($src===false)exit(1);
$marker="        'arca_integracion.php' => ";
if(str_contains($src,"'arca24_tablero.php'")) {echo "El menú de la Fase 24 ya está integrado. No se repiten cambios.\n";exit(0);}
if(!str_contains($src,$marker)){fwrite(STDERR,"Formato de catálogo distinto: revisar manualmente, sin cambios.\n");exit(1);}
$patch="        'arca24_tablero.php'=>['nombre'=>'Indicadores actualizados (Fase 24)','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CFO','COO','CHRO'],'obra'=>false],\n".
"        'arca25_reportes.php'=>['nombre'=>'Reportes filtrados PDF/Excel (Fase 25)','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CFO','COO','CHRO'],'obra'=>false],\n".
"        'arca26_seguridad.php'=>['nombre'=>'Auditoría y pruebas (Fase 26)','grupo'=>'Reportes y control','roles'=>['CEO','Director General','CIO'],'obra'=>false],\n";
$new=str_replace($marker,$patch.$marker,$src);
if(!in_array('--apply',$argv,true)){echo "SIMULACIÓN: se agregarán tres accesos en includes/arca22_accesos.php.\nEjecuta con --apply después de respaldar el proyecto.\n";exit(0);}
$backup=dirname($root,2).'/arca_respaldo_fase24_26_'.date('Ymd_His');
if(!is_dir($backup)&&!mkdir($backup,0700,true)){fwrite(STDERR,"No se creó carpeta de respaldo.\n");exit(1);}
if(!copy($target,$backup.'/arca22_accesos.php')){fwrite(STDERR,"No se respaldó catálogo; no se aplicó el parche.\n");exit(1);}
$temp=$target.'.tmp_'.getmypid();if(file_put_contents($temp,$new)===false)exit(1);
$lint='"'.PHP_BINARY.'" -l "'.$temp.'"';$output=[];$status=1;exec($lint,$output,$status);
if($status!==0){unlink($temp);fwrite(STDERR,"Error de sintaxis, sin cambios: ".implode(' ',$output)."\n");exit(1);}
if(!rename($temp,$target)){unlink($temp);fwrite(STDERR,"No se pudo instalar catálogo.\n");exit(1);}
echo "OK: tres rutas añadidas. Respaldo: $backup\n";
