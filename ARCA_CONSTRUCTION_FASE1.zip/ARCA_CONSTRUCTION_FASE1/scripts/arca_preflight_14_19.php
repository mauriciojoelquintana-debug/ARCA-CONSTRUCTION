<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
require_once __DIR__.'/../conexion.php';
if(!isset($conectar) || !($conectar instanceof mysqli))exit("Sin conexión\n");
$db=(string)($conectar->query('SELECT DATABASE()')->fetch_row()[0]??'');echo 'Base en uso: '.$db."\n";
if($db!=='arca_bd_fase1'){fwrite(STDERR,"DETENIDO: no es la base de pruebas\n");exit(2);}
$tables=['usuarios','obras_coo','finanzas_coo','arca_solicitudes_compra','arca_ordenes_compra','arca_movimientos_material','inventario_almacen_arca','arca_auditoria_modulos','arca_empleados','arca_autorizaciones_transversales','arca_recepciones_integradas','arca_seguimiento_integrado'];$fail=0;
foreach($tables as $t){$q=$conectar->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->bind_param('s',$t);$q->execute();$n=(int)$q->get_result()->fetch_row()[0];$q->close();echo ($n?'OK: ':'FALTA: ').$t."\n";$fail+=$n?0:1;}
$c=$conectar->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='finanzas_coo' AND column_name='moneda'")->fetch_row()[0];if(!(int)$c){echo "FALTA: finanzas_coo.moneda\n";$fail++;}
if(!extension_loaded('zip')){echo "AVISO: activa ZipArchive para exportar XLSX\n";}
echo $fail?"Preflight con $fail incidencia(s)\n":"Preflight completo. Falta validar roles, flujos y backups.\n";exit($fail?2:0);
