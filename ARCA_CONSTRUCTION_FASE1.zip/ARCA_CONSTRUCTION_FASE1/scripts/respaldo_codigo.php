<?php
declare(strict_types=1);
/** Respaldo controlado del código del ERP. Nunca incluye base MySQL ni almacén privado. */
if(PHP_SAPI!=='cli')exit('Solo terminal.');
$o=getopt('',['project:','dest:']);$project=realpath((string)($o['project']??''));
$dest=(string)($o['dest']??'');
if(!$project || $dest===''){fwrite(STDERR,"Uso: php respaldo_codigo.php --project=RUTA_ERP --dest=CARPETA_FUERA_DE_WWW\n");exit(2);}
if(!class_exists('ZipArchive')){fwrite(STDERR,"ERROR: extensión zip no disponible.\n");exit(2);}
if(!is_dir($dest) && !mkdir($dest,0700,true)){fwrite(STDERR,"ERROR: crear carpeta de destino.\n");exit(2);}
$real=realpath($dest);$norm=static fn($p)=>strtolower(rtrim(str_replace('\\','/',$p),'/'));
$public=dirname($project);$d=$norm($real);$p=$norm($public);
if($d===$p || str_starts_with($d,$p.'/')){fwrite(STDERR,"BLOQUEADO: destino dentro de www.\n");exit(2);}
if($d===$norm($project)||str_starts_with($d,$norm($project).'/')){fwrite(STDERR,"BLOQUEADO: destino dentro del ERP.\n");exit(2);}
$path=$real.'/ARCA_CODIGO_F36_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)).'.zip';
$zip=new ZipArchive();if($zip->open($path,ZipArchive::CREATE|ZipArchive::EXCL)!==true){fwrite(STDERR,"ERROR ZIP.\n");exit(2);}
$skipped=['.git','node_modules','cache','tmp'];$total=0;
$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($project,FilesystemIterator::SKIP_DOTS));
foreach($it as $file){
 if($file->isLink()||!$file->isFile())continue;
 $abs=$file->getPathname();$rel=str_replace('\\','/',substr($abs,strlen($project)+1));
 $parts=explode('/',$rel);if(array_intersect($parts,$skipped))continue;
 if(!$zip->addFile($abs,$rel)){ $zip->close();@unlink($path);fwrite(STDERR,"ERROR agregando archivo.\n");exit(2);}
 $total++;
}
if(!$zip->close()){fwrite(STDERR,"ERROR cerrando ZIP.\n");@unlink($path);exit(2);}
$sha=hash_file('sha256',$path);file_put_contents($path.'.sha256',$sha.'  '.basename($path)."\n");
@chmod($path,0600);@chmod($path.'.sha256',0600);
echo "Respaldo de CÓDIGO: $path\nArchivos: $total\nSHA-256: $sha\n";
echo "ATENCIÓN: puede contener conexion.php y credenciales. Guardar cifrado y restringido. Falta respaldo de MySQL y documentos privados F29.\n";
