<?php
declare(strict_types=1);
$project=null;foreach($argv as $arg)if(str_starts_with($arg,'--project='))$project=substr($arg,10);
$root=$project?realpath($project):false;
if(!$root||!is_file($root.'/includes/arca22_accesos.php')){fwrite(STDERR,"Indica --project=RUTA de ARCA con includes/arca22_accesos.php\n");exit(2);}
require_once $root.'/includes/arca22_accesos.php';
if(!function_exists('a22_catalogo')){fwrite(STDERR,"No se reconoce el catálogo de módulos.\n");exit(2);}
$items=a22_catalogo();$missing=[];
echo "ARCA - revisión de destinos físicos de Menú ARCA\n";
foreach($items as $file=>$meta){$valid=preg_match('~^[a-zA-Z0-9_-]+\.php$~D',$file)===1&&is_file($root.'/'.$file);echo ($valid?'OK':'FALTA')."  $file  |  ".($meta['nombre']??'')."\n";if(!$valid)$missing[]=$file;}
echo 'Módulos catalogados: '.count($items).'; archivos faltantes: '.count($missing)."\n";
echo "IMPORTANTE: que un archivo exista no demuestra que la página funcione o esté segura.\n";
exit($missing?1:0);
