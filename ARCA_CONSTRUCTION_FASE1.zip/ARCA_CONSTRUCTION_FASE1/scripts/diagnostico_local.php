<?php
declare(strict_types=1);
/** Diagnóstico estático de archivos; sin abrir BD ni modificar el proyecto. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal.');}
$opt=getopt('',['project:']);
$project=realpath((string)($opt['project']??''));
if(!$project||!is_dir($project)){fwrite(STDERR,"ERROR: --project debe indicar una carpeta existente.\n");exit(2);}
$files=['arca39_validacion.php','arca39_guardar.php','arca39_exportar.php','includes/arca39_reglas.php','includes/arca39_datos.php','assets/css/arca39.css'];
$deps=['includes/arca27.php','includes/arca34_datos.php','includes/arca36_38_datos.php','arca35_pruebas.php','arca38_flujos.php'];
$problems=0;
echo "ARCA · DIAGNÓSTICO ESTÁTICO F39\nProyecto: $project\n";
foreach(array_merge($files,$deps) as $rel){$found=is_file($project.'/'.$rel);echo ($found?'OK':'FALTA').": $rel\n";if(!$found)$problems++;}
$src=realpath(__DIR__.'/..');
foreach($files as $rel){
  if(!is_file($project.'/'.$rel)||!is_file($src.'/'.$rel))continue;
  if(hash_file('sha256',$project.'/'.$rel)!==hash_file('sha256',$src.'/'.$rel)){
    echo "AVISO: $rel difiere del paquete original. Revisar personalizaciones.\n";
  }
}
echo "TOTAL: $problems dependencias o archivos ausentes.\n";
echo "NOTA: sin conexión a MySQL; los controles de contenido se ejecutan desde arca39_validacion.php.\n";
exit($problems?1:0);
