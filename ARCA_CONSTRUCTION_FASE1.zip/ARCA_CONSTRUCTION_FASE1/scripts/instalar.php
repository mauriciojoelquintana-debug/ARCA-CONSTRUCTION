<?php
declare(strict_types=1);
/**
 * ARCA F40 - actualizador de PRESENTACIÓN no destructivo.
 * Uso: php ".../scripts/instalar.php" --project="C:\laragon\www\ARCA_CONSTRUCTION_FASE1" [--apply]
 * No crea/edita tablas, permisos, roles, estados o archivos de acciones.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo CLI'); }
$args = array_slice($argv, 1);
$apply = in_array('--apply', $args, true);
$path = null;
foreach ($args as $k => $arg) {
    if (str_starts_with($arg, '--project=')) { $path = substr($arg, 10); break; }
    if ($arg === '--project' && isset($args[$k+1])) { $path = $args[$k+1]; break; }
}
if (!$path) { fwrite(STDERR, "Uso: php instalar.php --project=RUTA [--apply]\n"); exit(2); }
$project = realpath($path);
if ($project === false || !is_dir($project) || strcasecmp(basename($project), 'ARCA_CONSTRUCTION_FASE1') !== 0) {
    fwrite(STDERR, "BLOQUEADO: proyecto inexistente o carpeta incorrecta.\n"); exit(2);
}
$base = dirname(__DIR__);
$rulesFile = $base . '/data/cambios.json';
$rules = json_decode((string)file_get_contents($rulesFile), true);
if (!is_array($rules)) { fwrite(STDERR, "BLOQUEADO: configuración de cambios inválida.\n"); exit(2); }
$cssRel = 'assets/css/arca40_corporativo.css';
$cssSource = file_get_contents($base.'/'.$cssRel);
if ($cssSource === false) { fwrite(STDERR, "BLOQUEADO: falta CSS del paquete.\n"); exit(2); }
$files = [];
$errors = [];
$statuses = [];
$links = [
 'arca32_auditoria.php'  => ['Auditoría integral', ['CEO','Director General']],
 'arca33_preparacion.php'=> ['Configuración operativa', ['CEO','Director General','CIO']],
 'arca34_calidad.php'    => ['Centro de calidad', ['CEO','Director General']],
 'arca35_pruebas.php'    => ['Verificación operativa', ['CEO','Director General','CIO']],
 'arca36_infraestructura.php'=>['Infraestructura y continuidad',['CEO','Director General','CIO']],
 'arca37_integracion.php'=>['Integración corporativa',['CEO','Director General','CFO','COO','CHRO','CIO','CTO','CCO','CMO','CSO']],
 'arca38_flujos.php'=> ['Flujos de revisión',['CEO','Director General','CFO','COO','CHRO']],
 'arca39_validacion.php'=> ['Centro de validación',['CEO','Director General']],
];
function patched_menu(string $src,array $links): ?string {
    if (!preg_match('/(\$links\s*=\s*\[)(.*?)(\n\s*\];)/s',$src,$found,PREG_OFFSET_CAPTURE)) return null;
    $body = $found[2][0];
    $initialBody = $body;
    $add = '';
    foreach ($links as $url => $details) {
        $label = $details[0]; $roles = $details[1];
        if (strpos($body, "'".$url."'") === false && strpos($body, '"'.$url.'"') === false) {
            $quoted = array_map(static fn($v)=>"'".$v."'", $roles);
            $add .= "\n  '".$url."'=>['".$label."',[".implode(',', $quoted)."]],";
        } else {
            // Etiquetas anteriores con números de fase, sin modificar etiquetas personalizadas.
            $pattern = "/('".preg_quote($url,'/')."'\\s*=>\\s*\\[\\s*')([^']*)(')/";
            $body = (string)preg_replace_callback($pattern,static function(array $m) use ($label):string {
                return preg_match('/(?:\\bF(?:32|33|34|35|36|37|38|39)\\b|\\bFase\\s*3[2-9]\\b)/iu',$m[2])
                    ? $m[1].$label.$m[3] : $m[0];
            },$body);
        }
    }
    if ($add === '') {
        if ($body === $initialBody) return $src;
        $at = $found[2][1];
        return substr($src, 0, $at).$body.substr($src, $found[3][1]);
    }
    $trimmed = rtrim($body);
    if ($add !== '' && !str_ends_with($trimmed,',')) $trimmed .= ',';
    $newBody = $trimmed.$add."\n";
    $start = $found[2][1];
    return substr($src,0,$start).$newBody.substr($src,$found[3][1]);
}
function lint_php(string $data): bool {
    if (!function_exists('exec')) return false;
    $temp = tempnam(sys_get_temp_dir(),'arcaf40_');
    if ($temp === false) return false;
    try {
        if (file_put_contents($temp,$data)===false) return false;
        $lines=[];$status=1;
        @exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($temp).' 2>&1',$lines,$status);
        return $status===0;
    } finally { @unlink($temp); }
}
foreach ($rules as $rel => $pairs) {
    $dest=$project.DIRECTORY_SEPARATOR.str_replace('/',DIRECTORY_SEPARATOR,$rel);
    if (!is_file($dest)) { $errors[]='Falta archivo: '.$rel; continue; }
    $original=file_get_contents($dest);
    if ($original===false || !str_contains($original,'a27_layout(') && $rel!=='includes/arca27.php') {
        $errors[]='Estructura desconocida: '.$rel; continue;
    }
    if ($rel==='includes/arca27.php' && (!str_contains($original,'function a27_layout(') || !str_contains($original,'$links'))) {
        $errors[]='Diseño compartido desconocido: '.$rel;continue;
    }
    $new=$original;
    foreach ($pairs as $pair) {
        if (!is_array($pair) || count($pair)!==2) { $errors[]='Regla inválida: '.$rel;continue 2; }
        [$from,$to]=$pair;
        if ($from!==$to) $new=str_replace($from,$to,$new);
    }
    if ($rel==='includes/arca27.php') {
        $m=patched_menu($new,$links);
        if ($m===null) { $errors[]='No se localizó el menú estándar: '.$rel;continue; }
        $new=$m;
        if (!str_contains($new,'arca40_corporativo.css')) {
            $ok=preg_match('~(<link\s+rel="stylesheet"\s+href="assets/css/arca27\.css[^\"]*">)~',$new,$match);
            if (!$ok) {$errors[]='No se encontró enlace CSS base: '.$rel;continue;}
            $new=str_replace($match[1],$match[1].'<link rel="stylesheet" href="assets/css/arca40_corporativo.css?v=1">',$new);
        }
    }
    if ($new!==$original && !lint_php($new)) {$errors[]='Error de sintaxis PHP tras los cambios: '.$rel;continue;}
    $files[$rel]=['target'=>$dest,'old'=>$original,'new'=>$new];
    $statuses[$rel]=$new===$original?'YA ACTUALIZADO / SIN CAMBIOS':'LISTO PARA ACTUALIZAR';
}
$cssTarget=$project.DIRECTORY_SEPARATOR.str_replace('/',DIRECTORY_SEPARATOR,$cssRel);
if (is_file($cssTarget)) {
    $existing=file_get_contents($cssTarget);
    if ($existing!==$cssSource) $errors[]='Existe CSS personalizado: '.$cssRel.'. Comparación manual requerida.';
    else $statuses[$cssRel]='YA INSTALADO';
} else {
    $files[$cssRel]=['target'=>$cssTarget,'old'=>null,'new'=>$cssSource];
    $statuses[$cssRel]='NUEVO';
}
echo 'ARCA CONSTRUCTION - F40 PRESENTACION CORPORATIVA - '.($apply?'APLICAR':'VISTA PREVIA').PHP_EOL;
echo 'Proyecto: '.$project.PHP_EOL;
foreach ($statuses as $rel=>$msg) echo 'OK: '.$rel.' -> '.$msg.PHP_EOL;
if ($errors) {
    echo "BLOQUEADO: no se realizaron cambios.\n";
    foreach ($errors as $e) echo '  - '.$e.PHP_EOL;
    exit(3);
}
if (!$apply) { echo "VISTA PREVIA CORRECTA. No se modificaron archivos. Ejecuta --apply tras respaldar.\n";exit(0); }
$changed=array_filter($files,static fn($d)=>$d['old']!==$d['new']);
if (!$changed) { echo "APLICADO ANTERIORMENTE. No se modificaron archivos.\n";exit(0); }
$backupDir=dirname(dirname($project)).DIRECTORY_SEPARATOR.'ARCA_RESPALDO_F40_'.date('Ymd_His').'_'.bin2hex(random_bytes(3));
if (!@mkdir($backupDir,0700,true)) { fwrite(STDERR,"BLOQUEADO: no se pudo crear respaldo fuera de www.\n");exit(4); }
$prepared=[];
foreach ($changed as $rel=>$item) {
    if ($item['old']===null) continue;
    $backup=$backupDir.DIRECTORY_SEPARATOR.str_replace('/',DIRECTORY_SEPARATOR,$rel);
    if (!is_dir(dirname($backup)) && !@mkdir(dirname($backup),0700,true)) { $errors[]='No se pudo crear subcarpeta de respaldo: '.$rel;break; }
    if (!@copy($item['target'],$backup) || hash_file('sha256',$backup)!==hash('sha256',$item['old'])) {
        $errors[]='Respaldo no verificado: '.$rel;break;
    }
    $prepared[$rel]=$backup;
}
if ($errors) { echo "BLOQUEADO: respaldo incompleto; no se modificó proyecto.\n";foreach($errors as $e)echo $e.PHP_EOL;exit(5); }
$written=[];
try {
    foreach ($changed as $rel=>$item) {
        $written[]=$rel;
        if (!is_dir(dirname($item['target']))) throw new RuntimeException('Carpeta inexistente para '.$rel);
        if (file_put_contents($item['target'],$item['new'],LOCK_EX)!==strlen($item['new'])) throw new RuntimeException('No se pudo escribir '.$rel);
        if (hash_file('sha256',$item['target'])!==hash('sha256',$item['new'])) throw new RuntimeException('Verificación fallida de '.$rel);
        echo 'APLICADO: '.$rel.PHP_EOL;
    }
} catch (Throwable $e) {
    fwrite(STDERR,'ERROR: '.$e->getMessage().". Restaurando archivos del respaldo...\n");
    foreach (array_reverse($written) as $rel) {
        $it=$files[$rel];if($it['old']===null){@unlink($it['target']);continue;}
        if(isset($prepared[$rel]))@copy($prepared[$rel],$it['target']);
    }
    exit(6);
}
echo 'Respaldo fuera de www: '.$backupDir.PHP_EOL;
echo "APLICACION COMPLETADA. Sin consultas SQL ni cambios en MySQL.\n";
