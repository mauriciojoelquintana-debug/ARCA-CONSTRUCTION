<?php
declare(strict_types=1);
// Diagnóstico local solo CLI, sin contraseñas ni modificación de datos.
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Uso exclusivo de terminal.');}
try {
    require __DIR__.'/../conexion.php';
    $db=$conectar;
    if(!($db instanceof mysqli))throw new RuntimeException('Sin conexión MySQL.');
    $database=(string)$db->query('SELECT DATABASE()')->fetch_row()[0];
    echo "ARCA CONSTRUCTION · Comprobación de Fases 5, 6, 7\n";
    echo "Base activa: $database\n";
    if($database!=='arca_bd_fase1') {echo "ERROR: no estás utilizando la base de PRUEBAS.\n";exit(1);}
    $need=['usuarios','finanzas_coo','arca_finanzas_bitacora','obras_coo','inventario_almacen_arca','catalogo_puestos_arca','gerencias_arca',
      'arca_accesos_obra','arca_auditoria_modulos','arca_avances_cortes','arca_movimientos_material','arca_maquinaria_obra','arca_solicitudes_compra',
      'arca_empleados','arca_empleado_usuario','arca_contratos_laborales','arca_asignaciones_personal'];
    $missing=[];
    foreach($need as $table){
        $st=$db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
        $st->bind_param('s',$table);$st->execute();$found=(int)$st->get_result()->fetch_row()[0];$st->close();
        echo ($found?'OK  ':'FALTA ').$table."\n";if(!$found)$missing[]=$table;
    }
    $cols=$db->query("SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='finanzas_coo'");
    $seen=array_column($cols->fetch_all(MYSQLI_ASSOC),'COLUMN_NAME');
    foreach(['moneda','categoria_costo'] as $col){echo (in_array($col,$seen,true)?'OK ':'FALTA ')."finanzas_coo.$col\n";if(!in_array($col,$seen,true))$missing[]='finanzas_coo.'.$col;}
    if(!$missing){
        $count=(int)$db->query('SELECT COUNT(*) FROM usuarios')->fetch_row()[0];
        $unknown=(int)$db->query('SELECT COUNT(*) FROM finanzas_coo WHERE moneda IS NULL')->fetch_row()[0];
        echo "Cuentas existentes: $count\nMovimientos financieros sin moneda confirmada: $unknown\nListo para pruebas locales.\n";
    } else {echo "Importa primero los SQL indicados en el LEEME.\n";exit(1);}
} catch(Throwable $e){fwrite(STDERR,"No se pudo completar la comprobación. Revisa Laragon y conexion.php.\n");exit(1);}
