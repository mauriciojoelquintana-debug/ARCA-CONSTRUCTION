<?php
/**
 * Diagnóstico de autenticación ARCA CONSTRUCTION - SOLO para la terminal.
 * Instrucciones: colocar este archivo en scripts/ dentro de
 * C:\laragon\www\ARCA_CONSTRUCTION_FASE1\ y ejecutar:
 * php scripts\ARCA_diagnosticar_acceso.php
 *
 * No modifica usuarios ni contraseñas. No registra la contraseña escrita.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Solo se permite ejecutar desde la terminal.');
}

require dirname(__DIR__) . '/conexion.php';

try {
    $db = $conectar->query('SELECT DATABASE() AS base')->fetch_assoc()['base'] ?? '(desconocida)';
    echo "=== DIAGNOSTICO DE ACCESO ARCA ===\n";
    echo "Base de datos utilizada por PHP: {$db}\n";

    $numero = 'CEO-001';
    $stmt = $conectar->prepare('SELECT id_usuario, numero_empleado, password, cargo FROM usuarios WHERE numero_empleado = ? LIMIT 1');
    $stmt->bind_param('s', $numero);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$usuario) {
        echo "Resultado: NO SE ENCONTRO CEO-001 en esta base.\n";
        exit(1);
    }

    echo "Cuenta: " . $usuario['numero_empleado'] . "\n";
    echo "Cargo: " . $usuario['cargo'] . "\n";
    echo "Hash: " . substr((string)$usuario['password'], 0, 7) . " ... (longitud " . strlen((string)$usuario['password']) . ")\n";
    echo "Escribe la contraseña para verificarla (no se guardara): ";
    $entrada = fgets(STDIN);
    if ($entrada === false) {
        echo "No se recibio ninguna contraseña.\n";
        exit(1);
    }
    $clave = rtrim($entrada, "\r\n");
    $valida = password_verify($clave, (string)$usuario['password']);
    unset($clave, $entrada);

    echo $valida
        ? "RESULTADO: CORRECTA. PHP reconoce esa contraseña.\n"
        : "RESULTADO: NO COINCIDE con el hash guardado en la base indicada.\n";
    echo "Esta prueba no modifica registros.\n";
} catch (Throwable $e) {
    fwrite(STDERR, "No se pudo completar el diagnostico.\n");
    fwrite(STDERR, "Comprueba que Laragon tenga MySQL iniciado y que conexion.php apunte a la base de pruebas.\n");
    exit(1);
} finally {
    if (isset($conectar) && $conectar instanceof mysqli) {
        $conectar->close();
    }
}
