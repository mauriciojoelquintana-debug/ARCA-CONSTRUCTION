<?php
declare(strict_types=1);
/** Inventario heurístico; marca riesgos para revisión, NO declara rutas seguras. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
$root=dirname(__DIR__);
$items=[];$count=0;
foreach(new DirectoryIterator($root) as $entry){
 if(!$entry->isFile() || strtolower($entry->getExtension())!=='php')continue;
 $file=$entry->getFilename();$content=file_get_contents($entry->getPathname());if($content===false)continue;
 $write=preg_match('/\$_POST|\$_FILES|REQUEST_METHOD|\b(INSERT|UPDATE|DELETE)\s+(INTO|FROM|[a-z_])/i',$content)===1;
 $token=preg_match('/arx_check_post|arca_verificar_token|hash_equals\s*\(|csrf_token/', $content)===1;
 $auth=preg_match('/arx_boot\s*\(|arca_requerir_roles\s*\(|a22_guard_legacy|\$_SESSION\s*\[\s*[\'\"]rol_activo/', $content)===1;
 $raw=preg_match('/->query\s*\(\s*[\'\"](?:SELECT|UPDATE|INSERT|DELETE)[^\n]*\$[a-z_]+/i',$content)===1;
 $upload=str_contains($content,'move_uploaded_file');
 $issues=[];
 if(!$auth && !$write && str_contains($content,'require_once')){} // Página informativa: revisar caso por caso.
 if($write&&!$token)$issues[]='POSIBLE_ESCRITURA_SIN_CSRF';
 if($write&&!$auth)$issues[]='POSIBLE_ESCRITURA_SIN_ROL';
 if($raw)$issues[]='SQL_DINAMICO_REVISAR';
 if($upload)$issues[]='CARGA_ARCHIVO_REVISAR';
 if(!$auth)$issues[]='SIN_BARRERA_DE_ROL_IDENTIFICABLE';
 if($issues)$items[]=['archivo'=>$file,'hallazgos'=>$issues];$count++;
}
echo "ARCA Fase 26 — inventario preliminar de archivos PHP\n";
echo "Archivos raíz inspeccionados: $count\n";
echo "Archivos para revisión manual: ".count($items)."\n";
foreach($items as $entry)echo str_pad($entry['archivo'],38).implode(', ',$entry['hallazgos'])."\n";
echo "\nEste informe es heurístico. Puede tener falsos positivos y NO equivale a un pentest.\n";
