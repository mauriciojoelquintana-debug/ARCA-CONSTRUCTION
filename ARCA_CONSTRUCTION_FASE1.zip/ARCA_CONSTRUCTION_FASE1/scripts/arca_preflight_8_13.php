<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal CLI');}
// Script opcional. No altera datos ni imprime credenciales.
try {
  require __DIR__.'/../conexion.php';
  if(!isset($conectar)||!($conectar instanceof mysqli))throw new RuntimeException('No hay conexión mysqli');
  $db=$conectar;
  $n=$db->query('SELECT DATABASE() as db')->fetch_assoc()['db']??'';
  echo "Base activa: $n\n";
  if($n!=='arca_bd_fase1'){fwrite(STDERR,"ALERTA: base distinta de arca_bd_fase1; no ejecutes migraciones aquí.\n");exit(2);}
  $checks=[
    'arca_departamentos_gerencias'=>['id_departamento','id_gerencia'],
    'arca_proveedores_compras'=>['id_proveedor','identificador'],
    'arca_cotizaciones_compra'=>['id_cotizacion','id_solicitud','moneda'],
    'arca_ordenes_compra'=>['id_orden','total','moneda'],
    'arca_auditoria_modulos'=>['id_evento','usuario_id'],
    'finanzas_coo'=>['id_finanza','moneda','categoria_costo'],
    'arca_empleados'=>['id_empleado','numero_empleado'],
    'arca_solicitudes_compra'=>['id_solicitud','moneda']
  ];
  $bad=false;
  foreach($checks as $table=>$cols){
    $st=$db->prepare('SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');$st->bind_param('s',$table);$st->execute();$actual=array_column($st->get_result()->fetch_all(MYSQLI_ASSOC),'COLUMN_NAME');
    $missing=array_diff($cols,$actual);if($missing){$bad=true;echo "FALTA: $table / ".implode(',',$missing)."\n";}else echo "OK: $table\n";
  }
  echo $bad?"Faltan columnas/tablas. Revisa la migración 01_fases_8_13.sql.\n":"Preflight estático correcto. Falta probar cada operación por rol y obra.\n";
  exit($bad?1:0);
}catch(Throwable $e){fwrite(STDERR,'Conexión/consulta falló. Revisa Laragon y error_log del servidor. Código: '.$e->getCode()."\n");exit(1);}
