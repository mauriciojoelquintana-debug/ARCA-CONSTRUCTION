<?php
declare(strict_types=1);
/** Instalador no destructivo. --apply aplica; sin parámetros solo informa. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Solo terminal');}
$root=dirname(__DIR__);
$apply=in_array('--apply',$argv,true);
$targets=[
 'panel_ceo.php','panel_cfo.php','panel_coo.php','panel_cio.php','panel_cto.php',
 'panel_cco.php','panel_cmo.php','panel_chro.php','panel_cso.php',
 'panel_estructura_arca.php','panel_departamentos_arca.php','panel_ingenieria.php',
 'panel_administrativo.php','panel_ejecutivo.php','panel_operativo.php',
 'historial_materiales.php','formulario_inventario.php','mis_obras.php',
 'soporte_tecnico.php','reportes_sql.php','desglose_federal.php',
 'ver_agenda.php','formulario_agenda.php','buscador_agenda.php',
 'resultados_agenda.php','formulario_alta_empleado.php',
 'subir_planos.php','panel_oficina_almacen.php'
];
// Al momento únicamente estas 5 rutas reciben además un guard de rol explícito.
// Las demás se modifican SOLO para agregar el acceso al portal.
$guarded=['reportes_sql.php','soporte_tecnico.php','desglose_federal.php','panel_ejecutivo.php','panel_ingenieria.php'];
$backup=dirname($root,2).DIRECTORY_SEPARATOR.'arca_respaldo_fase22_'.date('Ymd_His');
if(!$apply)echo "SIMULACIÓN: no se escribirán archivos. Para instalar, usa --apply.\n";
$changed=0;$skipped=0;
foreach($targets as $file){
 $path=$root.DIRECTORY_SEPARATOR.$file;
 if(!is_file($path)){echo "OMITIDO (no existe): $file\n";$skipped++;continue;}
 $old=file_get_contents($path);
 if($old===false || !str_contains($old,'</body>')){echo "OMITIDO (sin cierre body): $file\n";$skipped++;continue;}
 if(str_contains($old,'ARCA22_PORTAL_INYECTADO')){echo "YA INSTALADO: $file\n";$skipped++;continue;}
 $code=$old;
 // El link es visual y no concede privilegios. Evita insertar rutas inseguras vía Javascript.
 $footer='<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.\'/includes/arca22_accesos.php\'; a22_barra_flotante(); ?>';
 $code=preg_replace('~</body>~i',$footer.'</body>',$code,1);
 if(in_array($file,$guarded,true)){
  if(!preg_match('/^<\?php\b/',$code)){echo "OMITIDO (inicio PHP inesperado): $file\n";$skipped++;continue;}
  // Evita alertas por session_start() repetido (el guard abre primero la sesión).
  $code=preg_replace('/\bsession_start\s*\(\s*\)\s*;/','if(session_status() !== PHP_SESSION_ACTIVE) session_start();',$code);
  $injection="\n/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('".$file."');\n";
  $code=preg_replace('/^<\?php\b/','<?php'.$injection,$code,1);
 }
 if($apply){
  if(!is_dir($backup)&&!mkdir($backup,0700,true)&&!is_dir($backup))throw new RuntimeException('No se creó la carpeta de respaldo');
  if(file_put_contents($backup.DIRECTORY_SEPARATOR.$file,$old,LOCK_EX)===false)throw new RuntimeException('Fallo de respaldo: '.$file);
  if(file_put_contents($path,$code,LOCK_EX)===false)throw new RuntimeException('Fallo de escritura: '.$file);
 }
 echo ($apply?'ACTUALIZADO: ':'PREPARADO: ').$file.(in_array($file,$guarded,true)?' [con guard de rol]':' [enlace visual]')."\n";
 $changed++;
}
echo "Resultado: $changed disponibles / $skipped omitidos.\n";
if($apply)echo "Respaldo independiente: $backup\n";
