<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit("Ejecuta desde la terminal de Laragon.\n");
$root=dirname(__DIR__);
function db_arca20(): mysqli {require __DIR__.'/../conexion.php';return $conectar;}
try{$db=db_arca20();$name=$db->query('SELECT DATABASE() nombre')->fetch_assoc()['nombre']??'';echo "Base utilizada: $name\n";
if($name!=='arca_bd_fase1')echo "ADVERTENCIA: no estás utilizando arca_bd_fase1.\n";
foreach(['obras_coo','planos_oficina_tecnica','inventario_almacen_arca','arca_maquinaria_obra','arca_movimientos_material','arca_auditoria_modulos','arca_accesos_obra'] as $table){
  $st=$db->prepare('SHOW TABLES LIKE ?');$st->bind_param('s',$table);$st->execute();$ok=(bool)$st->get_result()->fetch_row();$st->close();echo ($ok?'OK':'FALTA').": $table\n";
}
foreach(['panel_oficina_almacen.php','arca20_descargar_plano.php','includes/arca20.php','assets/css/arca20.css','assets/css/arca21-legacy.css'] as $file)echo (is_file($root.'/'.$file)?'OK':'FALTA').": archivo $file\n";
$dir=dirname($root,2).DIRECTORY_SEPARATOR.'arca_archivos_privados'.DIRECTORY_SEPARATOR.'planos';echo "Planos privados previstos: $dir\n";
echo "Asegúrate de probar lectura, escritura y roles dentro del navegador.\n";
}catch(Throwable $e){echo "ERROR: ".$e->getMessage()."\n";exit(1);}
