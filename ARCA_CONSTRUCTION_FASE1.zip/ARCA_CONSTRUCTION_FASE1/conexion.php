<?php
// ARCA · configuración de conexión compatible con el código existente.
// Preferir variables de entorno en otros equipos/servidores. Los valores de
// respaldo están previstos únicamente para Laragon LOCAL.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$host = getenv('ARCA_DB_HOST') ?: 'localhost';
$usuario = getenv('ARCA_DB_USER') ?: 'root';
$password = getenv('ARCA_DB_PASSWORD') !== false ? getenv('ARCA_DB_PASSWORD') : '';
$basedatos = getenv('ARCA_DB_NAME') ?: 'arca_bd_fase1';
try {
    $conectar = new mysqli($host, $usuario, $password, $basedatos);
    $conectar->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    error_log('ARCA: error al conectar con la base de datos: ' . $e->getMessage());
    http_response_code(503);
    exit('El servicio de información no está disponible. Comunícate con el área de Sistemas.');
}
