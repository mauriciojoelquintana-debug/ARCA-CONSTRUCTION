<?php
session_start();
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';
$roles_tecnicos = [
    'Ingeniero Civil', 'Arquitecto', 'Residente de Obra', 'Supervisor de Obra', 
    'Ingeniero', 'Topógrafo', 'CTO', 'COO', 'Director de Construcción', 'Gerente de Proyectos'
];

if (!in_array($rol_limpio, $roles_tecnicos)) {
    header("Location: ingreso.html");
    exit();
}

include("conexion.php");

$nombre_material = $_POST['nombre_material'];
$cantidad        = $_POST['cantidad'];
$tipo_movimiento = $_POST['tipo_movimiento'];
$numero_empleado = $_POST['numero_empleado'];

$stmt = $conectar->prepare("INSERT INTO inventario (nombre_material, cantidad, tipo_movimiento, numero_empleado) VALUES (?, ?, ?, ?)");
$stmt->bind_param("siss", $nombre_material, $cantidad, $tipo_movimiento, $numero_empleado);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Procesando Registro...</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 50px; }
        .mensaje-box { background: white; padding: 40px; border-radius: 8px; display: inline-block; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-top: 4px solid #27ae60; }
        .btn-volver { display: inline-block; background: #34495e; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="mensaje-box">
        <?php
        if ($stmt->execute()) {
            echo "<h2 style='color: #27ae60;'>✅ Registro Guardado Exitosamente</h2>";
            echo "<p>El movimiento de <b>$cantidad</b> unidades de <b>$nombre_material</b> ha sido registrado correctamente por el técnico <b>$numero_empleado</b>.</p>";
        } else {
            echo "<h2 style='color: #e74c3c;'>❌ Error al insertar el registro</h2>";
            echo "<p>Detalle técnico: " . $stmt->error . "</p>";
        }
        $stmt->close();
        $conectar->close();
        ?>
        <br>
        <a href="registro_material.html" class="btn-volver">Registrar otro material</a>
        <a href="historial_materiales.php" class="btn-volver" style="background-color: #f39c12;">Ver Tabla de Almacén</a>
    </div>
</body>
</html>