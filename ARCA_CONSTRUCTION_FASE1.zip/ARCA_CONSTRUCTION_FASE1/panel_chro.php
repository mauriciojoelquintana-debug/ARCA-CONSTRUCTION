<?php
// ARCA CONSTRUCTION · Fase 2, dirección CHRO.
$arca_area = 'CHRO';
require __DIR__ . '/includes/panel_directivo.php';
