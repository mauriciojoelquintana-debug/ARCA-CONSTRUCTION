<?php
session_start();
if (!isset($_SESSION['rol_activo']) || (trim($_SESSION['rol_activo']) !== 'CEO' && trim($_SESSION['rol_activo']) !== 'Director General')) {
    header("Location: ingreso.html");
    exit();
}
include("conexion.php");

$q_direcciones     = $conectar->query("SELECT * FROM direcciones_arca ORDER BY id_direccion ASC");
$q_gerencias       = $conectar->query("SELECT g.*, d.titular_cargo FROM gerencias_arca g JOIN direcciones_arca d ON g.codigo_dir = d.codigo_dir ORDER BY g.id_gerencia ASC");
$q_puestos         = $conectar->query("SELECT * FROM catalogo_puestos_arca ORDER BY id_puesto ASC");
$q_ubicaciones     = $conectar->query("SELECT * FROM instalaciones_arca ORDER BY id_instalacion ASC");
$q_asignacion      = $conectar->query("SELECT * FROM asignaciones_obra_arca ORDER BY id_asignacion ASC");
$q_subcontratistas = $conectar->query("SELECT * FROM subcontratistas_arca ORDER BY id_subcontratista ASC");
$q_permisos        = $conectar->query("SELECT * FROM permisos_sistema_arca ORDER BY id_permiso ASC");

$enlaces_paneles = [
    'CEO'  => 'panel_ceo.php',
    'CFO'  => 'panel_cfo.php',
    'COO'  => 'panel_coo.php',
    'CIO'  => 'panel_cio.php',
    'CTO'  => 'panel_cto.php',
    'CCO'  => 'panel_cco.php',
    'CMO'  => 'panel_cmo.php',
    'CHRO' => 'panel_chro.php',
    'CSO'  => 'panel_cso.php'
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ARCA CONSTRUCTION | ERP Gobierno Corporativo (CEO)</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #070b14;
            color: #e2e8f0;
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 280px;
            background-color: #0b1120;
            border-right: 1px solid #1e293b;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .brand {
            padding: 24px 20px;
            border-bottom: 1px solid #1e293b;
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
        }
        .brand h1 { margin: 0; font-size: 18px; letter-spacing: 1px; color: #ffffff; }
        .brand span { font-size: 12px; color: #93c5fd; display: block; margin-top: 4px; }

        .user-card {
            padding: 16px 20px;
            border-bottom: 1px solid #1e293b;
            background-color: #0f172a;
        }
        .user-card .badge-nivel {
            background-color: #1d4ed8;
            color: #ffffff;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 6px;
        }
        .user-card h4 { margin: 0; font-size: 14px; color: #f8fafc; }
        .user-card p { margin: 2px 0 0 0; font-size: 12px; color: #94a3b8; }

        .nav-section {
            padding: 14px 20px 6px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #64748b;
            font-weight: bold;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 20px;
            color: #cbd5e1;
            text-decoration: none;
            font-size: 13px;
            border-left: 3px solid transparent;
            transition: 0.2s;
        }
        .nav-link:hover, .nav-link.active {
            background-color: #1e293b;
            color: #ffffff;
            border-left-color: #f59e0b;
        }

        .logout-box {
            margin-top: auto;
            padding: 20px;
            border-top: 1px solid #1e293b;
        }
        .btn-logout {
            display: block;
            width: 100%;
            text-align: center;
            background-color: #dc2626;
            color: #ffffff;
            padding: 10px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 13px;
        }

        .main-content {
            margin-left: 280px;
            flex: 1;
            padding: 30px 40px;
        }
        .top-banner {
            background: linear-gradient(90deg, #172554 0%, #0f172a 100%);
            border: 1px solid #1e3a8a;
            border-radius: 12px;
            padding: 24px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .top-banner h2 { margin: 0 0 6px 0; font-size: 24px; color: #ffffff; }
        .top-banner p { margin: 0; font-size: 14px; color: #93c5fd; }

        .btn-gestion-obra {
            background-color: #f59e0b;
            color: #000;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        .btn-gestion-obra:hover { background-color: #d97706; transform: translateY(-2px); }

        .niveles-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 12px;
            margin-bottom: 35px;
        }
        .nivel-card { padding: 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); text-align: center; }
        .n0 { background-color: #172554; border-top: 4px solid #3b82f6; }
        .n1 { background-color: #1e3a5f; border-top: 4px solid #60a5fa; }
        .n2 { background-color: #1f4e5f; border-top: 4px solid #38bdf8; }
        .n3 { background-color: #265c4b; border-top: 4px solid #34d399; }
        .n4 { background-color: #4b5d3b; border-top: 4px solid #a3e635; }
        .n5 { background-color: #6b5335; border-top: 4px solid #fbbf24; }
        .nivel-card span { font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .nivel-card h4 { margin: 8px 0 6px 0; font-size: 14px; color: #fff; }
        .nivel-card p { margin: 0; font-size: 11px; color: #cbd5e1; }

        .section-title {
            font-size: 18px;
            color: #f8fafc;
            margin: 35px 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #1e293b;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .direcciones-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
            margin-bottom: 35px;
        }
        .dir-card {
            background-color: #0f172a;
            border: 1px solid #1e293b;
            border-radius: 10px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: 0.2s;
        }
        .dir-card:hover { border-color: #3b82f6; transform: translateY(-2px); }
        .dir-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .dir-sigla { font-size: 18px; font-weight: bold; color: #60a5fa; }
        .dir-badge { background: #1e293b; color: #94a3b8; font-size: 11px; padding: 4px 8px; border-radius: 12px; }
        .dir-card h3 { margin: 0 0 8px 0; font-size: 15px; color: #f8fafc; }
        .dir-card p { margin: 0 0 15px 0; font-size: 12px; color: #94a3b8; line-height: 1.5; }
        .btn-auditar {
            display: inline-block;
            background: #1e293b;
            color: #93c5fd;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            border: 1px solid #334155;
            transition: 0.2s;
        }
        .btn-auditar:hover { background: #2563eb; color: #ffffff; border-color: #2563eb; }

        .table-wrap {
            background-color: #0f172a;
            border: 1px solid #1e293b;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 35px;
        }
        table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
        th { background-color: #1e293b; color: #93c5fd; padding: 12px 15px; font-weight: 600; }
        td { padding: 12px 15px; border-bottom: 1px solid #1e293b; color: #cbd5e1; vertical-align: top; }
        tr:hover td { background-color: #131c31; }

        .tag-pub { background: #064e3b; color: #34d399; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .tag-sec { background: #4c1d95; color: #c4b5fd; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .tag-corp { background: #1e3a8a; color: #93c5fd; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="brand">
            <h1>ARCA CONSTRUCTION</h1>
            <span>Sistema ERP • Gobierno Corporativo</span>
        </div>
        <div class="user-card">
            <span class="badge-nivel"><?php echo $_SESSION['nivel_jerarquico'] ?? 'Nivel 0'; ?></span>
            <h4><?php echo $_SESSION['nombre_usuario']; ?></h4>
            <p>ID: <?php echo $_SESSION['usuario_activo']; ?> | Rol: <?php echo $_SESSION['rol_activo']; ?></p>
        </div>

        <div class="nav-section">Estructura ARCA</div>
        <a href="#niveles" class="nav-link active">🏛️ 1. Niveles Jerárquicos (0-5)</a>
        <a href="#direcciones" class="nav-link">👔 2. Las 8 Direcciones + Apoyo</a>
        <a href="#gerencias" class="nav-link">📂 3. Segundo Nivel: Gerencias</a>
        <a href="#catalogo" class="nav-link">🪪 4. Catálogo de Puestos</a>
        <a href="#ubicaciones" class="nav-link">📍 5. Instalaciones y 10 Obras</a>
        <a href="#matriz-obra" class="nav-link">🏗️ 6. Relación Depto vs. Obra</a>
        <a href="#subcontratistas" class="nav-link">🤝 7. Empresas Subcontratistas</a>
        <a href="#permisos" class="nav-link">🔐 8. Permisos de Sistema RBAC</a>

        <div class="logout-box">
            <a href="cerrar_sesion.php" class="btn-logout">Cerrar Sesión Segura</a>
        </div>
    </div>

    <div class="main-content">

        <div class="top-banner" id="niveles">
            <div>
                <h2>CONSTRUCTORA ARCA — Arquitectura Organizacional y Operativa</h2>
                <p>Correlación integral entre las 8 Direcciones Ejecutivas, Gerencias, Subcontratistas, Permisos y las 10 Obras Activas.</p>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="panel_estructura_arca.php" class="btn-gestion-obra">⚙️ Frentes y Cuadrillas</a>
                <a href="panel_oficina_almacen.php" class="btn-gestion-obra" style="background-color: #38bdf8;">📐 Oficina Técnica y Almacén</a>
            </div>
        </div>

        <div class="niveles-grid">
            <div class="nivel-card n0"><span>Nivel 0</span><h4>CEO — Dirección General</h4><p>Máxima autoridad ejecutiva</p></div>
            <div class="nivel-card n1"><span>Nivel 1</span><h4>Directores Ejecutivos</h4><p>CFO • COO • CIO • CTO • CCO • CMO • CHRO • CSO</p></div>
            <div class="nivel-card n2"><span>Nivel 2</span><h4>Gerencias</h4><p>Responsables de departamentos y proyectos</p></div>
            <div class="nivel-card n3"><span>Nivel 3</span><h4>Jefaturas y Coordinaciones</h4><p>Residentes, Oficina Técnica y Planeación</p></div>
            <div class="nivel-card n4"><span>Nivel 4</span><h4>Supervisores y Especialistas</h4><p>Ingenieros, Arquitectos, SST y Calidad</p></div>
            <div class="nivel-card n5"><span>Nivel 5</span><h4>Técnicos y Operativos</h4><p>Maestros de obra, almacenistas y cuadrillas</p></div>
        </div>

        <div class="section-title" id="direcciones">
            <span>2. Organigrama Principal: CEO, 8 Direcciones Ejecutivas y 4 Áreas de Apoyo</span>
            <span style="font-size: 12px; color: #94a3b8;">Acceso directo de auditoría ejecutiva para el CEO</span>
        </div>
        <div class="direcciones-grid">
            <?php while($dir = $q_direcciones->fetch_assoc()) { 
                $cargo_titular = $dir['titular_cargo'];
                $link_panel = isset($enlaces_paneles[$cargo_titular]) ? $enlaces_paneles[$cargo_titular] : 'panel_estructura_arca.php';
            ?>
            <div class="dir-card">
                <div>
                    <div class="dir-header">
                        <span class="dir-sigla"><?php echo $cargo_titular; ?></span>
                        <span class="dir-badge"><?php echo $dir['nivel_jerarquico'] . " • " . $dir['total_gerencias']; ?> gerencias</span>
                    </div>
                    <h3><?php echo $dir['nombre_direccion']; ?></h3>
                    <p><?php echo $dir['enfoque_control']; ?></p>
                </div>
                <a href="<?php echo $link_panel; ?>" class="btn-auditar">Abrir Tablero de <?php echo $cargo_titular; ?> →</a>
            </div>
            <?php } ?>
        </div>

        <div class="section-title" id="gerencias">
            <span>3. Segundo Nivel: Desglose de Gerencias, Departamentos y Puestos Subordinados</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>Dirección</th>
                    <th>Gerencia (Nivel 2)</th>
                    <th>Departamentos / Equipos</th>
                    <th>Puestos Subordinados (Niveles 3, 4 y 5)</th>
                </tr>
                <?php while($ger = $q_gerencias->fetch_assoc()) { ?>
                <tr>
                    <td><b style="color: #60a5fa;"><?php echo $ger['titular_cargo']; ?></b></td>
                    <td><b style="color: #f8fafc;"><?php echo $ger['nombre_gerencia']; ?></b></td>
                    <td><?php echo $ger['departamentos_incluidos']; ?></td>
                    <td style="color: #94a3b8;"><?php echo $ger['puestos_subordinados']; ?></td>
                </tr>
                <?php } ?>
            </table>
        </div>

        <div class="section-title" id="catalogo">
            <span>4. Catálogo Maestro de Puestos de ARCA</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>Código</th>
                    <th>Nivel</th>
                    <th>Cargo / Puesto</th>
                    <th>Área de Pertenencia</th>
                    <th>Superior Jerárquico</th>
                    <th>Responsabilidad y Permisos en el ERP</th>
                </tr>
                <?php while($pto = $q_puestos->fetch_assoc()) { ?>
                <tr>
                    <td style="font-family: monospace; color: #f59e0b;"><?php echo $pto['codigo_puesto']; ?></td>
                    <td><b><?php echo $pto['nivel_jerarquico']; ?></b></td>
                    <td style="color: #ffffff; font-weight: 600;"><?php echo $pto['nombre_cargo']; ?></td>
                    <td><?php echo $pto['direccion_pertenencia']; ?></td>
                    <td><?php echo $pto['superior_inmediato']; ?></td>
                    <td>
                        <div><?php echo $pto['responsabilidad_principal']; ?></div>
                        <div style="color: #38bdf8; font-size: 12px; margin-top: 4px;"><b>Permisos ERP:</b> <?php echo $pto['permisos_sistema']; ?></div>
                    </td>
                </tr>
                <?php } ?>
            </table>
        </div>

        <div class="section-title" id="ubicaciones">
            <span>5. Jerarquía de Ubicaciones Físicas: Oficinas, Almacenes y las 10 Obras de ARCA</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>Código</th>
                    <th>Tipo de Instalación</th>
                    <th>Nombre de la Ubicación / Proyecto</th>
                    <th>Ciudad / Región</th>
                    <th>Clasificación</th>
                    <th>Responsable Titular</th>
                    <th>Plantilla</th>
                </tr>
                <?php while($ubi = $q_ubicaciones->fetch_assoc()) { 
                    $tag = 'tag-corp';
                    if(strpos($ubi['clasificacion_seguridad'], 'Pública') !== false) $tag = 'tag-pub';
                    if(strpos($ubi['clasificacion_seguridad'], 'Secreta') !== false) $tag = 'tag-sec';
                ?>
                <tr>
                    <td style="font-family: monospace; font-weight: bold; color: #93c5fd;"><?php echo $ubi['codigo_instalacion']; ?></td>
                    <td><?php echo $ubi['tipo_ubicacion']; ?></td>
                    <td style="color: #ffffff; font-weight: 600;"><?php echo $ubi['nombre_instalacion']; ?></td>
                    <td><?php echo $ubi['ciudad_region']; ?></td>
                    <td><span class="<?php echo $tag; ?>"><?php echo $ubi['clasificacion_seguridad']; ?></span></td>
                    <td><?php echo $ubi['responsable_instalacion']; ?></td>
                    <td><b><?php echo $ubi['personal_activo']; ?></b> pers.</td>
                </tr>
                <?php } ?>
            </table>
        </div>

        <div class="section-title" id="matriz-obra">
            <span>6. Matriz Relacional: Dependencia Organizacional vs. Asignación Operativa en Obra</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>ID / Personal</th>
                    <th>Cargo y Nivel</th>
                    <th>Dependencia Organizacional</th>
                    <th>Obra Asignada</th>
                    <th>Área de Obra (6 Ramas)</th>
                    <th>Frente / Cuadrilla</th>
                    <th>Vínculo</th>
                </tr>
                <?php while($asig = $q_asignacion->fetch_assoc()) { ?>
                <tr>
                    <td><b style="color: #f8fafc;"><?php echo $asig['nombre_personal']; ?></b><br><span style="font-size:11px; color:#64748b;"><?php echo $asig['num_empleado']; ?></span></td>
                    <td><?php echo $asig['puesto_cargo']; ?><br><span style="font-size:11px; color:#f59e0b;"><?php echo $asig['nivel_jerarquico']; ?></span></td>
                    <td style="color: #93c5fd;"><?php echo $asig['dependencia_organizacional']; ?></td>
                    <td><b style="color: #34d399;"><?php echo $asig['obra_asignada']; ?></b></td>
                    <td><?php echo $asig['area_dentro_obra']; ?></td>
                    <td><?php echo $asig['frente_cuadrilla']; ?></td>
                    <td><?php echo $asig['tipo_contratacion']; ?></td>
                </tr>
                <?php } ?>
            </table>
        </div>

        <div class="section-title" id="subcontratistas">
            <span>7. Padrón de Empresas Subcontratistas Autorizadas en las 10 Obras</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>Contrato</th>
                    <th>Empresa Subcontratista</th>
                    <th>Especialidad / Actividad en Obra</th>
                    <th>Obra Asignada</th>
                    <th>Personal Autorizado</th>
                    <th>Responsable Externo</th>
                    <th>Vigencia / Estado</th>
                </tr>
                <?php if($q_subcontratistas) { while($sub = $q_subcontratistas->fetch_assoc()) { ?>
                <tr>
                    <td style="font-family: monospace; color: #f59e0b;"><?php echo $sub['folio_contrato']; ?></td>
                    <td><b style="color: #ffffff;"><?php echo $sub['empresa_contratista']; ?></b></td>
                    <td><?php echo $sub['especialidad_actividad']; ?></td>
                    <td><b style="color: #34d399;"><?php echo $sub['codigo_obra']; ?></b></td>
                    <td><b><?php echo $sub['personal_autorizado']; ?></b> técnicos</td>
                    <td><?php echo $sub['responsable_externo']; ?></td>
                    <td><?php echo $sub['vigencia_contrato']; ?><br><span style="color:#60a5fa; font-size:11px; font-weight:bold;"><?php echo $sub['estado_acceso']; ?></span></td>
                </tr>
                <?php } } ?>
            </table>
        </div>

        <div class="section-title" id="permisos">
            <span>8. Matriz de Permisos Jerárquicos y Protección de Datos Sensibles (RBAC)</span>
        </div>
        <div class="table-wrap">
            <table>
                <tr>
                    <th>Nivel</th>
                    <th>Puesto / Nivel Organizacional</th>
                    <th>Qué información puede consultar</th>
                    <th>Qué puede modificar / gestionar</th>
                    <th>Qué puede autorizar</th>
                    <th>Protección de Datos Sensibles</th>
                </tr>
                <?php if($q_permisos) { while($per = $q_permisos->fetch_assoc()) { ?>
                <tr>
                    <td><b style="color: #f59e0b;"><?php echo $per['nivel_jerarquico']; ?></b></td>
                    <td><b style="color: #ffffff;"><?php echo $per['rol_puesto']; ?></b></td>
                    <td><?php echo $per['puede_consultar']; ?></td>
                    <td><?php echo $per['puede_modificar']; ?></td>
                    <td style="color: #34d399;"><?php echo $per['puede_autorizar']; ?></td>
                    <td style="color: #fca5a5; font-size: 12px;"><?php echo $per['restriccion_datos_sensibles']; ?></td>
                </tr>
                <?php } } ?>
            </table>
        </div>

    </div>

</body>
</html>  