<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_integracion.php';
$db=arx_boot(['CEO','CIO']);arx_check_post();
try{
 $codigo=arx_text($_POST['codigo']??'',35);$estado=(string)($_POST['estado']??'');$evidencia=arx_text($_POST['evidencia']??'',400);
 if(!in_array($estado,['PENDIENTE','VERIFICADO'],true))throw new InvalidArgumentException('Estado no permitido.');
 $db->begin_transaction();$old=arx_one($db,'SELECT estado,evidencia FROM arca_revision_despliegue WHERE codigo=? FOR UPDATE',[$codigo]);if(!$old)throw new InvalidArgumentException('Control no reconocido.');
 arx_exec($db,'UPDATE arca_revision_despliegue SET estado=?,evidencia=?,verificado_por=?,verificado_en=NOW() WHERE codigo=?',[$estado,$evidencia,arx_uid(),$codigo]);
 arx_audit($db,'SEGURIDAD','arca_revision_despliegue',0,'REVISAR',['codigo'=>$codigo,'estado'=>$old['estado']],['estado'=>$estado,'evidencia'=>$evidencia]);$db->commit();arx_flash('Revisión registrada; no implica autorización de puesta en producción.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $ignore){}error_log('ARCA checklist: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'Error de validación; consulta el log.',true);}
arx_redirect('arca_lanzamiento.php');
