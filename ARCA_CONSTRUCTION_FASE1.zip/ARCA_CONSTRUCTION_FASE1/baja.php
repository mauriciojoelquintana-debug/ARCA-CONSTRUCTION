<?php
session_start();
$rol_limpio = isset($_SESSION['rol_activo']) ? trim($_SESSION['rol_activo']) : '';
$roles_admin = ['Secretaria', 'Secretaria / Asistente', 'CEO', 'CIO', 'COO', 'Director General', 'Ejecutivo'];

if (!in_array($rol_limpio, $roles_admin)) {
    header("Location: ingreso.html");
    exit();
}

include("conexion.php");

$numero_empleado = $_POST['numero_empleado'];
$stmt = $conectar->prepare("DELETE FROM usuarios WHERE numero_empleado = ?");
$stmt->bind_param("s", $numero_empleado);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Procesando Baja...</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 50px; }
        .mensaje-box { background: white; padding: 40px; border-radius: 8px; display: inline-block; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-top: 4px solid #e74c3c; }
        .btn-volver { display: inline-block; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 20px; margin-right: 10px; }
    </style>
</head>
<body>
    <div class="mensaje-box">
        <?php
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo "<h2 style='color: #27ae60;'>✅ Baja Procesada Exitosamente</h2>";
                echo "<p>El usuario con la credencial <b>$numero_empleado</b> ha sido eliminado de la constructora.</p>";
            } else {
                echo "<h2 style='color: #f39c12;'>⚠️ Registro no encontrado</h2>";
                echo "<p>No existe ningún empleado con el número <b>$numero_empleado</b>.</p>";
            }
        } else {
            echo "<h2 style='color: #e74c3c;'>❌ Error al procesar la baja</h2>";
            echo "<p>Detalle técnico: " . $stmt->error . "</p>";
        }
        $stmt->close();
        $conectar->close();
        ?>
        <br>
        <a href="baja.html" class="btn-volver" style="background-color: #e74c3c;">Eliminar otro registro</a>
        <a href="panel_administrativo.php" class="btn-volver" style="background-color: #2c3e50;">Volver al Panel</a>
    </div>
</body>
</html>