<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca29_30.php';
$db=a27_boot(['CHRO']);
$real=arx_rows($db,'SELECT c.id_contrato,c.id_empleado,c.tipo,c.inicio,c.estado,e.numero_empleado,e.nombre_completo FROM arca_contratos_laborales c JOIN arca_empleados e ON e.id_empleado=c.id_empleado ORDER BY c.id_contrato DESC LIMIT 200');
$casos=a30_db_demo($db)?arx_rows($db,'SELECT x.id_caso,x.codigo_obra,x.funcion,e.numero_empleado,e.nombre_completo FROM arca30_demo_casos x JOIN arca_empleados e ON e.id_empleado=x.id_empleado ORDER BY x.id_caso DESC LIMIT 200'):[];
$casos=array_values(array_filter($casos,fn($c)=>a30_obra_autorizada($db,(string)$c['codigo_obra'])));
$docs=arx_rows($db,'SELECT d.id_documento,d.origen,d.id_contrato,d.id_demo_caso,d.tipo,d.nombre_original,d.tamano_bytes,d.subido_en,e.numero_empleado,e.nombre_completo FROM arca29_documentos d JOIN arca_empleados e ON e.id_empleado=d.id_empleado ORDER BY d.id_documento DESC LIMIT 200');
$visibleCases=array_column($casos,'id_caso');
$docs=array_values(array_filter($docs,static fn($d)=>$d['origen']==='REAL'||in_array($d['id_demo_caso'],$visibleCases)));
a27_layout('Gestión documental privada','Contratos y anexos PDF almacenados fuera de www. Acceso exclusivo de CHRO. Los documentos DEMO no acreditan contratación.','arca29_documentos.php');
?>
<link rel="stylesheet" href="assets/css/arca29-30.css?v=1">
<section class="a27-card"><h2>Almacenamiento protegido</h2><p class="a27-muted">El servidor guarda documentos con nombre aleatorio fuera del directorio público. Solo CHRO puede descargarlos desde una sesión autorizada. Máximo 6 MB por PDF; no se guardan claves, firmas ni documentos simulados como contratos auténticos.</p></section>
<section class="a27-card"><h2>Subir PDF de contrato registrado</h2><p class="a27-muted">Vincula un PDF con un contrato ya existente. Subirlo <strong>no</strong> lo activa ni valida automáticamente.</p>
<form class="a27-form" action="arca29_guardar.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="origen" value="REAL">
<label>Contrato en CHRO<select name="id_contrato" required><option value="">Selecciona un contrato...</option><?php foreach($real as $c):?><option value="<?=(int)$c['id_contrato']?>"><?=a27_h('#'.$c['id_contrato'].' · '.$c['numero_empleado'].' · '.$c['tipo'].' · '.$c['estado'])?></option><?php endforeach;?></select></label>
<label>Tipo de documento<select name="tipo"><option value="CONTRATO">Contrato</option><option value="ANEXO">Anexo de obra</option><option value="OTRO">Otro documento de expediente</option></select></label>
<label class="a27-wide">PDF (máximo 6 MB)<input type="file" name="pdf" accept=".pdf,application/pdf" required></label>
<button>Guardar documento privado</button></form></section>
<?php if($casos):?><section class="a27-card"><h2>Subir documento de una simulación</h2><p class="a27-muted"><strong>DEMOSTRACIÓN:</strong> estas copias se vinculan exclusivamente al flujo de demostración y no acreditan contratación ni asignación laboral.</p>
<form class="a27-form" action="arca29_guardar.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="origen" value="DEMO">
<label>Caso simulado<select name="id_demo_caso" required><?php foreach($casos as $c):?><option value="<?=(int)$c['id_caso']?>"><?=a27_h('#'.$c['id_caso'].' · '.$c['codigo_obra'].' · '.$c['numero_empleado'].' · '.$c['funcion'])?></option><?php endforeach;?></select></label>
<label>Tipo de documento<select name="tipo"><option value="CONTRATO">Contrato de muestra</option><option value="ANEXO">Anexo de muestra</option><option value="OTRO">Otro ejemplo</option></select></label>
<label class="a27-wide">PDF de demostración (máximo 6 MB)<input type="file" name="pdf" accept=".pdf,application/pdf" required></label><button>Adjuntar PDF DEMO</button></form></section><?php endif;?>
<section class="a27-card"><h2>Documentos registrados</h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Folio</th><th>Ámbito</th><th>Empleado</th><th>Tipo</th><th>Archivo</th><th>Fecha</th><th>Acción</th></tr></thead><tbody>
<?php foreach($docs as $d):?><tr><td>#<?=(int)$d['id_documento']?></td><td><span class="a27-label <?=$d['origen']==='DEMO'?'warn':'ok'?>"><?=a27_h($d['origen'])?></span></td><td><?=a27_h($d['numero_empleado'].' · '.$d['nombre_completo'])?></td><td><?=a27_h($d['tipo'])?></td><td><?=a27_h($d['nombre_original'])?> <small>(<?=round($d['tamano_bytes']/1024)?> KB)</small></td><td><?=a27_h($d['subido_en'])?></td><td><a href="arca29_descargar.php?id=<?=(int)$d['id_documento']?>">Descargar PDF</a></td></tr><?php endforeach;?>
<?php if(!$docs):?><tr><td colspan="7">Todavía no existen documentos registrados.</td></tr><?php endif;?></tbody></table></div></section>
<p class="a27-muted">Siguiente: <a href="arca30_demo.php">flujo de demostración</a> · <a href="chro_personal.php#contratos">Regresar a contratos</a>.</p>
<?php a27_end(); ?>
