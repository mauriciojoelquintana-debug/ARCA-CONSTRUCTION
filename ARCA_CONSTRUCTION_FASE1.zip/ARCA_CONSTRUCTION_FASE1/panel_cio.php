<?php
// ARCA CONSTRUCTION · Fase 2, dirección CIO.
$arca_area = 'CIO';
require __DIR__ . '/includes/panel_directivo.php';
