<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca27.php';$db=a27_boot(['CEO','Director General','CIO']);
$types=['sync'=>'Sincronización de paneles','servidores'=>'Estado de servidores','redes'=>'Redes corporativas','equipos'=>'Mantenimiento de equipos','conectividad'=>'Conectividad en obras','backup'=>'Respaldos de base de datos','firewall'=>'Seguridad informática','encriptacion'=>'Protección de datos'];
$m=(string)($_GET['modulo']??'sync');if(!isset($types[$m]))a27_die('Módulo TI no reconocido.',404);
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 a27_post();if(arx_role()!=='CIO')a27_die();
 try{
  $estado=(string)($_POST['estado']??'');if(!in_array($estado,['PENDIENTE','EN_REVISION','VALIDADO','INCIDENCIA'],true))throw new InvalidArgumentException('Estado incorrecto.');
  $ev=trim((string)($_POST['evidencia']??''));if(strlen($ev)>400)throw new InvalidArgumentException('Evidencia demasiado larga.');
  if($estado==='VALIDADO' && strlen($ev)<15)throw new InvalidArgumentException('Para validar debes identificar una evidencia comprobable.');
  $db->begin_transaction();try{
   $old=arx_one($db,'SELECT estado,evidencia FROM arca27_controles_ti WHERE modulo=? FOR UPDATE',[$m]);if(!$old)throw new InvalidArgumentException('Control TI inexistente.');
   arx_exec($db,'UPDATE arca27_controles_ti SET estado=?,evidencia=?,verificado_por=?,fecha_verificacion=NOW() WHERE modulo=?',[$estado,$ev,arx_uid(),$m]);
   arx_audit($db,'sistemas','control_ti',array_search($m,array_keys($types),true)+1,'VERIFICAR',$old,['modulo'=>$m,'estado'=>$estado,'evidencia'=>$ev]);$db->commit();
  }catch(Throwable $e){$db->rollback();throw $e;}
  a27_alert('Control actualizado con registro de auditoría.');
 }catch(Throwable $e){error_log('[ARCA27_TI] '.$e->getMessage());a27_alert($e instanceof InvalidArgumentException?$e->getMessage():'Error en la actualización.',true);}
 a27_redirect('arca27_ti.php?modulo='.rawurlencode($m));
}
$rows=arx_rows($db,'SELECT modulo,estado,evidencia,verificado_por,fecha_verificacion FROM arca27_controles_ti');$dict=[];foreach($rows as $r)$dict[$r['modulo']]=$r;
$info=$dict[$m]??['estado'=>'PENDIENTE','evidencia'=>null,'fecha_verificacion'=>null];
a27_layout('CIO · '.$types[$m],'Verificación basada en evidencias reales, sin inventar ping, respaldos, latencias ni métricas de red.','arca27_ti.php');
?><section class="a27-grid"><?php foreach($types as $key=>$name):?><a class="a27-card" href="?modulo=<?=a27_h($key)?>" style="text-decoration:none"><h3><?=a27_h($name)?></h3><span class="a27-label <?=($dict[$key]['estado']??'PENDIENTE')==='VALIDADO'?'ok':'warn'?>"><?=a27_h($dict[$key]['estado']??'PENDIENTE')?></span></a><?php endforeach;?></section><section class="a27-card"><h2><?=a27_h($types[$m])?></h2><p><b>Estado:</b> <?=a27_h($info['estado'])?> · <b>Última revisión:</b> <?=a27_h($info['fecha_verificacion']??'No realizada')?></p><p><b>Evidencia:</b> <?=a27_h($info['evidencia']?:'No registrada')?></p><p class="a27-warning">La aplicación no debe afirmar que existe un respaldo cifrado, red disponible o firewall protegido sin verificación externa y evidencia.</p>
<?php if($m==='servidores'):?><p>Versión PHP que atiende esta petición: <b><?=a27_h(PHP_VERSION)?></b>. Estado externo de servidores: <b>no monitorizado aquí</b>.</p><?php endif;?>
<?php if($m==='sync'):?><p>Los paneles se actualizan al consultar o recargar la pantalla. Sincronización de servicios externos: <b>no verificada</b>.</p><?php endif;?>
<?php if(arx_role()==='CIO'):?><form method="post" class="a27-form"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><label>Estado<select name="estado"><?php a27_opt(['PENDIENTE'=>'Pendiente','EN_REVISION'=>'En revisión','VALIDADO'=>'Validado con evidencia','INCIDENCIA'=>'Incidencia'],(string)$info['estado']);?></select></label><label class="a27-wide">Evidencia (ticket interno, fecha, responsable; nunca contraseñas)<textarea name="evidencia" maxlength="400"><?=a27_h($info['evidencia'])?></textarea></label><button>Guardar verificación</button></form><?php endif;?></section><?php a27_end();
