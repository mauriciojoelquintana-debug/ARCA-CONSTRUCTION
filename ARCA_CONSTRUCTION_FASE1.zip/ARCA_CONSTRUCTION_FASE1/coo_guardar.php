<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_core.php';
$db=arx_boot(['COO','Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén']);
arx_check_post();$action=(string)($_POST['accion']??'');$obra='';
try {
    $db->begin_transaction();
    if($action==='conceder') {
        if(arx_role()!=='COO') throw new InvalidArgumentException('Solo COO puede conceder accesos.');
        $uid=arx_int($_POST['id_usuario']??null);
        $obra=arx_code($_POST['codigo_obra']??'');
        $nivel=(string)($_POST['nivel']??'');
        if(!in_array($nivel,['consultar','operar','aprobar'],true))throw new InvalidArgumentException('Nivel inválido.');
        $user=arx_one($db,'SELECT id_usuario,cargo FROM usuarios WHERE id_usuario=?',[$uid]);
        if(!$user || !in_array($user['cargo'],['Gerente de Proyecto','Residente de Obra','Supervisor de Obra','Ingeniero Civil','Ingeniero','Arquitecto','Topógrafo','Almacenista','Jefe de Almacén'],true))throw new InvalidArgumentException('Solo personal operativo puede recibir este permiso.');
        arx_require_obra($db,$obra,'aprobar');
        $before=arx_one($db,'SELECT nivel FROM arca_accesos_obra WHERE id_usuario=? AND codigo_obra=?',[$uid,$obra]);
        arx_exec($db,'INSERT INTO arca_accesos_obra(id_usuario,codigo_obra,nivel,concedido_por) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE nivel=VALUES(nivel),concedido_por=VALUES(concedido_por),fecha_concesion=CURRENT_TIMESTAMP',[$uid,$obra,$nivel,arx_uid()]);
        arx_audit($db,'COO','arca_accesos_obra',$uid,'CONCEDER_ACCESO',$before,['obra'=>$obra,'nivel'=>$nivel]);
    } else {
        $obra=arx_code($_POST['codigo_obra']??'');
        $nivel=$action==='decision'?'aprobar':'operar';arx_require_obra($db,$obra,$nivel);
        if($action==='insumo_nuevo') {
            $codigo=arx_text($_POST['codigo_insumo']??'',50);
            $desc=arx_text($_POST['descripcion']??'',200);
            $categoria=arx_text($_POST['categoria']??'',80);
            $unidad=arx_text($_POST['unidad']??'',40);
            $cantidad=arx_decimal($_POST['cantidad']??'',true);
            $minimo=arx_decimal($_POST['minimo']??'',true);
            if(arx_one($db,'SELECT id_insumo FROM inventario_almacen_arca WHERE codigo_obra=? AND codigo_insumo=?',[$obra,$codigo]))throw new InvalidArgumentException('Código de artículo duplicado en esta obra.');
            $estado=((float)$cantidad<=(float)$minimo)?'Stock Bajo (Reordenar)':'Stock Óptimo';
            arx_exec($db,'INSERT INTO inventario_almacen_arca(codigo_insumo,codigo_obra,categoria_recurso,descripcion_recurso,unidad_medida,cantidad_actual,stock_minimo,ubicacion_almacen,responsable_resguardo,estado_inventario) VALUES(?,?,?,?,?,?,?,?,?,?)',[$codigo,$obra,$categoria,$desc,$unidad,$cantidad,$minimo,'Por asignar',arx_name(),$estado]);
            $id=(int)$db->insert_id;
            arx_audit($db,'COO','inventario_almacen_arca',$id,'ALTA',null,['obra'=>$obra,'codigo'=>$codigo,'cantidad'=>$cantidad]);
        } elseif($action==='avance') {
            $fecha=arx_date((string)($_POST['fecha']??''));
            $planeado=arx_decimal($_POST['planeado']??'',true);$real=arx_decimal($_POST['real']??'',true);
            if((float)$planeado>100||(float)$real>100)throw new InvalidArgumentException('El avance no puede superar 100%.');
            $nota=arx_text($_POST['observaciones']??'',500);
            // Serializa el registro de cortes por obra para impedir que uno antiguo sobrescriba el avance vigente.
            arx_one($db,'SELECT id_obra FROM obras_coo WHERE codigo_obra=? FOR UPDATE',[$obra]);
            $last=arx_one($db,'SELECT MAX(fecha_corte) AS ultima FROM arca_avances_cortes WHERE codigo_obra=?',[$obra]);
            if(!empty($last['ultima']) && $fecha < $last['ultima'])throw new InvalidArgumentException('El nuevo corte no puede ser anterior al último registrado.');
            arx_exec($db,'INSERT INTO arca_avances_cortes(codigo_obra,fecha_corte,avance_planeado,avance_real,observaciones,registrado_por) VALUES(?,?,?,?,?,?)',[$obra,$fecha,$planeado,$real,$nota,arx_uid()]);
            $id=(int)$db->insert_id;
            arx_exec($db,'UPDATE obras_coo SET avance_fisico=? WHERE codigo_obra=?',[(int)round((float)$real),$obra]);
            arx_audit($db,'COO','arca_avances_cortes',$id,'REGISTRAR',null,['obra'=>$obra,'fecha'=>$fecha,'planeado'=>$planeado,'real'=>$real]);
        } elseif($action==='material') {
            $id=arx_int($_POST['id_insumo']??null);$qty=arx_decimal($_POST['cantidad']??'');
            $tipo=(string)($_POST['tipo']??'');if(!in_array($tipo,['ENTRADA','SALIDA'],true))throw new InvalidArgumentException('Tipo incorrecto.');
            $item=arx_one($db,'SELECT id_insumo,codigo_obra,cantidad_actual,stock_minimo,categoria_recurso FROM inventario_almacen_arca WHERE id_insumo=? FOR UPDATE',[$id]);
            if(!$item || $item['codigo_obra']!==$obra)throw new InvalidArgumentException('El material no corresponde a tu obra.');
            $old=(float)$item['cantidad_actual'];$new=round($old+($tipo==='ENTRADA'?1:-1)*(float)$qty,2);
            if($new<0)throw new InvalidArgumentException('Stock insuficiente. No se permite saldo negativo.');
            if($new>9999999999.99)throw new InvalidArgumentException('Stock fuera de rango.');
            $estado=$item['categoria_recurso']==='Maquinaria Pesada'?'En Operación':($new<=(float)$item['stock_minimo']?'Stock Bajo (Reordenar)':'Stock Óptimo');
            arx_exec($db,'UPDATE inventario_almacen_arca SET cantidad_actual=?,estado_inventario=? WHERE id_insumo=?',[$new,$estado,$id]);
            $nota=trim((string)($_POST['observaciones']??''));
            arx_exec($db,'INSERT INTO arca_movimientos_material(id_insumo,codigo_obra,tipo,cantidad,anterior,posterior,observaciones,usuario_id) VALUES(?,?,?,?,?,?,?,?)',[$id,$obra,$tipo,$qty,$old,$new,substr($nota,0,250),arx_uid()]);
            arx_audit($db,'COO','inventario_almacen_arca',$id,$tipo,['cantidad'=>$old],['cantidad'=>$new,'stock'=>$qty]);
        } elseif($action==='maquina') {
            $codigo=arx_text($_POST['codigo_equipo']??'',35);
            if(!preg_match('/^[A-Za-z0-9-]{3,35}$/D',$codigo))throw new InvalidArgumentException('Código de equipo inválido.');
            $desc=arx_text($_POST['descripcion']??'',180);
            $fecha=trim((string)($_POST['mantenimiento']??''));if($fecha!=='')arx_date($fecha);
            arx_exec($db,'INSERT INTO arca_maquinaria_obra(codigo_equipo,codigo_obra,descripcion,fecha_proximo_mantenimiento,creado_por) VALUES(?,?,?,?,?)',[$codigo,$obra,$desc,$fecha?:null,arx_uid()]);
            arx_audit($db,'COO','arca_maquinaria_obra',(int)$db->insert_id,'REGISTRAR',null,['codigo'=>$codigo,'obra'=>$obra]);
        } elseif($action==='maquina_estado') {
            $id=arx_int($_POST['id_maquina']??null);$estado=(string)($_POST['estado']??'');
            if(!in_array($estado,['DISPONIBLE','EN_USO','MANTENIMIENTO','FUERA_SERVICIO'],true))throw new InvalidArgumentException('Estado incorrecto.');
            $m=arx_one($db,'SELECT estado,codigo_obra FROM arca_maquinaria_obra WHERE id_maquina=? FOR UPDATE',[$id]);
            if(!$m||$m['codigo_obra']!==$obra)throw new InvalidArgumentException('Equipo fuera de esta obra.');
            arx_exec($db,'UPDATE arca_maquinaria_obra SET estado=? WHERE id_maquina=?',[$estado,$id]);
            arx_audit($db,'COO','arca_maquinaria_obra',$id,'ESTADO',['estado'=>$m['estado']],['estado'=>$estado]);
        } elseif($action==='solicitud') {
            $desc=arx_text($_POST['descripcion']??'',200);$qty=arx_decimal($_POST['cantidad']??'');$unidad=arx_text($_POST['unidad']??'',30);
            $precio=arx_decimal($_POST['precio']??'',true);$moneda=arx_currency($_POST['moneda']??'');
            arx_exec($db,'INSERT INTO arca_solicitudes_compra(codigo_obra,descripcion,cantidad,unidad,precio_unitario,moneda,solicitado_por) VALUES(?,?,?,?,?,?,?)',[$obra,$desc,$qty,$unidad,$precio,$moneda,arx_uid()]);
            arx_audit($db,'COO','arca_solicitudes_compra',(int)$db->insert_id,'SOLICITAR',null,['obra'=>$obra,'descripcion'=>$desc,'cantidad'=>$qty,'moneda'=>$moneda]);
        } elseif($action==='decision') {
            $id=arx_int($_POST['id_solicitud']??null);
            $estado=(string)($_POST['estado']??'');if(!in_array($estado,['APROBADA','RECHAZADA'],true))throw new InvalidArgumentException('Decisión inválida.');
            $s=arx_one($db,'SELECT codigo_obra,estado,solicitado_por FROM arca_solicitudes_compra WHERE id_solicitud=? FOR UPDATE',[$id]);
            if(!$s || $s['codigo_obra']!==$obra || $s['estado']!=='PENDIENTE')throw new InvalidArgumentException('Solicitud no pendiente de esta obra.');
            if((int)$s['solicitado_por']===arx_uid())throw new InvalidArgumentException('La solicitud debe aprobarla una persona distinta de quien la creó.');
            arx_exec($db,'UPDATE arca_solicitudes_compra SET estado=?,revisado_por=?,fecha_revision=NOW() WHERE id_solicitud=?',[$estado,arx_uid(),$id]);
            arx_audit($db,'COO','arca_solicitudes_compra',$id,'DECISION',['estado'=>'PENDIENTE'],['estado'=>$estado]);
        } else throw new InvalidArgumentException('Acción desconocida.');
    }
    $db->commit();arx_flash('Operación guardada y auditada correctamente.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $ignored){}error_log('ARCA COO: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No fue posible guardar. Consulta el registro de PHP.',true);}
arx_redirect('coo_control.php'.($obra!==''?'?obra='.rawurlencode($obra):''));
