<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca29_30.php';
$db=a27_boot(a30_roles());a30_ensure_demo($db);
$role=arx_role();$funcs=a28_functions();
$obras=array_values(array_filter(arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra'),static fn($w)=>a30_obra_autorizada($db,(string)$w['codigo_obra'],$role==='COO'?'operar':'consultar')));
$allowed=array_column($obras,'codigo_obra');
$people=$role==='CHRO'?arx_rows($db,'SELECT id_empleado,numero_empleado,nombre_completo FROM arca_empleados ORDER BY numero_empleado'):[];
$cases=arx_rows($db,"SELECT x.id_caso,x.id_empleado,x.codigo_obra,x.funcion,x.contrato_tipo,x.inicio,x.fin,x.referencia,x.estado,x.propuesto_por,x.revisado_por,x.creado_en,e.numero_empleado,e.nombre_completo,(SELECT COUNT(*) FROM arca29_documentos d WHERE d.origen='DEMO' AND d.id_demo_caso=x.id_caso) AS pdfs FROM arca30_demo_casos x JOIN arca_empleados e ON e.id_empleado=x.id_empleado ORDER BY x.codigo_obra,x.funcion");
$cases=array_values(array_filter($cases,static fn($c)=>in_array($c['codigo_obra'],$allowed,true)));
$confirmed=0;$pending=0;
foreach($cases as $c){if($c['estado']==='APROBADO'&&a30_fecha_activa($c['inicio'],$c['fin']))$confirmed++;if($c['estado']==='PROPUESTO')$pending++;}
$coverage=[];foreach($cases as $c){$coverage[$c['codigo_obra']][$c['funcion']]=$c;}
a27_layout('Demostración del flujo de aprobación','SIMULACIÓN — CHRO prepara, COO aprueba y CEO consulta. Nunca activa contratos o responsables reales.','arca30_demo.php');
?>
<link rel="stylesheet" href="assets/css/arca29-30.css?v=1">
<section class="a30-warning"><strong>DEMOSTRACIÓN · SIN VALIDEZ LABORAL</strong><p>Los casos y documentos de demostración se registran por separado y no crean contratos, asignaciones ni responsables de obra.</p></section>
<section class="a27-grid">
 <article class="a27-card"><div class="a27-sub">Obras autorizadas</div><div class="a27-metric"><?=count($obras)?></div></article>
 <article class="a27-card"><div class="a27-sub">Funciones simuladas cubiertas</div><div class="a27-metric"><?=$confirmed?></div></article>
 <article class="a27-card"><div class="a27-sub">Propuestas para COO</div><div class="a27-metric"><?=$pending?></div></article>
 <article class="a27-card"><div class="a27-sub">Cobertura laboral validada</div><div class="a27-metric">No modificada</div></article>
</section>
<section class="a27-card"><h2>Matriz de cobertura simulada</h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Obra</th><?php foreach($funcs as $label):?><th><?=a27_h($label)?></th><?php endforeach;?></tr></thead><tbody>
<?php foreach($obras as $w):?><tr><td><strong><?=a27_h($w['codigo_obra'])?></strong><div class="a27-sub"><?=a27_h($w['nombre_proyecto'])?></div></td><?php foreach($funcs as $func=>$label):$c=$coverage[$w['codigo_obra']][$func]??null;$ok=$c&&$c['estado']==='APROBADO'&&a30_fecha_activa($c['inicio'],$c['fin']);?><td><span class="a27-label <?=$ok?'ok':'warn'?>"><?=$ok?'SIMULADO APROBADO':($c?a27_h($c['estado']):'PENDIENTE')?></span><?php if($c):?><div class="a27-sub"><?=a27_h($c['numero_empleado'].' · '.$c['nombre_completo'])?></div><?php endif;?></td><?php endforeach;?></tr><?php endforeach;?>
<?php if(!$obras):?><tr><td colspan="5">Sin obras autorizadas.</td></tr><?php endif;?></tbody></table></div></section>
<?php if($role==='CHRO'):?><section class="a27-card"><h2>Paso 1 · Crear expediente de demostración</h2><p class="a27-muted">Introduce fechas y una referencia de prueba. El caso quedará en BORRADOR hasta que se adjunte un PDF marcado DEMO.</p>
<form class="a27-form" action="arca30_demo_guardar.php" method="post"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="crear">
<label>Empleado de ejemplo<select name="id_empleado" required><?php foreach($people as $p):?><option value="<?=(int)$p['id_empleado']?>"><?=a27_h($p['numero_empleado'].' · '.$p['nombre_completo'])?></option><?php endforeach;?></select></label>
<label>Obra autorizada<select name="codigo_obra" required><?php foreach($obras as $o):?><option value="<?=a27_h($o['codigo_obra'])?>"><?=a27_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></option><?php endforeach;?></select></label>
<label>Función simulada<select name="funcion" required><?php a27_opt($funcs);?></select></label>
<label>Tipo de contrato (ejemplo)<input name="contrato_tipo" maxlength="60" value="Tiempo determinado - DEMO" required></label>
<label>Inicio del periodo ficticio<input type="date" name="inicio" value="2026-10-01" required></label>
<label>Fin del periodo ficticio<input type="date" name="fin" value="2027-09-30"></label>
<label>Referencia de simulación<input name="referencia" maxlength="100" value="DEMOSTRACIÓN - SIN VALIDEZ LABORAL" required></label>
<button>Crear caso en BORRADOR</button></form>
</section><?php endif;?>
<section class="a27-card"><h2>Seguimiento de los casos y aprobaciones</h2><p class="a27-muted">CHRO documenta, asigna y propone. Una cuenta COO distinta puede aprobar o rechazar. CEO solo puede consultar. Los casos vencidos no cuentan como cobertura vigente.</p>
<div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Caso / Obra</th><th>Empleado</th><th>Responsabilidad</th><th>Periodo</th><th>PDF</th><th>Estado</th><th>Acción permitida</th></tr></thead><tbody>
<?php foreach($cases as $c): $state=$c['estado'];$expired=!a30_fecha_activa($c['inicio'],$c['fin']);?><tr><td><strong>#<?=(int)$c['id_caso']?></strong><div class="a27-sub"><?=a27_h($c['codigo_obra'])?></div></td><td><?=a27_h($c['numero_empleado'].' · '.$c['nombre_completo'])?></td><td><?=a27_h($funcs[$c['funcion']]??$c['funcion'])?></td><td><?=a27_h($c['inicio'].' — '.($c['fin']??'Sin término'))?></td><td><?=(int)$c['pdfs']?> PDF</td><td><span class="a27-label <?=($state==='APROBADO'&&!$expired)?'ok':'warn'?>"><?=a27_h($state)?><?=$expired?' (VENCIDO)':''?></span></td><td>
<?php if($role==='CHRO' && $state==='BORRADOR'):?>
<?php if((int)$c['pdfs']>0):?><?=a30_action_form((int)$c['id_caso'],'documentar','Confirmar PDF DEMO')?><?php else:?><a href="arca29_documentos.php">Adjuntar PDF</a><?php endif;?>
<?php elseif($role==='CHRO' && $state==='DOCUMENTADO'):?><?=a30_action_form((int)$c['id_caso'],'asignar','Asignar (DEMO)')?>
<?php elseif($role==='CHRO' && $state==='ASIGNADO'):?><?=a30_action_form((int)$c['id_caso'],'proponer','Enviar a COO')?>
<?php elseif($role==='CHRO' && $state==='RECHAZADO'):?><?=a30_action_form((int)$c['id_caso'],'reabrir','Reabrir simulación')?>
<?php elseif($role==='COO' && $state==='PROPUESTO'):?><?=a30_action_form((int)$c['id_caso'],'aprobar','Aprobar DEMO')?> <?=a30_action_form((int)$c['id_caso'],'rechazar','Rechazar DEMO')?>
<?php else:?>Solo lectura<?php endif;?></td></tr><?php endforeach;?>
<?php if(!$cases):?><tr><td colspan="7">No hay casos simulados todavía. CHRO puede crear el primero arriba.</td></tr><?php endif;?></tbody></table></div></section>
<p class="a27-muted"><?php if($role==='CHRO'):?><a href="arca29_documentos.php">Documentos de demostración (solo CHRO)</a> · <?php endif;?><a href="arca27_equipo_obra.php">Matriz de responsables de obra</a></p>
<?php a27_end(); ?>
<?php
/** Formulario compacto; sin JavaScript, protegido por CSRF. */
function a30_action_form(int $id,string $accion,string $label):string {
    return '<form class="a30-inline" action="arca30_demo_guardar.php" method="post"><input type="hidden" name="csrf_token" value="'.a27_h(arx_token()).'"><input type="hidden" name="id_caso" value="'.$id.'"><input type="hidden" name="accion" value="'.a27_h($accion).'"><button type="submit">'.a27_h($label).'</button></form>';
}
