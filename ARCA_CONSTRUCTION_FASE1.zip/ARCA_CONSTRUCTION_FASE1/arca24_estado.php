<?php
declare(strict_types=1);
// El endpoint de actualización debe devolver JSON incluso ante fallos de sesión y permisos.
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Vary: Cookie');

function a24_responder(int $http, array $payload): never {
    http_response_code($http);
    try {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    } catch (Throwable $error) {
        error_log('[ARCA24 JSON] ' . $error->getMessage());
        echo '{"ok":false,"error":"No fue posible generar la respuesta JSON."}';
    }
    exit;
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        header('Allow: GET');
        a24_responder(405, ['ok'=>false,'error'=>'Método no permitido.']);
    }

    require_once __DIR__ . '/includes/seguridad.php';
    arca_iniciar_sesion();
    if ((int)($_SESSION['id_usuario'] ?? 0) <= 0 || empty($_SESSION['rol_activo'])) {
        a24_responder(401, ['ok'=>false,'error'=>'Sesión finalizada. Inicia sesión nuevamente desde el mismo dominio.']);
    }
    $role = trim((string)$_SESSION['rol_activo']);
    if (!in_array($role, ['CEO','Director General','CFO','COO','CHRO'], true)) {
        a24_responder(403, ['ok'=>false,'error'=>'Tu perfil no tiene acceso a este tablero.']);
    }

    require_once __DIR__ . '/includes/arca24_acceso_seguro.php';
    $db = a26_db();
    $obra = trim((string)($_GET['obra'] ?? ''));
    if ($obra !== '' && !preg_match('/^[A-Z0-9-]{4,30}$/D', $obra)) {
        a24_responder(422, ['ok'=>false,'error'=>'El código de obra no es válido.']);
    }
    $filas = a24_obras_autorizadas($db);
    $codigos = array_values(array_unique(array_map(
        static fn(array $f): string => (string)$f['codigo_obra'], $filas
    )));
    if (!$codigos) {
        a24_responder(403, ['ok'=>false,'error'=>'No tienes obras autorizadas para consulta.']);
    }
    if ($obra !== '') {
        if (!in_array($obra, $codigos, true)) {
            a24_responder(403, ['ok'=>false,'error'=>'No tienes permiso para consultar esta obra.']);
        }
        $codigos = [$obra];
    }
    $datos = a24_estado($db, $codigos);
    a24_responder(200, ['ok'=>true,'data'=>$datos]);
} catch (Throwable $error) {
    error_log('[ARCA24 API] ' . $error->getMessage());
    a24_responder(500, ['ok'=>false,'error'=>'La consulta de indicadores falló. Revisa el registro de errores PHP.']);
}
