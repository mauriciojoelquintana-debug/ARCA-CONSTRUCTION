<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit('Solo terminal');
require_once __DIR__.'/../includes/arca_reportes_binarios.php';
$heads=['Obra','Importe','Moneda'];$data=[['ARCA-PUB-01','25000.50','USD'],['=NO_EJECUTAR()','123.45','MXN']];
$pdf=ax_pdf('Prueba de exportación', $heads,$data);if(!str_starts_with($pdf,'%PDF-1.4')||!str_contains($pdf,'%%EOF'))exit("PDF inválido\n");
echo "OK firma PDF, estructura básica\n";
if(true){
 $path=ax_xlsx('Prueba de exportación',$heads,$data,[1]);$bytes=file_get_contents($path);@unlink($path);if(!str_starts_with($bytes,'PK'))exit('XLSX inválido');echo "OK estructura ZIP/XLSX creada sin dependencias\n";
}
