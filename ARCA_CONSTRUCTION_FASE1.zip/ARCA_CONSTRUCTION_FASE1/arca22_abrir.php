<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca22_accesos.php';
$db=arx_boot(array_values(array_unique(array_merge(...array_column(a22_catalogo(),'roles')))));
$ruta=(string)($_GET['modulo']??'');$obra=(string)($_GET['obra']??'');
if(!isset(a22_catalogo()[$ruta]) || !a22_modulo_permitido($db,$ruta,$obra!==''?$obra:null)){
    http_response_code(403);exit('Acceso denegado: el módulo o la obra no está autorizado.');
}
$query=[];
if($obra!=='' && !empty(a22_catalogo()[$ruta]['obra']))$query['obra']=$obra;
$url=$ruta.($query?'?'.http_build_query($query,'','&',PHP_QUERY_RFC3986):'');
header('Cache-Control: no-store');
header('Location: '.$url,true,303);exit;
