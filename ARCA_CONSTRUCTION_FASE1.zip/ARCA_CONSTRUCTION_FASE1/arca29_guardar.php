<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca29_30.php';
$db=a27_boot(['CHRO']);a27_post();
$target=null;$started=false;
try {
    $origen=(string)($_POST['origen']??'');$tipo=(string)($_POST['tipo']??'');
    if(!in_array($origen,['REAL','DEMO'],true)||!in_array($tipo,['CONTRATO','ANEXO','OTRO'],true))throw new InvalidArgumentException('Tipo de documento incorrecto.');
    if(!isset($_FILES['pdf'])||!is_array($_FILES['pdf']))throw new InvalidArgumentException('Selecciona un PDF.');
    [$tmp,$bytes,$original,$sha]=a29_validar_archivo($_FILES['pdf']);
    $contract=null;$case=null;$employee=0;
    if($origen==='REAL'){
        $contract=arx_int($_POST['id_contrato']??null);
        $c=arx_one($db,'SELECT id_empleado FROM arca_contratos_laborales WHERE id_contrato=?',[$contract]);
        if(!$c)throw new InvalidArgumentException('Contrato no registrado.');
        $employee=(int)$c['id_empleado'];
    } else {
        a30_ensure_demo($db);
        $case=arx_int($_POST['id_demo_caso']??null);
        $c=a30_case($db,$case);
        if(!$c||!a30_obra_autorizada($db,(string)$c['codigo_obra']))throw new InvalidArgumentException('Caso DEMO inexistente o no autorizado.');
        $employee=(int)$c['id_empleado'];
    }
    $dest=a29_storage();$random=bin2hex(random_bytes(24)).'.bin';
    $target=$dest.DIRECTORY_SEPARATOR.$random;
    if(!move_uploaded_file($tmp,$target))throw new RuntimeException('No se pudo guardar el archivo en la carpeta privada.');
    @chmod($target,0600);
    $db->begin_transaction();$started=true;
    arx_exec($db,'INSERT INTO arca29_documentos(origen,id_empleado,id_contrato,id_demo_caso,tipo,nombre_original,archivo_privado,tamano_bytes,sha256,subido_por) VALUES(?,?,?,?,?,?,?,?,?,?)',[
      $origen,$employee,$contract,$case,$tipo,$original,$random,$bytes,$sha,arx_uid()
    ]);
    $doc=(int)$db->insert_id;
    arx_audit($db,'CHRO','arca29_documentos',$doc,'PDF_PRIVADO_ADJUNTADO',null,['origen'=>$origen,'empleado'=>$employee,'contrato'=>$contract,'caso_demo'=>$case,'tipo'=>$tipo,'sha256'=>$sha]);
    $db->commit();$started=false;$target=null;
    a30_flash('Documento guardado en el almacén privado. Su registro no implica verificación contractual.');
}catch(Throwable $e){
    if($started){try{$db->rollback();}catch(Throwable $ignored){}}
    if($target!==null && is_file($target))@unlink($target);
    error_log('[ARCA29 UPLOAD] '.$e->getMessage());
    a30_flash($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo adjuntar el PDF. Revisa configuración y logs.',true);
}
a30_redirect('arca29_documentos.php');
