<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca31_datos.php';
$db=a27_boot(a31_roles());
$role=arx_role();
$permitidas=a24_obras_autorizadas($db); // La Fase 24 protege el acceso a obras clasificadas.
$requested=trim((string)($_GET['obra']??''));
$mensaje='';$datos=null;
try {$codes=a31_elegir_codigos($permitidas,$requested);$datos=a31_datos($db,$codes,$role);}
catch(InvalidArgumentException|DomainException $e){http_response_code(403);$mensaje=$e->getMessage();}
catch(Throwable $e){error_log('[ARCA31] '.$e->getMessage());http_response_code(500);$mensaje='No fue posible consultar los indicadores. Revisa el registro de PHP/Apache.';}
a27_layout('Inteligencia empresarial',a31_rol_alcance($role).' · Indicadores de gestión.','arca31_inteligencia.php');
?>
<link rel="stylesheet" href="assets/css/arca31.css?v=1">
<section class="a31-note"><strong>INFORME INTEGRADO · SOLO LECTURA</strong><p>Los datos reflejan las tablas del ERP. Las divisas se separan sin conversión; los contratos y responsabilidades DEMO nunca cuentan como plantilla real. El acceso se limita a las obras autorizadas para tu sesión.</p></section>
<form class="a31-filters" method="get" action="arca31_inteligencia.php">
<label for="a31-obra">Filtrar por obra</label><select id="a31-obra" name="obra"><option value="">Todas mis obras autorizadas</option>
<?php foreach($permitidas as $w):?><option value="<?=a27_h($w['codigo_obra'])?>"<?=$requested===$w['codigo_obra']?' selected':''?>><?=a27_h($w['codigo_obra'].' · '.$w['nombre_proyecto'])?></option><?php endforeach;?></select>
<button type="submit">Actualizar indicadores</button>
<?php if($datos):?><a class="a31-plain" href="arca31_exportar.php?<?=a27_h(http_build_query(['obra'=>$requested,'tipo'=>'resumen']))?>">Exportar resumen CSV</a><?php endif;?></form>
<?php if($mensaje):?><div class="a31-error" role="alert"><?=a27_h($mensaje)?></div><?php endif;?>
<?php if($datos): $t=$datos['totales'];?>
<div class="a31-meta">Consulta <?=a27_h($datos['consultado'])?> · <?=count($datos['obras'])?> obra(s) · Perfil <?=a27_h($role)?></div>
<section class="a31-kpis">
 <article><span>Obras consultadas</span><strong><?=count($datos['obras'])?></strong><small>Solo ámbito autorizado</small></article>
 <article><span>Avance promedio</span><strong><?=number_format($t['avance_promedio'],1)?> %</strong><small>Promedio simple; no ponderado</small></article>
 <article><span>Obras en riesgo o retraso</span><strong><?=$t['en_riesgo']?></strong><small>Estado actual en operaciones</small></article>
 <?php if(a31_es_personal($role)):?><article><span>Asignaciones verificadas</span><strong><?=$t['asignaciones_verificadas']?></strong><small>Contrato y expediente vigentes</small></article><?php endif;?>
 <?php if(a31_es_operaciones($role)):?><article><span>Artículos registrados</span><strong><?=$t['articulos']?></strong><small>Registros por almacén</small></article><article><span>Stock bajo o mínimo</span><strong><?=$t['stock_bajo']?></strong><small>Requieren atención</small></article><article><span>Órdenes emitidas</span><strong><?=$t['ordenes_emitidas']?></strong><small>No equivale a gasto pagado</small></article><?php endif;?>
 <?php if(a31_es_demo($role) && $t['demo_aprobados']!==null):?><article class="a31-demo"><span>Aprobaciones DEMO</span><strong><?=$t['demo_aprobados']?></strong><small>Simuladas; no suman a personal real</small></article><?php endif;?>
</section>
<section class="a31-panel"><div class="a31-panel-top"><div><h2>Situación consolidada por obra</h2><p>Avance físico, estado y cifras disponibles de cada dirección.</p></div></div>
<div class="a31-scroll"><table class="a31-table"><thead><tr><th>Obra</th><th>Avance</th><th>Estado</th><?php if(a31_es_personal($role)):?><th>Personal validado</th><?php endif;?><?php if(a31_es_operaciones($role)):?><th>Almacén</th><th>Stock bajo</th><th>Órdenes</th><?php endif;?><?php if(a31_es_demo($role)&&$t['demo_aprobados']!==null):?><th>DEMO aprobado</th><?php endif;?></tr></thead><tbody>
<?php foreach($datos['obras'] as $w):?><tr><td><strong><?=a27_h($w['codigo'])?></strong><small><?=a27_h($w['nombre'])?></small></td><td><b><?=number_format($w['avance'],1)?>%</b><div class="a31-bar"><i style="width:<?=$w['avance']?>%"></i></div></td><td><span class="a31-pill <?=a31_riesgo($w['estado'])?'warn':'ok'?>"><?=a27_h($w['estado'])?></span></td><?php if(a31_es_personal($role)):?><td><?=$w['personal']?></td><?php endif;?><?php if(a31_es_operaciones($role)):?><td><?=$w['articulos']?></td><td><?=$w['stock_bajo']?></td><td><?=$w['ordenes']?></td><?php endif;?><?php if(a31_es_demo($role)&&$t['demo_aprobados']!==null):?><td><?=$w['demo']?></td><?php endif;?></tr><?php endforeach;?>
<?php if(!$datos['obras']):?><tr><td colspan="8">Sin registros de obra en el filtro seleccionado.</td></tr><?php endif;?></tbody></table></div></section>
<?php if(a31_es_finanzas($role)):?><section class="a31-panel"><div class="a31-panel-top"><div><h2>Finanzas · movimientos registrados por divisa</h2><p>Se agrupa por moneda, módulo y estado de pago; el total no es necesariamente costo ejecutado ni saldo bancario.</p></div><a href="arca31_exportar.php?<?=a27_h(http_build_query(['obra'=>$requested,'tipo'=>'finanzas']))?>">CSV finanzas</a></div><div class="a31-scroll"><table class="a31-table"><thead><tr><th>Divisa</th><th>Módulo</th><th>Estado de pago</th><th>Registros</th><th>Importe sin convertir</th></tr></thead><tbody><?php foreach($datos['finanzas'] as $f):?><tr><td><span class="a31-pill <?=a31_moneda($f['moneda'])==='SIN CONFIRMAR'?'warn':'ok'?>"><?=a27_h(a31_moneda($f['moneda']))?></span></td><td><?=a27_h($f['modulo'])?></td><td><?=a27_h($f['estado_pago'])?></td><td><?=(int)$f['cantidad']?></td><td><?=a27_h(a31_dinero($f['importe'],$f['moneda']))?></td></tr><?php endforeach;?><?php if(!$datos['finanzas']):?><tr><td colspan="5">Sin movimientos financieros para las obras filtradas.</td></tr><?php endif;?></tbody></table></div></section><?php endif;?>
<?php if(a31_es_operaciones($role)):?><section class="a31-panel"><div class="a31-panel-top"><div><h2>Compras · órdenes por estado y divisa</h2><p>Importes de órdenes, no de facturas ni pagos realizados. No se suman con movimientos financieros.</p></div><a href="arca31_exportar.php?<?=a27_h(http_build_query(['obra'=>$requested,'tipo'=>'ordenes']))?>">CSV órdenes</a></div><div class="a31-scroll"><table class="a31-table"><thead><tr><th>Divisa</th><th>Estado</th><th>Órdenes</th><th>Importe sin convertir</th></tr></thead><tbody><?php foreach($datos['ordenes_divisa'] as $o):?><tr><td><?=a27_h(a31_moneda($o['moneda']))?></td><td><?=a27_h($o['estado'])?></td><td><?=(int)$o['cantidad']?></td><td><?=a27_h(a31_dinero($o['importe'],$o['moneda']))?></td></tr><?php endforeach;?><?php if(!$datos['ordenes_divisa']):?><tr><td colspan="4">Sin órdenes para las obras filtradas.</td></tr><?php endif;?></tbody></table></div></section><?php endif;?>
<section class="a31-panel a31-links"><h2>Continuar en el ERP</h2><a href="arca24_tablero.php">Indicadores operativos</a><a href="arca30_demo.php">Demostración de aprobación</a><a href="arca22_portal.php">Portal corporativo</a><p>Los registros históricos, las simulaciones y las asignaciones vigentes se presentan por separado. Este tablero es de solo lectura.</p></section>
<?php endif; a27_end(); ?>
