<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a34_roles());
a27_post(); // Solo POST con token CSRF válido.
try {
    a34_guardar_hallazgo($db,$_POST,__DIR__);
    a27_alert('Seguimiento actualizado. Esto no modifica los resultados de las comprobaciones automáticas.');
}catch(Throwable $e){
    error_log('[ARCA34 GUARDAR] '.$e->getMessage());
    a27_alert($e instanceof InvalidArgumentException || $e instanceof DomainException ? $e->getMessage() : 'No se pudo guardar el seguimiento. Comunícate con el área de Sistemas.',true);
}
a27_redirect('arca34_calidad.php');
