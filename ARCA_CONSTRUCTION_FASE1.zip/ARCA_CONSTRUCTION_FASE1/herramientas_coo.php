<?php
$arca_area = 'COO';
require __DIR__ . '/includes/herramienta_directiva.php';
