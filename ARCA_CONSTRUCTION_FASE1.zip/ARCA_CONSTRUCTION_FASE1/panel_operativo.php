<?php
// 1. Reanudamos la sesión segura
session_start();

// 2. CIBERSEGURIDAD: Bloqueo de URL por Roles
// Validamos que exista una sesión y que el rol sea estrictamente 'Ingeniero' o 'Arquitecto'
if (!isset($_SESSION['rol_activo']) || ($_SESSION['rol_activo'] != 'Ingeniero' && $_SESSION['rol_activo'] != 'Arquitecto')) {
    // Si un Ejecutivo o Secretaria intenta entrar aquí por URL, el sistema los expulsa
    session_destroy();
    header("Location: login.html");
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Operativo - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #eef2f3; margin: 0; padding: 20px; }
        .header { background-color: #34495e; color: white; padding: 15px; text-align: center; border-radius: 5px; }
        .dashboard-container { display: flex; justify-content: space-around; margin-top: 30px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 30%; text-align: center; border-top: 4px solid #f39c12; }
        .logout-btn { background-color: #e74c3c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; float: right; margin-top: -40px; }
        button { background-color: #34495e; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #2c3e50; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <div class="header">
        <!-- Imprimimos dinámicamente el nombre y el rol específico del usuario -->
        <h1>Bienvenido, <?php echo $_SESSION['usuario_activo']; ?></h1>
        <p>Nivel de Acceso: <b><?php echo $_SESSION['rol_activo']; ?> (Módulo de Campo)</b></p>
        <a href="cerrar_sesion.php" class="logout-btn">Cerrar Sesión</a>
    </div>

    <h2 style="text-align: center; margin-top: 20px;">Gestión de Obras y Proyectos</h2>

    <div class="dashboard-container">
        <div class="card">
            <h3>Proyectos Asignados</h3>
            <p>Visualiza únicamente las tareas y avances de tu obra actual.</p>
            <a href="mis_obras.php"><button>Ver Mis Obras</button></a> 
        </div>
        <div class="card">
            <h3>Planos y Diseños</h3>
            <p>Acceso a estudios de mecánica de suelo y planos estructurales.</p>
            <button>Abrir Planos</button>
        </div>
        <div class="card">
            <h3>Inventario de Obra</h3>
            <p>Solicita materiales al almacén y registra entradas/salidas.</p>
            <a href="formulario_inventario.php"><button>Gestionar Materiales</button></a>
        </div>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>