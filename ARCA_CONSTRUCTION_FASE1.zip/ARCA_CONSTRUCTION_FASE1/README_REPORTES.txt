ARCA CONSTRUCTION · Reportes de demostración
Fuente: arca_bd.sql, respaldo compartido por el usuario.
5 Excel + 5 PDF, agrupados por 5 temas.
Los importes de tablas anteriores a Fase 5 no incluyen divisa.
Estos archivos representan datos de prueba y NO deben guardarse en un servidor web público.
