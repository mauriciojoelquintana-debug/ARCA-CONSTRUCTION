<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_core.php';
$db=arx_boot(['CHRO']);arx_check_post();
require_once __DIR__.'/includes/arca28_rh.php'; a28_guard_legacy($_POST);$act=(string)($_POST['accion']??'');
try{
    $db->begin_transaction();
    if($act==='empleado'){
        $numero=arx_text($_POST['numero']??'',30);$nombre=arx_text($_POST['nombre']??'',120);
        if(!preg_match('/^[A-Za-z0-9-]{3,30}$/D',$numero))throw new InvalidArgumentException('Número de empleado inválido.');
        $puesto=(string)($_POST['puesto']??'');$gerencia=(string)($_POST['gerencia']??'');
        $puestoId=$puesto!==''?arx_int($puesto):null;$gerenciaId=$gerencia!==''?arx_int($gerencia):null;
        if($puestoId!==null&&!arx_one($db,'SELECT id_puesto FROM catalogo_puestos_arca WHERE id_puesto=?',[$puestoId]))throw new InvalidArgumentException('Puesto inexistente.');
        if($gerenciaId!==null&&!arx_one($db,'SELECT id_gerencia FROM gerencias_arca WHERE id_gerencia=?',[$gerenciaId]))throw new InvalidArgumentException('Gerencia inexistente.');
        $tipo=(string)($_POST['tipo']??'POR_VERIFICAR');if(!in_array($tipo,['PROPIO','SUBCONTRATADO','POR_VERIFICAR'],true))throw new InvalidArgumentException('Tipo de personal inválido.');
        $fecha=trim((string)($_POST['fecha_ingreso']??''));if($fecha!=='')arx_date($fecha);
        arx_exec($db,'INSERT INTO arca_empleados(numero_empleado,nombre_completo,id_puesto,id_gerencia,tipo_personal,fecha_ingreso) VALUES(?,?,?,?,?,?)',[$numero,$nombre,$puestoId,$gerenciaId,$tipo,$fecha?:null]);
        arx_audit($db,'CHRO','arca_empleados',(int)$db->insert_id,'ALTA',null,['numero'=>$numero,'nombre'=>$nombre,'tipo'=>$tipo]);
    }elseif($act==='estado'){
        $id=arx_int($_POST['id_empleado']??null);$estado=(string)($_POST['estado']??'');
        if(!in_array($estado,['POR_VERIFICAR','ACTIVO','INACTIVO'],true))throw new InvalidArgumentException('Estado inválido.');
        $r=arx_one($db,'SELECT estado_laboral,tipo_personal FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$id]);
        if(!$r)throw new InvalidArgumentException('Empleado inexistente.');
        if($estado==='ACTIVO' && $r['tipo_personal']==='POR_VERIFICAR')throw new InvalidArgumentException('Confirma primero si el personal es propio o subcontratado.');
        arx_exec($db,'UPDATE arca_empleados SET estado_laboral=? WHERE id_empleado=?',[$estado,$id]);
        arx_audit($db,'CHRO','arca_empleados',$id,'ESTADO',['estado'=>$r['estado_laboral']],['estado'=>$estado]);
    }elseif($act==='tipo'){
        $id=arx_int($_POST['id_empleado']??null);$tipo=(string)($_POST['tipo']??'');
        if(!in_array($tipo,['PROPIO','SUBCONTRATADO','POR_VERIFICAR'],true))throw new InvalidArgumentException('Tipo inválido.');
        $r=arx_one($db,'SELECT tipo_personal FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$id]);if(!$r)throw new InvalidArgumentException('No existe el empleado.');
        arx_exec($db,'UPDATE arca_empleados SET tipo_personal=? WHERE id_empleado=?',[$tipo,$id]);
        arx_audit($db,'CHRO','arca_empleados',$id,'TIPO',['tipo'=>$r['tipo_personal']],['tipo'=>$tipo]);
    }elseif($act==='estructura'){
        $emp=arx_int($_POST['id_empleado']??null);
        $pid=arx_int($_POST['id_puesto']??null);
        $gid=arx_int($_POST['id_gerencia']??null);
        if(!arx_one($db,'SELECT id_puesto FROM catalogo_puestos_arca WHERE id_puesto=?',[$pid]) || !arx_one($db,'SELECT id_gerencia FROM gerencias_arca WHERE id_gerencia=?',[$gid]))throw new InvalidArgumentException('Puesto o gerencia inexistente.');
        $old=arx_one($db,'SELECT id_puesto,id_gerencia FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$emp]);
        if(!$old)throw new InvalidArgumentException('Empleado inexistente.');
        arx_exec($db,'UPDATE arca_empleados SET id_puesto=?,id_gerencia=? WHERE id_empleado=?',[$pid,$gid,$emp]);
        arx_audit($db,'CHRO','arca_empleados',$emp,'ESTRUCTURA',$old,['id_puesto'=>$pid,'id_gerencia'=>$gid]);
    }elseif($act==='vincular'){
        $emp=arx_int($_POST['id_empleado']??null);$uid=arx_int($_POST['id_usuario']??null);
        $e=arx_one($db,'SELECT numero_empleado FROM arca_empleados WHERE id_empleado=?',[$emp]);
        $u=arx_one($db,'SELECT numero_empleado FROM usuarios WHERE id_usuario=?',[$uid]);
        if(!$e||!$u || $e['numero_empleado']!==$u['numero_empleado'])throw new InvalidArgumentException('Solo se vinculan empleado y cuenta con el mismo número verificado.');
        arx_exec($db,'INSERT INTO arca_empleado_usuario(id_empleado,id_usuario) VALUES(?,?)',[$emp,$uid]);
        arx_audit($db,'CHRO','arca_empleado_usuario',$emp,'VINCULAR',null,['cuenta'=>$uid]);
    }elseif($act==='contrato'){
        $emp=arx_int($_POST['id_empleado']??null);$tipo=arx_text($_POST['tipo_contrato']??'',60);
        $inicio=arx_date((string)($_POST['inicio']??''));$fin=trim((string)($_POST['fin']??''));if($fin!=='')arx_date($fin);
        if($fin!=='' && $fin<$inicio)throw new InvalidArgumentException('La fecha de fin debe ser posterior al inicio.');
        if(!arx_one($db,'SELECT id_empleado FROM arca_empleados WHERE id_empleado=?',[$emp]))throw new InvalidArgumentException('Empleado no encontrado.');
        $salario=trim((string)($_POST['salario']??''));$moneda=null;
        if($salario!==''){$salario=arx_decimal($salario,true);$moneda=arx_currency($_POST['moneda']??'');}
        else $salario=null;
        arx_exec($db,'INSERT INTO arca_contratos_laborales(id_empleado,tipo,inicio,fin,salario,moneda) VALUES(?,?,?,?,?,?)',[$emp,$tipo,$inicio,$fin?:null,$salario,$moneda]);
        // La bitácora guarda presencia de remuneración, NO el importe sensible.
        arx_audit($db,'CHRO','arca_contratos_laborales',(int)$db->insert_id,'REGISTRAR',null,['empleado'=>$emp,'tipo'=>$tipo,'inicio'=>$inicio,'salario_capturado'=>$salario!==null]);
    }elseif($act==='contrato_estado'){
        $id=arx_int($_POST['id_contrato']??null);
        $estado=(string)($_POST['estado']??'');
        if(!in_array($estado,['BORRADOR','VIGENTE','FINALIZADO'],true))throw new InvalidArgumentException('Estado contractual inválido.');
        $r=arx_one($db,'SELECT c.estado,c.fin,e.estado_laboral FROM arca_contratos_laborales c JOIN arca_empleados e ON e.id_empleado=c.id_empleado WHERE c.id_contrato=? FOR UPDATE',[$id]);
        if(!$r)throw new InvalidArgumentException('Contrato inexistente.');
        if($estado==='VIGENTE' && ($r['estado_laboral']!=='ACTIVO' || ($r['fin']!==null && $r['fin']<date('Y-m-d'))))throw new InvalidArgumentException('Se requiere empleado activo y fecha de contrato vigente.');
        arx_exec($db,'UPDATE arca_contratos_laborales SET estado=? WHERE id_contrato=?',[$estado,$id]);
        arx_audit($db,'CHRO','arca_contratos_laborales',$id,'ESTADO',['estado'=>$r['estado']],['estado'=>$estado]);
    }elseif($act==='asignacion'){
        $emp=arx_int($_POST['id_empleado']??null);$obra=arx_code($_POST['codigo_obra']??'');$cargo=arx_text($_POST['cargo_obra']??'',90);
        $frente=trim((string)($_POST['frente']??''));if(strlen($frente)>100)throw new InvalidArgumentException('Frente demasiado largo.');
        $inicio=arx_date((string)($_POST['inicio']??''));$fin=trim((string)($_POST['fin']??''));if($fin!=='')arx_date($fin);if($fin!==''&&$fin<$inicio)throw new InvalidArgumentException('Fechas incoherentes.');
        // Bloquear expediente para evitar asignaciones repetidas concurrentes.
        $e=arx_one($db,'SELECT id_empleado,estado_laboral FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$emp]);
        if(!$e || $e['estado_laboral']!=='ACTIVO')throw new InvalidArgumentException('Solo se asigna personal activo y verificado.');
        if(!arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=?',[$obra]))throw new InvalidArgumentException('La obra no existe.');
        $dup=arx_one($db,"SELECT id_asignacion FROM arca_asignaciones_personal WHERE id_empleado=? AND codigo_obra=? AND fecha_inicio<=COALESCE(?, '9999-12-31') AND COALESCE(fecha_fin,'9999-12-31')>=? LIMIT 1",[$emp,$obra,$fin?:null,$inicio]);
        if($dup)throw new InvalidArgumentException('Existe una asignación superpuesta del empleado a esa obra.');
        arx_exec($db,'INSERT INTO arca_asignaciones_personal(id_empleado,codigo_obra,cargo_obra,frente,fecha_inicio,fecha_fin,creado_por) VALUES(?,?,?,?,?,?,?)',[$emp,$obra,$cargo,$frente?:null,$inicio,$fin?:null,arx_uid()]);
        arx_audit($db,'CHRO','arca_asignaciones_personal',(int)$db->insert_id,'ASIGNAR',null,['empleado'=>$emp,'obra'=>$obra,'inicio'=>$inicio,'fin'=>$fin]);
    }elseif($act==='finalizar'){
        $id=arx_int($_POST['id_asignacion']??null);$r=arx_one($db,'SELECT estado FROM arca_asignaciones_personal WHERE id_asignacion=? FOR UPDATE',[$id]);
        if(!$r||$r['estado']!=='ACTIVA')throw new InvalidArgumentException('Asignación no está activa.');
        arx_exec($db,"UPDATE arca_asignaciones_personal SET estado='FINALIZADA',fecha_fin=COALESCE(fecha_fin,CURDATE()) WHERE id_asignacion=?",[$id]);
        arx_audit($db,'CHRO','arca_asignaciones_personal',$id,'FINALIZAR',['estado'=>$r['estado']],['estado'=>'FINALIZADA']);
    }else throw new InvalidArgumentException('Acción no reconocida.');
    $db->commit();arx_flash('Cambio registrado con auditoría.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $ignored){}error_log('ARCA CHRO: '.$e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'No fue posible guardar. Consulta los logs del servidor.',true);}
arx_redirect('chro_personal.php');
