<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca33_preparacion.php';
$db=a27_boot(a33_roles());
$rows=a33_comprobar(__DIR__,true);
$counts=['OK'=>0,'AVISO'=>0,'CRITICO'=>0,'PENDIENTE'=>0];
foreach($rows as $row)$counts[$row['estado']]++;
a27_layout('Configuración operativa','Estado de infraestructura, dependencias y actividades de continuidad.','arca33_preparacion.php');
?>
<link rel="stylesheet" href="assets/css/arca32-33.css?v=1">
<section class="a33-notice"><strong>CONFIGURACIÓN Y CONTINUIDAD</strong><p>Este panel presenta el estado de los controles. Las verificaciones de acceso, recuperación y seguridad requieren evidencia antes de habilitar un entorno productivo.</p></section>
<div class="a33-actions"><a class="a33-button" href="arca33_preparacion.php">Revisar configuración</a><?php if(in_array(arx_role(),a32_roles(),true)):?><a href="arca32_auditoria.php">Auditoría integral</a><?php endif;?></div>
<div class="a33-stats"><article><span>Correctos</span><strong><?=$counts['OK']?></strong></article><article><span>Advertencias</span><strong><?=$counts['AVISO']?></strong></article><article><span>Críticos</span><strong><?=$counts['CRITICO']?></strong></article><article><span>Pendientes manuales</span><strong><?=$counts['PENDIENTE']?></strong></article></div>
<section class="a33-panel"><h2>Controles de configuración</h2><p>Se informa únicamente el resultado de la verificación, sin mostrar contraseñas ni rutas internas completas.</p><div class="a33-scroll"><table><thead><tr><th>Área</th><th>Control</th><th>Estado</th><th>Resultado</th><th>Acción</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=a27_h($r['area'])?></td><td><strong><?=a27_h($r['nombre'])?></strong></td><td><span class="a33-tag <?=strtolower($r['estado'])?>"><?=a27_h($r['estado'])?></span></td><td><?=a27_h($r['detalle'])?></td><td><?=a27_h($r['accion'])?></td></tr><?php endforeach;?></tbody></table></div></section>
<section class="a33-panel"><h2>Criterios de habilitación</h2><p>La habilitación del sistema en un entorno operativo requiere resolver los controles críticos y conservar evidencia de revisión y recuperación. Esta pantalla informa el estado; no aplica cambios a la infraestructura.</p></section>
<?php a27_end(); ?>
