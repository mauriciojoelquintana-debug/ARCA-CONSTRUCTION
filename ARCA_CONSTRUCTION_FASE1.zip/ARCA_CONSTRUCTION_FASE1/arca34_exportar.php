<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a34_roles());
try {
    a34_base_pruebas($db);
    $rows=a34_actuales($db,__DIR__)['controles'];
    $save=a34_instalado($db)?a34_guardados($db):[];
}catch(Throwable $e){error_log('[ARCA34 CSV] '.$e->getMessage());http_response_code(500);exit('No se pudo preparar el informe.');}
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="arca_calidad_'.date('Ymd_His').'.csv"');
header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');
$out=fopen('php://output','wb');if($out===false)exit;
fwrite($out,"\xEF\xBB\xBF");fwrite($out,"sep=;\r\n");
$csv=static function(array $r)use($out):void{fputcsv($out,array_map('a34_csv_seguro',$r),';','"','');};
$csv(['ARCA CONSTRUCTION','CENTRO DE CALIDAD','SOLO LECTURA','EXPORTACIÓN DE HALLAZGOS']);
$csv(['Fuente','Área','Control','Diagnóstico automático','Detalle agregado','Seguimiento','Responsable','Prioridad','Compromiso','Referencia de evidencia','Nota']);
foreach($rows as $k=>$r) {
    if ($r['estado_auto']==='OK' && !isset($save[$k]))continue;
    $s=$save[$k]??[];
    $csv([(['F32'=>'Auditoría','F33'=>'Infraestructura'][$r['fuente']] ?? 'Control interno'),$r['area'],$r['control'],$r['estado_auto'],$r['detalle'],$s['estado']??'SIN_SEGUIMIENTO',$s['responsable']??'', $s['prioridad']??'',$s['fecha_compromiso']??'',$s['referencia_evidencia']??'',$s['nota']??'']);
}
fclose($out);
