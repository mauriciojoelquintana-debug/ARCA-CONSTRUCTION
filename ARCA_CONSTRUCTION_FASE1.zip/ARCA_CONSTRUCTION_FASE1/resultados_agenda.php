<?php
session_start();
$roles_admin = ['Secretaria / Asistente', 'Secretaria'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_admin)) {
    header("Location: login.html");
    exit();
}

include("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultados de Búsqueda</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 20px; }
        table { width: 80%; margin: 0 auto; border-collapse: collapse; background: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        th { background-color: #8e44ad; color: white; padding: 12px; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        tr:hover { background-color: #f9ebf2; }
        .btn-volver { display: inline-block; margin-top: 20px; color: #34495e; text-decoration: none; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <h2 style="color: #8e44ad;">Resultados de la Búsqueda</h2>

    <?php
    if (isset($_POST['busqueda'])) {
        $busqueda = $_POST['busqueda'];
        
        // Envolvemos el término de búsqueda con los comodines % para el operador LIKE
        $parametro_busqueda = "%" . $busqueda . "%";

        // Preparamos la consulta para evitar inyecciones SQL
        $stmt = $conectar->prepare("SELECT fecha, hora, asunto, modalidad FROM agenda_juntas WHERE asunto LIKE ? ORDER BY fecha DESC");
        $stmt->bind_param("s", $parametro_busqueda);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Fecha</th><th>Hora</th><th>Asunto</th><th>Modalidad</th></tr>";
            
            while ($fila = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $fila['fecha'] . "</td>";
                echo "<td>" . $fila['hora'] . "</td>";
                echo "<td>" . $fila['asunto'] . "</td>";
                echo "<td>" . $fila['modalidad'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<h3>No se encontraron reuniones que coincidan con la búsqueda: '<b>$busqueda</b>'</h3>";
        }
        $stmt->close();
    } else {
        echo "<h3>Error: No se recibió ningún término de búsqueda.</h3>";
    }
    $conectar->close();
    ?>

    <br>
    <a href="buscador_agenda.php" class="btn-volver">← Realizar otra búsqueda</a>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>