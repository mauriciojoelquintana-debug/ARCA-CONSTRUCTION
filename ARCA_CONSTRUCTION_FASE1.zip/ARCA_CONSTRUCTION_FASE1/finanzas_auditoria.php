<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_core.php';
$db=arx_boot(['CFO','CEO','Director General']);
$canWrite=arx_role()==='CFO';
$obras=arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra');
$sel=(string)($_GET['obra']??'');
if($sel!=='' && !in_array($sel,array_column($obras,'codigo_obra'),true)){http_response_code(400);exit('Obra no válida');}
$where=$sel!==''?' WHERE codigo_obra=?':'';$args=$sel!==''?[$sel]:[];
$totals=arx_rows($db,"SELECT codigo_obra,COALESCE(moneda,'SIN DEFINIR') AS moneda,
 SUM(CASE WHEN modulo='presupuesto' AND estado_pago='Aprobado' THEN monto ELSE 0 END) AS presupuesto,
 SUM(CASE WHEN modulo='costos' AND estado_pago='Pagado' THEN monto ELSE 0 END) AS costos,
 SUM(CASE WHEN modulo='ingresos' AND estado_pago='Cobrado' THEN monto ELSE 0 END) AS cobrado,
 SUM(CASE WHEN modulo='pagos' AND estado_pago='Pagado' THEN monto ELSE 0 END) AS pagos,
 SUM(CASE WHEN modulo='pagos' AND estado_pago IN ('Pendiente','Programado','Vencido') THEN monto ELSE 0 END) AS pendiente,
 COUNT(*) AS movimientos FROM finanzas_coo $where
 GROUP BY codigo_obra,COALESCE(moneda,'SIN DEFINIR') ORDER BY codigo_obra,moneda",$args);
$detalle=arx_rows($db,"SELECT id_finanza,codigo_obra,modulo,concepto,monto,moneda,categoria_costo,estado_pago,fecha_transaccion
 FROM finanzas_coo $where ORDER BY fecha_transaccion DESC,id_finanza DESC LIMIT 150",$args);
$categories=['Materiales','Mano de obra','Maquinaria','Subcontratos','Transporte','Servicios','Indirectos','Otros'];
$needs=arx_one($db,"SELECT SUM(moneda IS NULL) n_divisa,SUM(modulo='costos' AND categoria_costo IS NULL) n_categoria FROM finanzas_coo" . $where,$args);
$nav=['panel_cfo.php'=>'Resumen CFO','finanzas_auditoria.php'=>'Conciliación por obra','herramientas_cfo.php?modulo=costos'=>'Registrar costos','herramientas_cfo.php?modulo=ingresos'=>'Ingresos y facturación'];
arx_layout_start('Conciliación financiera por obra','Presupuestos, costos, cobros, pagos y clasificación por divisa real.','finanzas_auditoria.php','Finanzas · CFO',$nav);
?>
<div class="arx-note"><b>Regla contable:</b> se presentan los importes <b>por moneda</b>. No se suman MXN y USD ni se aplica tipo de cambio inventado. Los presupuestos aprobados y costos pagados permiten comparar ejecución; los pagos se muestran <b>por separado</b> para evitar contabilizarlos dos veces si representan el mismo gasto. Esta es conciliación de control operativo, no conciliación bancaria.</div>
<section class="arx-kpis">
 <div class="arx-kpi"><span>Movimientos sin divisa confirmada</span><strong><?= (int)($needs['n_divisa']??0) ?></strong></div>
 <div class="arx-kpi"><span>Costos sin clasificación</span><strong><?= (int)($needs['n_categoria']??0) ?></strong></div>
 <div class="arx-kpi"><span>Filas de obra / divisa</span><strong><?=count($totals)?></strong></div>
</section>
<section class="arx-card"><h2>Conciliación por obra y moneda</h2><p class="arx-sub">Solo se comparan conceptos registrados en la misma divisa y con estados finales relevantes.</p>
<form class="arx-filter" method="get"><label class="arx-field">Filtrar obra
<select name="obra"><option value="">Todas las obras</option><?php foreach($obras as $o): ?><option value="<?=arx_h($o['codigo_obra'])?>" <?= $sel===$o['codigo_obra']?'selected':'' ?>><?=arx_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></option><?php endforeach; ?></select></label><button class="arx-btn primary">Aplicar</button></form>
<div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Obra</th><th>Divisa</th><th>Presupuesto aprobado</th><th>Costos pagados</th><th>Margen presupuesto − costo</th><th>Cobrado</th><th>Pagos ejecutados*</th><th>Pagos pendientes</th></tr></thead><tbody>
<?php foreach($totals as $r): $mon=$r['moneda']; ?>
<tr><td><strong><?=arx_h($r['codigo_obra'])?></strong></td><td><span class="arx-tag"><?=arx_h($mon)?></span></td>
<?php foreach(['presupuesto','costos'] as $c): ?><td class="arx-number"><?=arx_h(arx_money($r[$c],$mon))?></td><?php endforeach; ?>
<td class="arx-number"><?=arx_h(arx_money((string)((float)$r['presupuesto']-(float)$r['costos']),$mon))?></td>
<?php foreach(['cobrado','pagos','pendiente'] as $c): ?><td class="arx-number"><?=arx_h(arx_money($r[$c],$mon))?></td><?php endforeach; ?>
</tr><?php endforeach; ?>
<?php if(!$totals): ?><tr><td colspan="8">No hay registros para la obra seleccionada.</td></tr><?php endif; ?></tbody></table></div><p class="arx-muted">*Pagos es un indicador informativo independiente; no se suma a costos. Un margen positivo no equivale a utilidad final.</p></section>
<section class="arx-card"><h2>Clasificación de movimientos</h2><p class="arx-sub">Verifica cada documento fuente antes de confirmar MXN o USD. Solo CFO puede etiquetar o reclasificar.</p><div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Folio / Obra</th><th>Módulo / Concepto</th><th>Importe</th><th>Divisa y categoría</th><th>Acción</th></tr></thead><tbody>
<?php foreach($detalle as $r): ?><tr><td><strong>#<?= (int)$r['id_finanza'] ?></strong><br><?=arx_h($r['codigo_obra'])?></td><td><b><?=arx_h($r['modulo'])?></b><br><?=arx_h($r['concepto'])?></td><td class="arx-number"><?=number_format((float)$r['monto'],2,'.',',')?></td><td>
<?php if($canWrite): ?><form id="f<?= (int)$r['id_finanza'] ?>" action="finanzas_etiquetar.php" method="post" class="arx-inline"><input type="hidden" name="csrf_token" value="<?=arx_h(arx_token())?>"><input type="hidden" name="id" value="<?= (int)$r['id_finanza'] ?>"><input type="hidden" name="obra" value="<?=arx_h($sel)?>">
<?=arx_select('moneda',[''=>'Sin confirmar','USD'=>'USD','MXN'=>'MXN'],$r['moneda'], 'required') ?>
<?php if($r['modulo']==='costos'): ?><?=arx_select('categoria_costo',[''=>'Sin clasificar']+array_combine($categories,$categories),$r['categoria_costo'])?><?php endif; ?></form>
<?php else: ?><?=arx_h($r['moneda']??'Sin definir')?> <?=arx_h($r['categoria_costo']??'')?><?php endif; ?></td>
<td><?php if($canWrite): ?><button class="arx-btn" form="f<?= (int)$r['id_finanza'] ?>">Guardar</button><?php else: ?>Solo lectura<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><p class="arx-muted">Mostrando hasta 150 movimientos. Utiliza el filtro de obra para revisar grupos más pequeños. Los movimientos nuevos también deberán declarar divisa.</p></section>
<?php arx_layout_end(); ?>
