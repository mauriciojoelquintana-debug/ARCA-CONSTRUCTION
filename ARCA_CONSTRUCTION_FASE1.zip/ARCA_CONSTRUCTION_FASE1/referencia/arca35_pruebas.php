<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a35_roles());
$ready=false;$data=[];$error='';$warnings=[];$audit=[];$gate=null;
try {
    a34_base_pruebas($db);
    $ready=a34_instalado($db);
    if($ready)$data=a35_guardados($db);
    $warnings=a33_comprobar(__DIR__,true);
    if(in_array(arx_role(),a34_roles(),true)) {
       $audit=a32_evaluar($db,a24_obras_autorizadas($db));
       $states=[];foreach($data as $id=>$row)$states[$id]=$row['resultado'];
       $gate=a35_puerta($audit,$warnings,$states);
    }
}catch(Throwable $e){error_log('[ARCA35 PANEL] '.$e->getMessage());$error='No se pudo completar el diagnóstico de F35. Revisa el log del servidor.';}
$passed=count(array_filter($data,static fn($r)=>$r['resultado']==='APROBADA'));
$failed=count(array_filter($data,static fn($r)=>in_array($r['resultado'],['FALLIDA','BLOQUEADA'],true)));
$catalog=a35_catalogo();
$notReady=count(array_filter($warnings,static fn($r)=>$r['estado']!=='OK'));
// No ejecutar F32 desde sesión CIO: contiene información global reservada al CEO.
$gateText=($gate!==null && $gate['apto'])?'EN REVISIÓN FINAL':'HABILITACIÓN PENDIENTE';
a27_layout('Verificación operativa','Comprobación de accesos, integridad, continuidad y resultados documentados.','arca35_pruebas.php');
?>
<link rel="stylesheet" href="assets/css/arca34-35.css?v=1">
<section class="qa-banner"><strong>MATRIZ DE VERIFICACIÓN</strong><p>El estado aprobado refleja la revisión registrada y su evidencia. Los controles de auditoría, recuperación y seguridad deben validarse de forma independiente, en un entorno autorizado y sin afectar la operación.</p></section>
<div class="qa-tools"><a href="arca33_preparacion.php">Configuración operativa</a><?php if(in_array(arx_role(),a34_roles(),true)):?><a href="arca34_calidad.php">Centro de calidad</a><?php endif;?><a href="arca35_exportar.php">Exportar matriz CSV</a></div>
<?php if($error):?><div role="alert" class="qa-alert"><?=a27_h($error)?></div><?php else:?>
<div class="qa-stats"><article><span>Casos definidos</span><strong><?=count($catalog)?></strong></article><article><span>Aprobados con evidencia</span><strong><?=$passed?></strong></article><article><span>Fallidos o bloqueados</span><strong><?=$failed?></strong></article><article><span>No aprobados</span><strong><?=count($catalog)-$passed?></strong></article></div>
<div class="qa-card"><h2>Puerta de salida</h2><p class="qa-alert"><strong><?=$gateText?></strong>. <?php if($notReady):?>Configuración operativa: <?=$notReady?> controles no correctos o pendientes. <?php endif;?><?php if($gate===null):?>La validación global está reservada a Dirección General.<?php else:?>Auditoría integral: <?= (int)$gate['auditoria_pendiente'] ?> controles pendientes y quedan <?= (int)$gate['pruebas_pendientes'] ?> pruebas sin aprobación.<?php endif;?> La restauración aislada, el transporte seguro y una revisión independiente requieren evidencia antes de habilitar la operación.</p></div>
<?php if(!$ready):?><div class="qa-alert" role="alert">El seguimiento de resultados no está disponible. Solicita al área de Sistemas revisar la configuración del módulo.</div><?php endif;?>
<section class="qa-card"><h2>Matriz de verificación</h2><p>Registra únicamente referencias a evidencias conservadas de forma privada. No adjuntes contraseñas, documentos laborales, números de identificación ni capturas con datos sensibles.</p>
<?php foreach($catalog as $code=>$case): $v=$data[$code]??null;$state=(string)($v['resultado']??'NO_EJECUTADA'); ?>
<details class="qa-panel"><summary><?=a27_h($code.' · '.$case[0].' · '.$case[1])?> <span class="qa-status <?=strtolower(a27_h($state))?>"><?=a27_h($state)?></span></summary>
<p><strong>Procedimiento sugerido:</strong> <?=a27_h($case[2])?></p>
<?php if($ready):?><form method="post" action="arca35_guardar.php" class="qa-grid">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>">
<input type="hidden" name="codigo_prueba" value="<?=a27_h($code)?>">
<label>Resultado<select name="resultado" required><?php foreach(a35_resultados() as $result):?><option value="<?=a27_h($result)?>" <?=$state===$result?'selected':''?>><?=a27_h($result)?></option><?php endforeach;?></select></label>
<label>Referencia de evidencia<input name="referencia_evidencia" maxlength="180" value="<?=a27_h($v['referencia_evidencia']??'')?>" placeholder="Ej.: PRUEBAS/SEG01/ACTA-001"></label>
<label class="qa-wide">Observación (resultado, fecha y responsable)<textarea name="observacion" maxlength="1500"><?=a27_h($v['observacion']??'')?></textarea></label>
<div class="qa-wide"><button class="qa-btn" type="submit">Registrar resultado</button> <span class="qa-muted">Último cambio: <?=a27_h($v['ejecutado_en']??'Sin ejecución')?></span></div>
</form><?php endif;?></details>
<?php endforeach;?></section><?php endif;?>
<section class="qa-card"><h2>Reglas de aceptación</h2><p>La aceptación operativa requiere todos los casos obligatorios aprobados, los hallazgos críticos resueltos y evidencia verificable de restauración y revisión de seguridad. Los resultados registrados están sujetos a comprobación.</p></section>
<?php a27_end(); ?>
