<?php /* ARCA27 REDIRECT: destino con guardia de rol */
header('Location: arca27_sql.php',true,302); exit; ?>
<?php
/* ARCA22_GUARD */ require_once __DIR__.'/includes/arca22_accesos.php'; a22_guard_legacy('reportes_sql.php');

require_once __DIR__ . '/includes/seguridad.php';
arca_requerir_roles(['CIO', 'CEO', 'Director General']);
include('conexion.php');
$query_reporte = $conectar->query("SELECT * FROM proyectos ORDER BY presupuesto DESC");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reportes de auditoría | ARCA</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #0d1117; color: #c9d1d9; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #30363d; padding: 12px; text-align: left; }
        th { background-color: #161b22; color: #3fb950; }
        .btn-volver { background: #58a6ff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">
    <h2>Auditoría de proyectos y presupuestos</h2>
    <a href="panel_cio.php" class="btn-volver">Volver al Panel CIO</a>
    <table>
        <tr>
            <th>ID Obra</th>
            <th>Nombre del Proyecto</th>
            <th>Ubicación</th>
            <th>Responsable</th>
            <th>Presupuesto</th>
            <th>Estado</th>
        </tr>
        <?php while($row = $query_reporte->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id_proyecto']; ?></td>
            <td><?php echo $row['nombre_obra']; ?></td>
            <td><?php echo $row['ubicacion']; ?></td>
            <td><?php echo $row['numero_empleado']; ?></td>
            <td>$<?php echo number_format($row['presupuesto'], 2); ?></td>
            <td><?php echo $row['estado']; ?></td>
        </tr>
        <?php } ?>
    </table>
<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>