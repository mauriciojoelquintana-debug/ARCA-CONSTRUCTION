<?php /* ARCA27 WRAPPER: derivación protegida */
if (isset($_GET['modulo']) && in_array((string)$_GET['modulo'], ['sync','servidores','redes','equipos','conectividad','backup','firewall','encriptacion'], true)) {
  header('Location: arca27_ti.php?modulo='.rawurlencode((string)$_GET['modulo']), true, 302); exit;
}
?>
<?php
$arca_area = 'CIO';
require __DIR__ . '/includes/herramienta_directiva.php';
