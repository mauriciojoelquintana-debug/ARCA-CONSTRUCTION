<?php
// 1. Validamos la sesión para mantener la seguridad (RBAC)
session_start();
$roles_tecnicos = ['Ingeniero Civil', 'Arquitecto', 'Residente de Obra', 'Supervisor de Obra'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_tecnicos)) {
    header("Location: login.html");
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Inventario - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #eef2f3; text-align: center; padding: 20px; }
        .formulario-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 400px; margin: 0 auto; border-top: 4px solid #f39c12; }
        input, select { width: 90%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;}
        .btn-enviar { background-color: #f39c12; color: white; border: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; cursor: pointer; font-weight: bold; width: 95%; }
        .btn-enviar:hover { background-color: #d68910; }
        .btn-volver { display: inline-block; margin-top: 15px; color: #34495e; text-decoration: none; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <h2>Gestión de Materiales - ARCA CONSTRUCTION</h2>
    <p>Técnico a cargo: <b><?php echo $_SESSION['usuario_activo']; ?></b></p>

    <div class="formulario-container">
        <!-- Formulario seguro usando el método POST -->
        <form action="procesar_inventario.php" method="POST">
            
            <label style="font-weight:bold; color:#2c3e50;">Código de Artículo (Ej. CEM-001):</label><br>
            <input type="text" name="codigo_articulo" required>

            <label style="font-weight:bold; color:#2c3e50;">Nombre del Material o Maquinaria:</label><br>
            <input type="text" name="nombre_material" required>

            <label style="font-weight:bold; color:#2c3e50;">Categoría:</label><br>
            <select name="categoria" required>
                <option value="Obra Negra">Obra Negra (Cemento, Varilla, Arena)</option>
                <option value="Acabados">Acabados (Pintura, Loseta, Yeso)</option>
                <option value="Herramienta">Herramienta Manual / Eléctrica</option>
                <option value="Maquinaria Pesada">Maquinaria Pesada</option>
            </select>

            <label style="font-weight:bold; color:#2c3e50;">Cantidad (Ingreso a Obra):</label><br>
            <input type="number" name="cantidad" min="1" required>

            <label style="font-weight:bold; color:#2c3e50;">Unidad de Medida:</label><br>
            <select name="unidad_medida" required>
                <option value="Bultos (50kg)">Bultos (50kg)</option>
                <option value="Toneladas">Toneladas</option>
                <option value="Metros Cúbicos">Metros Cúbicos</option>
                <option value="Piezas">Piezas</option>
                <option value="Litros">Litros</option>
            </select>

            <!-- Campo oculto dinámico para rastrear al responsable -->
            <input type="hidden" name="responsable_registro" value="<?php echo $_SESSION['usuario_activo']; ?>">

            <input type="submit" value="Registrar Movimiento" class="btn-enviar">
        </form>
        
        <br><br>
        <a href="panel_ingenieria.php" class="btn-volver">← Volver al Panel de Ingeniería</a>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>