<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca22_accesos.php';
$db=arx_boot(array_values(array_unique(array_merge(...array_column(a22_catalogo(),'roles')))));
$rol=arx_role();$uid=arx_uid();
$catalog=a22_catalogo();$visibles=0;
foreach($catalog as $ruta=>$meta){if(a22_modulo_permitido($db,$ruta))$visibles++;}
$accesos=arx_one($db,'SELECT COUNT(*) n FROM arca_accesos_obra WHERE id_usuario=?',[$uid]);
$users=arx_one($db,'SELECT COUNT(*) n FROM usuarios WHERE id_usuario=?',[$uid]);
$pendientes=[];
foreach(['procesar_alta_empleado.php','procesar_inventario.php','registro_material.php','procesar_agenda.php','actualiza.php','baja.php','panel_departamentos_arca.php','panel_estructura_arca.php'] as $p){$pendientes[]=['ruta'=>$p,'estado'=>'Revisión manual antes de producción'];}
header('Cache-Control: private, no-store');
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Verificación de accesos · ARCA</title><link rel="stylesheet" href="assets/css/arca22.css?v=22"></head><body class="a22-body"><main class="a22-alone"><a href="arca22_portal.php" class="a22-back">← Portal de navegación</a><div class="a22-card"><span class="a22-overline">VERIFICACIÓN DE ACCESOS</span><h1>Estado de acceso</h1><p>La sesión actual tiene usuario válido: <b><?= (int)($users['n']??0)===1?'Sí':'No'?></b>.</p><div class="a22-kpis"><div><small>Rol</small><strong><?=arx_h($rol)?></strong></div><div><small>Módulos visibles</small><strong><?=$visibles?></strong></div><div><small>Accesos individuales a obras</small><strong><?=(int)($accesos['n']??0)?></strong></div></div></div><div class="a22-card"><h2>Verificaciones de acceso</h2><p>Comprueba que cada cargo pueda abrir solo las obras permitidas y ejecutar las acciones autorizadas. La persona que solicita un trámite no debe aprobarlo.</p><div class="a22-tablewrap"><table><thead><tr><th>Ruta antigua</th><th>Estado de auditoría</th></tr></thead><tbody><?php foreach($pendientes as $i):?><tr><td><?=arx_h($i['ruta'])?></td><td><?=arx_h($i['estado'])?></td></tr><?php endforeach;?></tbody></table></div></div><div class="a22-card"><h2>Alcance de los controles</h2><p>El acceso se comprueba por cargo y por obra. Las rutas heredadas requieren una verificación independiente de acceso y autorización de operaciones.</p></div></main></body></html>
