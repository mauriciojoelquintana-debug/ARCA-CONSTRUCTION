<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca27.php';$db=a27_boot(['CEO','Director General','COO','CFO','CHRO']);
$areas=['APO-JUR'=>'Asuntos Jurídicos y Cumplimiento','APO-AUD'=>'Auditoría Interna','APO-SER'=>'Administración de Instalaciones y Servicios','APO-PAT'=>'Seguridad Patrimonial'];
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 a27_post();
 try{
  $area=(string)($_POST['codigo_area']??'');if(!isset($areas[$area]))throw new InvalidArgumentException('Área de apoyo incorrecta.');
  $obra=trim((string)($_POST['codigo_obra']??''));if($obra!==''&&!a27_can_obra($db,arx_code($obra),'consultar'))throw new InvalidArgumentException('Obra fuera del ámbito autorizado.');
  $asunto=arx_text($_POST['asunto']??'',180);$detalle=arx_text($_POST['detalle']??'',800);
  $db->begin_transaction();try{
   arx_exec($db,'INSERT INTO arca27_apoyo_solicitudes(codigo_area,codigo_obra,asunto,detalle,solicitado_por) VALUES(?,?,?,?,?)',[$area,$obra===''?null:$obra,$asunto,$detalle,arx_uid()]);
   $id=(int)$db->insert_id;arx_audit($db,'apoyos','solicitud',(int)$id,'CREAR',null,['area'=>$area,'obra'=>$obra]);$db->commit();
  }catch(Throwable $e){$db->rollback();throw $e;}
  a27_alert('Solicitud enviada a '. $areas[$area].' con folio #'.$id.'.');
 }catch(Throwable $e){error_log('[ARCA27_APOYOS] '.$e->getMessage());a27_alert($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo guardar la solicitud.',true);}
 a27_redirect('arca27_apoyos.php');
}
$list=arx_rows($db,'SELECT codigo_dir,nombre_direccion,enfoque_control FROM direcciones_arca WHERE codigo_dir IN (?,?,?,?) ORDER BY codigo_dir',array_keys($areas));
$obras=a27_obras_lectura($db);$allowViewAll=in_array(arx_role(),['CEO','Director General'],true);
$rows=$allowViewAll ? arx_rows($db,'SELECT id_solicitud,codigo_area,codigo_obra,asunto,estado,fecha_creacion FROM arca27_apoyo_solicitudes ORDER BY id_solicitud DESC LIMIT 100') : arx_rows($db,'SELECT id_solicitud,codigo_area,codigo_obra,asunto,estado,fecha_creacion FROM arca27_apoyo_solicitudes WHERE solicitado_por=? ORDER BY id_solicitud DESC LIMIT 100',[arx_uid()]);
a27_layout('Organización y áreas de apoyo','Áreas registradas en direcciones_arca y solicitudes documentadas con folio, responsable y estado.','arca27_apoyos.php');
?><section class="a27-grid"><?php foreach($list as $r):?><article class="a27-card"><h2><?=a27_h($r['nombre_direccion'])?></h2><p class="a27-muted"><?=a27_h($r['enfoque_control'])?></p><span class="a27-label"><?=a27_h($r['codigo_dir'])?></span></article><?php endforeach;?></section>
<section class="a27-card"><h2>Solicitar intervención de un área de apoyo</h2><form method="post" class="a27-form"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><label>Área<select name="codigo_area"><?php a27_opt($areas);?></select></label><label>Obra (opcional)<select name="codigo_obra"><option value="">Corporativa / sin obra</option><?php foreach($obras as $o):?><option value="<?=a27_h($o['codigo_obra'])?>"><?=a27_h($o['codigo_obra'])?></option><?php endforeach;?></select></label><label class="a27-wide">Asunto<input name="asunto" maxlength="180" required></label><label class="a27-wide">Detalle<textarea name="detalle" maxlength="800" required></textarea></label><button>Crear solicitud</button></form></section>
<section class="a27-card"><h2>Solicitudes de apoyo</h2><div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Folio</th><th>Área</th><th>Obra</th><th>Asunto</th><th>Estado</th><th>Creación</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td>#<?=(int)$r['id_solicitud']?></td><td><?=a27_h($areas[$r['codigo_area']]??$r['codigo_area'])?></td><td><?=a27_h($r['codigo_obra']??'Corporativa')?></td><td><?=a27_h($r['asunto'])?></td><td><span class="a27-label"><?=a27_h($r['estado'])?></span></td><td><?=a27_h($r['fecha_creacion'])?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="6">Sin solicitudes registradas.</td></tr><?php endif;?></tbody></table></div><p class="a27-sub">Esta bandeja registra las solicitudes; la asignación y resolución por titular de área deberá incorporarse cuando existan cuentas y reglas verificadas para esos cargos.</p></section><?php a27_end();
