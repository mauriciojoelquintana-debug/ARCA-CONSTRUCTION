<?php
session_start();

// =========================================================================
// 1. CABECERAS DE ALTA SEGURIDAD HTTP Y VALIDACIÓN DE SESIÓN ACTIVA
// =========================================================================
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: no-referrer");

if (!isset($_SESSION['rol_activo']) || !isset($_SESSION['usuario_activo'])) {
    header("Location: ingreso.html");
    exit();
}

// ESCUDO ANTI-URL: Si existe cualquier parámetro en la barra de direcciones (?depto=...),
// se limpia de inmediato para no exponer variables ni estructura en la URL.
if (!empty($_SERVER['QUERY_STRING'])) {
    header("Location: panel_departamentos_arca.php");
    exit();
}

include("conexion.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$usuario_activo = trim($_SESSION['usuario_activo']);
$nombre_usuario = trim($_SESSION['nombre_usuario'] ?? 'Especialista ARCA');
$rol_sesion     = trim($_SESSION['rol_activo']);
$obra_sesion    = trim($_SESSION['obra_asignada'] ?? 'GLOBAL (10 Obras)');

// =========================================================================
// 2. RESOLUCIÓN INTERNA DEL DEPARTAMENTO (100% EN SERVIDOR VÍA $_SESSION)
// =========================================================================
$mapa_rol_depto = [
    'Departamento RRHH' => 'RRHH',
    'Enlace RH'         => 'RRHH',
    'CHRO'              => 'RRHH',
    'Almacenista'       => 'ALMACEN',
    'Jefe de Almacén'   => 'ALMACEN',
    'Arquitecto'        => 'ARQUITECTOS',
    'Ingeniero Civil'   => 'INGENIEROS',
    'Ingeniero'         => 'INGENIEROS',
    'Abogado'           => 'ABOGADOS',
    'Gerente Jurídico'  => 'ABOGADOS',
    'Contador'          => 'CONTADORES',
    'CFO'               => 'CONTADORES',
    'Seguridad'         => 'SEGURIDAD'
];

$es_ceo = ($rol_sesion === 'CEO' || $rol_sesion === 'Director General');

// Cambio de departamento o filtro de obra vía POST oculto (Patrón Post/Redirect/Get)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion_contexto'])) {
    if (isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        if ($_POST['accion_contexto'] === 'cambiar_depto_ceo' && $es_ceo) {
            $nuevo_depto = strtoupper(trim($_POST['depto_destino'] ?? 'CONTADORES'));
            if (in_array($nuevo_depto, ['RRHH', 'ALMACEN', 'ARQUITECTOS', 'INGENIEROS', 'ABOGADOS', 'CONTADORES', 'SEGURIDAD'])) {
                $_SESSION['depto_ceo_vista'] = $nuevo_depto;
            }
        } elseif ($_POST['accion_contexto'] === 'filtrar_obra') {
            $_SESSION['filtro_obra_depto'] = trim($_POST['obra_seleccionada'] ?? 'TODAS');
        }
    }
    header("Location: panel_departamentos_arca.php");
    exit();
}

if ($es_ceo) {
    $depto_activo = $_SESSION['depto_ceo_vista'] ?? 'CONTADORES';
} else {
    $depto_activo = $mapa_rol_depto[$rol_sesion] ?? ($_SESSION['depto_autorizado'] ?? 'INGENIEROS');
}

// =========================================================================
// 3. SUITES CORPORATIVAS PERSONALIZADAS POR DEPARTAMENTO
// =========================================================================
$suites_corporativas = [
    'CONTADORES' => [
        'sistema_nombre' => 'ARCA ERP • Suite Financiera, Contable y Fiscal',
        'area_corta'     => 'Contabilidad Corporativa, Impuestos, Tesorería y Auditoría',
        'credencial'     => 'Auditoría & Finanzas Corporativas',
        'icono'          => '🧮',
        'tema'           => [
            'bg_body'    => '#060d13',
            'bg_panel'   => '#0b1622',
            'bg_card'    => '#0f1e2e',
            'borde'      => '#1c354d',
            'primario'   => '#0ea5e9',
            'secundario' => '#10b981',
            'gradiente'  => 'linear-gradient(135deg, #091e2c 0%, #0f364d 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Pólizas Conciliadas', 'valor' => '100%', 'sub' => 'Cierre mensual cuadrado en 10 obras'],
            ['titulo' => 'Cumplimiento SAT / SIROC', 'valor' => 'Opinión 32-D OK', 'sub' => 'ISR, IVA y cuotas IMSS al corriente'],
            ['titulo' => 'Facturación CFDI 4.0', 'valor' => '$4.28 M USD', 'sub' => 'Estimaciones timbradas en el periodo'],
            ['titulo' => 'Fondos Gubernamentales', 'valor' => '$80.0 M USD', 'sub' => 'Contabilidad blindada sin observaciones']
        ],
        'widget_titulo' => '📊 Monitor de Cumplimiento Fiscal, Liquidez y Auditoría',
        'monitores' => [
            ['nombre' => 'Conciliación Bancaria y Pólizas de Obra', 'estado' => 'Cuadrado al 100%', 'porcentaje' => 100, 'color' => '#10b981'],
            ['nombre' => 'Declaraciones Provisionales ISR / IVA y Retenciones', 'estado' => 'Presentadas en Tiempo', 'porcentaje' => 96, 'color' => '#0ea5e9'],
            ['nombre' => 'Dictamen de Cuotas Obrero-Patronales (SIROC - IMSS)', 'estado' => 'Vigente / Positivo', 'porcentaje' => 94, 'color' => '#10b981'],
            ['nombre' => 'Control de Desviación Presupuestal en Partidas Críticas', 'estado' => '1 Obra en Revisión (PUB-04)', 'porcentaje' => 82, 'color' => '#f59e0b']
        ],
        'form_titulo' => 'Registrar Póliza Contable, Declaración Fiscal o Dictamen de Auditoría',
        'lbl_folio'   => 'No. de Póliza / Folio Fiscal',
        'ph_folio'    => 'Ej. POL-ING-804 o CFDI-992',
        'lbl_subarea' => 'Módulo Contable / Fiscal',
        'sub_areas'   => [
            'Contabilidad General (Pólizas y Cierres Mensuales)',
            'Coordinación Fiscal (Declaraciones ISR, IVA y Comercio Exterior)',
            'Cumplimiento IMSS / Plataforma SIROC',
            'Tesorería Corporativa (Conciliación y Dispersión Bancaria)',
            'Cuentas por Cobrar y Facturación de Estimaciones (CFDI 4.0)',
            'Auditoría Interna de Partidas y Fondos Especiales'
        ],
        'lbl_desc'    => 'Concepto de la Póliza, Trámite Fiscal o Auditoría',
        'ph_desc'     => 'Ej. Conciliación de estimación #14 y entero de retenciones...',
        'lbl_metrica' => 'Importe Auditado / Resultado Fiscal (USD)',
        'ph_metrica'  => 'Ej. $450,000.00 USD Pagados / Póliza Cuadrada',
        'mostrar_herramientas_obra' => false
    ],

    'ABOGADOS' => [
        'sistema_nombre' => 'ARCA LegalTech • Dirección Jurídica y Cumplimiento Normativo',
        'area_corta'     => 'Contratos, Licencias de Construcción, Fianzas, Litigios y Seguridad Nacional',
        'credencial'     => 'Consejería Jurídica & Compliance',
        'icono'          => '⚖️',
        'tema'           => [
            'bg_body'    => '#0c0a12',
            'bg_panel'   => '#14111f',
            'bg_card'    => '#1c172b',
            'borde'      => '#32294d',
            'primario'   => '#d97706',
            'secundario' => '#a855f7',
            'gradiente'  => 'linear-gradient(135deg, #1f1633 0%, #3b2314 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Contratos Blindados', 'valor' => '52 Activos', 'sub' => 'Obra pública, privada y subcontratos'],
            ['titulo' => 'Licencias y Uso de Suelo', 'valor' => '10 / 10 Obras', 'sub' => 'SEMARNAT, MIA y permisos municipales OK'],
            ['titulo' => 'Acuerdos NDA (Gobierno)', 'valor' => '100% Vigentes', 'sub' => 'Protocolo SEDENA y CNI bajo reserva'],
            ['titulo' => 'Fianzas y Garantías', 'valor' => '$2.05 M USD', 'sub' => 'En ejecución por vicios o rescisión']
        ],
        'widget_titulo' => '🏛️ Semáforo de Blindaje Contractual y Regulatorio por Sector',
        'monitores' => [
            ['nombre' => 'Licencias de Construcción, Derechos de Vía y MIA (SEMARNAT)', 'estado' => '100% Liberados', 'porcentaje' => 100, 'color' => '#10b981'],
            ['nombre' => 'Convenios de Confidencialidad (NDA) y Ley de Seguridad Nacional', 'estado' => 'Blindaje Nivel V', 'porcentaje' => 100, 'color' => '#a855f7'],
            ['nombre' => 'Contratos de Compraventa, Fideicomisos y Licitaciones', 'estado' => 'En Regla Jurídica', 'porcentaje' => 92, 'color' => '#d97706'],
            ['nombre' => 'Litigios y Ejecución de Fianzas a Subcontratistas Incumplidos', 'estado' => '2 Casos Activos', 'porcentaje' => 75, 'color' => '#ef4444']
        ],
        'form_titulo' => 'Registrar Instrumento Contractual, Licencia o Actuación Jurídica',
        'lbl_folio'   => 'No. de Expediente / Instrumento Legal',
        'ph_folio'    => 'Ej. JUR-NDA-2026-14 o EXP-LIT-09',
        'lbl_subarea' => 'Materia Jurídica / Regulatoria',
        'sub_areas'   => [
            'Contratos Comerciales, Fideicomisos y Subcontratación',
            'Licencias de Construcción, Uso de Suelo y Impacto Ambiental (MIA)',
            'Derechos de Vía, Concesiones Federales y Portuarias',
            'Blindaje Gubernamental y Convenios NDA (SEDENA / CNI)',
            'Ejecución de Fianzas, Penalizaciones y Litigios Mercantiles'
        ],
        'lbl_desc'    => 'Síntesis del Dictamen Legal, Cláusula o Permiso',
        'ph_desc'     => 'Ej. Firma de adendum modificatorio y póliza de fianza de vicios ocultos...',
        'lbl_metrica' => 'Vigencia Legal / Monto de Garantía o Fianza',
        'ph_metrica'  => 'Ej. Vigente hasta 2028 / Fianza $1.2M USD',
        'mostrar_herramientas_obra' => false
    ],

    'INGENIEROS' => [
        'sistema_nombre' => 'ARCA Engineering • Consola de Ingeniería Civil, Estructural y Costos',
        'area_corta'     => 'Cálculo Estructural, Geotecnia, Instalaciones MEP, Topografía y Control de Avance',
        'credencial'     => 'Ingeniería de Obra & Soporte Técnico',
        'icono'          => '🏗️',
        'tema'           => [
            'bg_body'    => '#060b16',
            'bg_panel'   => '#0d1527',
            'bg_card'    => '#132038',
            'borde'      => '#233860',
            'primario'   => '#3b82f6',
            'secundario' => '#38bdf8',
            'gradiente'  => 'linear-gradient(135deg, #0b1c3d 0%, #17366e 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Factor de Seguridad Sísmico', 'valor' => 'FS ≥ 2.40', 'sub' => 'Cimentaciones y superestructuras validadas'],
            ['titulo' => 'Resistencia Concreto', 'valor' => '450 kg/cm² / MR-48', 'sub' => 'Pruebas de cilindro y deflexión aprobadas'],
            ['titulo' => 'Precisión Topográfica', 'valor' => '± 0.02 mm', 'sub' => 'Control láser con estación total en campo'],
            ['titulo' => 'Instalaciones MEP y Red', 'valor' => '1,500 kVA / 150 PSI', 'sub' => 'Balanceo eléctrico y pruebas hidrostáticas OK']
        ],
        'widget_titulo' => '📐 Parámetros Técnicos de Ingeniería y Ensayos de Laboratorio',
        'monitores' => [
            ['nombre' => 'Memorias de Cálculo Estructural y Cimentación Profunda (Pilotes)', 'estado' => 'Certificado', 'porcentaje' => 98, 'color' => '#3b82f6'],
            ['nombre' => 'Ensayos de Resistencia f\'c, Deflexión en Pistas y Fatiga en Puentes', 'estado' => 'En Norma Técnica', 'porcentaje' => 92, 'color' => '#10b981'],
            ['nombre' => 'Pruebas Hidrostáticas, Gases Medicinales, Media Tensión y Fibra OTDR', 'estado' => 'Sin Fugas / <0.2dB', 'porcentaje' => 95, 'color' => '#38bdf8'],
            ['nombre' => 'Cuantificación de Volúmenes de Obra y Control de Costos', 'estado' => 'Desviación +1.8%', 'porcentaje' => 88, 'color' => '#f59e0b']
        ],
        'form_titulo' => 'Registrar Memoria de Cálculo, Ensayo Técnico o Levantamiento',
        'lbl_folio'   => 'Código de Dictamen Técnico',
        'ph_folio'    => 'Ej. ING-EST-402 o TOP-NIV-19',
        'lbl_subarea' => 'Especialidad de Ingeniería',
        'sub_areas'   => [
            'Ingeniería Estructural (Cimentaciones, Acero y Sismo)',
            'Ingeniería Civil, Geotecnia y Mecánica de Suelos',
            'Ingeniería de Instalaciones (Eléctricas, Hidrosanitarias, HVAC y Especiales)',
            'Brigada de Topografía (Trazo, Nivelación y Batimetría)',
            'Planeación Técnica, Cuantificación y Control de Costos de Obra'
        ],
        'lbl_desc'    => 'Especificación Técnica, Ensayo o Revisión en Obra',
        'ph_desc'     => 'Ej. Prueba de carga estática en pilotes de cimentación eje B-12...',
        'lbl_metrica' => 'Parámetro Obtenido / Resultado de Laboratorio',
        'ph_metrica'  => 'Ej. f\'c = 450 kg/cm2 / Factor Seguridad 2.5',
        'mostrar_herramientas_obra' => true
    ],

    'ARQUITECTOS' => [
        'sistema_nombre' => 'ARCA Design & BIM Studio • Arquitectura y Modelado Digital',
        'area_corta'     => 'Coordinación Arquitectónica, Planos As-Built CAD, Modelos BIM LOD 400 y Sustentabilidad LEED',
        'credencial'     => 'Oficina Técnica de Arquitectura & BIM',
        'icono'          => '📐',
        'tema'           => [
            'bg_body'    => '#09090f',
            'bg_panel'   => '#12121e',
            'bg_card'    => '#1a1a2b',
            'borde'      => '#2e2e4d',
            'primario'   => '#ec4899',
            'secundario' => '#8b5cf6',
            'gradiente'  => 'linear-gradient(135deg, #241236 0%, #3d1430 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Modelos Federados BIM', 'valor' => 'LOD 400 / 500', 'sub' => 'Detección de interferencias (Clash Detection) OK'],
            ['titulo' => 'Planos As-Built Emitidos', 'valor' => '94 Láminas', 'sub' => 'Plantas, cortes, fachadas y detalles CAD'],
            ['titulo' => 'Eficiencia Bioclimática', 'valor' => '-32% Carga Térmica', 'sub' => 'Muros cortina Low-E con estándar LEED'],
            ['titulo' => 'Normatividad Arquitectónica', 'valor' => '100% Aprobada', 'sub' => 'Áreas limpias NOM-016 y blindaje acústico']
        ],
        'widget_titulo' => '🖥️ Estado de Modelos Digitales BIM, Láminas CAD y Acabados',
        'monitores' => [
            ['nombre' => 'Coordinación BIM 3D/4D (Arquitectura, Estructura e Instalaciones MEP)', 'estado' => '0 Interferencias', 'porcentaje' => 97, 'color' => '#ec4899'],
            ['nombre' => 'Emisión de Planos Ejecutivos CAD y Actualización As-Built', 'estado' => 'Rev. 3.0 Liberada', 'porcentaje' => 91, 'color' => '#8b5cf6'],
            ['nombre' => 'Diseño Bioclimático, Acústico y Certificación Sustentable LEED', 'estado' => 'Estándar Platino', 'porcentaje' => 94, 'color' => '#10b981'],
            ['nombre' => 'Aprobación de Catálogo de Acabados, Fachadas y Áreas Especiales', 'estado' => '2 Obras en Firma', 'porcentaje' => 86, 'color' => '#f59e0b']
        ],
        'form_titulo' => 'Registrar Entrega de Plano Ejecutivo, Modelo BIM o Especificación de Diseño',
        'lbl_folio'   => 'Código de Lámina CAD / Modelo BIM',
        'ph_folio'    => 'Ej. ARQ-CAD-305 o BIM-MEP-12',
        'lbl_subarea' => 'Coordinación de Diseño',
        'sub_areas'   => [
            'Arquitectura Ejecutiva y Planos As-Built (CAD)',
            'Modelado Digital BIM 3D/4D y Detección de Interferencias',
            'Diseño de Fachadas, Muros Cortina y Bioclimática LEED',
            'Arquitectura de Interiores, Acabados y Zonificación Comercial',
            'Diseño Especializado (Hospitalario NOM-016, Centros C5 y Militar)'
        ],
        'lbl_desc'    => 'Descripción del Proyecto Arquitectónico o Revisión Geométrica',
        'ph_desc'     => 'Ej. Liberación de planos de detalles constructivos en fachada sur...',
        'lbl_metrica' => 'Nivel de Desarrollo (LOD) / Revisión Aprobada',
        'ph_metrica'  => 'Ej. Modelo LOD 400 / Rev. 4.0 Aprobada',
        'mostrar_herramientas_obra' => true
    ],

    'ALMACEN' => [
        'sistema_nombre' => 'ARCA WMS • Control de Almacenes, Logística y Maquinaria Pesada',
        'area_corta'     => 'Gestión de Inventarios en Obra, Recepción/Despacho, Transporte y Flotilla de Maquinaria',
        'credencial'     => 'Cadena de Suministro & Equipos',
        'icono'          => '📦',
        'tema'           => [
            'bg_body'    => '#0c0a07',
            'bg_panel'   => '#17130d',
            'bg_card'    => '#211b12',
            'borde'      => '#3d311f',
            'primario'   => '#f59e0b',
            'secundario' => '#10b981',
            'gradiente'  => 'linear-gradient(135deg, #291d0a 0%, #422c0c 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Acero y Concreto en Stock', 'valor' => '237.5 Ton / 850 m³', 'sub' => 'Trazabilidad por lote en patios de obra'],
            ['titulo' => 'Maquinaria Pesada Activa', 'valor' => '11 Unidades', 'sub' => 'Grúas torre, excavadoras CAT y dragas'],
            ['titulo' => 'Rutas y Tránsitos Activos', 'valor' => '100% Custodiados', 'sub' => 'Suministro continuo a los 10 frentes'],
            ['titulo' => 'Alertas de Reorden (Stock)', 'valor' => '2 Insumos Críticos', 'sub' => 'Block térmico (PUB-02) y Acero balístico (SEC-08)']
        ],
        'widget_titulo' => '🚜 Disponibilidad de Materiales Críticos y Flotilla de Maquinaria',
        'monitores' => [
            ['nombre' => 'Abastecimiento de Acero Estructural, Cemento y Concreto MR-48', 'estado' => 'Stock Óptimo', 'porcentaje' => 93, 'color' => '#10b981'],
            ['nombre' => 'Operatividad de Grúas Torre, Excavadoras, Dragas y Pavimentadoras', 'estado' => '92% Disponibilidad', 'porcentaje' => 92, 'color' => '#f59e0b'],
            ['nombre' => 'Resguardo de Materiales Especiales (Cristal Low-E, Cobre Médico, Fibra)', 'estado' => 'Bodegas Selladas', 'porcentaje' => 100, 'color' => '#38bdf8'],
            ['nombre' => 'Reposición de Stock Mínimo en Almacenes Regionales', 'estado' => '2 Órdenes Urgentes', 'porcentaje' => 74, 'color' => '#ef4444']
        ],
        'form_titulo' => 'Registrar Vale de Entrada/Despacho, Flete Logístico o Bitácora de Maquinaria',
        'lbl_folio'   => 'Folio de Vale / Guía de Remisión',
        'ph_folio'    => 'Ej. ALM-VAL-209 o MAQ-BIT-44',
        'lbl_subarea' => 'Área de Almacén, Logística o Maquinaria',
        'sub_areas'   => [
            'Recepción, Resguardo y Despacho de Materiales en Obra',
            'Logística de Transporte, Fletes y Entregas Custodiadas',
            'Control de Stock Crítico e Inventario Físico',
            'Operación de Maquinaria Pesada (Grúas, Excavadoras, Dragas)',
            'Taller Mecánico y Mantenimiento Preventivo de Flotilla'
        ],
        'lbl_desc'    => 'Detalle del Suministro, Movimiento de Almacén o Equipo',
        'ph_desc'     => 'Ej. Despacho de 25 toneladas de varilla corrugada a Frente Cimentación...',
        'lbl_metrica' => 'Cantidad / Tonelaje / Horas Máquina',
        'ph_metrica'  => 'Ej. 25.0 Toneladas Despachadas / 180 Hrs Máquina',
        'mostrar_herramientas_obra' => true
    ],

    'RRHH' => [
        'sistema_nombre' => 'ARCA HCM • Sistema de Gestión de Capital Humano y Enlaces de Obra',
        'area_corta'     => 'Plantilla Activa, Asistencia Biométrica, Nómina, Certificaciones DC-3 y Relaciones Laborales',
        'credencial'     => 'Administración de Personal & Talento',
        'icono'          => '👥',
        'tema'           => [
            'bg_body'    => '#05100d',
            'bg_panel'   => '#0a1c17',
            'bg_card'    => '#102821',
            'borde'      => '#1d473b',
            'primario'   => '#10b981',
            'secundario' => '#34d399',
            'gradiente'  => 'linear-gradient(135deg, #092920 0%, #114235 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Fuerza Laboral en Obras', 'valor' => '1,283 Activos', 'sub' => 'Plantilla distribuida en los 10 proyectos'],
            ['titulo' => 'Asistencia Biométrica', 'valor' => '98.6%', 'sub' => 'Control de turnos en campo y oficinas'],
            ['titulo' => 'Certificaciones STPS (DC-3)', 'valor' => '94% Vigentes', 'sub' => 'Trabajo en alturas, grúas y seguridad'],
            ['titulo' => 'Filtros de Confianza', 'valor' => '450 Aprobados', 'sub' => 'Acreditación SEDENA y CNI para obras secretas']
        ],
        'widget_titulo' => '📋 Indicadores de Plantilla, Certificaciones STPS y Clima Laboral',
        'monitores' => [
            ['nombre' => 'Control de Asistencia Biométrica e Incidencias Quincenales en Obra', 'estado' => 'Nómina Liberada', 'porcentaje' => 99, 'color' => '#10b981'],
            ['nombre' => 'Altas IMSS, Contratos por Obra Determinada y Expedientes', 'estado' => '100% Auditados', 'porcentaje' => 100, 'color' => '#34d399'],
            ['nombre' => 'Capacitación Técnica y Constancias de Competencias DC-3 (STPS)', 'estado' => '1 Grupo en Renovación', 'porcentaje' => 90, 'color' => '#f59e0b'],
            ['nombre' => 'Cobertura de Vacantes Especializadas en Proyectos de Alta Seguridad', 'estado' => '16 Vacantes Activas', 'porcentaje' => 84, 'color' => '#38bdf8']
        ],
        'form_titulo' => 'Registrar Movimiento de Personal, Incidencia de Nómina o Capacitación DC-3',
        'lbl_folio'   => 'Folio de Expediente / Incidencia RH',
        'ph_folio'    => 'Ej. RH-NOM-401 o DC3-CAP-18',
        'lbl_subarea' => 'Proceso de Capital Humano',
        'sub_areas'   => [
            'Control de Asistencia Biométrica y Enlace RH en Obra',
            'Reclutamiento, Selección y Contratación de Especialistas',
            'Nómina Quincenal, Prestaciones, Altas IMSS y Finiquitos',
            'Capacitación Técnica, Inducción SST y Certificaciones DC-3',
            'Relaciones Laborales, Sindicatos y Filtros de Confianza (SEDENA/CNI)'
        ],
        'lbl_desc'    => 'Descripción del Movimiento de Personal o Curso Aplicado',
        'ph_desc'     => 'Ej. Alta en IMSS e inducción de seguridad para cuadrilla de estructuristas...',
        'lbl_metrica' => 'Personal Impactado / Indicador de Cumplimiento',
        'ph_metrica'  => 'Ej. 18 Trabajadores Certificados / 0 Incidencias',
        'mostrar_herramientas_obra' => false
    ],

    'SEGURIDAD' => [
        'sistema_nombre' => 'ARCA Command Center • Seguridad Industrial (SST/HSE), Patrimonial y Ciberdefensa',
        'area_corta'     => 'Prevención de Riesgos en Obra, Vigilancia Perimetral 24/7, Control de Accesos y Cifrado TI',
        'credencial'     => 'Centro de Operaciones de Seguridad',
        'icono'          => '🛡️',
        'tema'           => [
            'bg_body'    => '#0d0608',
            'bg_panel'   => '#180b0e',
            'bg_card'    => '#241015',
            'borde'      => '#471c25',
            'primario'   => '#ef4444',
            'secundario' => '#f59e0b',
            'gradiente'  => 'linear-gradient(135deg, #2e0d15 0%, #4a151b 100%)'
        ],
        'kpis' => [
            ['titulo' => 'Índice de Siniestralidad SST', 'valor' => '0 Accidentes', 'sub' => '120 días continuos sin incidentes incapacitantes'],
            ['titulo' => 'Anillos Perimetrales y CCTV', 'valor' => '10 / 10 Obras', 'sub' => 'Control de acceso biométrico y vehicular 24/7'],
            ['titulo' => 'Permisos de Alto Riesgo', 'valor' => '100% Supervisados', 'sub' => 'Trabajos en alturas, izajes críticos y corte'],
            ['titulo' => 'Ciberdefensa e ISO 27001', 'valor' => '0 Intrusiones', 'sub' => 'Túneles VPN y cifrado militar en obras C5/CNI']
        ],
        'widget_titulo' => '🚨 Estado Táctico de las 3 Divisiones de Seguridad ARCA',
        'monitores' => [
            ['nombre' => 'División 1 — Seguridad y Salud en el Trabajo (SST/HSE y Líneas de Vida)', 'estado' => 'Cero Accidentes', 'porcentaje' => 100, 'color' => '#10b981'],
            ['nombre' => 'División 2 — Seguridad Patrimonial, Guardias, CCTV y Código PBIP', 'estado' => 'Vigilancia 24/7 Activa', 'porcentaje' => 96, 'color' => '#f59e0b'],
            ['nombre' => 'División 2 — Protocolos de Enlace Militar y Esclusas Biométricas (SEDENA/CNI)', 'estado' => 'Alerta Alfa Blindada', 'porcentaje' => 100, 'color' => '#ef4444'],
            ['nombre' => 'División 3 — Ciberseguridad Informática, Firewalls y Resguardo de Planos', 'estado' => 'Cifrado AES-256 OK', 'porcentaje' => 99, 'color' => '#38bdf8']
        ],
        'form_titulo' => 'Registrar Inspección SST/HSE, Bitácora Patrimonial o Protocolo de Seguridad',
        'lbl_folio'   => 'Folio de Bitácora / Permiso de Riesgo',
        'ph_folio'    => 'Ej. SEG-SST-704 o PAT-ACC-15',
        'lbl_subarea' => 'División de Seguridad Aplicable',
        'sub_areas'   => [
            'Seguridad y Salud en el Trabajo (SST/HSE — Alturas, Izajes y EPP)',
            'Prevención de Incendios, Simulacros y Respuesta a Emergencias',
            'Seguridad Patrimonial (Control de Accesos, Guardias y Rondines CCTV)',
            'Enlace de Seguridad Nacional y Perímetros Clasificados (SEDENA / CNI)',
            'Ciberseguridad Industrial, Biometría y Protección de Datos de Obra'
        ],
        'lbl_desc'    => 'Descripción de la Inspección, Operativo o Protocolo Ejecutado',
        'ph_desc'     => 'Ej. Liberación de permiso de izaje crítico con grúa torre y revisión de arneses...',
        'lbl_metrica' => 'Resultado de la Inspección / Nivel de Alerta',
        'ph_metrica'  => 'Ej. 0 Incidencias / Zona Liberada / Nivel Alfa',
        'mostrar_herramientas_obra' => false
    ]
];

$suite = $suites_corporativas[$depto_activo];
$tema  = $suite['tema'];

$mensaje_exito = "";
$mensaje_error = "";

// =========================================================================
// 4. PROCESAMIENTO SEGURO DEL FORMULARIO (CSRF + PREPARED STATEMENTS)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'guardar_operacion') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $mensaje_error = "🚨 Error de Seguridad: Token de sesión inválido.";
    } else {
        $folio_post = trim($_POST['folio_control'] ?? '');
        $obra_post  = trim($_POST['codigo_obra'] ?? 'ARCA-PUB-01');
        $sub_post   = trim($_POST['sub_area_jerarquica'] ?? '');
        $act_post   = trim($_POST['actividad_expediente'] ?? '');
        $met_post   = trim($_POST['metrica_valor'] ?? '');
        $est_post   = trim($_POST['estado_operativo'] ?? 'Validado');
        $resp_post  = $nombre_usuario . " (" . $usuario_activo . ")";
        $fecha_hoy  = date('Y-m-d');

        $restringido_obra_post = (strpos($obra_sesion, 'GLOBAL') === false && $obra_sesion !== 'CORPORATIVO' && !$es_ceo);
        if ($restringido_obra_post) {
            $obra_post = $obra_sesion;
        }

        if ($folio_post !== '' && $act_post !== '' && $met_post !== '') {
            $stmt = $conectar->prepare("INSERT INTO operaciones_departamentos_arca 
                (departamento, codigo_obra, folio_control, sub_area_jerarquica, actividad_expediente, responsable_directo, metrica_valor, estado_operativo, fecha_actualizacion) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("sssssssss", $depto_activo, $obra_post, $folio_post, $sub_post, $act_post, $resp_post, $met_post, $est_post, $fecha_hoy);
                if ($stmt->execute()) {
                    $mensaje_exito = "✅ Registro [$folio_post] certificado y almacenado de forma segura en la obra $obra_post.";
                } else {
                    $mensaje_error = "⚠️ Error al registrar en base de datos: " . $stmt->error;
                }
                $stmt->close();
            }
        } else {
            $mensaje_error = "⚠️ Todos los campos operativos son obligatorios.";
        }
    }
}

// =========================================================================
// 5. CONSULTA PARAMETRIZADA DE REGISTROS POR OBRA
// =========================================================================
$restringido_obra = (strpos($obra_sesion, 'GLOBAL') === false && $obra_sesion !== 'CORPORATIVO' && !$es_ceo);
$filtro_obra      = $restringido_obra ? $obra_sesion : ($_SESSION['filtro_obra_depto'] ?? 'TODAS');

if ($filtro_obra !== 'TODAS') {
    $stmt_q = $conectar->prepare("SELECT * FROM operaciones_departamentos_arca WHERE departamento = ? AND codigo_obra = ? ORDER BY id_operacion DESC");
    $stmt_q->bind_param("ss", $depto_activo, $filtro_obra);
} else {
    $stmt_q = $conectar->prepare("SELECT * FROM operaciones_departamentos_arca WHERE departamento = ? ORDER BY id_operacion DESC");
    $stmt_q->bind_param("s", $depto_activo);
}
$stmt_q->execute();
$q_registros = $stmt_q->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($suite['sistema_nombre']); ?></title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: <?php echo $tema['bg_body']; ?>;
            color: #f1f5f9;
            margin: 0;
            padding: 24px 36px;
        }

        .ceo-audit-bar {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 10px 18px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .ceo-audit-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .ceo-tab {
            padding: 7px 13px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 700;
            color: #cbd5e1;
            background: #1e293b;
            border: 1px solid #334155;
            cursor: pointer;
            transition: 0.2s;
        }
        .ceo-tab:hover { color: #fff; border-color: #64748b; }
        .ceo-tab.active {
            background: <?php echo $tema['primario']; ?>;
            color: #000;
            border-color: <?php echo $tema['primario']; ?>;
        }

        .top-header {
            background: <?php echo $tema['gradiente']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            border-left: 6px solid <?php echo $tema['primario']; ?>;
            border-radius: 12px;
            padding: 22px 28px;
            margin-bottom: 22px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.45);
        }
        .credencial-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(0,0,0,0.45);
            border: 1px solid <?php echo $tema['primario']; ?>;
            color: <?php echo $tema['primario']; ?>;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }
        .top-header h1 { margin: 8px 0 4px 0; font-size: 23px; color: #ffffff; }
        .top-header p { margin: 0; font-size: 13px; color: #cbd5e1; }
        .header-actions { display: flex; align-items: center; gap: 10px; }
        .btn-action {
            background: rgba(15, 23, 42, 0.75);
            border: 1px solid <?php echo $tema['borde']; ?>;
            color: #f8fafc;
            text-decoration: none;
            padding: 10px 16px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            transition: 0.2s;
        }
        .btn-action:hover {
            border-color: <?php echo $tema['primario']; ?>;
            background: rgba(255,255,255,0.08);
        }
        .btn-logout {
            background: #dc2626;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 13px;
        }

        .kpi-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .kpi-card {
            background: <?php echo $tema['bg_panel']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            border-top: 3px solid <?php echo $tema['primario']; ?>;
            border-radius: 10px;
            padding: 18px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .kpi-card .k-title { font-size: 12px; color: #94a3b8; text-transform: uppercase; font-weight: 700; }
        .kpi-card .k-val { font-size: 24px; font-weight: 800; color: #ffffff; margin: 6px 0 4px 0; }
        .kpi-card .k-sub { font-size: 12px; color: <?php echo $tema['secundario']; ?>; }

        .alert-ok { background: #064e3b; border: 1px solid #10b981; color: #a7f3d0; padding: 13px 18px; border-radius: 8px; margin-bottom: 18px; font-weight: 600; font-size: 13px; }
        .alert-err { background: #7f1d1d; border: 1px solid #ef4444; color: #fecaca; padding: 13px 18px; border-radius: 8px; margin-bottom: 18px; font-weight: 600; font-size: 13px; }

        .workspace-grid {
            display: grid;
            grid-template-columns: 1.05fr 1.25fr;
            gap: 22px;
            margin-bottom: 28px;
        }
        .panel-box {
            background: <?php echo $tema['bg_panel']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            border-radius: 12px;
            padding: 22px 24px;
        }
        .panel-box h3 {
            margin: 0 0 18px 0;
            font-size: 16px;
            color: #ffffff;
            padding-bottom: 12px;
            border-bottom: 1px solid <?php echo $tema['borde']; ?>;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .monitor-item {
            background: <?php echo $tema['bg_card']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            border-radius: 8px;
            padding: 13px 16px;
            margin-bottom: 12px;
        }
        .monitor-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            font-size: 13px;
        }
        .monitor-name { font-weight: 600; color: #e2e8f0; }
        .monitor-badge {
            font-size: 11px;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 12px;
            background: rgba(255,255,255,0.08);
        }
        .progress-track { width: 100%; height: 7px; background: rgba(0,0,0,0.45); border-radius: 4px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 4px; }
        .security-footer {
            margin-top: 14px;
            padding: 10px 14px;
            border-radius: 8px;
            background: rgba(0,0,0,0.35);
            border: 1px dashed <?php echo $tema['borde']; ?>;
            font-size: 12px;
            color: #94a3b8;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .field { display: flex; flex-direction: column; gap: 6px; }
        .field.full { grid-column: span 2; }
        .field label { font-size: 11px; color: #94a3b8; font-weight: 700; text-transform: uppercase; }
        .field input, .field select {
            background: <?php echo $tema['bg_card']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            color: #ffffff;
            padding: 10px 12px;
            border-radius: 7px;
            font-size: 13px;
        }
        .btn-submit {
            margin-top: 16px;
            width: 100%;
            background: <?php echo $tema['primario']; ?>;
            color: #050811;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 800;
            font-size: 13px;
            cursor: pointer;
            text-transform: uppercase;
        }

        .table-header-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .table-wrap {
            background: <?php echo $tema['bg_panel']; ?>;
            border: 1px solid <?php echo $tema['borde']; ?>;
            border-radius: 12px;
            overflow: hidden;
        }
        table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
        th {
            background: <?php echo $tema['bg_card']; ?>;
            color: <?php echo $tema['primario']; ?>;
            padding: 14px 16px;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 11px;
            border-bottom: 1px solid <?php echo $tema['borde']; ?>;
        }
        td { padding: 13px 16px; border-bottom: 1px solid <?php echo $tema['borde']; ?>; color: #cbd5e1; }

        .st-ok   { background: #064e3b; color: #34d399; padding: 4px 9px; border-radius: 4px; font-size: 11px; font-weight: 700; }
        .st-proc { background: #1e3a8a; color: #93c5fd; padding: 4px 9px; border-radius: 4px; font-size: 11px; font-weight: 700; }
        .st-urg  { background: #78350f; color: #fcd34d; padding: 4px 9px; border-radius: 4px; font-size: 11px; font-weight: 700; }
        .st-sec  { background: #4c1d95; color: #c4b5fd; padding: 4px 9px; border-radius: 4px; font-size: 11px; font-weight: 700; }
        .st-crit { background: #7f1d1d; color: #fca5a5; padding: 4px 9px; border-radius: 4px; font-size: 11px; font-weight: 700; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <!-- BARRA DE AUDITORÍA DEL CEO VÍA POST (SIN EXPONER PARÁMETROS EN LA URL) -->
    <?php if ($es_ceo) { ?>
    <div class="ceo-audit-bar">
        <span style="font-size: 12px; font-weight: 700; color: #93c5fd;">👁️ MODO AUDITORÍA DIRECTIVA (CEO) — SELECCIONAR SUITE DEPARTAMENTAL:</span>
        <div class="ceo-audit-links">
            <?php foreach ($suites_corporativas as $clave => $info) { ?>
                <form method="POST" action="panel_departamentos_arca.php" style="margin:0;">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="accion_contexto" value="cambiar_depto_ceo">
                    <input type="hidden" name="depto_destino" value="<?php echo htmlspecialchars($clave); ?>">
                    <button type="submit" class="ceo-tab <?php echo ($depto_activo === $clave) ? 'active' : ''; ?>">
                        <?php echo $info['icono'] . " " . htmlspecialchars($clave); ?>
                    </button>
                </form>
            <?php } ?>
        </div>
    </div>
    <?php } ?>

    <div class="top-header">
        <div>
            <span class="credencial-pill">
                🔒 <?php echo htmlspecialchars($suite['credencial']); ?> • Sesión Cifrada: <?php echo htmlspecialchars($usuario_activo); ?>
            </span>
            <h1><?php echo $suite['icono'] . " " . htmlspecialchars($suite['sistema_nombre']); ?></h1>
            <p><?php echo htmlspecialchars($suite['area_corta']); ?> | Responsable Activo: <b><?php echo htmlspecialchars($nombre_usuario); ?></b></p>
        </div>
        <div class="header-actions">
            <?php if ($es_ceo) { ?>
                <a href="panel_ceo.php" class="btn-action">🏛️ Volver a Gobierno Corporativo</a>
            <?php } ?>
            <?php if ($suite['mostrar_herramientas_obra'] || $es_ceo) { ?>
                <a href="panel_oficina_almacen.php" class="btn-action">📐 Repositorio de Planos y Stock</a>
            <?php } ?>
            <a href="cerrar_sesion.php" class="btn-logout">Cerrar Sesión</a>
        </div>
    </div>

    <?php if ($mensaje_exito !== "") { ?>
        <div class="alert-ok"><?php echo htmlspecialchars($mensaje_exito); ?></div>
    <?php } ?>
    <?php if ($mensaje_error !== "") { ?>
        <div class="alert-err"><?php echo htmlspecialchars($mensaje_error); ?></div>
    <?php } ?>

    <div class="kpi-row">
        <?php foreach ($suite['kpis'] as $k) { ?>
        <div class="kpi-card">
            <div class="k-title"><?php echo htmlspecialchars($k['titulo']); ?></div>
            <div class="k-val"><?php echo htmlspecialchars($k['valor']); ?></div>
            <div class="k-sub"><?php echo htmlspecialchars($k['sub']); ?></div>
        </div>
        <?php } ?>
    </div>

    <div class="workspace-grid">
        <div class="panel-box">
            <h3>
                <span><?php echo htmlspecialchars($suite['widget_titulo']); ?></span>
                <span style="font-size: 11px; color: #94a3b8; font-weight: 600;">Tiempo Real • 10 Obras</span>
            </h3>

            <?php foreach ($suite['monitores'] as $mon) { ?>
            <div class="monitor-item">
                <div class="monitor-top">
                    <span class="monitor-name"><?php echo htmlspecialchars($mon['nombre']); ?></span>
                    <span class="monitor-badge" style="border: 1px solid <?php echo $mon['color']; ?>; color: <?php echo $mon['color']; ?>;">
                        <?php echo htmlspecialchars($mon['estado']); ?> (<?php echo intval($mon['porcentaje']); ?>%)
                    </span>
                </div>
                <div class="progress-track">
                    <div class="progress-fill" style="width: <?php echo intval($mon['porcentaje']); ?>%; background: <?php echo $mon['color']; ?>;"></div>
                </div>
            </div>
            <?php } ?>

            <div class="security-footer">
                <span>🛡️ <b>URL Limpia & Blindaje RBAC:</b> Enrutamiento por Sesión Cifrada</span>
                <span style="color: <?php echo $tema['secundario']; ?>; font-weight: 700;">Alcance: <?php echo htmlspecialchars($filtro_obra); ?></span>
            </div>
        </div>

        <div class="panel-box">
            <h3>➕ <?php echo htmlspecialchars($suite['form_titulo']); ?></h3>
            <form method="POST" action="panel_departamentos_arca.php">
                <input type="hidden" name="accion" value="guardar_operacion">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

                <div class="form-grid">
                    <div class="field">
                        <label><?php echo htmlspecialchars($suite['lbl_folio']); ?></label>
                        <input type="text" name="folio_control" placeholder="<?php echo htmlspecialchars($suite['ph_folio']); ?>" required>
                    </div>

                    <div class="field">
                        <label>Proyecto / Obra Asignada</label>
                        <select name="codigo_obra">
                            <?php if (!$restringido_obra) { ?>
                                <option value="ARCA-PUB-01">ARCA-PUB-01 — Torre ARCA 1</option>
                                <option value="ARCA-PUB-02">ARCA-PUB-02 — Residencial Norte</option>
                                <option value="ARCA-PUB-03">ARCA-PUB-03 — Plaza Comercial Puebla</option>
                                <option value="ARCA-PUB-04">ARCA-PUB-04 — Edificio Corporativo Sur</option>
                                <option value="ARCA-PUB-05">ARCA-PUB-05 — Ampliación Puerto Manzanillo</option>
                                <option value="ARCA-SEC-06">ARCA-SEC-06 — [CLASIFICADA] Base Aérea V</option>
                                <option value="ARCA-SEC-07">ARCA-SEC-07 — [CLASIFICADA] Hospital Federal S-9</option>
                                <option value="ARCA-SEC-08">ARCA-SEC-08 — [CLASIFICADA] Búnker CNI</option>
                                <option value="ARCA-SEC-09">ARCA-SEC-09 — [CLASIFICADA] Red C5</option>
                                <option value="ARCA-SEC-10">ARCA-SEC-10 — [CLASIFICADA] Puente Fronterizo</option>
                            <?php } else { ?>
                                <option value="<?php echo htmlspecialchars($obra_sesion); ?>"><?php echo htmlspecialchars($obra_sesion); ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="field full">
                        <label><?php echo htmlspecialchars($suite['lbl_subarea']); ?></label>
                        <select name="sub_area_jerarquica">
                            <?php foreach ($suite['sub_areas'] as $sub) { ?>
                                <option value="<?php echo htmlspecialchars($sub); ?>"><?php echo htmlspecialchars($sub); ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="field full">
                        <label><?php echo htmlspecialchars($suite['lbl_desc']); ?></label>
                        <input type="text" name="actividad_expediente" placeholder="<?php echo htmlspecialchars($suite['ph_desc']); ?>" required>
                    </div>

                    <div class="field">
                        <label><?php echo htmlspecialchars($suite['lbl_metrica']); ?></label>
                        <input type="text" name="metrica_valor" placeholder="<?php echo htmlspecialchars($suite['ph_metrica']); ?>" required>
                    </div>

                    <div class="field">
                        <label>Dictamen / Estatus</label>
                        <select name="estado_operativo">
                            <option value="Validado">Validado / Aprobado</option>
                            <option value="En Proceso">En Proceso / En Revisión</option>
                            <option value="Urgente">Urgente / Prioridad Alta</option>
                            <option value="Blindado">Blindado (Protocolo Gubernamental)</option>
                            <option value="Crítico">Crítico / Alerta Activa</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Certificar y Guardar en Base de Datos</button>
            </form>
        </div>
    </div>

    <div class="table-header-bar">
        <h3 style="margin: 0; font-size: 16px; color: #ffffff;">
            📁 Expedientes y Operaciones Registradas — <?php echo htmlspecialchars($suite['sistema_nombre']); ?>
        </h3>
        <?php if (!$restringido_obra) { ?>
        <form method="POST" action="panel_departamentos_arca.php" style="display: flex; gap: 8px; align-items: center; margin: 0;">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <input type="hidden" name="accion_contexto" value="filtrar_obra">
            <select name="obra_seleccionada" style="background: <?php echo $tema['bg_card']; ?>; color: #fff; border: 1px solid <?php echo $tema['borde']; ?>; padding: 8px 12px; border-radius: 6px; font-size: 12px;">
                <option value="TODAS" <?php echo ($filtro_obra === 'TODAS') ? 'selected' : ''; ?>>Todas las 10 Obras (5 Públicas / 5 Clasificadas)</option>
                <option value="ARCA-PUB-01" <?php echo ($filtro_obra === 'ARCA-PUB-01') ? 'selected' : ''; ?>>ARCA-PUB-01 — Torre ARCA 1</option>
                <option value="ARCA-PUB-02" <?php echo ($filtro_obra === 'ARCA-PUB-02') ? 'selected' : ''; ?>>ARCA-PUB-02 — Residencial Norte</option>
                <option value="ARCA-PUB-03" <?php echo ($filtro_obra === 'ARCA-PUB-03') ? 'selected' : ''; ?>>ARCA-PUB-03 — Plaza Puebla</option>
                <option value="ARCA-PUB-04" <?php echo ($filtro_obra === 'ARCA-PUB-04') ? 'selected' : ''; ?>>ARCA-PUB-04 — Corporativo Sur</option>
                <option value="ARCA-PUB-05" <?php echo ($filtro_obra === 'ARCA-PUB-05') ? 'selected' : ''; ?>>ARCA-PUB-05 — Puerto Manzanillo</option>
                <option value="ARCA-SEC-06" <?php echo ($filtro_obra === 'ARCA-SEC-06') ? 'selected' : ''; ?>>ARCA-SEC-06 — Base Aérea V</option>
                <option value="ARCA-SEC-07" <?php echo ($filtro_obra === 'ARCA-SEC-07') ? 'selected' : ''; ?>>ARCA-SEC-07 — Hospital Federal S-9</option>
                <option value="ARCA-SEC-08" <?php echo ($filtro_obra === 'ARCA-SEC-08') ? 'selected' : ''; ?>>ARCA-SEC-08 — Búnker CNI</option>
                <option value="ARCA-SEC-09" <?php echo ($filtro_obra === 'ARCA-SEC-09') ? 'selected' : ''; ?>>ARCA-SEC-09 — Red C5</option>
                <option value="ARCA-SEC-10" <?php echo ($filtro_obra === 'ARCA-SEC-10') ? 'selected' : ''; ?>>ARCA-SEC-10 — Puente Fronterizo</option>
            </select>
            <button type="submit" style="background: <?php echo $tema['primario']; ?>; color: #000; border: none; padding: 8px 14px; border-radius: 6px; font-weight: 800; font-size: 12px; cursor: pointer;">Filtrar</button>
        </form>
        <?php } ?>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th><?php echo htmlspecialchars($suite['lbl_folio']); ?></th>
                <th>Obra</th>
                <th><?php echo htmlspecialchars($suite['lbl_subarea']); ?></th>
                <th><?php echo htmlspecialchars($suite['lbl_desc']); ?></th>
                <th>Responsable</th>
                <th><?php echo htmlspecialchars($suite['lbl_metrica']); ?></th>
                <th>Dictamen</th>
            </tr>
            <?php if ($q_registros && $q_registros->num_rows > 0) {
                while ($r = $q_registros->fetch_assoc()) {
                    $clase_st = 'st-ok';
                    if ($r['estado_operativo'] === 'En Proceso') $clase_st = 'st-proc';
                    if ($r['estado_operativo'] === 'Urgente')    $clase_st = 'st-urg';
                    if ($r['estado_operativo'] === 'Blindado')   $clase_st = 'st-sec';
                    if ($r['estado_operativo'] === 'Crítico')    $clase_st = 'st-crit';
            ?>
            <tr>
                <td style="font-family: 'Consolas', monospace; color: <?php echo $tema['primario']; ?>; font-weight: 700;">
                    <?php echo htmlspecialchars($r['folio_control']); ?>
                </td>
                <td><b style="color: <?php echo $tema['secundario']; ?>;"><?php echo htmlspecialchars($r['codigo_obra']); ?></b></td>
                <td style="color: #e2e8f0; font-weight: 600;"><?php echo htmlspecialchars($r['sub_area_jerarquica']); ?></td>
                <td style="color: #ffffff;"><?php echo htmlspecialchars($r['actividad_expediente']); ?></td>
                <td>
                    <?php echo htmlspecialchars($r['responsable_directo']); ?><br>
                    <span style="font-size: 11px; color: #64748b;"><?php echo htmlspecialchars($r['fecha_actualizacion']); ?></span>
                </td>
                <td style="font-family: 'Consolas', monospace; font-weight: 700; color: #f8fafc;">
                    <?php echo htmlspecialchars($r['metrica_valor']); ?>
                </td>
                <td><span class="<?php echo $clase_st; ?>"><?php echo htmlspecialchars(strtoupper($r['estado_operativo'])); ?></span></td>
            </tr>
            <?php } } else { ?>
            <tr>
                <td colspan="7" style="text-align: center; padding: 28px; color: #94a3b8;">
                    No existen expedientes registrados para la obra seleccionada.
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>