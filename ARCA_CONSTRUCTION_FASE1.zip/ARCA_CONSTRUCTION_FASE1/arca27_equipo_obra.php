<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca28_rh.php';
$db=a27_boot(['CEO','Director General','COO','CHRO','Gerente de Proyecto','Residente de Obra','Arquitecto','Ingeniero Civil']);
$functions=a28_functions();
$works=array_values(array_filter(arx_rows($db,'SELECT codigo_obra,nombre_proyecto FROM obras_coo ORDER BY codigo_obra'),
    static fn($w)=>a28_obra_acceso($db,(string)$w['codigo_obra'],'consultar')));
$allowed=array_column($works,'codigo_obra');
// Se limita el resultado visible a las obras autorizadas (obras clasificadas incluidas).
$actual=arx_rows($db,'SELECT r.codigo_obra,r.funcion,r.id_asignacion,a.id_empleado,a.cargo_obra,e.nombre_completo FROM arca27_responsables_obra r JOIN arca_asignaciones_personal a ON a.id_asignacion=r.id_asignacion JOIN arca_empleados e ON e.id_empleado=a.id_empleado');
$matrix=[];$validos=0;
foreach($actual as $r){
    if(!in_array($r['codigo_obra'],$allowed,true))continue;
    try {a28_validar_asignacion($db,(int)$r['id_asignacion'],$r['codigo_obra'],$r['funcion']);$r['vigente']=true;$validos++;}
    catch(Throwable $e){$r['vigente']=false;}
    $matrix[$r['codigo_obra']][$r['funcion']]=$r;
}
$propuestas=arx_rows($db,"SELECT p.codigo_obra,p.funcion,p.id_asignacion,p.estado,p.propuesto_por,p.propuesto_en,e.nombre_completo,a.cargo_obra FROM arca28_propuestas_responsables p JOIN arca_asignaciones_personal a ON a.id_asignacion=p.id_asignacion JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE p.estado='PENDIENTE' ORDER BY p.propuesto_en DESC");
$propuestas=array_values(array_filter($propuestas,static fn($p)=>in_array($p['codigo_obra'],$allowed,true)));
$options=[];
if(arx_role()==='CHRO'){
    $rows=arx_rows($db,"SELECT a.id_asignacion,a.codigo_obra,a.cargo_obra,e.nombre_completo FROM arca_asignaciones_personal a JOIN arca_empleados e ON e.id_empleado=a.id_empleado WHERE a.estado='ACTIVA' AND e.estado_laboral='ACTIVO' ORDER BY a.codigo_obra,e.nombre_completo");
    foreach($rows as $r){if(!in_array($r['codigo_obra'],$allowed,true))continue;try {a28_validar_asignacion($db,(int)$r['id_asignacion'],$r['codigo_obra']);$options[]=$r;}catch(Throwable $e){}}
}
$missing=count($works)*count($functions)-$validos;
a27_layout('Responsables obligatorios por obra','CHRO propone funciones basadas en contratos y asignaciones vigentes; COO las confirma y CEO consulta la cobertura.','arca27_equipo_obra.php');
?>
<section class="a27-grid">
  <article class="a27-card"><div class="a27-sub">Obras autorizadas</div><div class="a27-metric"><?=count($works)?></div></article>
  <article class="a27-card"><div class="a27-sub">Responsabilidades confirmadas vigentes</div><div class="a27-metric"><?=$validos?></div></article>
  <article class="a27-card"><div class="a27-sub">Responsabilidades pendientes</div><div class="a27-metric"><?=$missing?></div></article>
  <article class="a27-card"><div class="a27-sub">Propuestas por revisar</div><div class="a27-metric"><?=count($propuestas)?></div></article>
</section>
<section class="a27-card"><h2>Matriz de cobertura por obra</h2>
  <div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Obra</th><?php foreach($functions as $label):?><th><?=a27_h($label)?></th><?php endforeach;?></tr></thead><tbody>
  <?php foreach($works as $w):?><tr><td><strong><?=a27_h($w['codigo_obra'])?></strong><div class="a27-sub"><?=a27_h($w['nombre_proyecto'])?></div></td>
  <?php foreach($functions as $func=>$label):$r=$matrix[$w['codigo_obra']][$func]??null;$ok=$r && $r['vigente'];?><td><span class="a27-label <?=$ok?'ok':'warn'?>"><?=$ok?'CONFIRMADO':'PENDIENTE'?></span><?php if($ok):?><div><?=a27_h($r['nombre_completo'])?></div><?php elseif($r):?><div class="a27-sub">Designación sin vigencia válida: renovar revisión</div><?php endif;?></td><?php endforeach;?></tr><?php endforeach;?>
  <?php if(!$works):?><tr><td colspan="5">Tu perfil no tiene obras asignadas o autorizadas.</td></tr><?php endif;?></tbody></table></div>
  <p class="a27-muted">Los 28 registros de <code>asignaciones_obra_arca</code> siguen como antecedentes, no como responsables certificados. Las bajas y los vencimientos dejan de contar automáticamente en esta vista.</p>
</section>
<?php if(arx_role()==='CHRO'):?>
<section class="a27-card"><h2>Proponer un responsable (CHRO)</h2>
<p class="a27-muted">Primero registra la validación documental y la asignación en <a href="arca28_validacion.php">Validación laboral</a>. El sistema vuelve a comprobar obra, contrato, función y fechas al enviar la propuesta.</p>
<form class="a27-form" method="post" action="arca28_guardar.php">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="proponer_responsable">
<label>Obra<select name="codigo_obra" required><?php foreach($works as $w):?><option value="<?=a27_h($w['codigo_obra'])?>"><?=a27_h($w['codigo_obra'].' · '.$w['nombre_proyecto'])?></option><?php endforeach;?></select></label>
<label>Responsabilidad<select name="funcion" required><?php a27_opt($functions); ?></select></label>
<label class="a27-wide">Asignación laboral vigente<select name="id_asignacion" required><?php foreach($options as $o):?><option value="<?=(int)$o['id_asignacion']?>">#<?=(int)$o['id_asignacion']?> · <?=a27_h($o['codigo_obra'].' · '.$o['nombre_completo'].' · '.$o['cargo_obra'])?></option><?php endforeach;?></select></label>
<button <?=empty($options)?'disabled':''?>>Proponer para revisión de COO</button>
</form>
<?php if(!$options):?><p class="a27-muted">Todavía no hay asignaciones validadas y vigentes disponibles para proponer.</p><?php endif;?></section>
<?php endif;?>
<?php if(in_array(arx_role(),['COO','CHRO','CEO','Director General'],true)):?>
<section class="a27-card"><h2>Propuestas pendientes de confirmar</h2>
<div class="a27-tbl-wrap"><table class="a27-table"><thead><tr><th>Obra</th><th>Responsabilidad</th><th>Empleado y cargo</th><th>Estado</th><?php if(arx_role()==='COO'):?><th>Decisión COO</th><?php endif;?></tr></thead><tbody>
<?php foreach($propuestas as $p):?><tr><td><?=a27_h($p['codigo_obra'])?></td><td><?=a27_h($functions[$p['funcion']]??$p['funcion'])?></td><td><?=a27_h($p['nombre_completo'])?><div class="a27-sub"><?=a27_h($p['cargo_obra'])?></div></td><td><span class="a27-label warn">PENDIENTE COO</span></td>
<?php if(arx_role()==='COO'):?><td><form method="post" action="arca28_guardar.php"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="accion" value="revisar_propuesta"><input type="hidden" name="codigo_obra" value="<?=a27_h($p['codigo_obra'])?>"><input type="hidden" name="funcion" value="<?=a27_h($p['funcion'])?>"><button name="decision" value="APROBAR">Aprobar</button> <button name="decision" value="RECHAZAR">Rechazar</button></form></td><?php endif;?></tr><?php endforeach;?>
<?php if(!$propuestas):?><tr><td colspan="<?=arx_role()==='COO'?5:4?>">No hay propuestas pendientes en las obras autorizadas.</td></tr><?php endif;?></tbody></table></div></section>
<?php endif;?>
<?php a27_end(); ?>
