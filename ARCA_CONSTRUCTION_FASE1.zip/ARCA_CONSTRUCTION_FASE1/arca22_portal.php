<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca22_accesos.php';
$all=array_values(array_unique(array_merge(...array_column(a22_catalogo(),'roles'))));
$db=arx_boot($all);
$obras=a22_obras_permitidas($db);
$seleccion=(string)($_GET['obra']??'');
$permitido = $seleccion!=='' && in_array($seleccion,array_column($obras,'codigo_obra'),true);
if(!$permitido)$seleccion='';
$grupos=[];$total=0;
foreach(a22_catalogo() as $ruta=>$meta){
    if(!a22_modulo_permitido($db,$ruta,$seleccion?:null))continue;
    $grupos[$meta['grupo']][]=['ruta'=>$ruta,'nombre'=>$meta['nombre'],'obra'=>!empty($meta['obra']),'disponible'=>is_file(__DIR__.'/'.$ruta)];$total++;
}
header('Cache-Control: private, no-store');
?>
<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>Portal corporativo · ARCA</title><link rel="stylesheet" href="assets/css/arca22.css?v=22"></head>
<body class="a22-body"><div class="a22-layout">
<aside class="a22-side"><a class="a22-brand" href="arca22_portal.php"><span>A</span><div><b>ARCA CONSTRUCTION</b><small>Sistema integrado ERP</small></div></a><div class="a22-label">NAVEGACIÓN GENERAL</div><a class="a22-nav active" href="arca22_portal.php">▦ &nbsp; Portal de módulos</a><a class="a22-nav" href="arca22_mis_permisos.php">♙ &nbsp; Mis permisos</a><a class="a22-nav" href="arca22_pruebas.php">▤ &nbsp; Estado de acceso</a><div class="a22-user"><strong><?=arx_h(arx_name())?></strong><small><?=arx_h(arx_role())?> · <?=arx_h($_SESSION['usuario_activo']??'')?></small><a href="cerrar_sesion.php">Cerrar sesión</a></div></aside>
<main class="a22-main"><div class="a22-top">ARCA / Navegación empresarial <span>Gestión corporativa</span></div>
<header class="a22-hero"><span class="a22-overline">PORTAL CORPORATIVO</span><h1>Tu espacio de trabajo</h1><p>Accede a los módulos disponibles para tu cargo.</p></header>
<div class="a22-kpis"><div><small>Módulos del catálogo</small><strong><?=$total?></strong></div><div><small>Obras autorizadas</small><strong><?=count($obras)?></strong></div><div><small>Nivel declarado</small><strong><?=arx_h((string)($_SESSION['nivel_jerarquico']??'Sin asignar'))?></strong></div></div>
<section class="a22-card"><h2>Contexto de obra</h2><p>Selecciona una obra si deseas navegar con su filtro. Solo podrás consultar las obras autorizadas para tu cuenta.</p><form method="get" class="a22-form"><label for="obra">Obra autorizada</label><select name="obra" id="obra"><option value="">Sin filtro / acceso según cargo</option><?php foreach($obras as $o):?><option value="<?=arx_h($o['codigo_obra'])?>" <?=$seleccion===$o['codigo_obra']?'selected':''?>><?=arx_h($o['codigo_obra'].' · '.$o['nombre_proyecto'])?></option><?php endforeach;?></select><button type="submit">Aplicar contexto</button></form></section>
<?php foreach($grupos as $grupo=>$items):?><section class="a22-section"><div class="a22-section-title"><h2><?=arx_h($grupo)?></h2><small><?=count($items)?> accesos</small></div><div class="a22-grid"><?php foreach($items as $item):?><?php if($item['disponible']):?><a class="a22-module" href="<?=arx_h(a22_url($item['ruta'],$item['obra']?$seleccion:null))?>"><span class="a22-module-icon">↗</span><strong><?=arx_h($item['nombre'])?></strong><small><?=arx_h($item['ruta'])?></small></a><?php else:?><div class="a22-module" aria-disabled="true" style="opacity:.5;cursor:not-allowed"><span class="a22-module-icon">!</span><strong><?=arx_h($item['nombre'])?></strong><small>Pendiente: <?=arx_h($item['ruta'])?></small></div><?php endif;?><?php endforeach;?></div></section><?php endforeach;?>
<section class="a22-card a22-muted"><h2>Seguridad</h2><p>Cada módulo verifica los permisos de tu perfil y de la obra seleccionada.</p></section>
</main></div></body></html>
