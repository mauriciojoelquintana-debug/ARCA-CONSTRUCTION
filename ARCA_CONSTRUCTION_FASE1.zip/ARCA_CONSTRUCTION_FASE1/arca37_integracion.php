<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca36_38_datos.php';
$db=a27_boot(a37_roles());
$rol=arx_role();$error='';$works=[];$data=null;
try {
    a36_pruebas_bd($db);
    $authorized=a24_obras_autorizadas($db);
    $codes=a38_codigos_autorizados($db);
    // El motor F31 muestra cifras financieras / laborales exclusivamente a sus roles autorizados.
    if(in_array($rol,a31_roles(),true) && $codes){
       $requested=trim((string)($_GET['obra']??''));
       $codes=a31_elegir_codigos($authorized,$requested);
       $data=a31_datos($db,$codes,$rol);
       $works=$data['obras'];
    } else {
       if(isset($_GET['obra']) && trim((string)$_GET['obra'])!=='')a38_verificar_obra($codes,(string)$_GET['obra']);
       // Para CIO/CTO/CCO/CMO/CSO: solo conteo de ámbito, sin cifras operativas sensibles.
    }
}catch(Throwable $e){error_log('[ARCA F37] '.$e->getMessage());$error=($e instanceof DomainException || $e instanceof InvalidArgumentException)?$e->getMessage():'No fue posible cargar la información. Comunícate con el área de Sistemas.';}
$routes=[
 'CEO'=>['panel_ceo.php'=>'Dirección General','arca34_calidad.php'=>'Centro de calidad'],
 'CFO'=>['panel_cfo.php'=>'Dirección Financiera','arca31_inteligencia.php'=>'Indicadores financieros'],
 'COO'=>['panel_coo.php'=>'Operaciones','arca27_equipo_obra.php'=>'Responsables de obra'],
 'CHRO'=>['panel_chro.php'=>'Recursos humanos','arca28_validacion.php'=>'Validación laboral'],
 'CIO'=>['panel_cio.php'=>'Sistemas de información','arca33_preparacion.php'=>'Infraestructura'],
 'CTO'=>['panel_cto.php'=>'Tecnología e innovación'],
 'CCO'=>['panel_cco.php'=>'Dirección comercial'],
 'CMO'=>['panel_cmo.php'=>'Marketing'],
 'CSO'=>['panel_cso.php'=>'Estrategia corporativa']
];
if($rol==='Director General')$myRoutes=$routes['CEO'];else $myRoutes=$routes[$rol]??[];
a27_layout('Integración corporativa','Información centralizada por dirección, obra y perfil autorizado.','arca37_integracion.php');
?>
<link rel="stylesheet" href="assets/css/arca36-38.css?v=1">
<div class="ar-banner"><strong>VISIÓN CORPORATIVA</strong><p>Información de seguimiento correspondiente a tus obras y atribuciones. Los indicadores permiten consultar el desempeño; cualquier registro o autorización se realiza desde su módulo específico. Los importes se presentan en su divisa de origen, sin conversiones automáticas.</p></div>
<?php if($error):?><div class="ar-error" role="alert"><?=a27_h($error)?></div><?php else:?>
<div class="ar-metrics"><article><span>Perfil activo</span><strong class="ar-word"><?=a27_h($rol)?></strong></article><article><span>Obras autorizadas</span><strong><?=count($codes)?></strong></article><?php if($data):?><article><span>Avance medio del alcance</span><strong><?=number_format((float)$data['totales']['avance_promedio'],1)?>%</strong></article><article><span>Obras en riesgo / retraso</span><strong><?= (int)$data['totales']['en_riesgo']?></strong></article><?php endif;?></div>
<?php if(in_array($rol,a31_roles(),true) && $data):?>
<section class="ar-card"><h2>Situación consolidada por obra</h2>
<form class="ar-filters" method="get"><label>Ámbito<select name="obra"><option value="">Todas las obras autorizadas</option><?php foreach($authorized as $work):$c=(string)$work['codigo_obra'];?><option value="<?=a27_h($c)?>" <?=($_GET['obra']??'')===$c?'selected':''?>><?=a27_h($c)?></option><?php endforeach;?></select></label><button type="submit">Consultar</button></form>
<div class="ar-scroll"><table class="ar-table"><thead><tr><th>Obra</th><th>Avance</th><th>Estado</th><?php if(a31_es_personal($rol)):?><th>Personal validado</th><?php endif;?><?php if(a31_es_operaciones($rol)):?><th>Almacén</th><th>Stock bajo</th><th>Órdenes emitidas</th><?php endif;?></tr></thead><tbody>
<?php foreach($works as $w):?><tr><td><strong><?=a27_h($w['codigo'])?></strong><small><?=a27_h($w['nombre'])?></small></td><td><?=number_format((float)$w['avance'],1)?>%</td><td><?=a27_h($w['estado'])?></td><?php if(a31_es_personal($rol)):?><td><?= (int)($w['personal']??0)?></td><?php endif;?><?php if(a31_es_operaciones($rol)):?><td><?= (int)($w['articulos']??0)?></td><td><?= (int)($w['stock_bajo']??0)?></td><td><?= (int)($w['ordenes']??0)?></td><?php endif;?></tr><?php endforeach;?></tbody></table></div>
<?php if(a31_es_finanzas($rol)):?><h3>Movimientos por divisa (sin sumar entre monedas)</h3><div class="ar-scroll"><table class="ar-table"><thead><tr><th>Moneda</th><th>Módulo</th><th>Pago</th><th>Registros</th><th>Importe original</th></tr></thead><tbody><?php foreach($data['finanzas'] as $f):?><tr><td><?=a27_h(a31_moneda($f['moneda']))?></td><td><?=a27_h($f['modulo'])?></td><td><?=a27_h($f['estado_pago'])?></td><td><?= (int)$f['cantidad']?></td><td><?=a27_h(a31_dinero($f['importe'],(string)$f['moneda']))?></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section>
<?php else:?><section class="ar-card"><h2>Resumen de tu dirección</h2><p>Accede a los módulos correspondientes a tu área desde los accesos disponibles. La información se presenta de acuerdo con las atribuciones asignadas y la confidencialidad de cada dirección.</p></section><?php endif;?>
<?php endif;?>
<section class="ar-card"><h2>Accesos a módulos existentes</h2><div class="ar-actions"><?php foreach($myRoutes as $uri=>$label):if(is_file(__DIR__.'/'.$uri)):?><a href="<?=a27_h($uri)?>"><?=a27_h($label)?></a><?php endif;endforeach;?><?php if(in_array($rol,a38_roles(),true)):?><a href="arca38_flujos.php">Flujos de revisión</a><?php endif;?><?php if(in_array($rol,a36_roles(),true)):?><a href="arca36_infraestructura.php">Infraestructura y continuidad</a><?php endif;?></div><p class="ar-help">Los accesos están sujetos a las autorizaciones de cada dirección.</p></section>
<?php a27_end(); ?>

