<?php
// 1. Validamos la sesión y la seguridad RBAC para el área administrativa
session_start();
$roles_admin = ['Secretaria / Asistente', 'Secretaria'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_admin)) {
    // Si un ingeniero intenta entrar a la agenda directiva, el sistema lo bloquea
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agenda Directiva - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 20px; }
        .form-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 400px; margin: 0 auto; border-top: 4px solid #8e44ad; }
        input, select { width: 90%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        .btn-enviar { background-color: #8e44ad; color: white; border: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; cursor: pointer; font-weight: bold; width: 95%; }
        .btn-enviar:hover { background-color: #732d91; }
        .btn-volver { display: inline-block; margin-top: 15px; color: #34495e; text-decoration: none; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <h2>Control de Agenda Directiva</h2>
    <p>Administrativo en turno: <b><?php echo $_SESSION['usuario_activo']; ?></b></p>

    <div class="form-container">
        <!-- El formulario enviará los datos al motor de procesamiento mediante POST -->
        <form action="procesar_agenda.php" method="POST">
            
            <label style="font-weight:bold; color:#2c3e50;">Fecha de la Reunión:</label><br>
            <input type="date" name="fecha" required>

            <label style="font-weight:bold; color:#2c3e50;">Hora:</label><br>
            <input type="time" name="hora" required>

            <label style="font-weight:bold; color:#2c3e50;">Asunto / Tema a tratar:</label><br>
            <input type="text" name="asunto" placeholder="Ej. Revisión de presupuesto de obra" required>

            <label style="font-weight:bold; color:#2c3e50;">Modalidad:</label><br>
            <select name="modalidad" required>
                <option value="Presencial - Sala de Juntas">Presencial - Sala de Juntas</option>
                <option value="Virtual - Zoom">Virtual - Zoom</option>
                <option value="Virtual - Google Meet">Virtual - Google Meet</option>
                <option value="Presencial - En Obra">Presencial - En Obra</option>
            </select>

            <input type="submit" value="Agendar Reunión" class="btn-enviar">
        </form>
        
        <br>
        <a href="panel_administrativo.php" class="btn-volver">← Volver al Panel Administrativo</a>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>