<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_integracion.php';
$db=arx_boot(['CEO','Director General','CIO']);
$check=[
 'Documentación pendiente de divisa'=>"SELECT COUNT(*) n FROM finanzas_coo WHERE moneda IS NULL",
 'Órdenes recibidas sin recepción física integrada'=>"SELECT COUNT(*) n FROM arca_ordenes_compra o LEFT JOIN arca_recepciones_integradas r ON r.id_orden=o.id_orden WHERE o.estado='RECIBIDA' AND r.id_recepcion IS NULL",
 'Recepciones físicas duplicadas'=>"SELECT COUNT(*) n FROM (SELECT id_orden FROM arca_recepciones_integradas GROUP BY id_orden HAVING COUNT(*)>1) x",
 'Solicitudes aprobadas por su propio creador'=>"SELECT COUNT(*) n FROM arca_solicitudes_compra WHERE estado='APROBADA' AND solicitado_por=revisado_por",
 'Autorizaciones aprobadas por su solicitante'=>"SELECT COUNT(*) n FROM arca_autorizaciones_transversales WHERE estado='APROBADA' AND solicitado_por=decidido_por",
 'Movimientos físicos vinculados a artículo ajeno a la obra'=>"SELECT COUNT(*) n FROM arca_recepciones_integradas r JOIN arca_ordenes_compra o ON o.id_orden=r.id_orden JOIN inventario_almacen_arca i ON i.id_insumo=r.id_insumo WHERE o.codigo_obra<>i.codigo_obra",
 'Existencias negativas'=>"SELECT COUNT(*) n FROM inventario_almacen_arca WHERE cantidad_actual<0",
 'Aprobaciones por resolver'=>"SELECT COUNT(*) n FROM arca_autorizaciones_transversales WHERE estado='PENDIENTE'"
];
$out=[];foreach($check as $name=>$sql){try{$out[$name]=(int)(arx_one($db,$sql)['n']??0);}catch(Throwable $e){error_log($e->getMessage());$out[$name]='No disponible';}}
$aud=arx_rows($db,'SELECT modulo,entidad,accion,fecha FROM arca_auditoria_modulos ORDER BY id_evento DESC LIMIT 25');
ax_layout('Seguridad, consistencia y bitácora','Controles de calidad del ERP. Verifica los registros históricos antes de solicitar cualquier corrección.','arca_seguridad.php');
?>
<section class="arx-card"><h2>Controles de integridad de datos</h2><p class="ax-note">Una cifra distinta de cero puede indicar un pendiente administrativo, no necesariamente una incidencia técnica. Las cifras se actualizan al recargar.</p><div class="ax-scroll"><table class="ax-table"><tr><th>Verificación</th><th>Registros</th><th>Interpretación</th></tr><?php foreach($out as $name=>$num):?><tr><td><?=arx_h($name)?></td><td><b><?=arx_h($num)?></b></td><td><?=in_array($name,['Documentación pendiente de divisa','Órdenes recibidas sin recepción física integrada','Aprobaciones por resolver'],true)?'Revisión documental / pendiente':'Comprobar si es mayor que cero'?></td></tr><?php endforeach;?></table></div></section>
<section class="arx-card"><h2>Bitácora de modificaciones recientes</h2><div class="ax-scroll"><table class="ax-table"><tr><th>Fecha</th><th>Módulo</th><th>Entidad</th><th>Acción</th></tr><?php foreach($aud as $e):?><tr><td><?=arx_h($e['fecha'])?></td><td><?=arx_h($e['modulo'])?></td><td><?=arx_h($e['entidad'])?></td><td><?=arx_h($e['accion'])?></td></tr><?php endforeach;?></table></div></section>
<section class="arx-card"><h2>Alcance de la validación</h2><p class="ax-note">Esta pantalla NO certifica que el software sea seguro en Internet. Pendiente: pruebas de permisos para cada ruta antigua, CSRF en formularios heredados, subida de archivos, revisión de consultas, HTTPS, respaldos restaurables, registro centralizado y pruebas de recuperación.</p><div class="ax-actions"><a class="arx-btn" href="arca_reportes_vivos.php">Reportes protegidos</a><a class="arx-btn" href="arca_integracion.php">Integración</a></div></section>
<?php arx_layout_end(); ?>
