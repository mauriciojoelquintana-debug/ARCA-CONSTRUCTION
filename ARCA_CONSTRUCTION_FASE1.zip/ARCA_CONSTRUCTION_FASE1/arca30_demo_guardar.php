<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca29_30.php';
$db=a27_boot(['CHRO','COO']);a27_post();
try {
    a30_ensure_demo($db);
    $action=(string)($_POST['accion']??'');$role=arx_role();
    if(in_array($action,['crear','documentar','asignar','proponer','reabrir'],true)&&$role!=='CHRO')a27_die('Solo CHRO crea y propone casos DEMO.',403);
    if(in_array($action,['aprobar','rechazar'],true)&&$role!=='COO')a27_die('Solo COO puede resolver una propuesta DEMO.',403);
    $db->begin_transaction();
    if($action==='crear'){
        $employee=arx_int($_POST['id_empleado']??null);$obra=arx_code($_POST['codigo_obra']??'');
        $func=(string)($_POST['funcion']??'');
        $tipo=arx_text($_POST['contrato_tipo']??'',60);
        $inicio=arx_date((string)($_POST['inicio']??''));
        $fin=trim((string)($_POST['fin']??''));if($fin!=='')arx_date($fin);
        $ref=arx_text($_POST['referencia']??'',100);
        if(!isset(a28_functions()[$func]))throw new InvalidArgumentException('Función no permitida.');
        if($fin!==''&&$fin<$inicio)throw new InvalidArgumentException('Periodo contractual simulado incorrecto.');
        if(!a30_obra_autorizada($db,$obra,'consultar'))throw new InvalidArgumentException('Obra no autorizada para CHRO.');
        if(!arx_one($db,'SELECT id_empleado FROM arca_empleados WHERE id_empleado=?',[$employee]))throw new InvalidArgumentException('Empleado de prueba inexistente.');
        if(a30_no_duplicate($db,$obra,$func))throw new InvalidArgumentException('Ya hay un caso DEMO en esa obra y función; no se duplican responsables.');
        arx_exec($db,"INSERT INTO arca30_demo_casos(id_empleado,codigo_obra,funcion,contrato_tipo,inicio,fin,referencia,estado,creado_por) VALUES(?,?,?,?,?,?,?,'BORRADOR',?)",[$employee,$obra,$func,$tipo,$inicio,$fin?:null,$ref,arx_uid()]);
        $id=(int)$db->insert_id;
        arx_audit($db,'CHRO','arca30_demo_casos',$id,'DEMO_CREAR',null,['empleado'=>$employee,'obra'=>$obra,'funcion'=>$func,'inicio'=>$inicio,'fin'=>$fin?:null]);
        a30_flash('Caso de prueba creado. Adjunta ahora el documento correspondiente desde Gestión documental.');
    }else{
        $id=arx_int($_POST['id_caso']??null);
        $case=a30_case($db,$id,true);
        if(!$case || !a30_obra_autorizada($db,(string)$case['codigo_obra'],$role==='COO'?'operar':'consultar'))throw new InvalidArgumentException('Caso no encontrado o acceso a obra denegado.');
        $old=(string)$case['estado'];$next='';$audit='';
        if($action==='documentar'){
            if($old!=='BORRADOR')throw new InvalidArgumentException('El caso ya salió de borrador.');
            if(!a30_has_pdf($db,$id))throw new InvalidArgumentException('Adjunta primero un PDF de demostración desde Gestión documental.');
            $next='DOCUMENTADO';$audit='DEMO_DOCUMENTAR';
        }elseif($action==='asignar'){
            if($old!=='DOCUMENTADO')throw new InvalidArgumentException('Primero documenta el caso.');
            if(!a30_fecha_activa($case['inicio'],$case['fin']))throw new InvalidArgumentException('El periodo simulado no está vigente.');
            $next='ASIGNADO';$audit='DEMO_ASIGNAR';
        }elseif($action==='proponer'){
            if($old!=='ASIGNADO')throw new InvalidArgumentException('Primero registra la asignación simulada.');
            if(!a30_fecha_activa($case['inicio'],$case['fin']))throw new InvalidArgumentException('El periodo simulado no está vigente.');
            $next='PROPUESTO';$audit='DEMO_PROPONER';
        }elseif($action==='reabrir'){
            if($old!=='RECHAZADO')throw new InvalidArgumentException('Solo se reabren casos rechazados.');
            $next=a30_has_pdf($db,$id)?'DOCUMENTADO':'BORRADOR';$audit='DEMO_REABRIR';
        }elseif($action==='aprobar'||$action==='rechazar'){
            if($old!=='PROPUESTO')throw new InvalidArgumentException('No existe propuesta pendiente.');
            if((int)$case['propuesto_por']===arx_uid())throw new InvalidArgumentException('Quien propone no puede aprobar ni rechazar su propia solicitud.');
            if($action==='aprobar' && !a30_fecha_activa($case['inicio'],$case['fin']))throw new InvalidArgumentException('El caso simulado ya no está vigente.');
            $next=$action==='aprobar'?'APROBADO':'RECHAZADO';
            $audit=$action==='aprobar'?'DEMO_APROBAR':'DEMO_RECHAZAR';
        } else throw new InvalidArgumentException('Acción desconocida.');
        if($action==='reabrir'){
            arx_exec($db,"UPDATE arca30_demo_casos SET estado=?,propuesto_por=NULL,propuesto_en=NULL,revisado_por=NULL,revisado_en=NULL WHERE id_caso=? AND estado='RECHAZADO'",[$next,$id]);
        }elseif($action==='proponer'){
            arx_exec($db,"UPDATE arca30_demo_casos SET estado=?,propuesto_por=?,propuesto_en=NOW() WHERE id_caso=? AND estado='ASIGNADO'",[$next,arx_uid(),$id]);
        }elseif($action==='reabrir'){
            if($old!=='RECHAZADO')throw new InvalidArgumentException('Solo se reabren casos rechazados.');
            $next=a30_has_pdf($db,$id)?'DOCUMENTADO':'BORRADOR';$audit='DEMO_REABRIR';
        }elseif($action==='aprobar'||$action==='rechazar'){
            arx_exec($db,"UPDATE arca30_demo_casos SET estado=?,revisado_por=?,revisado_en=NOW() WHERE id_caso=? AND estado='PROPUESTO'",[$next,arx_uid(),$id]);
        }else{
            arx_exec($db,'UPDATE arca30_demo_casos SET estado=? WHERE id_caso=? AND estado=?',[$next,$id,$old]);
        }
        arx_audit($db,$role,'arca30_demo_casos',$id,$audit,['estado'=>$old],['estado'=>$next,'SIMULACION'=>true]);
        a30_flash('Paso DEMO completado: '.$old.' → '.$next.'. No alteró la situación laboral real.');
    }
    $db->commit();
}catch(Throwable $e){
    try{$db->rollback();}catch(Throwable $ignored){}
    error_log('[ARCA30 DEMO] '.$e->getMessage());
    a30_flash($e instanceof InvalidArgumentException?$e->getMessage():'Error en el flujo de demostración. Revisa los logs.',true);
}
a30_redirect('arca30_demo.php');
