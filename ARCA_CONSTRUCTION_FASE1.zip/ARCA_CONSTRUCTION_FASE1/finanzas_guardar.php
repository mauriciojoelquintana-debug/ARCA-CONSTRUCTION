<?php
// Escritura financiera: únicamente CFO, verificación CSRF, transacción y bitácora.
require_once __DIR__ . '/includes/seguridad.php';
require_once __DIR__ . '/includes/finanzas_utilidades.php';
arca_requerir_roles(['CFO']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método no permitido'); }
arca_verificar_token();
require __DIR__ . '/conexion.php';
$modulo = (string)($_POST['modulo'] ?? '');
$obraFiltro = arca_fin_filtrar_obra((string)($_POST['obra_filtro'] ?? ''));
if (!array_key_exists($modulo, arca_fin_modulos())) { http_response_code(400); exit('Módulo no válido'); }
$accion = (string)($_POST['accion'] ?? '');
$actor = (string)($_SESSION['usuario_activo'] ?? '');
if ($actor === '') { http_response_code(403); exit('Sesión no válida'); }
try {
    if (!arca_fin_auditoria_disponible($conectar)) throw new RuntimeException('El registro con auditoría no está disponible. Comunícate con el área de Sistemas.');
    if ($accion === 'crear') {
        $codigo = arca_fin_filtrar_obra((string)($_POST['codigo_obra'] ?? ''));
        $concepto = trim((string)($_POST['concepto'] ?? ''));
        $importe = trim((string)($_POST['monto'] ?? ''));
        $estado = trim((string)($_POST['estado_pago'] ?? ''));
        $moneda = arca_fin_moneda((string)($_POST['moneda'] ?? ''));
        $categoria = ($modulo === 'costos') ? arca_fin_categoria((string)($_POST['categoria_costo'] ?? '')) : null;
        $fecha = (string)($_POST['fecha_transaccion'] ?? '');
        if ($codigo === '' || $concepto === '' || (function_exists('mb_strlen') ? mb_strlen($concepto,'UTF-8') : strlen($concepto)) > 150 ||
            !preg_match('/^(?:0|[1-9][0-9]{0,12})(?:\.[0-9]{1,2})?$/D', $importe) || (float)$importe <= 0 ||
            !in_array($estado, arca_fin_estados($modulo), true) || !arca_fin_fecha($fecha)) {
            throw new InvalidArgumentException('Verifica obra, concepto, importe positivo, fecha y estado.');
        }
        $busca = $conectar->prepare('SELECT nombre_proyecto FROM obras_coo WHERE codigo_obra = ? LIMIT 1');
        $busca->bind_param('s', $codigo); $busca->execute();
        $obra = $busca->get_result()->fetch_assoc(); $busca->close();
        if (!$obra) throw new InvalidArgumentException('La obra no existe en el catálogo de Operaciones.');
        $nombreProyecto = (string)$obra['nombre_proyecto'];
        $conectar->begin_transaction();
        $stmt = $conectar->prepare('INSERT INTO finanzas_coo (codigo_obra,nombre_proyecto,modulo,concepto,monto,moneda,categoria_costo,estado_pago,fecha_transaccion) VALUES (?,?,?,?,?,?,?,?,?)');
        $stmt->bind_param('sssssssss',$codigo,$nombreProyecto,$modulo,$concepto,$importe,$moneda,$categoria,$estado,$fecha);
        $stmt->execute(); $id = $conectar->insert_id; $stmt->close();
        $anterior = null;
        $nuevo = json_encode(['codigo_obra'=>$codigo,'nombre_proyecto'=>$nombreProyecto,'concepto'=>$concepto,'monto'=>$importe,'moneda'=>$moneda,'categoria_costo'=>$categoria,'estado_pago'=>$estado,'fecha_transaccion'=>$fecha], JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $tipo = 'CREAR';
        $audit = $conectar->prepare('INSERT INTO arca_finanzas_bitacora (id_finanza,usuario_actor,accion,modulo,datos_anteriores,datos_nuevos) VALUES (?,?,?,?,?,?)');
        $audit->bind_param('isssss', $id, $actor, $tipo, $modulo, $anterior, $nuevo); $audit->execute(); $audit->close();
        $conectar->commit();
        $_SESSION['arca_fin_flash'] = ['ok','Movimiento financiero registrado. Folio #' . $id . '.'];
    } elseif ($accion === 'estado') {
        $id = filter_var($_POST['id_finanza'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        $estadoNuevo = trim((string)($_POST['estado_pago'] ?? ''));
        if (!$id || !in_array($estadoNuevo, arca_fin_estados($modulo), true)) throw new InvalidArgumentException('Registro o estado inválido.');
        $conectar->begin_transaction();
        $stmt = $conectar->prepare('SELECT id_finanza,modulo,estado_pago FROM finanzas_coo WHERE id_finanza=? FOR UPDATE');
        $stmt->bind_param('i',$id); $stmt->execute(); $fila = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$fila || $fila['modulo'] !== $modulo) throw new InvalidArgumentException('El registro no corresponde a este módulo.');
        $estadoAntes = (string)$fila['estado_pago'];
        if ($estadoAntes !== $estadoNuevo) {
            $stmt = $conectar->prepare('UPDATE finanzas_coo SET estado_pago = ? WHERE id_finanza = ?');
            $stmt->bind_param('si',$estadoNuevo,$id); $stmt->execute(); $stmt->close();
            $anterior = json_encode(['estado_pago'=>$estadoAntes],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
            $nuevo = json_encode(['estado_pago'=>$estadoNuevo],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
            $tipo = 'ESTADO';
            $audit = $conectar->prepare('INSERT INTO arca_finanzas_bitacora (id_finanza,usuario_actor,accion,modulo,datos_anteriores,datos_nuevos) VALUES (?,?,?,?,?,?)');
            $audit->bind_param('isssss', $id,$actor,$tipo,$modulo,$anterior,$nuevo); $audit->execute(); $audit->close();
            $_SESSION['arca_fin_flash'] = ['ok','Estado actualizado para el folio #' . $id . '.'];
        } else {
            $_SESSION['arca_fin_flash'] = ['ok','El registro ya tenía ese estado.'];
        }
        $conectar->commit();
    } else {
        throw new InvalidArgumentException('Acción no reconocida.');
    }
} catch (Throwable $e) {
    try { $conectar->rollback(); } catch (Throwable $ignored) {}
    error_log('ARCA finanzas: '.$e->getMessage());
    $_SESSION['arca_fin_flash'] = ['error', $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'No fue posible guardar la operación. Revisa el log de PHP.'];
}
arca_fin_redirigir($modulo,$obraFiltro);
