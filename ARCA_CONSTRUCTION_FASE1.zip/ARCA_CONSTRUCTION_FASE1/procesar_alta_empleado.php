<?php
require_once __DIR__.'/includes/seguridad.php';
arca_requerir_roles(['CEO','Director General','CHRO','Director de RR.HH.','Departamento RRHH']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: formulario_alta_empleado.php'); exit; }
$nombre=trim((string)($_POST['nombre_empleado']??''));
$numero=trim((string)($_POST['numero_empleado']??''));
$cargo=trim((string)($_POST['rol_asignado']??''));
// Catálogo inicial autorizado para altas por RRHH. Cargos directivos requieren un flujo separado.
$cargos=['Arquitecto','Ingeniero Civil','Residente de Obra','Supervisor de Obra','Secretaria','Contador','Almacenista','Abogado','Seguridad','Departamento RRHH'];
if ($nombre==='' || $numero==='' || !in_array($cargo,$cargos,true)) { http_response_code(422); exit('Datos incompletos o cargo no permitido en este formulario.'); }
require __DIR__.'/conexion.php';
$temporal=bin2hex(random_bytes(8));
$hash=password_hash($temporal,PASSWORD_DEFAULT);
$ok=false;$mensaje='';
try {
 $st=$conectar->prepare('INSERT INTO usuarios (numero_empleado,nombre_completo,password,cargo) VALUES (?,?,?,?)');
 $st->bind_param('ssss',$numero,$nombre,$hash,$cargo);$st->execute();$st->close();$ok=true;
} catch(Throwable $e){ error_log($e->getMessage());$mensaje='No se pudo registrar. Verifica que no exista el número de empleado.'; }
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nuevo usuario | ARCA</title><link rel="stylesheet" href="assets/css/arca.css"></head>
<body style="min-height:100vh;display:grid;place-items:center"><main class="metric-card" style="max-width:560px;width:calc(100% - 30px)"><span class="eyebrow">RECURSOS HUMANOS</span><h1 style="font-size:23px;color:var(--arca-navy)"><?= $ok?'Cuenta creada':'Error de registro' ?></h1><?php if($ok): ?><p>Cuenta: <b><?= arca_h($numero) ?></b> · Cargo: <b><?= arca_h($cargo) ?></b></p><p>Contraseña temporal: <code style="padding:7px 11px;background:#edf1f5;border-radius:6px;font-size:17px;letter-spacing:1px"><?= arca_h($temporal) ?></code></p><p class="small">Entrégala al empleado de forma privada y solicítale cambiarla. No se volverá a mostrar.</p><?php else: ?><p><?= arca_h($mensaje) ?></p><?php endif; ?><a class="btn btn-primary" href="formulario_alta_empleado.php">Volver al formulario →</a></main></body></html>
