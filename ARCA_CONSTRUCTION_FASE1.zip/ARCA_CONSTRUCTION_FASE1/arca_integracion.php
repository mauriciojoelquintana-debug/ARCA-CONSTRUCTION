<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca_integracion.php';
$db=arx_boot(['CEO','Director General','COO','CFO','CHRO']);
$obras=ax_obras($db);
$estado=arx_rows($db,"SELECT o.codigo_obra,o.nombre_proyecto,o.avance_fisico,o.estado_tiempo,
 (SELECT COUNT(*) FROM arca_asignaciones_personal p WHERE p.codigo_obra=o.codigo_obra AND p.estado='ACTIVA') personal,
 (SELECT COUNT(*) FROM inventario_almacen_arca i WHERE i.codigo_obra=o.codigo_obra) materiales,
 (SELECT COUNT(*) FROM arca_maquinaria_obra m WHERE m.codigo_obra=o.codigo_obra) maquinaria,
 (SELECT COUNT(*) FROM arca_solicitudes_compra s WHERE s.codigo_obra=o.codigo_obra AND s.estado='PENDIENTE') compras,
 (SELECT COUNT(*) FROM arca_autorizaciones_transversales a WHERE a.codigo_obra=o.codigo_obra AND a.estado='PENDIENTE') autorizaciones
 FROM obras_coo o ORDER BY o.codigo_obra");
$estado=array_values(array_filter($estado,static fn($v)=>ax_can_obra($db,(string)$v['codigo_obra'])));
$fm=in_array(arx_role(),['CEO','Director General','CFO'],true)?arx_rows($db,"SELECT COALESCE(moneda,'SIN CONFIRMAR') divisa,modulo,estado_pago,SUM(monto) importe,COUNT(*) n FROM finanzas_coo GROUP BY COALESCE(moneda,'SIN CONFIRMAR'),modulo,estado_pago ORDER BY divisa,modulo LIMIT 80"):[];
$pending=array_sum(array_column($estado,'autorizaciones'));$pendCompras=array_sum(array_column($estado,'compras'));
ax_layout('Centro de integración empresarial','Información enlazada por código de obra: operaciones, equipos, plantilla asignada, compras y finanzas; se actualiza al recargar la página.','arca_integracion.php');
?>
<div class="ax-actions"><a class="arx-btn" href="panel_ceo.php">Panel original CEO</a><a class="arx-btn" href="arca_ceo_integrado.php">Dirección general</a><a class="arx-btn" href="arca_reportes_vivos.php">Reportes actualizados</a><a class="arx-btn" href="arca_autorizaciones.php">Autorizaciones</a><a class="arx-btn" href="arca_integracion.php">Actualizar datos</a></div>
<section class="ax-panels">
 <div class="ax-panel"><small>Obras visibles</small><strong><?=count($estado)?></strong><span class="ax-muted">Según tus permisos</span></div>
 <div class="ax-panel"><small>Solicitudes pendientes</small><strong><?=$pendCompras?></strong><span class="ax-muted">COO / Compras</span></div>
 <div class="ax-panel"><small>Autorizaciones pendientes</small><strong><?=$pending?></strong><span class="ax-muted">Decisión por cargo</span></div>
 <?php if(in_array(arx_role(),['CEO','Director General','CFO'],true)):?><div class="ax-panel"><small>Registros financieros</small><strong><?=array_sum(array_column($fm,'n'))?></strong><span class="ax-muted">No son saldos bancarios</span></div><?php endif;?>
</section>
<section class="arx-card ax-section"><h2>Obras, personal y recursos</h2><p class="arx-sub">Una consulta a las tablas originales: evita copiar movimientos y mantiene permisos por proyecto.</p><div class="ax-scroll"><table class="ax-table"><thead><tr><th>Obra</th><th>Avance</th><th>Empleados asignados</th><th>Insumos</th><th>Maquinaria</th><th>Compras pendientes</th><th>Decisiones</th></tr></thead><tbody>
<?php foreach($estado as $o):?><tr><td><a href="arca_obra_360.php?obra=<?=rawurlencode($o['codigo_obra'])?>"><b><?=arx_h($o['codigo_obra'])?></b></a><br><span class="ax-muted"><?=arx_h($o['nombre_proyecto'])?></span></td><td><div class="ax-bar"><span style="width:<?=min(100,max(0,(float)$o['avance_fisico']))?>%"></span></div><?=arx_h($o['avance_fisico'])?>%</td><td><?= (int)$o['personal']?></td><td><?= (int)$o['materiales']?></td><td><?= (int)$o['maquinaria']?></td><td><?= (int)$o['compras']?></td><td><?= (int)$o['autorizaciones']?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php if(in_array(arx_role(),['CEO','Director General','CFO'],true)):?>
<section class="arx-card"><h2>Finanzas por clasificación y divisa</h2><p class="ax-note">No se suman MXN, USD ni importes históricos sin confirmar. Los importes son movimientos registrados, no dinero en caja ni el presupuesto definitivo.</p><div class="ax-scroll"><table class="ax-table"><thead><tr><th>Divisa</th><th>Módulo</th><th>Estado</th><th>Registros</th><th>Total</th></tr></thead><tbody>
<?php foreach($fm as $f):?><tr><td><?=arx_h($f['divisa'])?></td><td><?=arx_h($f['modulo'])?></td><td><?=arx_h($f['estado_pago'])?></td><td><?=(int)$f['n']?></td><td><?=arx_h(ax_money($f['importe'],$f['divisa']==='SIN CONFIRMAR'?null:$f['divisa']))?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php endif; ?>
<section class="arx-card"><h2>Actualizaciones entre áreas</h2><p>El residente registra avances y movimientos en COO; CHRO asigna personal; Compras emite órdenes y el CFO consulta las obligaciones registradas. Los tableros actualizan los datos al recargar, sin duplicar presupuestos ni cargos.</p><p class="ax-muted">Esta vista reúne los datos de las áreas. Los cambios se consultan al actualizar la pantalla.</p></section>
<?php arx_layout_end(); ?>
