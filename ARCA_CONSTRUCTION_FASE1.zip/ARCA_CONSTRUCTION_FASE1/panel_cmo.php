<?php
// ARCA CONSTRUCTION · Fase 2, dirección CMO.
$arca_area = 'CMO';
require __DIR__ . '/includes/panel_directivo.php';
