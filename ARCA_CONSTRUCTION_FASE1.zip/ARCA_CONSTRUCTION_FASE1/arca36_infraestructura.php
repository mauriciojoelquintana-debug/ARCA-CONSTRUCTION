<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca36_38_datos.php';
$db=a27_boot(a36_roles());
$check=[];$err='';$f35=[];
try{
    a36_pruebas_bd($db);
    $check=a33_comprobar(__DIR__,true);
    if(a38_instalado($db)) $f35=[]; // F38 no afecta a F36.
}catch(Throwable $e){error_log('[ARCA F36] '.$e->getMessage());$err='No se pudo realizar el diagnóstico; consulta el registro protegido de PHP.';}
$ok=count(array_filter($check,static fn($r)=>$r['estado']==='OK'));
$warn=count($check)-$ok;
a27_layout('Infraestructura y continuidad','Disponibilidad, seguridad de sesiones, respaldos y recuperación operativa.','arca36_infraestructura.php');
?>
<link rel="stylesheet" href="assets/css/arca36-38.css?v=1">
<div class="ar-banner"><strong>ESTADO DE INFRAESTRUCTURA</strong><p>Los indicadores reflejan la configuración disponible. La continuidad operativa, la recuperación y la seguridad se habilitan únicamente tras completar sus verificaciones.</p></div>
<div class="ar-actions"><a href="arca33_preparacion.php">Configuración operativa</a><a href="arca35_pruebas.php">Verificación operativa</a><a href="arca37_integracion.php">Integración corporativa</a></div>
<?php if($err):?><div class="ar-error" role="alert"><?=a27_h($err)?></div><?php else:?>
<div class="ar-metrics"><article><span>Controles revisados</span><strong><?=count($check)?></strong></article><article><span>Correctos</span><strong><?=$ok?></strong></article><article><span>Advertencias o pendientes</span><strong><?=$warn?></strong></article></div>
<section class="ar-card"><h2>Verificación de infraestructura</h2><p>El estado de cada control corresponde a la infraestructura evaluada. Las validaciones de acceso, exposición y recuperación se documentan por separado.</p><div class="ar-scroll"><table class="ar-table"><thead><tr><th>Área</th><th>Control</th><th>Estado</th><th>Observación</th><th>Siguiente acción</th></tr></thead><tbody>
<?php foreach($check as $x):?><tr><td><?=a27_h($x['area'])?></td><td><strong><?=a27_h($x['nombre'])?></strong></td><td><span class="ar-tag"><?=a27_h($x['estado'])?></span></td><td><?=a27_h($x['detalle'])?></td><td><?=a27_h($x['accion'])?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php endif;?>
<section class="ar-card"><h2>Plan de continuidad y recuperación</h2><div class="ar-cards">
<article><h3>1. Protección de información</h3><p>Conservar respaldos completos, fechados y protegidos de la información corporativa. Verificar periódicamente integridad y capacidad de recuperación.</p></article>
<article><h3>2. Sistema y documentos</h3><p>Mantener copias separadas del sistema y del archivo documental, con acceso restringido y almacenamiento independiente.</p></article>
<article><h3>3. Recuperación verificada</h3><p>Comprobar la restauración en un entorno independiente, documentar la integridad, los accesos y los resultados de recuperación.</p></article>
</div><p class="ar-help">El área de Sistemas administra los procedimientos técnicos de respaldo, verificación de integridad y recuperación de información.</p></section>
<?php a27_end(); ?>
