<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_fases_8_13.php';require_once __DIR__.'/includes/arca_report_data.php';
$db=arx_boot(['CEO','Director General','COO']);
$tipo=(string)($_GET['tipo']??'');$formato=(string)($_GET['formato']??'');
if(!in_array($tipo,['portafolio','avances','fases','personal','materiales'],true)||!in_array($formato,['csv','imprimir'],true)){http_response_code(404);exit('Reporte no disponible');}
[$titulo,$nota,$cabeceras,$rows]=af8_report_data($db,$tipo);
if($formato==='csv'){
 header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="arca_'.$tipo.'_actual.csv"');header('Cache-Control: no-store');
 $fp=fopen('php://output','wb');fwrite($fp,"\xEF\xBB\xBF");fputcsv($fp,[$titulo]);fputcsv($fp,[$nota]);fputcsv($fp,$cabeceras);
 foreach($rows as $row){$clean=[];foreach(array_values($row) as $v){$txt=(string)($v??'');if(preg_match('/^[\s\x00-\x1F]*[=+@-]/u',$txt))$txt="'".$txt;$clean[]=$txt;}fputcsv($fp,$clean);}fclose($fp);exit();
}
header('Content-Type: text/html; charset=UTF-8');header('Cache-Control: no-store');
?><!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?=arx_h($titulo)?> — ARCA</title><style>
@page{size:A4 landscape;margin:14mm}body{font:12px/1.5 Arial,sans-serif;color:#263B53;background:#F5F7FA;margin:25px}.wrap{background:#fff;padding:26px;max-width:1320px;margin:auto}h1{font-size:23px;margin:0 0 8px}.note{color:#687C90;margin:0 0 18px}table{border-collapse:collapse;width:100%;font-size:10px}th{background:#263B53;color:white;text-align:left}td,th{padding:8px;border-bottom:1px solid #DDE5ED;overflow-wrap:anywhere}tr:nth-child(even){background:#F5F7FA}.foot{margin-top:17px;color:#687C90}.actions{margin:0 auto 12px;max-width:1320px}.btn{background:#263B53;color:white;padding:10px 14px;text-decoration:none;border:0;border-radius:5px;cursor:pointer}@media print{body{margin:0;background:white}.wrap{padding:0}.actions{display:none}thead{display:table-header-group}tr{break-inside:avoid}}</style></head><body>
<div class="actions"><button class="btn" onclick="window.print()">Imprimir / Guardar como PDF</button></div><div class="wrap"><small>ARCA CONSTRUCTION · REPORTES</small><h1><?=arx_h($titulo)?></h1><p class="note"><?=arx_h($nota)?></p><table><thead><tr><?php foreach($cabeceras as $h):?><th><?=arx_h($h)?></th><?php endforeach;?></tr></thead><tbody>
<?php foreach($rows as $row):?><tr><?php foreach(array_values($row) as $v):?><td><?=arx_h($v)?></td><?php endforeach;?></tr><?php endforeach;?></tbody></table><p class="foot">Registros: <?=count($rows)?> · Fecha de emisión: <?=date('Y-m-d')?> · Fuente: base ARCA local · No implica datos verificados ni divisas históricas confirmadas.</p></div></body></html>
