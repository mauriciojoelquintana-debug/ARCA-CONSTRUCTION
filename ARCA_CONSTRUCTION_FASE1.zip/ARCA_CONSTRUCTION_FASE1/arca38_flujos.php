<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca36_38_datos.php';
$db=a27_boot(a38_roles());
$error='';$rows=[];$history=[];$codes=[];$installed=false;
try {
   a36_pruebas_bd($db);$codes=a38_codigos_autorizados($db);
   $installed=a38_instalado($db);
   if($installed){$rows=a38_listado($db,$codes);$history=a38_historial($db,$rows);}
} catch(Throwable $e){error_log('[ARCA F38 PANEL] '.$e->getMessage());$error='No fue posible cargar las solicitudes. Comunícate con el área de Sistemas.';}
$state=a38_resumen_estado($rows);
a27_layout('Flujos de revisión','Solicitudes interdepartamentales, responsables, decisiones y seguimiento.','arca38_flujos.php');
?>
<link rel="stylesheet" href="assets/css/arca36-38.css?v=1">
<div class="ar-banner"><strong>GESTIÓN DE SOLICITUDES Y AUTORIZACIONES</strong><p>Las solicitudes se asignan a la dirección responsable y cada decisión queda registrada. La aprobación de un trámite autoriza su revisión administrativa; las compras, pagos, contrataciones y movimientos de inventario se ejecutan únicamente en sus módulos correspondientes.</p></div>
<?php if($error):?><div class="ar-error" role="alert"><?=a27_h($error)?></div><?php else:?>
<div class="ar-metrics"><article><span>Pendientes de decisión</span><strong><?=$state['PENDIENTE']?></strong></article><article><span>Devueltas</span><strong><?=$state['DEVUELTA']?></strong></article><article><span>Aprobadas</span><strong><?=$state['APROBADA']?></strong></article><article><span>Rechazadas</span><strong><?=$state['RECHAZADA']?></strong></article></div>
<?php if(!$installed):?><p class="ar-error" role="alert">El servicio de solicitudes no está configurado. Comunícate con el área de Sistemas.</p><?php else:?>
<section class="ar-card"><h2>Crear solicitud</h2><form method="post" action="arca38_guardar.php" class="ar-form">
<input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="operacion" value="CREAR"><input type="hidden" name="nonce" value="<?=bin2hex(random_bytes(16))?>">
<label>Tipo de proceso<select name="tipo" required><?php foreach(a38_tipos() as $tipo=>$meta):if(a38_crear_permitido(arx_role(),$tipo)):?><option value="<?=a27_h($tipo)?>"><?=a27_h($meta['nombre'])?></option><?php endif;endforeach;?></select></label>
<label>Obra autorizada<select name="codigo_obra" required><?php foreach($codes as $code):?><option value="<?=a27_h($code)?>"><?=a27_h($code)?></option><?php endforeach;?></select></label>
<label>Título<input name="titulo" maxlength="140" required placeholder="Ej.: Solicitud de revisión de materiales"></label>
<label>Referencia de expediente / solicitud<input name="referencia_origen" maxlength="80" placeholder="Opcional; sin datos personales"></label>
<label class="ar-wide">Descripción de la revisión<textarea name="detalle" maxlength="2000" required placeholder="Motivo, alcance y acción solicitada; no incluyas credenciales ni datos personales"></textarea></label>
<div><button type="submit" <?=!$codes?'disabled':''?>>Enviar para revisión</button></div>
</form><p class="ar-help">Las solicitudes de compras se envían a Finanzas; las de personal, a Operaciones; las de divisas e incidencias, a Dirección General. La aprobación requiere una persona distinta de quien registró la solicitud.</p></section>
<section class="ar-card"><h2>Solicitudes de las obras autorizadas</h2><p>Se muestran los últimos 150 folios visibles. Las decisiones finales son inmutables; los casos devueltos pueden reenviarse por su creador.</p>
<?php if(!$rows):?><p>No hay solicitudes registradas para tu ámbito.</p><?php endif;?>
<?php foreach($rows as $r):$can=a38_puede_ver_resolver($r);?><details class="ar-panel"><summary><strong>#<?= (int)$r['id_flujo']?> · <?=a27_h($r['titulo'])?></strong> <span class="ar-tag"><?=a27_h($r['estado'])?></span> <small><?=a27_h($r['codigo_obra'].' · '.$r['tipo'])?></small></summary><p><strong>Descripción del trámite:</strong> <?=a27_h($r['detalle'])?></p><p>Referencia: <?=a27_h($r['referencia_origen']??'Sin referencia')?> · Creado <?=a27_h($r['creado_en'])?></p>
<h3>Historial de decisiones</h3><div class="ar-history"><?php foreach(($history[(int)$r['id_flujo']]??[]) as $ev):?><p><strong><?=a27_h($ev['accion'].' · '.$ev['estado_nuevo'])?></strong> · <?=a27_h($ev['registrado_en'])?> · Usuario #<?=(int)$ev['actor_id']?><br><?=a27_h($ev['nota'])?></p><?php endforeach;?></div>
<?php if($can):?><form class="ar-form" method="post" action="arca38_guardar.php"><input type="hidden" name="csrf_token" value="<?=a27_h(arx_token())?>"><input type="hidden" name="operacion" value="DECIDIR"><input type="hidden" name="id_flujo" value="<?= (int)$r['id_flujo']?>"><label>Decisión<select name="accion" required><?php if($r['estado']==='DEVUELTA'):?><option value="REENVIAR">Reenviar con observación</option><?php else:?><option value="APROBAR">Aprobar solicitud</option><option value="DEVOLVER">Devolver para corrección</option><option value="RECHAZAR">Rechazar</option><?php endif;?></select></label><label class="ar-wide">Nota obligatoria<textarea name="nota" maxlength="1200" required></textarea></label><div><button type="submit">Guardar decisión auditada</button></div></form><?php else:?><p class="ar-help">Sin acción disponible para este rol o estado. Revisión separada del solicitante.</p><?php endif;?></details><?php endforeach;?></section>
<?php endif;endif;?>
<section class="ar-card"><h2>Módulos relacionados</h2><div class="ar-actions"><a href="arca37_integracion.php">Integración corporativa</a><a href="arca31_inteligencia.php">Inteligencia empresarial</a><a href="arca38_exportar.php">Exportar solicitudes CSV</a></div></section>
<?php a27_end(); ?>
