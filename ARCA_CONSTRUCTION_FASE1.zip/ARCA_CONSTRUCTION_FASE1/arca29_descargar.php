<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca29_30.php';
$db=a27_boot(['CHRO']);
try {
    $id=arx_int($_GET['id']??null);
    $d=arx_one($db,'SELECT * FROM arca29_documentos WHERE id_documento=?',[$id]);
    if(!$d||!a30_can_read_document($db,$d)){http_response_code(404);exit('Documento no disponible.');}
    $name=(string)$d['archivo_privado'];
    if(!preg_match('/^[a-f0-9]{48}\.bin$/D',$name))throw new RuntimeException('Identificador de archivo no válido.');
    $base=a29_storage();$file=realpath($base.DIRECTORY_SEPARATOR.$name);
    if(!$file||dirname($file)!==realpath($base)||!is_file($file))throw new RuntimeException('Archivo no encontrado en almacén privado.');
    if(!hash_equals((string)$d['sha256'],hash_file('sha256',$file)))throw new RuntimeException('El archivo no superó la verificación de integridad.');
    arx_audit($db,'CHRO','arca29_documentos',$id,'DESCARGA_PRIVADA',null,['origen'=>$d['origen']]);
    if(ob_get_length())ob_end_clean();
    header('Content-Type: application/pdf');header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: attachment; filename="arca-documento-'.$id.'.pdf"');
    header('Content-Length: '.filesize($file));header('Cache-Control: no-store, private');
    header('X-Frame-Options: DENY');
    readfile($file);exit;
}catch(Throwable $e){error_log('[ARCA29 DOWNLOAD] '.$e->getMessage());http_response_code(500);exit('No se pudo descargar el documento.');}
