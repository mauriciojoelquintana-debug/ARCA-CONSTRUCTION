<?php
// Validamos la sesión y la seguridad RBAC para el área administrativa
session_start();
$roles_admin = ['Secretaria / Asistente', 'Secretaria'];

if (!isset($_SESSION['rol_activo']) || !in_array($_SESSION['rol_activo'], $roles_admin)) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Juntas - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 20px; }
        .form-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 400px; margin: 0 auto; border-top: 4px solid #8e44ad; }
        input { width: 90%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        .btn-buscar { background-color: #8e44ad; color: white; border: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; cursor: pointer; font-weight: bold; width: 95%; }
        .btn-buscar:hover { background-color: #732d91; }
        .btn-volver { display: inline-block; margin-top: 15px; color: #34495e; text-decoration: none; font-weight: bold; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <h2>Motor de Búsqueda Directiva</h2>
    <p>Administrativo en turno: <b><?php echo $_SESSION['usuario_activo']; ?></b></p>

    <div class="form-container">
        <form action="resultados_agenda.php" method="POST">
            <label style="font-weight:bold; color:#2c3e50;">Buscar por Asunto / Tema:</label><br>
            <input type="text" name="busqueda" placeholder="Ej. Presupuesto, Obra, Federal..." required>
            <input type="submit" value="Buscar Reuniones" class="btn-buscar">
        </form>
        <br>
        <a href="panel_administrativo.php" class="btn-volver">← Volver al Panel Administrativo</a>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>