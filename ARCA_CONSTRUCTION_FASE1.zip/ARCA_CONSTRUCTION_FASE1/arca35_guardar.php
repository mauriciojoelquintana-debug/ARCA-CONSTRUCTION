<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca34_datos.php';
$db=a27_boot(a35_roles());
a27_post();
try {
    a35_guardar_prueba($db,$_POST);
    a27_alert('Resultado de verificación registrado. La evidencia debe conservarse fuera del acceso público.');
}catch(Throwable $e){
    error_log('[ARCA35 GUARDAR] '.$e->getMessage());
    a27_alert($e instanceof InvalidArgumentException || $e instanceof DomainException ? $e->getMessage() : 'No se pudo registrar el resultado. Comunícate con el área de Sistemas.',true);
}
a27_redirect('arca35_pruebas.php');
