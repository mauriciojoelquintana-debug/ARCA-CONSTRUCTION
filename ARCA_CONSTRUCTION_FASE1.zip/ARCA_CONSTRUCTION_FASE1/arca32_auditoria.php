<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca32_auditoria.php';
$db=a27_boot(a32_roles());
$items=[];$error='';
try {
  $obras=a24_obras_autorizadas($db);
  $items=a32_evaluar($db,$obras);
} catch(Throwable $e) {
  error_log('[ARCA32 AUDIT] '.$e->getMessage());
  http_response_code(500);$error='No fue posible completar la auditoría. Consulta el registro de errores de PHP/Apache.';
}
$tot=a32_resumen($items);
a27_layout('Auditoría integral','Supervisión de integridad, cumplimiento y trazabilidad corporativa.','arca32_auditoria.php');
?>
<link rel="stylesheet" href="assets/css/arca32-33.css?v=1">
<section class="a33-notice"><strong>ESTADO DE AUDITORÍA</strong><p>Los controles muestran hallazgos y acciones de seguimiento. La habilitación operativa requiere validaciones documentadas y una revisión independiente de seguridad.</p></section>
<?php if($error):?><div class="a33-error" role="alert"><?=a27_h($error)?></div><?php else:?>
<div class="a33-actions"><a class="a33-button" href="arca32_auditoria.php">Actualizar controles</a><a class="a33-button outline" href="arca32_exportar.php">Descargar auditoría CSV</a><a href="arca33_preparacion.php">Configuración operativa</a></div>
<div class="a33-stats"><article><span>Correctos</span><strong><?=$tot['OK']?></strong></article><article><span>Por revisar</span><strong><?=$tot['AVISO']?></strong></article><article><span>Críticos detectados</span><strong><?=$tot['CRITICO']?></strong></article><article><span>Controles ejecutados</span><strong><?=count($items)?></strong></article></div>
<section class="a33-panel"><h2>Matriz de hallazgos</h2><p>Los indicadores resumen controles pendientes y completados. La información protegida se consulta sin revelar expedientes personales.</p><div class="a33-scroll"><table><thead><tr><th>Área</th><th>Comprobación</th><th>Resultado</th><th>Evidencia agregada</th><th>Acción recomendada</th></tr></thead><tbody>
<?php foreach($items as $i):?><tr><td><?=a27_h($i['modulo'])?></td><td><strong><?=a27_h($i['control'])?></strong></td><td><span class="a33-tag <?=strtolower($i['estado'])?>"><?=a27_h($i['estado'])?></span></td><td><?=a27_h($i['detalle'])?></td><td><?=a27_h($i['accion'])?></td></tr><?php endforeach;?>
</tbody></table></div></section>
<?php endif; ?>
<section class="a33-panel"><h2>Alcance del seguimiento</h2><p>La revisión automática tiene un alcance delimitado. La autenticación, los permisos históricos, la vigencia laboral y las divisas pendientes requieren comprobación individual y evidencia verificable.</p><p>La configuración operativa reúne los requisitos de infraestructura y continuidad.</p></section>
<?php a27_end(); ?>
