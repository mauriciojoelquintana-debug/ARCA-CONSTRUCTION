<?php
declare(strict_types=1);
require_once __DIR__.'/includes/arca28_rh.php';
$db=a27_boot(['CHRO','COO']);
a27_post();
$accion=(string)($_POST['accion']??'');
$role=arx_role();
$hoy=date('Y-m-d');
$destino=in_array($accion,['verificar_expediente','crear_asignacion'],true)?'arca28_validacion.php':'arca27_equipo_obra.php';
try {
    if(in_array($accion,['verificar_expediente','crear_asignacion','proponer_responsable'],true) && $role!=='CHRO') {
        a27_die('Solo CHRO puede completar esta operación.',403);
    }
    if($accion==='revisar_propuesta' && $role!=='COO') {
        a27_die('Solo COO puede confirmar responsabilidades de obra.',403);
    }
    $db->begin_transaction();
    if($accion==='verificar_expediente') {
        $id=arx_int($_POST['id_empleado']??null);
        $contratoId=arx_int($_POST['id_contrato']??null);
        $puesto=arx_int($_POST['id_puesto']??null);
        $gerencia=arx_int($_POST['id_gerencia']??null);
        $fechaIngreso=arx_date((string)($_POST['fecha_ingreso']??''));
        $ref=arx_text($_POST['referencia_verificacion']??'',120);
        if(strlen($ref)<8 || empty($_POST['evidencia_revisada']))throw new InvalidArgumentException('Confirma la revisión documental e indica una referencia verificable de al menos 8 caracteres.');
        if($fechaIngreso>$hoy)throw new InvalidArgumentException('La fecha de ingreso no puede ser futura.');
        $e=arx_one($db,'SELECT id_empleado,numero_empleado,id_puesto,id_gerencia,tipo_personal,estado_laboral,fecha_ingreso FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$id]);
        if(!$e)throw new InvalidArgumentException('No existe el empleado.');
        if($e['estado_laboral']==='INACTIVO')throw new InvalidArgumentException('La reactivación de personal inactivo requiere revisión administrativa adicional.');
        if(!arx_one($db,'SELECT id_puesto FROM catalogo_puestos_arca WHERE id_puesto=?',[$puesto]) || !arx_one($db,'SELECT id_gerencia FROM gerencias_arca WHERE id_gerencia=?',[$gerencia]))throw new InvalidArgumentException('Puesto o gerencia inexistente.');
        $c=arx_one($db,'SELECT id_contrato,inicio,fin,estado FROM arca_contratos_laborales WHERE id_contrato=? AND id_empleado=? FOR UPDATE',[$contratoId,$id]);
        if(!$c || !in_array($c['estado'],['BORRADOR','VIGENTE'],true))throw new InvalidArgumentException('Selecciona un contrato en borrador o vigente del empleado.');
        if(!a28_fecha_vigente($c['inicio'],$c['fin'],'VIGENTE',$hoy))throw new InvalidArgumentException('Las fechas del contrato no cubren la fecha actual.');
        if($fechaIngreso>$c['inicio'])throw new InvalidArgumentException('La fecha de ingreso debe ser igual o anterior al inicio del contrato.');
        $otro=arx_one($db,"SELECT id_contrato FROM arca_contratos_laborales WHERE id_empleado=? AND id_contrato<>? AND estado='VIGENTE' AND inicio<=? AND (fin IS NULL OR fin>=?) LIMIT 1",[$id,$contratoId,$hoy,$hoy]);
        if($otro)throw new InvalidArgumentException('Ya existe otro contrato vigente del mismo empleado. Revisar antes de validar.');
        arx_exec($db,"UPDATE arca_empleados SET tipo_personal='PROPIO',estado_laboral='ACTIVO',id_puesto=?,id_gerencia=?,fecha_ingreso=? WHERE id_empleado=?",[$puesto,$gerencia,$fechaIngreso,$id]);
        if($c['estado']==='BORRADOR')arx_exec($db,"UPDATE arca_contratos_laborales SET estado='VIGENTE' WHERE id_contrato=?",[$contratoId]);
        arx_audit($db,'CHRO','arca_empleados',$id,'VALIDAR_DOCUMENTOS',[
            'estado'=>$e['estado_laboral'],'tipo'=>$e['tipo_personal'],'puesto'=>$e['id_puesto'],'gerencia'=>$e['id_gerencia']
        ],['estado'=>'ACTIVO','tipo'=>'PROPIO','puesto'=>$puesto,'gerencia'=>$gerencia,'contrato'=>$contratoId,'referencia'=>$ref]);
        a27_alert('Expediente validado. Contrato vigente asociado.');
    } elseif($accion==='crear_asignacion') {
        $id=arx_int($_POST['id_empleado']??null);
        $code=arx_code($_POST['codigo_obra']??'');
        $cargo=arx_text($_POST['cargo_obra']??'',90);
        $frente=trim((string)($_POST['frente']??''));
        if(strlen($frente)>100)throw new InvalidArgumentException('Frente demasiado largo.');
        $inicio=arx_date((string)($_POST['fecha_inicio']??''));
        $fin=trim((string)($_POST['fecha_fin']??''));
        if($fin!=='')arx_date($fin);
        if($inicio>$hoy || ($fin!=='' && $fin<$hoy) || ($fin!=='' && $fin<$inicio))throw new InvalidArgumentException('Solo se registran asignaciones vigentes con fechas coherentes.');
        $e=arx_one($db,'SELECT id_empleado,tipo_personal,estado_laboral,fecha_ingreso FROM arca_empleados WHERE id_empleado=? FOR UPDATE',[$id]);
        if(!$e || $e['estado_laboral']!=='ACTIVO' || $e['tipo_personal']!=='PROPIO')throw new InvalidArgumentException('Se requiere empleado propio, activo y validado.');
        if(!$e['fecha_ingreso'] || $inicio<$e['fecha_ingreso'])throw new InvalidArgumentException('La asignación no puede comenzar antes del ingreso validado.');
        if(!a28_obra_acceso($db,$code,'consultar'))throw new InvalidArgumentException('La obra no existe o falta autorización.');
        $c=a28_contrato_vigente($db,$id,null,true);
        if(!$c || $inicio<$c['inicio'])throw new InvalidArgumentException('No existe contrato vigente que cubra el inicio de la asignación.');
        if($c['fin']!==null && ($fin==='' || $fin>$c['fin']))throw new InvalidArgumentException('Indica fin de asignación igual o anterior a la terminación del contrato.');
        $dup=arx_one($db,"SELECT id_asignacion FROM arca_asignaciones_personal WHERE id_empleado=? AND codigo_obra=? AND fecha_inicio<=COALESCE(?, '9999-12-31') AND COALESCE(fecha_fin,'9999-12-31')>=? LIMIT 1",[$id,$code,$fin?:null,$inicio]);
        if($dup)throw new InvalidArgumentException('Ya existe una asignación superpuesta para el empleado y la obra.');
        arx_exec($db,'INSERT INTO arca_asignaciones_personal(id_empleado,codigo_obra,cargo_obra,frente,fecha_inicio,fecha_fin,creado_por) VALUES(?,?,?,?,?,?,?)',[$id,$code,$cargo,$frente?:null,$inicio,$fin?:null,arx_uid()]);
        $aid=(int)$db->insert_id;
        arx_audit($db,'CHRO','arca_asignaciones_personal',$aid,'ASIGNAR_VALIDADO',null,['empleado'=>$id,'obra'=>$code,'cargo'=>$cargo,'inicio'=>$inicio,'fin'=>$fin?:null]);
        a27_alert('Asignación registrada con validación laboral. Ya puedes proponer su responsabilidad.');
    } elseif($accion==='proponer_responsable') {
        $code=arx_code($_POST['codigo_obra']??'');
        $func=(string)($_POST['funcion']??'');
        $aid=arx_int($_POST['id_asignacion']??null);
        if(!isset(a28_functions()[$func]) || !a28_obra_acceso($db,$code,'consultar'))throw new InvalidArgumentException('Función u obra fuera del ámbito autorizado.');
        // Serializa los cambios por obra; evita propuestas simultáneas contradictorias.
        arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=? FOR UPDATE',[$code]);
        $a=a28_validar_asignacion($db,$aid,$code,$func,true);
        $old=arx_one($db,'SELECT id_asignacion,estado,propuesto_por FROM arca28_propuestas_responsables WHERE codigo_obra=? AND funcion=? FOR UPDATE',[$code,$func]);
        if($old && $old['estado']==='PENDIENTE' && (int)$old['id_asignacion']===$aid)throw new InvalidArgumentException('Ya existe esta misma propuesta pendiente.');
        arx_exec($db,"INSERT INTO arca28_propuestas_responsables(codigo_obra,funcion,id_asignacion,estado,propuesto_por) VALUES(?,?,?,'PENDIENTE',?) ON DUPLICATE KEY UPDATE id_asignacion=VALUES(id_asignacion),estado='PENDIENTE',propuesto_por=VALUES(propuesto_por),propuesto_en=CURRENT_TIMESTAMP,revisado_por=NULL,revisado_en=NULL",[$code,$func,$aid,arx_uid()]);
        arx_audit($db,'CHRO','arca28_propuestas_responsables',$aid,'PROPONER',$old,['obra'=>$code,'funcion'=>$func,'id_asignacion'=>$aid]);
        a27_alert('Propuesta registrada. COO debe confirmar la designación.');
    } elseif($accion==='revisar_propuesta') {
        $code=arx_code($_POST['codigo_obra']??'');
        $func=(string)($_POST['funcion']??'');
        $decision=(string)($_POST['decision']??'');
        if(!isset(a28_functions()[$func]) || !in_array($decision,['APROBAR','RECHAZAR'],true))throw new InvalidArgumentException('Operación no permitida.');
        if(!a28_obra_acceso($db,$code,'operar'))throw new InvalidArgumentException('Falta permiso operativo para esta obra.');
        arx_one($db,'SELECT codigo_obra FROM obras_coo WHERE codigo_obra=? FOR UPDATE',[$code]);
        $p=arx_one($db,'SELECT id_asignacion,estado,propuesto_por FROM arca28_propuestas_responsables WHERE codigo_obra=? AND funcion=? FOR UPDATE',[$code,$func]);
        if(!$p || $p['estado']!=='PENDIENTE')throw new InvalidArgumentException('La propuesta ya fue revisada o no existe.');
        if((int)$p['propuesto_por']===arx_uid())throw new InvalidArgumentException('Quien propone no puede aprobar su propia solicitud.');
        $aid=(int)$p['id_asignacion'];
        if($decision==='APROBAR') {
            a28_validar_asignacion($db,$aid,$code,$func,true);
            $other=arx_one($db,'SELECT funcion FROM arca27_responsables_obra WHERE codigo_obra=? AND id_asignacion=? AND funcion<>? LIMIT 1',[$code,$aid,$func]);
            if($other)throw new InvalidArgumentException('La misma asignación ya cubre otra responsabilidad en esta obra.');
            $old=arx_one($db,'SELECT id_asignacion FROM arca27_responsables_obra WHERE codigo_obra=? AND funcion=? FOR UPDATE',[$code,$func]);
            arx_exec($db,'INSERT INTO arca27_responsables_obra(codigo_obra,funcion,id_asignacion,asignado_por) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE id_asignacion=VALUES(id_asignacion),asignado_por=VALUES(asignado_por),asignado_en=CURRENT_TIMESTAMP',[$code,$func,$aid,arx_uid()]);
            arx_audit($db,'COO','arca27_responsables_obra',$aid,'APROBAR_DESIGNACION',$old,['obra'=>$code,'funcion'=>$func,'asignacion'=>$aid]);
        }
        arx_exec($db,'UPDATE arca28_propuestas_responsables SET estado=?,revisado_por=?,revisado_en=CURRENT_TIMESTAMP WHERE codigo_obra=? AND funcion=?',[$decision==='APROBAR'?'APROBADA':'RECHAZADA',arx_uid(),$code,$func]);
        arx_audit($db,'COO','arca28_propuestas_responsables',$aid,$decision,['estado'=>'PENDIENTE'],['obra'=>$code,'funcion'=>$func,'decision'=>$decision]);
        a27_alert('La propuesta fue '.($decision==='APROBAR'?'aprobada':'rechazada').'.');
    } else throw new InvalidArgumentException('Acción desconocida.');
    $db->commit();
} catch (Throwable $e) {
    try { $db->rollback(); } catch (Throwable $ignored) {}
    error_log('[ARCA28 RH] '.$e->getMessage());
    a27_alert($e instanceof InvalidArgumentException?$e->getMessage():'No se pudo guardar. Consulta el registro de errores.',true);
}
a27_redirect($destino);
