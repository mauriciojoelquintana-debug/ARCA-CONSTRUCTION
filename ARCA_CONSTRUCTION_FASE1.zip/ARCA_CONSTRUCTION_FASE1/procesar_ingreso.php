<?php
require_once __DIR__ . '/includes/seguridad.php';
arca_iniciar_sesion();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ingreso.html?error=metodo'); exit;
}
$numeroEmpleado = trim((string)($_POST['num_empleado'] ?? ''));
$claveIngresada = (string)($_POST['password'] ?? '');
if ($numeroEmpleado === '' || $claveIngresada === '' || strlen($numeroEmpleado) > 30 || strlen($claveIngresada) > 1024) {
    header('Location: ingreso.html?error=credenciales'); exit;
}
// Barrera básica por sesión para el entorno local; en producción usar límite persistente.
$ahora = time();
if (isset($_SESSION['login_bloqueado_hasta']) && $_SESSION['login_bloqueado_hasta'] > $ahora) {
    header('Location: ingreso.html?error=bloqueado'); exit;
}
if (($_SESSION['login_bloqueado_hasta'] ?? 0) <= $ahora) unset($_SESSION['login_bloqueado_hasta']);
require __DIR__ . '/conexion.php';
try {
    $stmt = $conectar->prepare('SELECT id_usuario, numero_empleado, nombre_completo, password, cargo, nivel_jerarquico, direccion_area, obra_asignada FROM usuarios WHERE numero_empleado = ? LIMIT 1');
    $stmt->bind_param('s', $numeroEmpleado);
    $stmt->execute();
    $registro = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    // Se exige hash. Antes del primer acceso ejecutar scripts/migrar_passwords.php desde la terminal.
    $es_valido = $registro && password_verify($claveIngresada, (string)$registro['password']);
    if (!$es_valido) {
        $_SESSION['login_intentos'] = ($_SESSION['login_intentos'] ?? 0) + 1;
        if ($_SESSION['login_intentos'] >= 5) {
            $_SESSION['login_bloqueado_hasta'] = $ahora + 300;
            header('Location: ingreso.html?error=bloqueado'); exit;
        }
        header('Location: ingreso.html?error=credenciales'); exit;
    }
    session_regenerate_id(true);
    unset($_SESSION['login_intentos'], $_SESSION['login_bloqueado_hasta']);
    if (password_needs_rehash((string)$registro['password'], PASSWORD_DEFAULT)) {
        $hash = password_hash($claveIngresada, PASSWORD_DEFAULT);
        $up = $conectar->prepare('UPDATE usuarios SET password=? WHERE id_usuario=?');
        $up->bind_param('si', $hash, $registro['id_usuario']);
        $up->execute(); $up->close();
    }
    $_SESSION['id_usuario'] = (int)$registro['id_usuario'];
    $_SESSION['usuario_activo'] = $registro['numero_empleado'];
    $_SESSION['nombre_usuario'] = $registro['nombre_completo'];
    $_SESSION['rol_activo'] = trim((string)$registro['cargo']);
    $_SESSION['nivel_jerarquico'] = $registro['nivel_jerarquico'];
    $_SESSION['direccion_area'] = $registro['direccion_area'];
    $_SESSION['obra_asignada'] = $registro['obra_asignada'];
    header('Location: validar_roles.php'); exit;
} catch (Throwable $e) {
    error_log('ARCA acceso: ' . $e->getMessage());
    header('Location: ingreso.html?error=sistema'); exit;
}