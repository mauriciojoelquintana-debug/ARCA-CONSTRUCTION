<?php
require_once __DIR__.'/includes/seguridad.php';
arca_requerir_roles(['CEO','Director General','CHRO','Director de RR.HH.','Departamento RRHH']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Alta de Personal - ARCA CONSTRUCTION</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f7; text-align: center; padding: 20px; }
        .formulario-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 450px; margin: 0 auto; border-top: 4px solid #16a085; }
        input, select { width: 90%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; }
        .btn-enviar { background-color: #16a085; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 5px; cursor: pointer; font-weight: bold; }
        .btn-enviar:hover { background-color: #117a65; }
        .btn-volver { display: inline-block; margin-top: 15px; color: #34495e; text-decoration: none; }
        .nota-seguridad { font-size: 12px; color: #7f8c8d; margin-bottom: 20px; }
    </style>
<!-- ARCA_FASE21_CSS --><link rel="stylesheet" href="assets/css/arca21-legacy.css?v=21"></head>
<body class="arca21-legacy">

    <h2>Departamento de Recursos Humanos</h2>
    <h3>Reclutamiento y Registro de Personal</h3>

    <div class="formulario-container">
        <p class="nota-seguridad">Las contraseñas se almacenan mediante hash. Los niveles y asignaciones requieren validación administrativa.</p>

        <!-- Formulario seguro usando el método POST -->
        <form action="procesar_alta_empleado.php" method="post">
            
            <label><b>Nombre Completo del Empleado:</b></label><br>
            <input type="text" name="nombre_empleado" required placeholder="Ej. Ana Ramírez">

            <!-- ID Asignado Automáticamente o Manualmente -->
            <label><b>ID (Número de Empleado):</b></label><br>
            <input type="text" name="numero_empleado" required placeholder="Ej. EMP-005">

            <!-- Catálogo Oficial de ARCA -->
            <label><b>Cargo / Nivel de Acceso (RBAC):</b></label><br>
            <select name="rol_asignado" required>
              <option value="" disabled selected>Seleccione el puesto</option>
              <option value="Arquitecto">Arquitecto</option>
              <option value="Ingeniero Civil">Ingeniero Civil</option>
              <option value="Residente de Obra">Residente de Obra</option>
              <option value="Supervisor de Obra">Supervisor de Obra</option>
              <option value="Secretaria">Secretaria</option>
              <option value="Contador">Contador</option>
              <option value="Almacenista">Almacenista</option>
              <option value="Abogado">Abogado</option>
              <option value="Seguridad">Seguridad</option>
              <option value="Departamento RRHH">Departamento RRHH</option>
            </select>
            
            <input type="submit" value="Registrar Empleado en Sistema" class="btn-enviar">
        </form>
        
        <a href="ingreso.html" class="btn-volver">← Volver al Acceso Principal</a>
    </div>

<!-- ARCA22_PORTAL_INYECTADO --><?php require_once __DIR__.'/includes/arca22_accesos.php'; a22_barra_flotante(); ?></body>
</html>