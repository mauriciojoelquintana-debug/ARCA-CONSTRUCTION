<?php
declare(strict_types=1);require_once __DIR__.'/includes/arca_fases_8_13.php';$db=arx_boot(['CHRO']);arx_check_post();
try{
 $codigo=strtoupper(arx_text($_POST['codigo']??'',25)); if(!preg_match('/^[A-Z0-9-]{3,25}$/D',$codigo))throw new InvalidArgumentException('Código inválido.');
 $nombre=arx_text($_POST['nombre']??'',120);$gerencia=arx_int($_POST['id_gerencia']??null);$desc=trim((string)($_POST['descripcion']??''));if(strlen($desc)>250)throw new InvalidArgumentException('Descripción demasiado larga.');
 if(!arx_one($db,'SELECT id_gerencia FROM gerencias_arca WHERE id_gerencia=?',[$gerencia]))throw new InvalidArgumentException('Gerencia no registrada.');
 $db->begin_transaction();arx_exec($db,'INSERT INTO arca_departamentos_gerencias(codigo,nombre,id_gerencia,descripcion) VALUES(?,?,?,?)',[$codigo,$nombre,$gerencia,$desc?:null]);arx_audit($db,'ESTRUCTURA','arca_departamentos_gerencias',(int)$db->insert_id,'ALTA',null,['codigo'=>$codigo,'gerencia'=>$gerencia]);$db->commit();arx_flash('Departamento registrado.');
}catch(Throwable $e){try{$db->rollback();}catch(Throwable $unused){}error_log($e->getMessage());arx_flash($e instanceof InvalidArgumentException?$e->getMessage():'Error al guardar el departamento.',true);}arx_redirect('arca_estructura.php');
