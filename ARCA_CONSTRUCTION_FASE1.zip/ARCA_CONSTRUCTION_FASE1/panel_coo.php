<?php
// ARCA CONSTRUCTION · Fase 2, dirección COO.
$arca_area = 'COO';
require __DIR__ . '/includes/panel_directivo.php';
