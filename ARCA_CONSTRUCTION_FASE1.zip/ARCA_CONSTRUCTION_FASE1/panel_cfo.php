<?php
// ARCA CONSTRUCTION · Fase 2, dirección CFO.
$arca_area = 'CFO';
require __DIR__ . '/includes/panel_directivo.php';
