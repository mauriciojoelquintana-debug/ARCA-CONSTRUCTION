<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/arca_fases_8_13.php';
$db = arx_boot(['CEO', 'Director General', 'COO']);
$edit = arx_role() === 'COO';

// Los contadores son de la BD completa, no de las listas con LIMIT.
$totales = [
    'proveedores' => (int)(arx_one($db, 'SELECT COUNT(*) n FROM arca_proveedores_compras')['n'] ?? 0),
    'solicitudes' => (int)(arx_one($db, 'SELECT COUNT(*) n FROM arca_solicitudes_compra')['n'] ?? 0),
    'cotizaciones' => (int)(arx_one($db, 'SELECT COUNT(*) n FROM arca_cotizaciones_compra')['n'] ?? 0),
    'ordenes' => (int)(arx_one($db, 'SELECT COUNT(*) n FROM arca_ordenes_compra')['n'] ?? 0),
];
$prov = arx_rows($db, 'SELECT id_proveedor,razon_social,identificador,correo,activo FROM arca_proveedores_compras ORDER BY id_proveedor DESC LIMIT 100');
$sol = arx_rows($db, 'SELECT id_solicitud,codigo_obra,descripcion,cantidad,unidad,precio_unitario,moneda,estado,solicitado_por FROM arca_solicitudes_compra ORDER BY id_solicitud DESC LIMIT 150');
$quotes = arx_rows($db, 'SELECT c.id_cotizacion,c.id_solicitud,c.id_proveedor,c.precio_unitario,c.moneda,c.vigencia,p.razon_social FROM arca_cotizaciones_compra c JOIN arca_proveedores_compras p ON p.id_proveedor=c.id_proveedor ORDER BY c.id_cotizacion DESC LIMIT 120');
$orders = arx_rows($db, 'SELECT o.id_orden,o.id_solicitud,o.codigo_obra,o.total,o.moneda,o.estado,p.razon_social FROM arca_ordenes_compra o JOIN arca_cotizaciones_compra c ON c.id_cotizacion=o.id_cotizacion JOIN arca_proveedores_compras p ON p.id_proveedor=c.id_proveedor ORDER BY o.id_orden DESC LIMIT 150');
// Los combos de captura no dependen de las listas limitadas para visualización.
$proveedoresActivos = $edit ? arx_rows($db, 'SELECT id_proveedor,razon_social FROM arca_proveedores_compras WHERE activo=1 ORDER BY razon_social LIMIT 200') : [];
$solicitudesAprobadas = $edit ? arx_rows($db, "SELECT id_solicitud,codigo_obra FROM arca_solicitudes_compra WHERE estado='APROBADA' ORDER BY id_solicitud DESC LIMIT 200") : [];
$cotizacionesVigentes = $edit ? arx_rows($db, "SELECT c.id_cotizacion,c.id_solicitud,p.razon_social FROM arca_cotizaciones_compra c JOIN arca_proveedores_compras p ON p.id_proveedor=c.id_proveedor JOIN arca_solicitudes_compra s ON s.id_solicitud=c.id_solicitud WHERE c.vigencia>=CURRENT_DATE() AND p.activo=1 AND s.estado='APROBADA' ORDER BY c.id_cotizacion DESC LIMIT 200") : [];

// Un catálogo vacío después de importar las tablas NO es un fallo de la conexión.
$sinDatos = array_sum($totales) === 0;
af8_layout('Compras y proveedores', 'Solicitudes aprobadas, cotizaciones, órdenes de compra y recepción documental.', 'arca_compras.php');
?>
<section class="arx-grid4">
 <div class="arx-kpi"><span>Proveedores registrados</span><strong><?= $totales['proveedores'] ?></strong></div>
 <div class="arx-kpi"><span>Solicitudes de compra</span><strong><?= $totales['solicitudes'] ?></strong></div>
 <div class="arx-kpi"><span>Cotizaciones</span><strong><?= $totales['cotizaciones'] ?></strong></div>
 <div class="arx-kpi"><span>Órdenes de compra</span><strong><?= $totales['ordenes'] ?></strong></div>
</section>
<?php if ($sinDatos): ?>
<div class="arx-note"><strong>Catálogos pendientes de registro.</strong> Aún no hay registros en los catálogos de Compras. Los subcontratistas y los proveedores se gestionan por separado. Registra los proveedores en Compras y crea las solicitudes desde Operaciones.</div>
<?php endif; ?>
<div class="arx-note">
 <strong>Cómo se alimenta Compras:</strong> 1) COO registra un proveedor; 2) se crea una solicitud en Operaciones; 3) otro responsable autorizado la aprueba; 4) se registra la cotización; 5) se emite la orden y se confirma la recepción documental.
 <div class="af8-links">
 <?php if ($edit): ?>
  <a class="arx-btn primary" href="coo_control.php#compras">Ir a solicitudes de Operaciones</a>
 <?php else: ?>
  <span class="arx-tag">Sesión de <?= arx_h(arx_role()) ?>: consulta solamente. Las altas de Compras las realiza el COO.</span>
 <?php endif; ?>
 </div>
</div>
<section class="arx-card" id="proveedores">
 <h2>Proveedores</h2><p class="arx-sub">Catálogo de proveedores verificados; no equivale al catálogo de subcontratistas.</p>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Código</th><th>Razón social</th><th>Correo</th><th>Estado</th></tr></thead><tbody>
 <?php foreach ($prov as $p): ?><tr><td><?= arx_h($p['identificador']) ?></td><td><?= arx_h($p['razon_social']) ?></td><td><?= arx_h($p['correo']) ?></td><td><?= ((int)$p['activo']) ? 'Activo' : 'Inactivo' ?></td></tr><?php endforeach; ?>
 <?php if (!$prov): ?><tr><td colspan="4">Aún no hay proveedores. Inicia sesión como COO para registrar el primero.</td></tr><?php endif; ?>
 </tbody></table></div>
 <?php if ($edit): ?><div class="arx-divider"></div><h3>Alta de proveedor</h3>
 <form class="arx-form" method="post" action="arca_compras_guardar.php">
  <input type="hidden" name="csrf_token" value="<?= arx_h(arx_token()) ?>"><input type="hidden" name="accion" value="proveedor">
  <label>Código / identificador<input name="identificador" maxlength="30" pattern="[A-Z0-9-]{3,30}" required></label>
  <label>Razón social<input name="razon_social" maxlength="160" required></label>
  <label>Correo<input type="email" name="correo" maxlength="160"></label>
  <label>Teléfono<input name="telefono" maxlength="35"></label>
  <button class="arx-btn primary">Registrar proveedor</button>
 </form><?php endif; ?>
</section>
<section class="arx-card" id="solicitudes">
 <h2>Solicitudes de compra</h2><p class="arx-sub">Las solicitudes se crean y aprueban en el módulo COO, con autorización por obra.</p>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Solicitud</th><th>Obra / concepto</th><th>Valor estimado</th><th>Estado</th></tr></thead><tbody>
 <?php foreach ($sol as $s): ?><tr><td>#<?= (int)$s['id_solicitud'] ?></td><td><?= arx_h($s['codigo_obra'] . ' · ' . $s['descripcion']) ?></td><td><?= arx_h(af8_money((float)$s['cantidad']*(float)$s['precio_unitario'], $s['moneda'])) ?></td><td><?= arx_h($s['estado']) ?></td></tr><?php endforeach; ?>
 <?php if (!$sol): ?><tr><td colspan="4">No hay solicitudes. El COO puede crearlas desde «Operaciones por obra».</td></tr><?php endif; ?>
 </tbody></table></div>
 <?php if ($edit): ?><div class="arx-divider"></div><h3>Registrar cotización</h3>
 <?php if (!$solicitudesAprobadas || !$proveedoresActivos): ?><p class="arx-sub">Para cotizar se necesita al menos una solicitud <strong>APROBADA</strong> y un proveedor activo. No podrás continuar hasta tener ambos.</p><?php else: ?>
 <form class="arx-form" method="post" action="arca_compras_guardar.php"><input type="hidden" name="csrf_token" value="<?= arx_h(arx_token()) ?>"><input type="hidden" name="accion" value="cotizacion">
  <label>Solicitud aprobada<select name="id_solicitud" required><?php foreach ($solicitudesAprobadas as $s): ?><option value="<?= (int)$s['id_solicitud'] ?>">#<?= (int)$s['id_solicitud'] ?> · <?= arx_h($s['codigo_obra']) ?></option><?php endforeach; ?></select></label>
  <label>Proveedor activo<select name="id_proveedor" required><?php foreach ($proveedoresActivos as $p): ?><option value="<?= (int)$p['id_proveedor'] ?>"><?= arx_h($p['razon_social']) ?></option><?php endforeach; ?></select></label>
  <label>Precio unitario<input type="number" name="precio" step="0.01" min="0" required></label>
  <label>Divisa <?= arx_select('moneda', ['USD'=>'USD','MXN'=>'MXN'], 'USD') ?></label>
  <label>Vigente hasta<input type="date" name="vigencia" min="<?= date('Y-m-d') ?>" required></label>
  <label class="wide">Notas<input name="notas" maxlength="250"></label><button class="arx-btn primary">Guardar cotización</button>
 </form><?php endif; ?><?php endif; ?>
</section>
<section class="arx-card" id="cotizaciones">
 <h2>Cotizaciones recibidas</h2>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>ID</th><th>Solicitud</th><th>Proveedor</th><th>Precio unitario</th><th>Vigencia</th></tr></thead><tbody>
 <?php foreach ($quotes as $q): ?><tr><td>#<?= (int)$q['id_cotizacion'] ?></td><td>#<?= (int)$q['id_solicitud'] ?></td><td><?= arx_h($q['razon_social']) ?></td><td><?= arx_h(af8_money($q['precio_unitario'], $q['moneda'])) ?></td><td><?= arx_h($q['vigencia']) ?></td></tr><?php endforeach; ?>
 <?php if (!$quotes): ?><tr><td colspan="5">Aún no hay cotizaciones vinculadas a solicitudes aprobadas.</td></tr><?php endif; ?>
 </tbody></table></div>
 <?php if ($edit): ?><div class="arx-divider"></div><h3>Emitir orden de compra</h3>
 <?php if (!$cotizacionesVigentes): ?><p class="arx-sub">No hay cotizaciones vigentes de solicitudes aprobadas.</p><?php else: ?>
 <form class="arx-form" action="arca_compras_guardar.php" method="post"><input type="hidden" name="csrf_token" value="<?= arx_h(arx_token()) ?>"><input type="hidden" name="accion" value="orden">
  <label>Cotización vigente<select name="id_cotizacion" required><?php foreach ($cotizacionesVigentes as $q): ?><option value="<?= (int)$q['id_cotizacion'] ?>">#<?= (int)$q['id_cotizacion'] ?> · Solicitud #<?= (int)$q['id_solicitud'] ?> · <?= arx_h($q['razon_social']) ?></option><?php endforeach; ?></select></label>
  <button class="arx-btn primary">Emitir orden</button>
 </form><?php endif; ?><?php endif; ?>
</section>
<section class="arx-card" id="ordenes"><h2>Órdenes de compra</h2>
 <div class="arx-table-wrap"><table class="arx-table"><thead><tr><th>Folio</th><th>Obra</th><th>Proveedor</th><th>Total</th><th>Estado / acción</th></tr></thead><tbody>
 <?php foreach ($orders as $o): ?><tr><td>#<?= (int)$o['id_orden'] ?></td><td><?= arx_h($o['codigo_obra']) ?></td><td><?= arx_h($o['razon_social']) ?></td><td><?= arx_h(af8_money($o['total'], $o['moneda'])) ?></td><td><?= arx_h($o['estado']) ?><?php if ($edit && $o['estado'] === 'EMITIDA'): ?><form method="post" action="arca_compras_guardar.php" class="arx-inline"><input type="hidden" name="csrf_token" value="<?= arx_h(arx_token()) ?>"><input type="hidden" name="accion" value="recibir"><input type="hidden" name="id_orden" value="<?= (int)$o['id_orden'] ?>"><button class="arx-btn">Confirmar recepción documental</button></form><?php endif; ?></td></tr><?php endforeach; ?>
 <?php if (!$orders): ?><tr><td colspan="5">Sin órdenes emitidas. Se generan desde cotizaciones vigentes.</td></tr><?php endif; ?>
 </tbody></table></div>
 <p class="arx-sub">Confirmar recepción documental no modifica existencias. El ingreso físico se registra en COO, preservando el historial de almacén.</p>
</section>
<?php arx_layout_end(); ?>
