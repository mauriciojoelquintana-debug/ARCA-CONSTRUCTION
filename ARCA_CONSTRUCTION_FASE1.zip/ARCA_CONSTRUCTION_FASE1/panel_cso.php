<?php
// ARCA CONSTRUCTION · Fase 2, dirección CSO.
$arca_area = 'CSO';
require __DIR__ . '/includes/panel_directivo.php';
